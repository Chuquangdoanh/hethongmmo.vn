--
-- PostgreSQL database dump
--

\restrict mViOf6PhMW6hzkIt6GdG01fvt483JKgvprsXsTkBxmj3qc7PyNf8uf6ypsC0yz8

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY "public"."user_sub_categories" DROP CONSTRAINT IF EXISTS "user_sub_categories_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."user_sub_categories" DROP CONSTRAINT IF EXISTS "user_sub_categories_sub_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."transactions" DROP CONSTRAINT IF EXISTS "transactions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."transactions" DROP CONSTRAINT IF EXISTS "transactions_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."testimonials" DROP CONSTRAINT IF EXISTS "testimonials_service_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."testimonials" DROP CONSTRAINT IF EXISTS "testimonials_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."staff_permissions" DROP CONSTRAINT IF EXISTS "staff_permissions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."site_content" DROP CONSTRAINT IF EXISTS "site_content_updated_by_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_withdrawals" DROP CONSTRAINT IF EXISTS "seller_withdrawals_seller_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_sub_categories" DROP CONSTRAINT IF EXISTS "seller_sub_categories_category_name_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_requests" DROP CONSTRAINT IF EXISTS "seller_requests_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_products" DROP CONSTRAINT IF EXISTS "seller_products_sub_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_products" DROP CONSTRAINT IF EXISTS "seller_products_seller_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_product_stock" DROP CONSTRAINT IF EXISTS "seller_product_stock_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_tut_trick_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_service_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_seller_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_mmo_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."notifications" DROP CONSTRAINT IF EXISTS "notifications_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."mmo_product_items" DROP CONSTRAINT IF EXISTS "mmo_product_items_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."login_attempts" DROP CONSTRAINT IF EXISTS "login_attempts_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_support_items" DROP CONSTRAINT IF EXISTS "course_support_items_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faqs" DROP CONSTRAINT IF EXISTS "course_faqs_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faqs" DROP CONSTRAINT IF EXISTS "course_faqs_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faq_categories" DROP CONSTRAINT IF EXISTS "course_faq_categories_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."complaints" DROP CONSTRAINT IF EXISTS "complaints_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_rooms" DROP CONSTRAINT IF EXISTS "chat_rooms_complaint_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_participants" DROP CONSTRAINT IF EXISTS "chat_participants_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_participants" DROP CONSTRAINT IF EXISTS "chat_participants_room_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_messages" DROP CONSTRAINT IF EXISTS "chat_messages_sender_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_messages" DROP CONSTRAINT IF EXISTS "chat_messages_room_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."bank_change_requests" DROP CONSTRAINT IF EXISTS "bank_change_requests_seller_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."audit_logs" DROP CONSTRAINT IF EXISTS "audit_logs_actor_id_fkey";
DROP INDEX IF EXISTS "public"."users_uid_prefix_idx";
DROP INDEX IF EXISTS "public"."users_status_idx";
DROP INDEX IF EXISTS "public"."users_seller_status_idx";
DROP INDEX IF EXISTS "public"."users_role_idx";
DROP INDEX IF EXISTS "public"."users_email_key";
DROP INDEX IF EXISTS "public"."users_email_idx";
DROP INDEX IF EXISTS "public"."unmatched_transfers_status_created_at_idx";
DROP INDEX IF EXISTS "public"."unmatched_transfers_reference_code_key";
DROP INDEX IF EXISTS "public"."tut_tricks_slug_key";
DROP INDEX IF EXISTS "public"."tut_tricks_slug_idx";
DROP INDEX IF EXISTS "public"."tut_tricks_platform_idx";
DROP INDEX IF EXISTS "public"."tut_tricks_is_active_is_featured_idx";
DROP INDEX IF EXISTS "public"."tut_trick_categories_name_key";
DROP INDEX IF EXISTS "public"."tut_trick_categories_name_idx";
DROP INDEX IF EXISTS "public"."transactions_user_id_created_at_idx";
DROP INDEX IF EXISTS "public"."transactions_type_idx";
DROP INDEX IF EXISTS "public"."transactions_reference_code_key";
DROP INDEX IF EXISTS "public"."transactions_reference_code_idx";
DROP INDEX IF EXISTS "public"."ticker_texts_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."ticker_notifications_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."testimonials_type_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."testimonials_service_id_is_active_idx";
DROP INDEX IF EXISTS "public"."testimonials_course_id_is_active_idx";
DROP INDEX IF EXISTS "public"."staff_permissions_user_id_permission_key";
DROP INDEX IF EXISTS "public"."staff_permissions_user_id_idx";
DROP INDEX IF EXISTS "public"."site_content_key_key";
DROP INDEX IF EXISTS "public"."sessions_user_id_idx";
DROP INDEX IF EXISTS "public"."sessions_session_token_key";
DROP INDEX IF EXISTS "public"."sessions_session_token_idx";
DROP INDEX IF EXISTS "public"."sessions_expires_at_idx";
DROP INDEX IF EXISTS "public"."services_slug_key";
DROP INDEX IF EXISTS "public"."services_slug_idx";
DROP INDEX IF EXISTS "public"."services_platform_idx";
DROP INDEX IF EXISTS "public"."services_is_active_is_featured_idx";
DROP INDEX IF EXISTS "public"."services_category_idx";
DROP INDEX IF EXISTS "public"."service_categories_name_key";
DROP INDEX IF EXISTS "public"."service_categories_name_idx";
DROP INDEX IF EXISTS "public"."seller_withdrawals_status_created_at_idx";
DROP INDEX IF EXISTS "public"."seller_withdrawals_seller_id_status_idx";
DROP INDEX IF EXISTS "public"."seller_tier_definitions_key_key";
DROP INDEX IF EXISTS "public"."seller_tier_definitions_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."seller_sub_categories_category_name_name_key";
DROP INDEX IF EXISTS "public"."seller_sub_categories_category_name_is_active_idx";
DROP INDEX IF EXISTS "public"."seller_requests_user_id_key";
DROP INDEX IF EXISTS "public"."seller_requests_status_idx";
DROP INDEX IF EXISTS "public"."seller_products_sub_category_id_idx";
DROP INDEX IF EXISTS "public"."seller_products_seller_id_idx";
DROP INDEX IF EXISTS "public"."seller_products_is_active_is_hidden_is_restricted_idx";
DROP INDEX IF EXISTS "public"."seller_product_stock_product_id_status_idx";
DROP INDEX IF EXISTS "public"."reviews_user_id_idx";
DROP INDEX IF EXISTS "public"."reviews_product_type_product_id_idx";
DROP INDEX IF EXISTS "public"."resource_categories_name_key";
DROP INDEX IF EXISTS "public"."resource_categories_name_idx";
DROP INDEX IF EXISTS "public"."refresh_tokens_user_id_idx";
DROP INDEX IF EXISTS "public"."refresh_tokens_token_hash_key";
DROP INDEX IF EXISTS "public"."refresh_tokens_family_idx";
DROP INDEX IF EXISTS "public"."public_page_configs_page_key_key";
DROP INDEX IF EXISTS "public"."pending_registrations_email_key";
DROP INDEX IF EXISTS "public"."page_permissions_role_page_key_key";
DROP INDEX IF EXISTS "public"."page_permissions_role_idx";
DROP INDEX IF EXISTS "public"."otp_codes_expires_at_idx";
DROP INDEX IF EXISTS "public"."otp_codes_email_purpose_idx";
DROP INDEX IF EXISTS "public"."orders_user_id_created_at_idx";
DROP INDEX IF EXISTS "public"."orders_status_idx";
DROP INDEX IF EXISTS "public"."orders_seller_id_idx";
DROP INDEX IF EXISTS "public"."orders_order_type_idx";
DROP INDEX IF EXISTS "public"."orders_order_code_key";
DROP INDEX IF EXISTS "public"."orders_order_code_idx";
DROP INDEX IF EXISTS "public"."orders_idempotency_key_key";
DROP INDEX IF EXISTS "public"."notifications_user_id_is_read_created_at_idx";
DROP INDEX IF EXISTS "public"."mmo_products_slug_key";
DROP INDEX IF EXISTS "public"."mmo_products_slug_idx";
DROP INDEX IF EXISTS "public"."mmo_products_is_active_idx";
DROP INDEX IF EXISTS "public"."mmo_products_category_idx";
DROP INDEX IF EXISTS "public"."mmo_product_items_product_id_status_idx";
DROP INDEX IF EXISTS "public"."mmo_product_items_order_id_idx";
DROP INDEX IF EXISTS "public"."login_attempts_ip_address_created_at_idx";
DROP INDEX IF EXISTS "public"."login_attempts_email_created_at_idx";
DROP INDEX IF EXISTS "public"."fanpage_registrations_status_idx";
DROP INDEX IF EXISTS "public"."fanpage_registrations_created_at_idx";
DROP INDEX IF EXISTS "public"."courses_slug_key";
DROP INDEX IF EXISTS "public"."courses_slug_idx";
DROP INDEX IF EXISTS "public"."courses_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."courses_category_idx";
DROP INDEX IF EXISTS "public"."course_support_items_course_id_display_order_idx";
DROP INDEX IF EXISTS "public"."course_faqs_course_id_display_order_idx";
DROP INDEX IF EXISTS "public"."course_faq_categories_course_id_display_order_idx";
DROP INDEX IF EXISTS "public"."course_categories_name_key";
DROP INDEX IF EXISTS "public"."course_categories_display_order_idx";
DROP INDEX IF EXISTS "public"."complaints_user_id_idx";
DROP INDEX IF EXISTS "public"."complaints_status_idx";
DROP INDEX IF EXISTS "public"."chat_rooms_complaint_id_key";
DROP INDEX IF EXISTS "public"."chat_participants_user_id_idx";
DROP INDEX IF EXISTS "public"."chat_participants_room_id_user_id_key";
DROP INDEX IF EXISTS "public"."chat_messages_room_id_created_at_idx";
DROP INDEX IF EXISTS "public"."bank_change_requests_status_created_at_idx";
DROP INDEX IF EXISTS "public"."bank_change_requests_seller_id_status_idx";
DROP INDEX IF EXISTS "public"."audit_logs_target_type_target_id_idx";
DROP INDEX IF EXISTS "public"."audit_logs_actor_id_created_at_idx";
DROP INDEX IF EXISTS "public"."audit_logs_action_idx";
DROP INDEX IF EXISTS "public"."ads_registrations_status_idx";
DROP INDEX IF EXISTS "public"."ads_registrations_created_at_idx";
ALTER TABLE IF EXISTS ONLY "public"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "public"."user_sub_categories" DROP CONSTRAINT IF EXISTS "user_sub_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."unmatched_transfers" DROP CONSTRAINT IF EXISTS "unmatched_transfers_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tut_tricks" DROP CONSTRAINT IF EXISTS "tut_tricks_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tut_trick_categories" DROP CONSTRAINT IF EXISTS "tut_trick_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."transactions" DROP CONSTRAINT IF EXISTS "transactions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ticker_texts" DROP CONSTRAINT IF EXISTS "ticker_texts_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ticker_notifications" DROP CONSTRAINT IF EXISTS "ticker_notifications_pkey";
ALTER TABLE IF EXISTS ONLY "public"."testimonials" DROP CONSTRAINT IF EXISTS "testimonials_pkey";
ALTER TABLE IF EXISTS ONLY "public"."system_config" DROP CONSTRAINT IF EXISTS "system_config_pkey";
ALTER TABLE IF EXISTS ONLY "public"."staff_permissions" DROP CONSTRAINT IF EXISTS "staff_permissions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."site_content" DROP CONSTRAINT IF EXISTS "site_content_pkey";
ALTER TABLE IF EXISTS ONLY "public"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."services" DROP CONSTRAINT IF EXISTS "services_pkey";
ALTER TABLE IF EXISTS ONLY "public"."service_categories" DROP CONSTRAINT IF EXISTS "service_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_withdrawals" DROP CONSTRAINT IF EXISTS "seller_withdrawals_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_tier_definitions" DROP CONSTRAINT IF EXISTS "seller_tier_definitions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_sub_categories" DROP CONSTRAINT IF EXISTS "seller_sub_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_requests" DROP CONSTRAINT IF EXISTS "seller_requests_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_products" DROP CONSTRAINT IF EXISTS "seller_products_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_product_stock" DROP CONSTRAINT IF EXISTS "seller_product_stock_pkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_pkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_order_id_key";
ALTER TABLE IF EXISTS ONLY "public"."resource_categories" DROP CONSTRAINT IF EXISTS "resource_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "public"."public_page_configs" DROP CONSTRAINT IF EXISTS "public_page_configs_pkey";
ALTER TABLE IF EXISTS ONLY "public"."pending_registrations" DROP CONSTRAINT IF EXISTS "pending_registrations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."page_permissions" DROP CONSTRAINT IF EXISTS "page_permissions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."otp_codes" DROP CONSTRAINT IF EXISTS "otp_codes_pkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_pkey";
ALTER TABLE IF EXISTS ONLY "public"."notifications" DROP CONSTRAINT IF EXISTS "notifications_pkey";
ALTER TABLE IF EXISTS ONLY "public"."mmo_products" DROP CONSTRAINT IF EXISTS "mmo_products_pkey";
ALTER TABLE IF EXISTS ONLY "public"."mmo_product_items" DROP CONSTRAINT IF EXISTS "mmo_product_items_pkey";
ALTER TABLE IF EXISTS ONLY "public"."login_attempts" DROP CONSTRAINT IF EXISTS "login_attempts_pkey";
ALTER TABLE IF EXISTS ONLY "public"."fanpage_registrations" DROP CONSTRAINT IF EXISTS "fanpage_registrations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."courses" DROP CONSTRAINT IF EXISTS "courses_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_support_items" DROP CONSTRAINT IF EXISTS "course_support_items_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faqs" DROP CONSTRAINT IF EXISTS "course_faqs_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faq_categories" DROP CONSTRAINT IF EXISTS "course_faq_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_categories" DROP CONSTRAINT IF EXISTS "course_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."complaints" DROP CONSTRAINT IF EXISTS "complaints_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_rooms" DROP CONSTRAINT IF EXISTS "chat_rooms_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_participants" DROP CONSTRAINT IF EXISTS "chat_participants_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_messages" DROP CONSTRAINT IF EXISTS "chat_messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."bank_change_requests" DROP CONSTRAINT IF EXISTS "bank_change_requests_pkey";
ALTER TABLE IF EXISTS ONLY "public"."audit_logs" DROP CONSTRAINT IF EXISTS "audit_logs_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ads_registrations" DROP CONSTRAINT IF EXISTS "ads_registrations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."_prisma_migrations" DROP CONSTRAINT IF EXISTS "_prisma_migrations_pkey";
DROP TABLE IF EXISTS "public"."users";
DROP TABLE IF EXISTS "public"."user_sub_categories";
DROP TABLE IF EXISTS "public"."unmatched_transfers";
DROP TABLE IF EXISTS "public"."tut_tricks";
DROP TABLE IF EXISTS "public"."tut_trick_categories";
DROP TABLE IF EXISTS "public"."transactions";
DROP TABLE IF EXISTS "public"."ticker_texts";
DROP TABLE IF EXISTS "public"."ticker_notifications";
DROP TABLE IF EXISTS "public"."testimonials";
DROP TABLE IF EXISTS "public"."system_config";
DROP TABLE IF EXISTS "public"."staff_permissions";
DROP TABLE IF EXISTS "public"."site_content";
DROP TABLE IF EXISTS "public"."sessions";
DROP TABLE IF EXISTS "public"."services";
DROP TABLE IF EXISTS "public"."service_categories";
DROP TABLE IF EXISTS "public"."seller_withdrawals";
DROP TABLE IF EXISTS "public"."seller_tier_definitions";
DROP TABLE IF EXISTS "public"."seller_sub_categories";
DROP TABLE IF EXISTS "public"."seller_requests";
DROP TABLE IF EXISTS "public"."seller_products";
DROP TABLE IF EXISTS "public"."seller_product_stock";
DROP TABLE IF EXISTS "public"."reviews";
DROP TABLE IF EXISTS "public"."resource_categories";
DROP TABLE IF EXISTS "public"."refresh_tokens";
DROP TABLE IF EXISTS "public"."public_page_configs";
DROP TABLE IF EXISTS "public"."pending_registrations";
DROP TABLE IF EXISTS "public"."page_permissions";
DROP TABLE IF EXISTS "public"."otp_codes";
DROP TABLE IF EXISTS "public"."orders";
DROP TABLE IF EXISTS "public"."notifications";
DROP TABLE IF EXISTS "public"."mmo_products";
DROP TABLE IF EXISTS "public"."mmo_product_items";
DROP TABLE IF EXISTS "public"."login_attempts";
DROP TABLE IF EXISTS "public"."fanpage_registrations";
DROP TABLE IF EXISTS "public"."courses";
DROP TABLE IF EXISTS "public"."course_support_items";
DROP TABLE IF EXISTS "public"."course_faqs";
DROP TABLE IF EXISTS "public"."course_faq_categories";
DROP TABLE IF EXISTS "public"."course_categories";
DROP TABLE IF EXISTS "public"."complaints";
DROP TABLE IF EXISTS "public"."chat_rooms";
DROP TABLE IF EXISTS "public"."chat_participants";
DROP TABLE IF EXISTS "public"."chat_messages";
DROP TABLE IF EXISTS "public"."bank_change_requests";
DROP TABLE IF EXISTS "public"."audit_logs";
DROP TABLE IF EXISTS "public"."ads_registrations";
DROP TABLE IF EXISTS "public"."_prisma_migrations";
DROP TYPE IF EXISTS "public"."WithdrawalStatus";
DROP TYPE IF EXISTS "public"."TxType";
DROP TYPE IF EXISTS "public"."TestimonialType";
DROP TYPE IF EXISTS "public"."StockItemStatus";
DROP TYPE IF EXISTS "public"."SellerStatus";
DROP TYPE IF EXISTS "public"."Role";
DROP TYPE IF EXISTS "public"."Platform";
DROP TYPE IF EXISTS "public"."OtpPurpose";
DROP TYPE IF EXISTS "public"."OrderType";
DROP TYPE IF EXISTS "public"."OrderStatus";
DROP TYPE IF EXISTS "public"."NotificationType";
DROP TYPE IF EXISTS "public"."LearningFormat";
DROP TYPE IF EXISTS "public"."CourseBadge";
DROP TYPE IF EXISTS "public"."ComplaintStatus";
DROP TYPE IF EXISTS "public"."BankChangeStatus";
DROP TYPE IF EXISTS "public"."AccountStatus";
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: app_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA "public" OWNER TO "app_user";

--
-- Name: AccountStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."AccountStatus" AS ENUM (
    'ACTIVE',
    'PENDING_VERIFICATION',
    'BANNED',
    'DELETED'
);


ALTER TYPE "public"."AccountStatus" OWNER TO "app_user";

--
-- Name: BankChangeStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."BankChangeStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE "public"."BankChangeStatus" OWNER TO "app_user";

--
-- Name: ComplaintStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."ComplaintStatus" AS ENUM (
    'OPEN',
    'IN_REVIEW',
    'RESOLVED',
    'REJECTED'
);


ALTER TYPE "public"."ComplaintStatus" OWNER TO "app_user";

--
-- Name: CourseBadge; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."CourseBadge" AS ENUM (
    'NONE',
    'HOT',
    'POPULAR',
    'TREND',
    'NEW',
    'VIP'
);


ALTER TYPE "public"."CourseBadge" OWNER TO "app_user";

--
-- Name: LearningFormat; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."LearningFormat" AS ENUM (
    'ONLINE',
    'OFFLINE',
    'HYBRID'
);


ALTER TYPE "public"."LearningFormat" OWNER TO "app_user";

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."NotificationType" AS ENUM (
    'DEPOSIT',
    'PURCHASE',
    'ORDER_STATUS',
    'SELLER_APPROVED',
    'WITHDRAWAL_STATUS',
    'SYSTEM',
    'PROMOTION'
);


ALTER TYPE "public"."NotificationType" OWNER TO "app_user";

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."OrderStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'DONE',
    'CANCELLED',
    'REFUNDED',
    'DISPUTED',
    'FROZEN'
);


ALTER TYPE "public"."OrderStatus" OWNER TO "app_user";

--
-- Name: OrderType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."OrderType" AS ENUM (
    'SERVICE',
    'COURSE',
    'TUTTRICK',
    'MMO_PRODUCT',
    'SELLER_PRODUCT'
);


ALTER TYPE "public"."OrderType" OWNER TO "app_user";

--
-- Name: OtpPurpose; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."OtpPurpose" AS ENUM (
    'REGISTER',
    'LOGIN_2FA',
    'RESET_PASSWORD',
    'EMAIL_VERIFY',
    'WITHDRAWAL_CONFIRM',
    'SENSITIVE_ACTION'
);


ALTER TYPE "public"."OtpPurpose" OWNER TO "app_user";

--
-- Name: Platform; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."Platform" AS ENUM (
    'FACEBOOK',
    'TIKTOK',
    'GOOGLE',
    'INSTAGRAM',
    'YOUTUBE',
    'ICLOUD',
    'ZALO',
    'TELEGRAM',
    'TWITTER',
    'OTHER'
);


ALTER TYPE "public"."Platform" OWNER TO "app_user";

--
-- Name: Role; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."Role" AS ENUM (
    'USER',
    'SELLER',
    'STAFF',
    'ADMIN'
);


ALTER TYPE "public"."Role" OWNER TO "app_user";

--
-- Name: SellerStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."SellerStatus" AS ENUM (
    'NONE',
    'PENDING',
    'APPROVED',
    'REJECTED',
    'REVOKED'
);


ALTER TYPE "public"."SellerStatus" OWNER TO "app_user";

--
-- Name: StockItemStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."StockItemStatus" AS ENUM (
    'AVAILABLE',
    'RESERVED',
    'SOLD'
);


ALTER TYPE "public"."StockItemStatus" OWNER TO "app_user";

--
-- Name: TestimonialType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."TestimonialType" AS ENUM (
    'COURSE',
    'SERVICE'
);


ALTER TYPE "public"."TestimonialType" OWNER TO "app_user";

--
-- Name: TxType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."TxType" AS ENUM (
    'DEPOSIT_AUTO',
    'DEPOSIT_MANUAL',
    'BUY_SERVICE',
    'BUY_COURSE',
    'BUY_TUTTRICK',
    'BUY_MMO_PRODUCT',
    'BUY_SELLER_PRODUCT',
    'REFUND',
    'SELLER_REGISTRATION',
    'SELLER_PAYOUT',
    'WITHDRAWAL_FEE',
    'ADMIN_ADJUSTMENT',
    'COMPLAINT_DEDUCTION',
    'SELLER_SLOT_PURCHASE'
);


ALTER TYPE "public"."TxType" OWNER TO "app_user";

--
-- Name: WithdrawalStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."WithdrawalStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'PROCESSING',
    'COMPLETED'
);


ALTER TYPE "public"."WithdrawalStatus" OWNER TO "app_user";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."_prisma_migrations" (
    "id" character varying(36) NOT NULL,
    "checksum" character varying(64) NOT NULL,
    "finished_at" timestamp with time zone,
    "migration_name" character varying(255) NOT NULL,
    "logs" "text",
    "rolled_back_at" timestamp with time zone,
    "started_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "applied_steps_count" integer DEFAULT 0 NOT NULL
);


ALTER TABLE "public"."_prisma_migrations" OWNER TO "app_user";

--
-- Name: ads_registrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."ads_registrations" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "service_name" "text" NOT NULL,
    "service_tab" "text" NOT NULL,
    "fanpage_status" "text" NOT NULL,
    "has_content" "text" NOT NULL,
    "ads_experience" "text" NOT NULL,
    "product_category" "text" NOT NULL,
    "budget" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "status" "text" DEFAULT 'PENDING'::"text" NOT NULL,
    "note" "text"
);


ALTER TABLE "public"."ads_registrations" OWNER TO "app_user";

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."audit_logs" (
    "id" "uuid" NOT NULL,
    "actor_id" "uuid",
    "action" "text" NOT NULL,
    "target_type" "text",
    "target_id" "text",
    "before" "jsonb",
    "after" "jsonb",
    "metadata" "jsonb",
    "ip_address" "text",
    "user_agent" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."audit_logs" OWNER TO "app_user";

--
-- Name: bank_change_requests; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."bank_change_requests" (
    "id" "uuid" NOT NULL,
    "seller_id" "uuid" NOT NULL,
    "bank_name_enc" "bytea" NOT NULL,
    "bank_account_number_enc" "bytea" NOT NULL,
    "bank_account_holder_enc" "bytea" NOT NULL,
    "status" "public"."BankChangeStatus" DEFAULT 'PENDING'::"public"."BankChangeStatus" NOT NULL,
    "reject_reason" "text",
    "reviewed_by_user_id" "uuid",
    "reviewed_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."bank_change_requests" OWNER TO "app_user";

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."chat_messages" (
    "id" "uuid" NOT NULL,
    "room_id" "uuid" NOT NULL,
    "sender_id" "uuid" NOT NULL,
    "sender_name" "text" NOT NULL,
    "sender_label" "text" NOT NULL,
    "content" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."chat_messages" OWNER TO "app_user";

--
-- Name: chat_participants; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."chat_participants" (
    "id" "uuid" NOT NULL,
    "room_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "label" "text" NOT NULL,
    "joined_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."chat_participants" OWNER TO "app_user";

--
-- Name: chat_rooms; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."chat_rooms" (
    "id" "uuid" NOT NULL,
    "complaint_id" "uuid" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."chat_rooms" OWNER TO "app_user";

--
-- Name: complaints; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."complaints" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_id" "uuid",
    "subject" "text" NOT NULL,
    "content" "text" NOT NULL,
    "status" "public"."ComplaintStatus" DEFAULT 'OPEN'::"public"."ComplaintStatus" NOT NULL,
    "resolution" "text",
    "resolved_by_user_id" "uuid",
    "resolved_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."complaints" OWNER TO "app_user";

--
-- Name: course_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "icon" "text" DEFAULT ''::"text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_categories" OWNER TO "app_user";

--
-- Name: course_faq_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_faq_categories" (
    "id" "uuid" NOT NULL,
    "course_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_faq_categories" OWNER TO "app_user";

--
-- Name: course_faqs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_faqs" (
    "id" "uuid" NOT NULL,
    "course_id" "uuid" NOT NULL,
    "category_id" "uuid",
    "question" "text" NOT NULL,
    "answer" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_faqs" OWNER TO "app_user";

--
-- Name: course_support_items; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_support_items" (
    "id" "uuid" NOT NULL,
    "course_id" "uuid" NOT NULL,
    "icon" "text" DEFAULT '✅'::"text" NOT NULL,
    "title" "text" NOT NULL,
    "description" "text",
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_support_items" OWNER TO "app_user";

--
-- Name: courses; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."courses" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "description" "text",
    "category" "text" NOT NULL,
    "learning_format" "public"."LearningFormat" NOT NULL,
    "original_price" numeric(18,2) NOT NULL,
    "sale_price" numeric(18,2) NOT NULL,
    "duration" "text",
    "student_count" integer DEFAULT 0 NOT NULL,
    "instructor_name" "text",
    "rating" double precision DEFAULT 0 NOT NULL,
    "content_list" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "platform_variants" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "badge" "public"."CourseBadge" DEFAULT 'NONE'::"public"."CourseBadge" NOT NULL,
    "sale_deadline" "date",
    "youtube_url" "text",
    "seo_title" "text",
    "seo_description" "text",
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL,
    "commitments" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "registration_procedure" "text"
);


ALTER TABLE "public"."courses" OWNER TO "app_user";

--
-- Name: fanpage_registrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."fanpage_registrations" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "service_type" "text" NOT NULL,
    "service_name" "text" NOT NULL,
    "description" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "status" "text" DEFAULT 'PENDING'::"text" NOT NULL,
    "note" "text"
);


ALTER TABLE "public"."fanpage_registrations" OWNER TO "app_user";

--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."login_attempts" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "email" "text" NOT NULL,
    "ip_address" "text" NOT NULL,
    "user_agent" "text",
    "success" boolean NOT NULL,
    "fail_reason" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."login_attempts" OWNER TO "app_user";

--
-- Name: mmo_product_items; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."mmo_product_items" (
    "id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "value_enc" "bytea" NOT NULL,
    "status" "public"."StockItemStatus" DEFAULT 'AVAILABLE'::"public"."StockItemStatus" NOT NULL,
    "sold_to_user_id" "uuid",
    "order_id" "uuid",
    "sold_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."mmo_product_items" OWNER TO "app_user";

--
-- Name: mmo_products; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."mmo_products" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "category" "text" NOT NULL,
    "category_group" "text" NOT NULL,
    "price" numeric(18,2) NOT NULL,
    "description" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "rating" double precision DEFAULT 0 NOT NULL,
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL
);


ALTER TABLE "public"."mmo_products" OWNER TO "app_user";

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."notifications" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "title" "text" NOT NULL,
    "body" "text" NOT NULL,
    "type" "public"."NotificationType" DEFAULT 'SYSTEM'::"public"."NotificationType" NOT NULL,
    "is_read" boolean DEFAULT false NOT NULL,
    "meta" "jsonb",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."notifications" OWNER TO "app_user";

--
-- Name: orders; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."orders" (
    "id" "uuid" NOT NULL,
    "order_code" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_type" "public"."OrderType" NOT NULL,
    "service_id" "uuid",
    "course_id" "uuid",
    "tut_trick_id" "uuid",
    "mmo_product_id" "uuid",
    "seller_product_id" "uuid",
    "seller_id" "uuid",
    "item_name" "text" NOT NULL,
    "original_price" numeric(18,2) NOT NULL,
    "final_price" numeric(18,2) NOT NULL,
    "warranty_variant" "text",
    "payment_method" "text" DEFAULT 'BALANCE'::"text" NOT NULL,
    "status" "public"."OrderStatus" DEFAULT 'PENDING'::"public"."OrderStatus" NOT NULL,
    "delivered_item_id" "uuid",
    "idempotency_key" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "completed_at" timestamp(3) without time zone,
    "customer_note" "text",
    "withdrawn" boolean DEFAULT false NOT NULL,
    "tut_trick_content_url_enc" "bytea",
    "tut_trick_docs" "text"
);


ALTER TABLE "public"."orders" OWNER TO "app_user";

--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."otp_codes" (
    "id" "uuid" NOT NULL,
    "email" "text" NOT NULL,
    "user_id" "uuid",
    "purpose" "public"."OtpPurpose" NOT NULL,
    "code_hash" "text" NOT NULL,
    "attempts" integer DEFAULT 0 NOT NULL,
    "max_attempts" integer DEFAULT 5 NOT NULL,
    "ip_address" "text",
    "expires_at" timestamp(3) without time zone NOT NULL,
    "used_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."otp_codes" OWNER TO "app_user";

--
-- Name: page_permissions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."page_permissions" (
    "id" "uuid" NOT NULL,
    "role" "public"."Role" NOT NULL,
    "page_key" character varying(100) NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    "updated_by_user_id" "uuid",
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."page_permissions" OWNER TO "app_user";

--
-- Name: pending_registrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."pending_registrations" (
    "id" "uuid" NOT NULL,
    "email" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "phone" "text",
    "otp_code_hash" "text",
    "attempts" integer DEFAULT 0 NOT NULL,
    "ip_address" "text",
    "expires_at" timestamp(3) without time zone NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."pending_registrations" OWNER TO "app_user";

--
-- Name: public_page_configs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."public_page_configs" (
    "id" "uuid" NOT NULL,
    "page_key" character varying(100) NOT NULL,
    "is_visible" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "custom_label" character varying(200),
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."public_page_configs" OWNER TO "app_user";

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."refresh_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_hash" character varying(128) NOT NULL,
    "family" character varying(64) NOT NULL,
    "revoked" boolean DEFAULT false NOT NULL,
    "expires_at" timestamp(3) without time zone NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."refresh_tokens" OWNER TO "app_user";

--
-- Name: resource_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."resource_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "icon_url" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE "public"."resource_categories" OWNER TO "app_user";

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."reviews" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "product_type" "text" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "rating" integer NOT NULL,
    "comment" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "order_id" "uuid" NOT NULL
);


ALTER TABLE "public"."reviews" OWNER TO "app_user";

--
-- Name: seller_product_stock; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_product_stock" (
    "id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "content_enc" "bytea" NOT NULL,
    "status" "public"."StockItemStatus" DEFAULT 'AVAILABLE'::"public"."StockItemStatus" NOT NULL,
    "sold_to_user_id" "uuid",
    "order_id" "uuid",
    "sold_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."seller_product_stock" OWNER TO "app_user";

--
-- Name: seller_products; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_products" (
    "id" "uuid" NOT NULL,
    "seller_id" "uuid" NOT NULL,
    "seller_category" "text" NOT NULL,
    "name" "text" NOT NULL,
    "price" numeric(18,2) NOT NULL,
    "description" "text",
    "image_url" "text",
    "publish_date" timestamp(3) without time zone,
    "is_active" boolean DEFAULT true NOT NULL,
    "is_hidden" boolean DEFAULT false NOT NULL,
    "is_restricted" boolean DEFAULT false NOT NULL,
    "sales_count" integer DEFAULT 0 NOT NULL,
    "revenue" numeric(18,2) DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "sub_category_id" "uuid"
);


ALTER TABLE "public"."seller_products" OWNER TO "app_user";

--
-- Name: seller_requests; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_requests" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "category" "text" NOT NULL,
    "fee" numeric(18,2) DEFAULT 50000 NOT NULL,
    "status" "public"."SellerStatus" DEFAULT 'PENDING'::"public"."SellerStatus" NOT NULL,
    "approved_category" "text",
    "reject_reason" "text",
    "reviewed_by_user_id" "uuid",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approved_at" timestamp(3) without time zone,
    "rejected_at" timestamp(3) without time zone
);


ALTER TABLE "public"."seller_requests" OWNER TO "app_user";

--
-- Name: seller_sub_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_sub_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "category_name" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."seller_sub_categories" OWNER TO "app_user";

--
-- Name: seller_tier_definitions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_tier_definitions" (
    "id" "uuid" NOT NULL,
    "key" character varying(50) NOT NULL,
    "label" character varying(30) NOT NULL,
    "description" character varying(200),
    "badge_color" character varying(30) DEFAULT 'gray'::character varying NOT NULL,
    "fee_percent" double precision DEFAULT 5 NOT NULL,
    "min_withdrawal" integer DEFAULT 200000 NOT NULL,
    "hold_days" integer DEFAULT 3 NOT NULL,
    "benefits" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "upgrade_min_revenue" integer DEFAULT 0 NOT NULL,
    "upgrade_min_orders" integer DEFAULT 0 NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_built_in" boolean DEFAULT false NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."seller_tier_definitions" OWNER TO "app_user";

--
-- Name: seller_withdrawals; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_withdrawals" (
    "id" "uuid" NOT NULL,
    "seller_id" "uuid" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "fee_percent" double precision NOT NULL,
    "fee_amount" numeric(18,2) NOT NULL,
    "net_amount" numeric(18,2) NOT NULL,
    "bank_name_enc" "bytea" NOT NULL,
    "bank_account_number_enc" "bytea" NOT NULL,
    "bank_account_holder_enc" "bytea" NOT NULL,
    "status" "public"."WithdrawalStatus" DEFAULT 'PENDING'::"public"."WithdrawalStatus" NOT NULL,
    "qualifying_order_ids" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "reject_reason" "text",
    "processed_by_user_id" "uuid",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "processed_at" timestamp(3) without time zone
);


ALTER TABLE "public"."seller_withdrawals" OWNER TO "app_user";

--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."service_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "icon_url" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE "public"."service_categories" OWNER TO "app_user";

--
-- Name: services; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."services" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "platform" "public"."Platform" NOT NULL,
    "category" "text" NOT NULL,
    "price" numeric(18,2) NOT NULL,
    "success_rate" integer DEFAULT 100 NOT NULL,
    "processing_time" "text",
    "rating" double precision DEFAULT 0 NOT NULL,
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "description" "text",
    "seo_title" "text",
    "seo_description" "text",
    "warranty_options" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "product_list" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "customer_count" integer DEFAULT 0 NOT NULL,
    "platform_variants" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "review_count" integer DEFAULT 0 NOT NULL,
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL
);


ALTER TABLE "public"."services" OWNER TO "app_user";

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "session_token" character varying(128) NOT NULL,
    "ip_address" "text",
    "user_agent" "text",
    "expires_at" timestamp(3) without time zone NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."sessions" OWNER TO "app_user";

--
-- Name: site_content; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."site_content" (
    "id" "uuid" NOT NULL,
    "key" character varying(64) NOT NULL,
    "content" "jsonb" NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "updated_by_id" "uuid"
);


ALTER TABLE "public"."site_content" OWNER TO "app_user";

--
-- Name: staff_permissions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."staff_permissions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "permission" character varying(64) NOT NULL
);


ALTER TABLE "public"."staff_permissions" OWNER TO "app_user";

--
-- Name: system_config; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."system_config" (
    "key" "text" NOT NULL,
    "value" "jsonb" NOT NULL,
    "description" "text",
    "updated_by_user_id" "uuid",
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."system_config" OWNER TO "app_user";

--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."testimonials" (
    "id" "uuid" NOT NULL,
    "type" "public"."TestimonialType" NOT NULL,
    "course_id" "uuid",
    "category" "text",
    "reviewer_name" "text" NOT NULL,
    "reviewer_role" "text",
    "reviewer_avatar" "text",
    "reviewer_initials" "text",
    "reviewer_color" "text",
    "content" "text" NOT NULL,
    "rating" integer DEFAULT 5 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "service_id" "uuid"
);


ALTER TABLE "public"."testimonials" OWNER TO "app_user";

--
-- Name: ticker_notifications; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."ticker_notifications" (
    "id" "uuid" NOT NULL,
    "phone" "text" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."ticker_notifications" OWNER TO "app_user";

--
-- Name: ticker_texts; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."ticker_texts" (
    "id" "uuid" NOT NULL,
    "text" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."ticker_texts" OWNER TO "app_user";

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."transactions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_id" "uuid",
    "type" "public"."TxType" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "description" "text" NOT NULL,
    "balance_before" numeric(18,2) NOT NULL,
    "balance_after" numeric(18,2) NOT NULL,
    "reference_code" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "metadata" "jsonb",
    "account_number" character varying(50),
    "transaction_date" character varying(30)
);


ALTER TABLE "public"."transactions" OWNER TO "app_user";

--
-- Name: tut_trick_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."tut_trick_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "icon_url" "text",
    "display_order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE "public"."tut_trick_categories" OWNER TO "app_user";

--
-- Name: tut_tricks; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."tut_tricks" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "platform" "public"."Platform" NOT NULL,
    "category" "text" NOT NULL,
    "price" numeric(18,2) DEFAULT 0 NOT NULL,
    "description" "text",
    "content_url_enc" "bytea",
    "docs" "text",
    "seo_title" "text",
    "seo_description" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "success_rate" integer DEFAULT 100 NOT NULL,
    "rating" double precision DEFAULT 0 NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "published_date" "date",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "processing_time" "text",
    "warranty_policy" "text",
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL,
    "tier" "text" DEFAULT 'Miễn phí'::"text" NOT NULL
);


ALTER TABLE "public"."tut_tricks" OWNER TO "app_user";

--
-- Name: unmatched_transfers; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."unmatched_transfers" (
    "id" "uuid" NOT NULL,
    "content" "text" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "reference_code" "text" NOT NULL,
    "raw_payload" "jsonb" NOT NULL,
    "candidates_tried" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "status" "text" DEFAULT 'PENDING'::"text" NOT NULL,
    "resolved_by_user_id" "uuid",
    "resolved_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."unmatched_transfers" OWNER TO "app_user";

--
-- Name: user_sub_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."user_sub_categories" (
    "user_id" "uuid" NOT NULL,
    "sub_category_id" "uuid" NOT NULL
);


ALTER TABLE "public"."user_sub_categories" OWNER TO "app_user";

--
-- Name: users; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."users" (
    "id" "uuid" NOT NULL,
    "email" character varying(255) NOT NULL,
    "email_verified_at" timestamp(3) without time zone,
    "password_hash" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "phone" "text",
    "role" "public"."Role" DEFAULT 'USER'::"public"."Role" NOT NULL,
    "status" "public"."AccountStatus" DEFAULT 'PENDING_VERIFICATION'::"public"."AccountStatus" NOT NULL,
    "balance" numeric(18,2) DEFAULT 0 NOT NULL,
    "total_deposited" numeric(18,2) DEFAULT 0 NOT NULL,
    "total_spent" numeric(18,2) DEFAULT 0 NOT NULL,
    "seller_status" "public"."SellerStatus" DEFAULT 'NONE'::"public"."SellerStatus" NOT NULL,
    "seller_category" "text",
    "max_seller_products" integer DEFAULT 3 NOT NULL,
    "bank_name_enc" "bytea",
    "bank_account_number_enc" "bytea",
    "bank_account_holder_enc" "bytea",
    "cccd_image_url" "text",
    "portrait_image_url" "text",
    "two_factor_secret_enc" "bytea",
    "two_factor_enabled" boolean DEFAULT false NOT NULL,
    "last_login_at" timestamp(3) without time zone,
    "last_login_ip" "text",
    "failed_login_count" integer DEFAULT 0 NOT NULL,
    "locked_until" timestamp(3) without time zone,
    "uid_prefix" character varying(8) NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "facebook_url" character varying(500),
    "telegram_username" character varying(100),
    "shop_locked" boolean DEFAULT false NOT NULL,
    "seller_tier" character varying(50) DEFAULT 'STANDARD'::character varying NOT NULL,
    "discount_percent" integer DEFAULT 0 NOT NULL,
    "avatar_url" character varying(500)
);


ALTER TABLE "public"."users" OWNER TO "app_user";

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."_prisma_migrations" ("id", "checksum", "finished_at", "migration_name", "logs", "rolled_back_at", "started_at", "applied_steps_count") FROM stdin;
4bf06588-1274-4681-9d88-30eb77fa2353	bb95ce68bd4bf15bdd467ed7075f60c8b4f42398daabe2e348e661d8bdee2ac8	2026-05-23 12:39:16.45714+00	20260523123915_init	\N	\N	2026-05-23 12:39:15.716735+00	1
f8498d12-a4e5-44c8-898a-aa9a7f753e34	9fdebf45d780b78105ebc7ec97b00b6f227880ce62fd9fa5248344776c42ab7c	2026-05-23 17:07:16.311501+00	20260523170716_add_service_customer_review_platform_variants	\N	\N	2026-05-23 17:07:16.292612+00	1
7e962818-f2b9-43ef-b410-2274175f5be9	56b9543d7614ab846e30e8288a15122aeb34045bbf3def8c4e33bbd8205aac25	2026-05-29 08:04:52.387718+00	20260529080452_add_resource_categories	\N	\N	2026-05-29 08:04:52.33563+00	1
4d574ae2-a062-4b99-82bd-31ad5ecc72b5	a3788a19196c5319118f04ff09e82405d404b188ad055acbc69a2ca4028d5261	2026-05-24 10:02:11.351339+00	20260524100211_add_course_categories	\N	\N	2026-05-24 10:02:11.309535+00	1
dd81d1b3-5f8d-4a00-85dd-56281d0c6168	e68c6194095cf1e5b857d199d7ed62cc9b2002bc0647879993a2652bd04fe7d8	2026-05-24 14:51:03.593432+00	20260524145103_add_mmo_stats	\N	\N	2026-05-24 14:51:03.57079+00	1
62865735-f765-47d6-a476-0618c4b35a0a	bd67af39e1e789ffc8d66f49f388ad9823dfb1302fb2d1f292b34ab252b34d17	2026-06-03 19:39:59.051392+00	20260603193958_add_page_permissions	\N	\N	2026-06-03 19:39:59.002114+00	1
bc045ead-0b9d-4687-b2a1-c4ac918a1abd	ed28f184c13712e8e60ab1e01f57e71aebf3f1d1257adc8c23e5f4adfaef7d54	2026-05-24 16:23:23.602139+00	20260524162323_add_customer_note_to_orders	\N	\N	2026-05-24 16:23:23.565639+00	1
25b232c0-407f-4300-bb22-86f740f397eb	5acbf9a1a548cf9f82b910bd3bc5ee380f1f286fe9a63591e2e447f65c1a6421	2026-05-29 08:59:06.054982+00	20260529085905_add_service_categories	\N	\N	2026-05-29 08:59:06.012642+00	1
096a35d1-43bf-4b8b-8bd5-1693732113f3	4700aae7643d3f8a352ac56960dbaab891f03172186b117580893850426ff06c	2026-05-25 11:00:43.671227+00	20260525110043_add_withdrawn_to_orders	\N	\N	2026-05-25 11:00:43.654762+00	1
1b2ab19e-9d2c-4e91-bbd5-e3b9ed99e48b	8e8997000a57f917e6d13e4fcc4248b5a027529ca6b3b6f7bdc9292d46c71057	2026-05-25 17:18:49.158558+00	20260525171849_add_social_links_to_users	\N	\N	2026-05-25 17:18:49.13712+00	1
eddb0d9e-3eac-425f-a28e-6894375724b1	fa6e4760c64a350f72e94f506058120a93cf3d3e1533dfbfba942768c9200e1f	2026-06-02 04:03:16.17697+00	20260602040316_add_service_id_to_testimonials	\N	\N	2026-06-02 04:03:16.138953+00	1
eed01c4c-bd91-4b4a-945b-e65a4175fa15	361d11f8c7a6ea405fafb1ff87928d70756f44c07a33889c7530656e6d515262	2026-05-25 18:04:28.640465+00	20260525180428_add_shop_locked_to_users	\N	\N	2026-05-25 18:04:28.621835+00	1
66a527bf-0a10-4893-959f-ecb15520a27a	b65ca580b8c8878688c95cb0643c782c0cace880901ccb66c6b9b1d5dfcbd096	2026-05-29 18:50:13.262518+00	20260529185013_add_seller_slot_purchase_tx_type	\N	\N	2026-05-29 18:50:13.247579+00	1
2a6ad5a0-46bf-4570-9b08-d157f8151894	a8a826036ca31c6f8fbc0e9f7cb96ffd7d6190548de11e450a7508d758359e15	2026-05-26 12:22:39.438939+00	20260526000001_add_order_id_to_reviews	\N	\N	2026-05-26 12:22:39.388298+00	1
79b40c94-888c-4bbe-9ed8-6156e6e5a0cd	6d35ce6af9f6cc3181cd71c3b6da38530668ebb881053f6af847b7427a323cb6	2026-05-26 14:52:23.632365+00	20260526145223_add_chat_system	\N	\N	2026-05-26 14:52:23.522281+00	1
518e0150-b5c3-4f27-a4c2-e8fa09d8ec28	07546c6bfed76b7ed0106c22b182228544f7025b1eaa7f1f48240599a2f151c3	2026-05-26 16:25:16.929131+00	20260526162516_add_frozen_order_status	\N	\N	2026-05-26 16:25:16.913553+00	1
21811c23-39ec-42ba-abfa-30a78d998bd9	29687602d957ef08e40467d052da3c289a7ccfb6ae09250e57d65beb23276071	2026-05-30 03:43:47.285485+00	20260530034347_add_seller_tier	\N	\N	2026-05-30 03:43:47.26439+00	1
5fb42ea5-ddfa-4941-9800-563c87aefedc	acc5cb066c45c8ec91482a014056158bb85209bd1a1246d9c7ef25a09878703f	2026-05-27 02:38:41.417746+00	20260527023841_snapshot_tuttrick_content_on_order	\N	\N	2026-05-27 02:38:41.403233+00	1
ac7f2b29-5dde-417a-a1c7-4a9bc818c951	23336b899701cf6271d4acc09e0ce99ab45061e34862281f44afa1293fd97713	2026-05-27 02:42:55.212247+00	20260527024255_add_warranty_processing_to_tut_tricks	\N	\N	2026-05-27 02:42:55.202232+00	1
90bd64e7-e4de-4a6d-9a3f-b2639c08ffec	b5dd452883e89f398bbb841e39e86cfee8dd385778400b1ea9a7c17c315aa099	2026-06-03 08:03:54.737715+00	20260603080354_add_transaction_date_account_number	\N	\N	2026-06-03 08:03:54.719549+00	1
40f557bb-7574-4710-96c2-30cc470e844f	00560b0fd845d00d70cc4ad4144af21bc4d1cf38f2e7df0e991d6e32973f7260	2026-05-30 08:47:43.071865+00	20260530084743_add_requires_account_type_cccd_to_services	\N	\N	2026-05-30 08:47:43.040186+00	1
2df9c5bd-e558-4445-877d-422e76ae4651	7aa092130babe8add95759d697013174664f2ba5e1d7982765ff878803d67c8e	2026-06-02 10:11:42.934133+00	20260602101142_add_tut_trick_category	\N	\N	2026-06-02 10:11:42.885988+00	1
10123860-b220-436f-86c5-2bf5e83083b0	7cb3c7f2251f4a71092c8923fa8af0199be2c037e4dc6df3026a4c71bc3ef0ec	2026-05-31 17:55:18.382087+00	20260531175518_add_order_requirements_to_all_products	\N	\N	2026-05-31 17:55:18.35545+00	1
990d04e8-8fd2-440b-a7c6-eca7aea504e9	13c848e2e2f53aaf97a2965d3060f35c2e4de133137315075b456599c9c19ca5	2026-06-02 03:11:38.739314+00	20260602031138_add_commitments_registration_procedure_to_courses	\N	\N	2026-06-02 03:11:38.723798+00	1
4c027591-17ad-49b9-815f-41170df2e26d	d6b6a00b06c01dc7ec6f61036961cea88b2c0e280cdfbc08c2c7a16f966096bd	2026-06-02 03:44:53.597197+00	20260602034453_add_testimonials	\N	\N	2026-06-02 03:44:53.524958+00	1
15c9d908-2118-4117-9a42-be0e295ddc73	e627dadc7929934d42e4932db0c9f4d75acb262683de1a89cab0d8d69da58bd0	2026-06-02 13:28:04.317392+00	20260602132804_add_icon_url_to_tut_trick_category	\N	\N	2026-06-02 13:28:04.304545+00	1
e0834f9c-a4d9-4185-b16e-1c7639f39cde	efff1efe0f3b459a6ed710f09f6d9b6a77a5aa00bf382de59c3ebee46e30f192	2026-06-04 03:26:55.993445+00	20260604000000_add_seller_tier_definitions		\N	2026-06-04 03:26:55.993445+00	0
730747d3-df0d-4509-b007-c7470d622c8b	29bbaff949c9e87da33bd28ac8a7db2a6b6e44414360feba7f9edc4b54aa7d4c	2026-06-02 13:50:01.723999+00	20260602135001_add_tier_to_tut_tricks	\N	\N	2026-06-02 13:50:01.711484+00	1
ab071d8b-4029-4ed1-901b-a991694fe12a	ad030afc8f08d654eff9980fd587475b163fab9120c03b9da1253fb809a47628	2026-06-03 08:46:22.599939+00	20260603084622_change_transaction_varchar_to_text	\N	\N	2026-06-03 08:46:22.568952+00	1
3d205362-dcc5-4fa3-ae53-1718b3393375	0defb9ccdc149d041172f26b82f2f338aefe7ff82c2ef04083edd76d78c66425	2026-06-03 07:59:14.877573+00	20260603075914_add_metadata_to_transactions	\N	\N	2026-06-03 07:59:14.864165+00	1
d199992b-11f5-4678-816d-740aff533cff	c8f1cc707f5147e235758faa78e4e320156303401c286e3711cffe7f57e8623d	2026-06-03 08:49:12.468802+00	20260603084912_restore_varchar_annotations	\N	\N	2026-06-03 08:49:12.337183+00	1
2dfec399-fc2b-424c-9607-abd714f0ccd6	5730f31d4d345db403dde07c1008dd73da6b7155fccf96ec8a2bbda94b70f4dd	2026-06-05 16:54:50.906359+00	20260605165450_add_public_page_configs	\N	\N	2026-06-05 16:54:50.870847+00	1
ce231f92-414e-41a0-b85e-620a8b98fdee	fe0bf71634960eb7142e6eb2127e185de7b57ac48c3b834fc68b84eee591a6ff	2026-06-04 03:28:12.713175+00	20260604032812_add_discount_percent_to_users	\N	\N	2026-06-04 03:28:12.676529+00	1
0213cc68-0439-4a62-8eda-e767290ad4ba	e5e4e35e7140265ec1ea31aa71a1e41a20b126ae42f96e39dddcdb12c7c2fdf8	2026-06-06 07:31:49.882401+00	20260606073149_add_fanpage_registration	\N	\N	2026-06-06 07:31:49.851421+00	1
c0a3f882-88be-465e-83be-0ffefa87ab73	56bee881a72fca7e492650511e2f7cd0b4fe14885eda0fc46025de93471dda35	2026-06-06 08:04:56.797823+00	20260606080456_add_ads_registration	\N	\N	2026-06-06 08:04:56.763591+00	1
a267d75e-5fe6-488f-a677-16cf584d7a2f	79c42022cc3f1eb46e10667bb59fa366090ddf4a690b0c4cb39516522d24c9ee	2026-06-06 09:27:46.644189+00	20260606092746_add_status_to_registrations	\N	\N	2026-06-06 09:27:46.610742+00	1
05f44480-f93e-4f77-a346-4c95ba16bea1	91b9f93a79c74453321489cb38ff234487af5de5617a1cf144bb1a8ea4ed7993	2026-06-06 15:01:37.400222+00	20260606150137_add_display_order_to_service_resource_tuttrick_categories	\N	\N	2026-06-06 15:01:37.381367+00	1
f2ea9727-3d7a-4039-af22-7bb7739f0c0c	6cf716a93022a96af9782b01192fd5fd1c8dfcf4e961ce86b3eb50bf15f10b8a	2026-06-07 11:01:50.307294+00	20260607110150_add_note_to_registrations	\N	\N	2026-06-07 11:01:50.292408+00	1
17ce4c68-315e-4861-89f9-bb30277773f1	e41d5b42bdc35b0d948de8ea75f81d6df453574e3e4cd241cb82718ee26b5381	2026-06-08 03:20:01.420266+00	20260608032001_add_avatar_url_to_users	\N	\N	2026-06-08 03:20:01.405738+00	1
3e402490-f16b-485f-86b3-a4f0e6e182cb	f5cd525182c15c698aed8430ec6d1f7592627d2a1d3487e5e7d5b46ef54e2fb7	2026-06-12 14:15:16.200667+00	20260612120000_add_seller_sub_categories	\N	\N	2026-06-12 14:15:16.066361+00	1
d3c95852-66b8-4c04-8ee1-ca9095e00511	37e968345ea00183baac250cbc323eab8dd256fc76ea8f9bcf016ae6e01d52ad	2026-06-12 14:15:16.233791+00	20260612150000_add_sub_category_to_seller_products	\N	\N	2026-06-12 14:15:16.205274+00	1
a1c4fb23-7571-42aa-954a-e715c869047f	55cef7b60a075487d87f84d953360f227b936fcf2ddee22e32f2b8f36d302d93	2026-06-14 10:21:25.132208+00	20260614102125_add_staff_permissions	\N	\N	2026-06-14 10:21:25.080458+00	1
972efc5d-7cf1-4e38-8a14-4a162fae2e0d	0831bfcc7b6d2af908cf9a29d42470cb2022c3bed9b31c22d020b2fc46365323	2026-06-14 15:19:23.144002+00	20260614151923_add_site_content	\N	\N	2026-06-14 15:19:23.103958+00	1
b4e82d8b-01af-49c8-8590-8f2a669b47c3	e73c4aed28a9c09171e6c3058ac843e2c9c6a7a8754b08cb8302f40f87f8bf8c	2026-06-14 20:28:44.957012+00	20260614202844_add_bank_change_requests	\N	\N	2026-06-14 20:28:44.899489+00	1
ecd9c8ca-9978-4514-aee0-c76770ad26c4	61c2e15aa278c3bcb790e7fc3318d47a01dc534883f597227c1a66270da17e02	2026-06-15 09:57:28.829543+00	20260615095728_add_course_faq_support	\N	\N	2026-06-15 09:57:28.745194+00	1
\.


--
-- Data for Name: ads_registrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."ads_registrations" ("id", "name", "phone", "service_name", "service_tab", "fanpage_status", "has_content", "ads_experience", "product_category", "budget", "created_at", "status", "note") FROM stdin;
c5152f02-99bb-4beb-815e-3dff14611a8d	Chuquangdoanh	0929990999	Cung Cấp Tài Nguyên Ads	facebook	none	has	never	my-pham	100-300m	2026-06-06 08:22:35.914	DONE	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."audit_logs" ("id", "actor_id", "action", "target_type", "target_id", "before", "after", "metadata", "ip_address", "user_agent", "created_at") FROM stdin;
e3eb770f-325d-4c03-9301-543bea9cf4ba	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 18:37:46.679
8eefab82-d989-4382-bfa1-130f240e1c56	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-08 03:04:38.712
1ffff6f8-1c95-46e3-a966-71ee7ffc5309	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 18:44:43.36
fcf631d8-838b-4afb-ac57-e98655e106f8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_SLOT_PURCHASE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	\N	{"price": 50000, "slots": 5}	\N	\N	2026-06-07 11:11:32.887
01395536-bc02-4d3a-8b97-61e38ce23c2c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 20}	{"slot_packages": [{"price": 50000, "slots": 1}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 1000000, "withdrawal_fee_percent": 20}	\N	\N	\N	2026-06-07 14:40:48.345
abf6578c-0a1b-4ad2-bd8b-616e02bb9b84	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 14:42:20.688
4ccc426c-781f-4865-8d84-15141a85555b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-08 04:15:59.738
2330ef12-2cb2-4f4c-bdfe-4c073cdd4dec	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-06 18:45:41.272
f799f7b2-132b-428f-92b3-ef64881a64f3	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 18:45:46.282
089baeca-621d-4201-90f7-96c57ef45429	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 18:45:48.419
900ce982-aada-4c3e-845a-2aca185da37f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 14:41:29.959
4bef0132-ef5b-4b13-ab90-eb54b1fbf999	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 2, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "seoDescription": "Cam kết  hiểu  cv", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:28:20.846
22758e34-4e8a-4f07-bec6-194681464c4d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 18:47:53.69
71a6bad4-7eed-4a90-93b1-bd4db9505440	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 18:48:02.572
831c858c-1427-440e-a398-b44ffeb27f5c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 14:56:43.169
cab2197b-a383-404b-9646-ce823785927f	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:28:47.002
e8463d70-8074-4293-bc20-687b0c30a628	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-06T03:30:27.058Z", "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 10000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	\N	\N	\N	2026-06-06 19:20:17.893
b1dab639-27a2-4b5f-836a-005a8779a99a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 17:35:01.261
80bd982e-f715-43d3-bfb5-b83912a4074d	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:29:30.178
137c85d9-422a-4a32-9c4b-97427a55339d	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 17:52:47.925
15cc5390-14ff-4f3b-9167-08d0be9f27ec	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:31:14.19
076b6cd4-6d7d-4bb4-a48f-aecffbc0d944	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	e410cf1a-2a57-4179-a9da-67a5de2ed875	{"name": "Instargram"}	\N	\N	\N	\N	2026-06-06 15:42:06.612
520af349-e199-4667-9c78-35cc49ca62f4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	1208edbf-e67b-42f8-a0c2-f115e20aacc3	{"id": "1208edbf-e67b-42f8-a0c2-f115e20aacc3", "key": "VIP", "label": "VIP", "benefits": ["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:32:34.760Z", "badgeColor": "violet", "feePercent": 9, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	{"label": "Cấp 4", "benefits": ["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "badgeColor": "violet", "feePercent": 9, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	\N	\N	\N	2026-06-08 02:54:05.908
5611be18-79ca-4ae3-8aea-4517eea998d5	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 2, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "seoDescription": "Cam kết  hiểu  cv", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:31:41.279
958126ad-b9d9-44e5-83fd-07aff54c3e6c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	1c149d14-f5c4-43e4-93b5-f6f0c467c8da	{"id": "1c149d14-f5c4-43e4-93b5-f6f0c467c8da", "key": "SUPPER", "label": "Siêu VIP", "benefits": [], "holdDays": 3, "isActive": true, "createdAt": "2026-06-04T13:05:38.539Z", "isBuiltIn": false, "updatedAt": "2026-06-04T13:05:38.539Z", "badgeColor": "blue", "feePercent": 8, "description": "Nhà bán hàng kinh nghiệm", "displayOrder": 4, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	{"label": "Cấp 5", "benefits": [], "holdDays": 3, "isActive": true, "badgeColor": "blue", "feePercent": 8, "description": "Nhà bán hàng kinh nghiệm", "displayOrder": 4, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	\N	\N	\N	2026-06-08 02:54:12.014
253a4df6-b1f6-4bcb-a067-0271399b17c7	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": true, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-08 08:46:51.706
ccd9b4f7-004a-4a3b-b186-eb8e921dac5a	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	b2a4ef6e-4502-4435-8d9f-78c4d4b1abcc	{"name": "Icloud"}	\N	\N	\N	\N	2026-06-06 15:42:09.138
577dc1ae-9f86-4e8b-9732-42dc6192b6bc	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "khóa học 1", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["1️⃣ ĐÀO TẠO DỊCH VỤ FACEBOOK\\n- SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\n- Lấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n- Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n- Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n- Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n- TUT TRICK Facebook | Khai Thác Tricker Update New", "2️⃣ CHẠY QUẢNG CÁO ADS FACEBOOK \\n- Thiết Kế và Làm Conten (Video + Hình Ảnh) Chuẩn Chỉnh\\n- Tối Ưu FanFanpage Chuẩn SEO + Tăng Đề Xuất Fanpage\\n- Quy Trình Sử Dụng VIA + TKQC + BM Thành Thạo\\n- SET Quảng Cáo Mess + Livestream + Chuyển Đổi\\n- Tets Sản Phẩm WIN + Bán Hàng Online Thực Chiến\\n- Đọc Chỉ Số Quảng Cáo + Tối Ưu Camp Hiệu Quả\\n- Kinh Nghiệm SET Quảng Cáo Hàng VPCS Cực Nặng\\n- Care Camp Ngân Sách Cực Lớn (Trên 500Tr/1 Ngày)\\n- Kháng Nghị VIA + TKQC + BM Bị Hạn Chế (Cảnh Báo)\\n- TUT Trick Xử Lý Các Lỗi Trong Quá Trình Chạy ADS", "3️⃣ CHẠY QUẢNG CÁO ADS TIK TOK\\n- Sử Dụng và Vận Hành Tik Tok Shop\\n- Quy Trình Thành Thạo BC + Tài Khoản Quảng Cáo\\n- Cài Pixel + Test Sự Kiện Chuyển Đổi\\n- Quy Trình SET Quảng Cáo Livestream và Chuyển Đổi Landing Page\\n- Đọc Chỉ Số + Phân Tích Quảng Cáo Hiệu Quả\\n- Kháng Nghị Tài Nguyên Bị Vô Hiệu Hóa", "4️⃣ KHAI THÁC TÀI NGUYÊN \\n- TUT Buil BM 5 đến BM 10\\n- Setup Dàn TKQC Cá Nhân + BM Siêu Trâu\\n- Thiêt Kế Landing Page Bán Hàng (Cài Tên Miền + Lưu Data)\\nMô tả 4", "5️⃣ KIẾM TIỀN TỪ FACEBOOK #ADBREAK\\n- Bật Kiếm Tiền Cho Trang Fanpage\\n- Cung Cấp Nguồn Fanpage Bật Kiếm Tiền Việt + Ngoại\\n- SETUP Cài Payout Phương Thức Rút Tiền + Khai Báo Thuế\\n- Sử Dụng Al + Làm Video Al Để Khai Thác Nội Dung"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:11:33.559
ee535f55-c295-4ab1-af6b-c386a7800918	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["1️⃣ ĐÀO TẠO DỊCH VỤ FACEBOOK\\n- SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\n- Lấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n- Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n- Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n- Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n- TUT TRICK Facebook | Khai Thác Tricker Update New", "2️⃣ CHẠY QUẢNG CÁO ADS FACEBOOK \\n- Thiết Kế và Làm Conten (Video + Hình Ảnh) Chuẩn Chỉnh\\n- Tối Ưu FanFanpage Chuẩn SEO + Tăng Đề Xuất Fanpage\\n- Quy Trình Sử Dụng VIA + TKQC + BM Thành Thạo\\n- SET Quảng Cáo Mess + Livestream + Chuyển Đổi\\n- Tets Sản Phẩm WIN + Bán Hàng Online Thực Chiến\\n- Đọc Chỉ Số Quảng Cáo + Tối Ưu Camp Hiệu Quả\\n- Kinh Nghiệm SET Quảng Cáo Hàng VPCS Cực Nặng\\n- Care Camp Ngân Sách Cực Lớn (Trên 500Tr/1 Ngày)\\n- Kháng Nghị VIA + TKQC + BM Bị Hạn Chế (Cảnh Báo)\\n- TUT Trick Xử Lý Các Lỗi Trong Quá Trình Chạy ADS", "3️⃣ CHẠY QUẢNG CÁO ADS TIK TOK\\n- Sử Dụng và Vận Hành Tik Tok Shop\\n- Quy Trình Thành Thạo BC + Tài Khoản Quảng Cáo\\n- Cài Pixel + Test Sự Kiện Chuyển Đổi\\n- Quy Trình SET Quảng Cáo Livestream và Chuyển Đổi Landing Page\\n- Đọc Chỉ Số + Phân Tích Quảng Cáo Hiệu Quả\\n- Kháng Nghị Tài Nguyên Bị Vô Hiệu Hóa", "4️⃣ KHAI THÁC TÀI NGUYÊN \\n- TUT Buil BM 5 đến BM 10\\n- Setup Dàn TKQC Cá Nhân + BM Siêu Trâu\\n- Thiêt Kế Landing Page Bán Hàng (Cài Tên Miền + Lưu Data)\\nMô tả 4", "5️⃣ KIẾM TIỀN TỪ FACEBOOK #ADBREAK\\n- Bật Kiếm Tiền Cho Trang Fanpage\\n- Cung Cấp Nguồn Fanpage Bật Kiếm Tiền Việt + Ngoại\\n- SETUP Cài Payout Phương Thức Rút Tiền + Khai Báo Thuế\\n- Sử Dụng Al + Làm Video Al Để Khai Thác Nội Dung"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:16:25.039
e9f10d03-b81f-4e47-a4cf-901625595099	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	e22e8ca8-9c91-4573-b152-e532c6f3bc28	\N	{"id": "e22e8ca8-9c91-4573-b152-e532c6f3bc28", "name": "Mở khóa tài khoản xác thực 2 yếu tố", "slug": "mo-khoa-tai-khoan-xac-thuc-2-yeu-to"}	\N	\N	\N	2026-06-02 12:03:26.376
7a616aea-ac5f-4ae4-aa8e-a64c6ece1164	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_CREATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	\N	{"id": "15ef906b-fe34-43a9-83a8-b1a542251db3", "name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "hasContentUrl": true}	\N	\N	\N	2026-06-01 12:35:04.386
9d766faa-fede-4003-b312-39682b965fd3	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "price": 99000, "rating": 5, "category": "Có phí", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "processingTime": "Giao ngay", "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "warrantyPolicy": "Không bảo hành", "requiresAccountType": false}	\N	\N	\N	2026-06-01 12:36:16.023
d1c7d315-a131-4b6a-b689-8516ffe10f5c	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "price": 100000, "rating": 5, "category": "Miễn phí", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "processingTime": "giao ngay", "seoDescription": "2026", "warrantyPolicy": "3 ngày", "requiresAccountType": false}	\N	\N	\N	2026-06-01 12:36:51.418
813286bb-3ecc-4062-8233-eaa81270149b	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": true, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-01 18:55:49.357
c101eae5-da69-423e-8a82-a088e9b11477	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "khóa học 1", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["1️⃣ ĐÀO TẠO DỊCH VỤ FACEBOOK - SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội - Lấy Lại Tài Khoản Facebook Bị Hack (Ép From) - Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 -"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-01 18:58:08.676
a2575895-545a-410b-a55f-e9257cc06392	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 3, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:16:33.469
1eec62f0-ba72-4d24-a3df-5fc4373feda1	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:22:12.202
c3d21cef-e888-43f1-b5d1-15d14bf13135	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": true, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-01 19:22:35.609
8f15b77b-8581-4c8a-9c2e-7eb8c063d5a4	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "commitments": ["Hoàn Tiền", "Dạy có cộng động học viên"], "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false, "registrationProcedure": "Nộp tiền là done"}	\N	\N	\N	2026-06-02 03:20:11.858
f95b2834-53a9-416a-a48c-ce3019d7d426	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "khóa học 1", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-02 03:31:43.971
594179f9-224b-4a1c-9ded-4cbe05c9d1a3	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_ADJUST_BALANCE	User	15bbcf73-c01d-4730-85d7-a1cca3730c83	{"balance": 41000}	{"amount": 5000000, "balance": 5041000}	\N	\N	\N	2026-06-02 10:04:43.062
a554077f-6ac8-462b-9836-de4ba3589c30	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	914a7223-ade0-464f-aeb8-2506fd1bd252	\N	{"id": "914a7223-ade0-464f-aeb8-2506fd1bd252", "name": "Mở Khóa Tài Khoản Vô Hiệu Hóa", "slug": "mo-khoa-tai-khoan-vo-hieu-hoa"}	\N	\N	\N	2026-06-02 12:01:32.512
bf146e42-2530-4610-b597-a94844b6f5a9	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	914a7223-ade0-464f-aeb8-2506fd1bd252	{"name": "Mở Khóa Tài Khoản Vô Hiệu Hóa", "slug": "mo-khoa-tai-khoan-vo-hieu-hoa", "price": "4500000"}	{"name": "Mở Khóa Tài Khoản Vô Hiệu Hóa", "slug": "mo-khoa-tai-khoan-vo-hieu-hoa", "price": 4500000, "rating": 4.8, "category": "Facebook", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401699924.png", "isFeatured": false, "totalViews": 4231, "description": "Mở Khóa Tài khoản vô hiệu hóa vĩnh viễn dạng 583, 811, 035 ...", "productList": [], "reviewCount": 342, "successRate": 100, "totalOrders": 423, "displayOrder": 1, "requiresCccd": true, "customerCount": 3213, "processingTime": "1-7 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:01:44.381
fdbfaad2-6939-4073-a47c-046297624a92	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	6b802cb2-5052-4578-9e7b-1b0281d6e820	\N	{"id": "6b802cb2-5052-4578-9e7b-1b0281d6e820", "name": "Mở khóa Tài khoản 956", "slug": "mo-khoa-tai-khoan-956"}	\N	\N	\N	2026-06-02 12:04:49.515
2166412d-f7bb-452a-90e6-bb9bc3cdfff4	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	1700c5db-6a48-48bf-9c5c-57037050267d	{"name": "Mở Khóa 282", "slug": "dvfb", "price": "200000"}	{"name": "Mở Khóa 282", "slug": "dvfb", "price": 200000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779616281373.png", "isFeatured": true, "totalViews": 1323123, "description": "abc", "productList": [], "reviewCount": 2144, "successRate": 100, "totalOrders": 132, "displayOrder": 2, "requiresCccd": true, "customerCount": 123, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "1 Tháng", "price": 150000}, {"name": "2 tháng", "price": 500000}], "platformVariants": [{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:02.993
76f5c2a5-e9fc-4959-ae1d-5dc69ea88fd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	d11fa0ca-9935-441c-9f62-d46cf4d45999	{"name": "Mở Khóa Fanpage Bị Đình Chỉ Đăng", "slug": "adadad", "price": "3500000"}	{"name": "Mở Khóa Fanpage Bị Đình Chỉ Đăng", "slug": "adadad", "price": 3500000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779618629337.png", "isFeatured": true, "totalViews": 2543, "description": "Update siêu tut khôi phục những fanpage thời gian nhanh nhất qua hệ thống meta ai auto tools !", "productList": [], "reviewCount": 21, "successRate": 100, "totalOrders": 212, "displayOrder": 3, "requiresCccd": true, "customerCount": 241, "processingTime": "3 Ngày", "warrantyOptions": [{"name": "24 giờ", "price": 0}, {"name": "1 tháng", "price": 3000000}], "platformVariants": [{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:10.784
b1df3c79-c8ce-4c7e-8e50-2f49b190bcc0	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	1700c5db-6a48-48bf-9c5c-57037050267d	{"name": "Mở Khóa 282", "slug": "dvfb", "price": "200000"}	{"name": "Mở Khóa 282", "slug": "dvfb", "price": 200000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779616281373.png", "isFeatured": true, "totalViews": 1323123, "description": "abc", "productList": [], "reviewCount": 2144, "successRate": 100, "totalOrders": 132, "displayOrder": 4, "requiresCccd": true, "customerCount": 123, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "1 Tháng", "price": 150000}, {"name": "2 tháng", "price": 500000}], "platformVariants": [{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:18.154
e2197186-43d7-45f1-a859-ec34f1ea2223	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	6b802cb2-5052-4578-9e7b-1b0281d6e820	{"name": "Mở khóa Tài khoản 956", "slug": "mo-khoa-tai-khoan-956", "price": "900000"}	{"name": "Mở khóa Tài khoản 956", "slug": "mo-khoa-tai-khoan-956", "price": 900000, "rating": 4.9, "category": "Facebook", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401926201.png", "isFeatured": false, "totalViews": 1412, "description": "Mở khóa những tài khoản bị dạng khóa két sắt tím và dạng khóa 956 két sắt mở", "productList": [], "reviewCount": 123, "successRate": 100, "totalOrders": 212, "displayOrder": 5, "requiresCccd": true, "customerCount": 324, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:27.854
2d49d6a0-07fd-4ab6-b4ae-2c3f9ad143e1	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	f2251457-dd7e-464f-8942-85447bf0fe95	\N	{"id": "f2251457-dd7e-464f-8942-85447bf0fe95", "name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip"}	\N	\N	\N	2026-06-02 12:07:13.982
693bd851-9d1d-4e05-bc31-ca07cb76f466	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	7d6cafc1-de27-4831-b383-6fb4fdf53e4c	\N	{"id": "7d6cafc1-de27-4831-b383-6fb4fdf53e4c", "name": "Tài khoản tiktok hạn chế đề xuất", "slug": "tai-khoan-tiktok-han-che-de-xuat"}	\N	\N	\N	2026-06-02 12:08:25.734
744a26aa-3aa5-49d3-89a8-a7bac17007d3	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	870c3504-944a-4833-a0ee-a25bef4c21e1	\N	{"id": "870c3504-944a-4833-a0ee-a25bef4c21e1", "name": "Xóa tài khoản tiktok mao danh", "slug": "xoa-tai-khoan-tiktok-mao-danh"}	\N	\N	\N	2026-06-02 12:09:51.855
794eb406-4a77-4175-b273-8206fe727ae7	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	39484b26-a985-4dcb-bccd-87aa3904aa9b	\N	{"id": "39484b26-a985-4dcb-bccd-87aa3904aa9b", "name": "Mở khóa video tiktok vi phạm", "slug": "mo-khoa-video-tiktok-vi-pham"}	\N	\N	\N	2026-06-02 12:10:39.596
7545f1cf-1a79-456f-845b-10dee4a8e2fd	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	c8f14b74-fff9-46ee-b36b-93fa0e33287f	\N	{"id": "c8f14b74-fff9-46ee-b36b-93fa0e33287f", "name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay"}	\N	\N	\N	2026-06-02 12:11:50.317
b5ac244b-e802-4afc-8413-50698f206fe9	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_ADJUST_BALANCE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"balance": 50509}	{"amount": 6666666, "balance": 6717175}	\N	\N	\N	2026-06-02 12:33:50.541
6f5d0781-53a9-4ae7-821c-5d5057bcb45b	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	1113abc4-9877-487d-82b4-588cf58f029b	\N	{"name": "Facebook", "iconUrl": "https://svgl.app/library/facebook-icon.svg"}	\N	\N	\N	2026-06-02 13:40:25.422
a870bf98-4b5d-48e2-8b8e-9d928f44be1d	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	32b13f3d-eb0c-4ca7-998d-95fb5a8416a8	\N	{"name": "TikTok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-02 13:40:27.445
013e0079-3a05-4117-9f0b-34e4db683272	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	636885d6-4e1a-439e-9809-9deaa8040a7a	\N	{"name": "YouTube", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-02 13:40:29.727
eb07b359-07e1-4880-b894-db94c9ea2f8d	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	d09c9d63-c764-496d-b276-6ded8a3a997f	\N	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-02 13:40:31.313
51003c5a-809b-4e37-9d05-273510c767a6	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_CREATE	TutTrick	2729244b-ae96-4a23-9703-180bb075df0a	\N	{"id": "2729244b-ae96-4a23-9703-180bb075df0a", "name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq", "hasContentUrl": false}	\N	\N	\N	2026-06-02 13:56:54.175
63dca868-bf97-4372-ab60-40c691059be0	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	636885d6-4e1a-439e-9809-9deaa8040a7a	{"name": "YouTube"}	\N	\N	\N	\N	2026-06-02 14:07:28.318
1d3d009c-882c-4591-9781-55f37bb01385	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	05ba9669-f0a5-4a3b-9abe-a0de72ce2ef6	\N	{"name": "YouTube", "iconUrl": "https://svgl.app/library/youtube.svg"}	\N	\N	\N	2026-06-02 14:07:30.641
2035eefa-34e1-4ad8-9859-1ce48baa6fd9	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	75261ce4-87c0-4447-8ee8-1f362ef473b5	{"name": "Tiktok"}	\N	\N	\N	\N	2026-06-06 15:42:11.039
17737fcf-fd0e-42b4-a64a-3c04324660a8	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Miễn phí", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 13:57:10.565
378437d7-ede3-4615-a4a1-076e6bbdd381	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail"}	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "tier": "Có phí", "price": 600000, "rating": 5, "category": "Có phí", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png", "isFeatured": false, "successRate": 100, "totalOrders": 123, "displayOrder": 3, "requiresCccd": false, "requiresAccountType": false}	\N	\N	\N	2026-06-02 13:57:25.659
9a02649e-6000-4bf7-a91f-3fd4e2357bea	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Có phí", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-02 13:57:32.189
81b544f3-594f-4832-8f98-070e87538ca9	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "TikTok", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:03.93
7601b43d-577f-4717-8f73-cf8c9000ee22	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:08.15
db7d8e64-9f24-4fbf-9677-861c5d5ec484	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Miễn phí", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:12.203
297b156b-0713-4ffb-aee0-474bde488012	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Instagram", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:15.786
f194578e-8359-429e-978a-067f78ee5765	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:20.658
e476a289-6e60-4552-961e-e4ddc9db7108	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail"}	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "tier": "Có phí", "price": 600000, "rating": 5, "category": "Instagram", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png", "isFeatured": false, "successRate": 100, "totalOrders": 123, "displayOrder": 3, "requiresCccd": false, "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:25.085
524acf98-eab0-4d1e-a756-e857c1fa390f	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail"}	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "tier": "Có phí", "price": 600000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png", "isFeatured": false, "successRate": 100, "totalOrders": 123, "displayOrder": 3, "requiresCccd": false, "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:29.096
6295f87c-335c-4aa9-82f5-b0e6b639585b	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	d09c9d63-c764-496d-b276-6ded8a3a997f	{"name": "Instagram"}	\N	\N	\N	\N	2026-06-02 14:07:13.221
5ba24119-98d6-489f-91a7-6840be3c5c97	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	99d356a9-4744-4678-9d73-51500d050b6a	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-02 14:07:33.435
cdafacb2-2692-4fad-afdc-34b09c6fe76a	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	99d356a9-4744-4678-9d73-51500d050b6a	{"name": "Google"}	\N	\N	\N	\N	2026-06-02 14:07:39.883
8b166058-0117-4b46-afbe-c566a86b5585	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_SLOT_PURCHASE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	\N	{"price": 120000, "slots": 10}	\N	\N	2026-06-02 19:05:28.864
a8510042-7276-40a9-a732-a3aa77682e95	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_REGISTRATION_REQUESTED	SellerRequest	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	\N	{"ip": "::1", "category": "Canva: a"}	\N	\N	2026-06-02 19:19:02.313
05d97715-4fb0-4c7d-a6c2-9b5dc96b2a28	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_REQUEST_REJECTED	SellerRequest	d7f444d4-7577-4561-a630-6908916d41d7	{"sellerStatus": "PENDING"}	{"rejectReason": "ad", "sellerStatus": "REJECTED"}	{"rejectReason": "ad"}	\N	\N	2026-06-02 19:19:27.034
cebdbc23-609e-4969-b523-550a3e219c3d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	b490690a-17bd-4b8b-8e8a-88f060bbbd9c	{"role": "ADMIN"}	{"role": "USER"}	\N	\N	\N	2026-06-02 19:25:45.272
8b9fc5d2-fd08-44d7-9aae-44cff0b9d669	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CREATE_USER	User	55d1694a-443e-4f08-8875-8dadff9cbf62	\N	{"role": "STAFF", "email": "nhanvien@gmail.com", "status": "ACTIVE", "fullName": "chu quang doanh"}	\N	\N	\N	2026-06-02 19:26:23.865
5259552c-4c35-44df-b2eb-01649c587d73	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	05ba9669-f0a5-4a3b-9abe-a0de72ce2ef6	{"name": "YouTube"}	\N	\N	\N	\N	2026-06-02 19:31:58.137
04aca532-b5f8-4c7f-8165-32d64d3bd03e	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	32b13f3d-eb0c-4ca7-998d-95fb5a8416a8	{"name": "TikTok"}	\N	\N	\N	\N	2026-06-02 19:31:59.849
eb78956f-f835-4cb5-a394-ba24767cfec1	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	4ad9b472-ceda-4b83-9d79-ddfb09c175d1	{"name": "Canva"}	\N	\N	\N	\N	2026-06-02 19:32:19.82
988a1fd4-1ffd-41fc-a3c3-06f3e051e972	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	c8f14b74-fff9-46ee-b36b-93fa0e33287f	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": "2500000"}	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": 2500000, "rating": 5, "category": "Intagram", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428759528.png", "isFeatured": false, "totalViews": 32123, "description": "Mở khóa những tài khoản instagram chính chủ", "productList": [], "reviewCount": 3242, "successRate": 100, "totalOrders": 2134, "displayOrder": 0, "requiresCccd": false, "customerCount": 4124, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 19:32:45.118
58968ca1-2353-4579-8ef5-bffd858a70db	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	7d6cafc1-de27-4831-b383-6fb4fdf53e4c	{"name": "Tài khoản tiktok hạn chế đề xuất", "slug": "tai-khoan-tiktok-han-che-de-xuat", "price": "1500000"}	{"name": "Tài khoản tiktok hạn chế đề xuất", "slug": "tai-khoan-tiktok-han-che-de-xuat", "price": 1500000, "rating": 4.9, "category": "Tiktok", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428774308.png", "isFeatured": false, "totalViews": 4321, "description": "Kháng nghị tài khoản tiktok hạn chế đề xuất kênh vi phạm cảnh báo đỏ", "productList": [], "reviewCount": 1231, "successRate": 100, "totalOrders": 243, "displayOrder": 2, "requiresCccd": false, "customerCount": 1231, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 19:32:56.836
9a373308-b56e-4573-94dc-45570b7cb4c3	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	f2251457-dd7e-464f-8942-85447bf0fe95	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": "600000"}	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": 600000, "rating": 5, "category": "Google", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428783583.png", "isFeatured": false, "totalViews": 241, "description": "30 đánh giá gg map 5 sao ngay lập tực cho gg map khi thanh toán chỉ cần link gg map cho chúng tôi. ", "productList": [], "reviewCount": 86, "successRate": 100, "totalOrders": 45, "displayOrder": 2, "requiresCccd": false, "customerCount": 132, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:33:06.238
4f29ff1f-3bd5-4506-b6a3-c91151871eee	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	39484b26-a985-4dcb-bccd-87aa3904aa9b	{"name": "Mở khóa video tiktok vi phạm", "slug": "mo-khoa-video-tiktok-vi-pham", "price": "1500000"}	{"name": "Mở khóa video tiktok vi phạm", "slug": "mo-khoa-video-tiktok-vi-pham", "price": 1500000, "rating": 5, "category": "Tiktok", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428792008.png", "isFeatured": false, "totalViews": 123, "productList": [], "reviewCount": 324, "successRate": 100, "totalOrders": 124, "displayOrder": 3, "requiresCccd": false, "customerCount": 3423, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 19:33:15.23
7562c5c8-4d63-4dd2-be3e-bdbaa549214f	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	870c3504-944a-4833-a0ee-a25bef4c21e1	{"name": "Xóa tài khoản tiktok mao danh", "slug": "xoa-tai-khoan-tiktok-mao-danh", "price": "1500000"}	{"name": "Xóa tài khoản tiktok mao danh", "slug": "xoa-tai-khoan-tiktok-mao-danh", "price": 1500000, "rating": 5, "category": "Tiktok", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428801249.png", "isFeatured": false, "totalViews": 212, "description": "Xóa tai khoản tiktok mạo danh chính chủ, yêu cầu cccd trùng thông tin ", "productList": [], "reviewCount": 54, "successRate": 100, "totalOrders": 34, "displayOrder": 3, "requiresCccd": true, "customerCount": 412, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:33:23.908
1a082138-15fe-4392-a6c6-9462bba1cb1c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	STAFF	\N	{"permissions": {"admin/chats": true, "admin/users": false, "admin/orders": true, "admin/courses": false, "admin/reviews": true, "admin/sellers": true, "admin/tickers": false, "admin/danh-gia": true, "admin/deposits": true, "admin/services": false, "admin/audit-log": false, "admin/dashboard": true, "admin/complaints": true, "admin/tut-tricks": false, "admin/withdrawals": false, "admin/mmo-products": false, "admin/san-pham-ban": true, "admin/cai-dat-ban-hang": false, "admin/course-categories": false, "admin/service-categories": false, "admin/resource-categories": false, "admin/tut-trick-categories": false}}	\N	\N	\N	2026-06-03 20:01:22.161
9705aebb-6060-46df-a957-6c3f516299e9	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 5}	{"discountPercent": 5}	\N	\N	\N	2026-06-04 07:50:48.497
7d8add15-9a58-47fb-aaa3-23fcfaa3ec0c	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:34:27.872
61b41d42-af8b-427b-a87c-4467ab7210c3	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:34:34.205
e8918950-cbc5-43f2-97a9-cdf1bd6e0657	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "Khóa học online", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:35:01.239
30b3db75-2254-4b2c-8232-2ccdce08ed30	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 3, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:35:12.108
a4c1439f-f269-4128-a43b-78e8385d6d7e	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "Khóa học online", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:38:18.1
c00b59be-721c-4b06-9f69-e0945eca2622	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_HARD_DELETE_USER	User	c687c44b-288e-4fb7-8817-cfebb988db15	{"role": "USER", "email": "lasvergasblackmeta@gmail.com"}	{"deleted": true}	\N	\N	\N	2026-06-03 03:04:35.317
2bc4c89b-d129-442e-ae56-321556847f3b	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	15bbcf73-c01d-4730-85d7-a1cca3730c83	{"role": "USER"}	{"role": "ADMIN"}	\N	\N	\N	2026-06-03 07:23:43.892
119d2f12-8bca-43ed-87b1-ce4c9049338f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	STAFF	\N	{"permissions": {"admin/chats": true, "admin/users": false, "admin/orders": true, "admin/courses": false, "admin/reviews": true, "admin/sellers": true, "admin/tickers": false, "admin/danh-gia": true, "admin/deposits": true, "admin/services": false, "admin/audit-log": false, "admin/dashboard": true, "admin/complaints": true, "admin/tut-tricks": false, "admin/withdrawals": false, "admin/mmo-products": false, "admin/san-pham-ban": true, "admin/cai-dat-ban-hang": false, "admin/course-categories": false, "admin/service-categories": false, "admin/resource-categories": false, "admin/tut-trick-categories": false}}	\N	\N	\N	2026-06-03 19:50:06.299
fb037e25-ad66-4778-a9be-0e70c35d0ced	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"role": "SELLER"}	{"role": "STAFF"}	\N	\N	\N	2026-06-03 19:51:34.925
df000555-d84f-4918-937c-6665c1e432a3	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	53f04ea0-9b5e-4f15-8a3a-76572bb81859	\N	{"status": "RESOLVED", "orderId": "3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05", "outcome": "seller_wins"}	\N	\N	\N	2026-06-04 03:10:58.386
e717f0af-faeb-4bc9-a1cc-47358623f87f	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 0}	{"discountPercent": 5}	\N	\N	\N	2026-06-04 07:50:45.316
3d019c8b-61af-466e-b80c-8f9fd45757e0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT_DELETE	SellerProduct	45a65117-624f-4e87-b2cc-add4714bc25e	{"name": "Tài khoản 250$"}	\N	\N	\N	\N	2026-06-04 11:31:54.487
78a53b59-dbf1-4566-9653-801f2903d371	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 5}	{"discountPercent": 5}	\N	\N	\N	2026-06-04 07:50:50.081
82911a91-8727-4064-894e-d7ceda67f5f3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_RESTRICTED	SellerProduct	a4a52a6a-5914-4f9d-9c07-606b73a5e842	{"isRestricted": false}	{"reason": "", "isRestricted": true}	\N	\N	\N	2026-06-04 07:59:51.523
bd934eb0-7989-4d12-81b1-6970c9f6c723	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_UNRESTRICTED	SellerProduct	a4a52a6a-5914-4f9d-9c07-606b73a5e842	{"isRestricted": true}	{"isRestricted": false}	\N	\N	\N	2026-06-04 07:59:54.095
cef625e9-03e1-49fa-bc29-0044a6ca29ca	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_RESTRICTED	SellerProduct	0fbf8797-e5c2-493a-b175-61f2b6b412ef	{"isRestricted": false}	{"reason": "", "isRestricted": true}	\N	\N	\N	2026-06-04 08:00:02.091
474d62e9-7205-43e0-be39-a110c8507b8d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_UNRESTRICTED	SellerProduct	0fbf8797-e5c2-493a-b175-61f2b6b412ef	{"isRestricted": true}	{"isRestricted": false}	\N	\N	\N	2026-06-04 08:00:18.939
72571b4d-f1ac-43c6-9f6c-6860ba071d05	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	STAFF	\N	{"permissions": {"admin/chats": true, "admin/users": true, "admin/orders": true, "admin/courses": false, "admin/reviews": true, "admin/sellers": true, "admin/tickers": true, "admin/danh-gia": true, "admin/deposits": true, "admin/services": false, "admin/audit-log": false, "admin/dashboard": true, "admin/complaints": true, "admin/tut-tricks": false, "admin/withdrawals": false, "admin/mmo-products": false, "admin/san-pham-ban": true, "admin/cai-dat-ban-hang": false, "admin/course-categories": false, "admin/service-categories": false, "admin/resource-categories": false, "admin/tut-trick-categories": false}}	\N	\N	\N	2026-06-04 08:03:44.776
28c02710-6b5b-4c89-bb3c-a66fce38966c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	USER	\N	{"permissions": {"don-hang": true, "nap-tien": true, "tro-chuyen": false, "lich-su-giao-dich": true, "thong-tin-ca-nhan": true}}	\N	\N	\N	2026-06-04 08:19:42.303
c76d1302-1c6a-4ff0-9f3f-f1126286b0ef	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Standard", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 3, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "gray", "feePercent": 5, "description": "Hạng mặc định khi được duyệt", "displayOrder": 0, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 7, "isActive": true, "badgeColor": "gray", "feePercent": 15, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 5000000}	\N	\N	\N	2026-06-04 08:29:18.835
3e491a30-a7c8-4530-851a-a7107f96c14f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	77f20ddc-fd13-4ba5-b536-30f12353c35d	{"id": "77f20ddc-fd13-4ba5-b536-30f12353c35d", "key": "SILVER", "label": "Silver", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 2, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "slate", "feePercent": 4, "description": "Seller hoạt động tích cực", "displayOrder": 1, "minWithdrawal": 150000, "upgradeMinOrders": 20, "upgradeMinRevenue": 5000000}	{"label": "Cấp 2", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 7, "isActive": true, "badgeColor": "slate", "feePercent": 13, "description": "Nhà bán hàng hoạt động tích cực", "displayOrder": 2, "minWithdrawal": 3500000, "upgradeMinOrders": 20, "upgradeMinRevenue": 5000000}	\N	\N	\N	2026-06-04 08:30:17.355
a9eb8af2-8b1d-4c7d-90e0-4d1b7438a5ee	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	9033a6a8-f624-4b37-af6c-d907a82dab11	{"id": "9033a6a8-f624-4b37-af6c-d907a82dab11", "key": "GOLD", "label": "Gold", "benefits": ["Phí rút tiền chỉ 3%", "Rút tối thiểu 100.000đ", "Badge Gold nổi bật"], "holdDays": 1, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "amber", "feePercent": 3, "description": "Seller có doanh thu tốt", "displayOrder": 2, "minWithdrawal": 100000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	{"label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	\N	\N	\N	2026-06-04 08:31:41.126
0396caf7-4040-43a7-b928-3be88862b041	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	9033a6a8-f624-4b37-af6c-d907a82dab11	{"id": "9033a6a8-f624-4b37-af6c-d907a82dab11", "key": "GOLD", "label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:31:41.111Z", "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	{"label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	\N	\N	\N	2026-06-04 08:31:44.238
27ff3dc6-ca4d-4eed-b8b8-eb0838b62a0c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	9033a6a8-f624-4b37-af6c-d907a82dab11	{"id": "9033a6a8-f624-4b37-af6c-d907a82dab11", "key": "GOLD", "label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:31:44.223Z", "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	{"label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 3, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	\N	\N	\N	2026-06-04 08:31:47.209
2fe97a6e-da7b-4e14-844f-d067629ce8f3	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_SHOP_UNLOCKED	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"shopLocked": true}	{"shopLocked": false}	\N	\N	\N	2026-06-04 11:36:05.931
b6787b10-90c8-4889-a2b3-ab652f4de328	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	89b3932c-59f2-4d51-abfa-c40ced675fc8	\N	{"status": "RESOLVED", "orderId": "0334e4cd-2a86-4638-b18b-2665b94c0143", "outcome": "seller_wins"}	\N	\N	\N	2026-06-04 12:13:31.517
b6145a2e-7cce-4223-834b-522c662c681c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "STANDARD"}	{"sellerTier": "SILVER"}	\N	\N	\N	2026-06-04 12:15:12.259
d9e7cefc-7951-42ee-9083-b7c9a484dcbb	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	1208edbf-e67b-42f8-a0c2-f115e20aacc3	{"id": "1208edbf-e67b-42f8-a0c2-f115e20aacc3", "key": "VIP", "label": "VIP", "benefits": ["Phí rút tiền chỉ 1%", "Không giữ đơn khi rút", "Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "violet", "feePercent": 1, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 3, "minWithdrawal": 50000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	{"label": "VIP", "benefits": ["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "badgeColor": "violet", "feePercent": 9, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	\N	\N	\N	2026-06-04 08:32:34.764
323bbd50-2e40-4932-9993-57e4c08ab7a5	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:29:18.813Z", "badgeColor": "gray", "feePercent": 15, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 5000000}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 7, "isActive": true, "badgeColor": "gray", "feePercent": 15, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	\N	\N	\N	2026-06-04 08:32:54.447
19bfba1c-1aa9-469c-8b8f-22bf37476476	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	77f20ddc-fd13-4ba5-b536-30f12353c35d	{"id": "77f20ddc-fd13-4ba5-b536-30f12353c35d", "key": "SILVER", "label": "Cấp 2", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:30:17.349Z", "badgeColor": "slate", "feePercent": 13, "description": "Nhà bán hàng hoạt động tích cực", "displayOrder": 2, "minWithdrawal": 3500000, "upgradeMinOrders": 20, "upgradeMinRevenue": 5000000}	{"label": "Cấp 2", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 7, "isActive": true, "badgeColor": "slate", "feePercent": 13, "description": "Nhà bán hàng hoạt động tích cực", "displayOrder": 2, "minWithdrawal": 3500000, "upgradeMinOrders": 20, "upgradeMinRevenue": 3000000}	\N	\N	\N	2026-06-04 08:33:01.458
aa078c81-e15c-4557-a690-147d46644e4a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"tier_config": {"VIP": {"hold_days": 5, "fee_percent": 8, "min_withdrawal": 5000000}, "GOLD": {"hold_days": 7, "fee_percent": 10, "min_withdrawal": 600000}, "SILVER": {"hold_days": 7, "fee_percent": 13, "min_withdrawal": 7000000}, "STANDARD": {"hold_days": 10, "fee_percent": 15, "min_withdrawal": 10000000}}, "slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "min_withdrawal_amount": 50000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 3, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:34:03.927
1170b04b-495a-4649-9275-932359f79a68	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	80270900-1509-4867-96a3-c1402df7412d	\N	{"status": "RESOLVED", "orderId": "2ec9ccff-7621-4925-a6df-6a6dc48a961a", "outcome": "seller_wins"}	\N	\N	\N	2026-06-04 08:36:11.939
b0513483-1b66-40df-95d4-78b0b4905379	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"role": "STAFF"}	{"role": "SELLER"}	\N	\N	\N	2026-06-04 08:37:53.93
918432e6-2bd5-49f1-952f-4634555b68b9	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 3, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:41:05.5
28863396-a2bd-46ff-8886-54a3551ef1a0	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 100000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:46:32.905
9ece502e-b5da-4620-8ea0-303904a99faa	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 100000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:47:17.363
92591004-0c83-4b5a-a15b-37ddff68f00b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "STANDARD"}	{"sellerTier": "VIP"}	\N	\N	\N	2026-06-04 08:48:36.33
efacc5a8-4612-42a2-bfc0-a510858184c2	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "VIP"}	{"sellerTier": "STANDARD"}	\N	\N	\N	2026-06-04 08:49:00.305
60f64e1e-5338-45e3-af41-9831208a3737	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_SHOP_LOCKED	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"shopLocked": false}	{"shopLocked": true}	\N	\N	\N	2026-06-04 11:28:30.138
a8e465f1-e890-4d0c-b3b8-e2e2cabfc367	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT_DELETE	SellerProduct	a4a52a6a-5914-4f9d-9c07-606b73a5e842	{"name": "Via Facebook Clone 2019"}	\N	\N	\N	\N	2026-06-04 11:31:33.178
8c47806c-06de-42a4-abe6-7337b55e6cf3	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "SILVER"}	{"sellerTier": "STANDARD"}	\N	\N	\N	2026-06-04 12:15:31.353
c6c9b6d3-7328-4a0e-a43a-9e8da77d640e	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_REVIEW	Review	33212fce-536f-4b54-ad55-955a881dacee	{"rating": 2, "comment": null}	{"rating": 5, "comment": null}	\N	\N	\N	2026-06-04 12:21:36.246
50eb2e0c-04d5-47a1-8098-ed5ce5635392	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 2, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "seoDescription": "Cam kết  hiểu  cv", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:24:49.181
30483bc7-7b09-4d78-aabf-928c1a71f6ae	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:25:53.001
fe7f9750-b888-4236-ae99-6060a9967872	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": false, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:26:14.277
d9870cf6-3bfb-47de-b018-82fff4592a6a	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	{"name": "Tài khoản tiktok", "slug": "tai-khoan-tiktok"}	{"name": "Tài khoản tiktok", "slug": "tai-khoan-tiktok", "price": 360000, "category": "Tài khoản tiktok ", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779734932645.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Tiktok", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:27:51.95
6269001f-e829-4c8d-84b3-d0c012a29a97	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	{"name": "VIA", "slug": "via"}	{"name": "VIA", "slug": "via", "price": 99000, "category": "Via 1m1", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779642138078.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Facebook", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:27:56.808
9e73bc1e-5974-496a-8fbf-8b9c32be8569	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_STOCK_ADD	MmoProduct	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	{"count": 1}	\N	\N	\N	2026-06-04 12:28:04.01
d7e22054-6ee4-4514-9043-f7fe008614cb	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:00:59.648
5b35606f-f4ff-4e56-9160-c0f92b8f10a1	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:01:01.055
cfdb898d-db3e-432d-aecc-08aac1cc2151	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-04 13:01:03.041
bdf6c83b-a7d2-4df3-93d3-e1ad34ea6f41	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:01:37.96
664fc925-3437-4bb7-b940-e50b22f48c73	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-04 13:01:45.786
acd7eda9-aaf3-497d-b028-d080504d7be4	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:01:53.752
5e3df5a8-2ffb-4d35-bb1b-1a1e68a8b643	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:02:08.527
2d0a8f89-af71-46a7-9d59-598d7cd63009	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:03:14.451
82cd6f98-4204-4e5e-ae3c-b4d2d9abf47d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:03:19.167
510bc90f-a7e5-4989-a150-31933f0787a2	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-04 13:03:21.546
a4217541-7177-4056-a639-f4ac65a7f347	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:03:23.931
fb819915-779f-4f1d-a82f-4f6b74e51a73	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:03:29.454
a6b6ad0e-a9ac-4cb0-acad-3f5415f0fc68	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SELLER_TIER	SellerTierDefinition	1c149d14-f5c4-43e4-93b5-f6f0c467c8da	\N	{"key": "SUPPER", "label": "Siêu VIP", "benefits": [], "holdDays": 3, "isActive": true, "badgeColor": "blue", "feePercent": 8, "description": "Nhà bán hàng kinh nghiệm", "displayOrder": 4, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	\N	\N	\N	2026-06-04 13:05:38.545
d3fad4b2-9f34-4f90-8b8b-215e5fddda71	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_CREATE	TutTrick	165f87a9-d530-48aa-beb9-c94995d60aae	\N	{"id": "165f87a9-d530-48aa-beb9-c94995d60aae", "name": "TUT MỞ KHÓA CHAT META", "slug": "tut-mo-khoa-chat-meta", "hasContentUrl": false}	\N	\N	\N	2026-06-05 16:14:51.063
81c2d478-c9cc-4830-b1bd-90c340cb2d98	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	57acac26-5f8e-4822-b755-d3db1017d7de	\N	{"status": "RESOLVED", "orderId": "e075b268-818d-41dc-9a2a-4f89177f1acf", "outcome": "seller_wins"}	\N	\N	\N	2026-06-06 14:21:56.251
0a5734b5-1c67-4182-9cae-1522cd225725	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	2729244b-ae96-4a23-9703-180bb075df0a	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq"}	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq", "tier": "Miễn phí", "price": 1000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "OTHER", "isFeatured": false, "successRate": 100, "totalOrders": 234, "displayOrder": 3, "requiresCccd": false, "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:21:02.815
d9d572c6-a925-4355-be00-3207ddc65ab5	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_ADJUST_BALANCE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"balance": 60175}	{"amount": 500000000, "balance": 500060175}	\N	\N	\N	2026-06-05 16:27:13.773
778b92d0-d6d0-48e9-ba0d-4d6d4b5e614b	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:32:47.251
4b398e12-0443-4869-924e-b8b926d0307e	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": false, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:33:18.281
2da80557-f33d-4fc3-a5eb-89a7ebb44697	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:37:28.885
d307eacf-665d-4123-b8cf-8f9fcb12d05a	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:39:18.747
51363895-6dc7-4908-8cee-10aa5354c3c4	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:39:39.468
bc22c220-626b-4112-8c93-e2a0b84c8003	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:43:17.955
3304c9f5-0e04-4c86-8b99-6c6070c3bb02	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:43:23.502
6c38c379-4b1f-4602-9545-1880db5ab345	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:43:28.929
11372430-5a3b-472e-8b79-a254d3ff648f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 7, "registration_fee": 10000, "min_withdrawal_amount": 200000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-05 16:56:46.127
4fe8a214-5cfd-4586-b8b3-28dab0b3f9c8	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 7, "registration_fee": 10000, "min_withdrawal_amount": 200000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-05 16:59:05.016
74e7fbfd-b169-48a8-b32b-19f4a2d2a95f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 30}	\N	\N	\N	2026-06-05 16:59:26.813
684651ec-d25c-43d4-b22e-864343344355	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"sellerTier": "STANDARD"}	{"sellerTier": "VIP"}	\N	\N	\N	2026-06-05 17:00:04.967
448a45c9-f72f-4a6d-93fa-f533e8bfda2d	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 30}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 20}	\N	\N	\N	2026-06-05 17:00:56.933
063b791f-bd46-4150-ab82-b976a8fb1ac4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:05:35.536
80ebf986-7394-4d63-b717-d312b5cabbef	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:06:01.334
f235ca65-d0ef-4b04-a276-191d367fef99	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:06:14.874
957e7665-ec7a-4130-add9-f2862f68d9c4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:07:11.936
8c69e9f0-d64d-4618-8889-f106f32e2d4c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:19:55.069
b64f6c08-7549-4dc5-a7e1-a5e55969eb8a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:19:57.12
8f65c793-2c17-40c4-9ed2-e5326f60925a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:32:36.198
42d3e9d3-ad2b-4fb7-bad6-5fdf17776ee9	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:32:58.93
acefe409-a905-46c1-8ce1-d6f47aaf66bd	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:33:00.056
25771b2b-af24-4117-9557-d8a5149132a9	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:33:17.137
5efdaaf3-4f8d-4f5e-ae71-6cfccf284400	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:33:55.909
a1df9ea2-c0f0-42e9-b3fe-00212e29b05b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:34:12.969
7d9c5e3e-9951-4c07-b203-3ae00d35b0e7	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:35:44.07
da51d591-5006-4457-b104-f6ded9eb2607	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 18:06:54.321
7d0db511-5ad9-491c-9639-0995a3fb7a2a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 18:15:51.295
64ce77e7-61d7-4827-bf2c-ce1cb305b1ba	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	db70abee-03c1-4208-810b-81d28e28290f	\N	{"name": "TOOL MMO", "iconUrl": "https://svgl.app/library/wordpress.svg"}	\N	\N	\N	2026-06-05 18:27:18.861
e66714bc-65ec-4c42-ab5a-62063cc0522d	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_CREATE	MmoProduct	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	{"id": "7418205f-3c53-4823-ab68-d5c9a1b17f6a", "name": "TOOL JOIN BOX TELEGRAM", "slug": "tool-join-box-telegram"}	\N	\N	\N	2026-06-05 18:28:49.924
57b1f915-54ec-4395-a61e-ad7c68e4e4fb	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_STOCK_ADD	MmoProduct	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	{"count": 6}	\N	\N	\N	2026-06-05 18:29:08.409
6db4ebcd-e359-4fae-b04b-cba7de3f3936	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 02:32:37.234
02840e02-d493-4904-8ccc-477b10fcfe35	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 02:52:42.17
ccc9bfad-cbe7-4e0d-9959-13c201c6121f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 02:53:24.46
ee446086-eb78-43af-88ae-951b39ec61b1	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:04:03.517
640ac050-1f78-4046-9e7f-072c863e15aa	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:04:10.79
ce9434db-addd-4bc1-a838-937987892147	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:05:05.428
611fe0f0-52b4-4ccd-b648-9cc02f96f73c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:17:21.627
c4fbda7d-e298-4de3-b1f4-4cf9b872e98d	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-05T17:00:56.914Z", "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 10000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 10000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	\N	\N	\N	2026-06-06 03:30:27.075
cae40fa5-0b07-4aff-8fdc-5cab7f5301b8	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:34:31
ae4009ba-7e3b-440c-aab8-c72f6bb934e3	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 07:41:29.516
6a4a37e8-c429-407c-b781-9502ed923d51	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 5}	{"discountPercent": 5}	\N	\N	\N	2026-06-06 14:51:12.596
5670b0d2-0eef-445c-a8e8-fd6f0a5851fb	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_CATEGORY_CREATE	CourseCategory	17e7f260-7123-4117-aaaa-84a0ff9ce385	\N	{"icon": "https://svgl.app/library/instagram-icon.svg", "name": "Intagram"}	\N	\N	\N	2026-06-06 14:58:23.694
e1c5a5db-0d21-4587-a6b0-6bf2d96339c6	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	1ab87278-fbbc-4951-a896-d56e99d6b778	{"name": "Icloud"}	\N	\N	\N	\N	2026-06-06 14:58:30.551
c8fe438e-4980-416a-b4ed-1d361d6f3e43	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	6ab091d4-57d5-4a54-b817-6b059ace99f5	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 14:58:34.359
405889db-2fe2-4b71-a8b3-f6069bf72624	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	4aa374ce-65d3-47c8-b4ef-3d6a1aa4c42d	{"name": "Intagram"}	\N	\N	\N	\N	2026-06-06 14:58:36.697
da027773-d8c3-4cc3-945d-d5c4803d13ab	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	385c063d-63ce-414e-9793-4d9e02267b61	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 14:58:45.925
17a20277-0a90-491c-a88d-b06e61f7aed8	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	385c063d-63ce-414e-9793-4d9e02267b61	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 15:07:52.679
1f5b0258-a686-4fac-b356-df6662d649f0	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	ad51f6c1-4a8d-4237-ba55-0958fe2041af	{"name": "Tiktok"}	\N	\N	\N	\N	2026-06-06 15:07:54.643
443f8928-2c02-420b-bdb6-fa41a4c5e99b	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	75261ce4-87c0-4447-8ee8-1f362ef473b5	\N	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:08:47.083
7d5a0f78-45ed-46fb-ae40-353374616f8b	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	e410cf1a-2a57-4179-a9da-67a5de2ed875	\N	{"name": "Instargram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-06 15:09:04.468
88344cd4-4e59-48fc-9f18-7b15c8dacce3	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	314a50b6-1fcd-45da-88ea-80fb6e31274c	\N	{"name": "Goole", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:20:54.354
54df2f71-538c-48c5-8f4e-267a774b2600	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	47ac02aa-34d0-4557-9e24-3333a89ee8fe	\N	{"name": "Youtube", "iconUrl": "https://svgl.app/library/youtube.svg"}	\N	\N	\N	2026-06-06 15:21:03.601
a4fb4369-c0f8-46f9-addf-7c7fbab95052	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	b2a4ef6e-4502-4435-8d9f-78c4d4b1abcc	\N	{"name": "Icloud", "iconUrl": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780759302415.png"}	\N	\N	\N	2026-06-06 15:21:45.264
2111f0d3-ae9f-4901-a6e7-ea4a2f61f423	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_RESOURCE_CATEGORY	ResourceCategory	5f939196-fba1-41fb-930e-a12293a336be	{"name": "Youtobe", "iconUrl": "https://svgl.app/library/youtube.svg"}	{"name": "Youtube", "iconUrl": "https://svgl.app/library/youtube.svg"}	\N	\N	\N	2026-06-06 15:22:05.618
c66d0087-d17a-4054-befc-1c791ca7701e	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	50707025-9e6c-4793-a0e2-f9ea7f37b4aa	{"name": "Tài Khoản X"}	\N	\N	\N	\N	2026-06-06 15:22:09.093
826b6207-a6f9-4834-b611-df796d02caed	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	e1655a16-b14e-46c9-940f-309c29ce0865	{"name": "Linkedln"}	\N	\N	\N	\N	2026-06-06 15:22:12.538
7fc5697f-3344-4672-8fbe-4c0833503d05	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	32cbfa2a-44ad-4f67-bcc4-49e08d77f35c	{"name": "Game"}	\N	\N	\N	\N	2026-06-06 15:22:15.404
0c60a4e3-cd31-4549-979b-e450cd919843	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	0fa33473-2d75-4a9a-9fc2-76271dfa8e50	\N	{"name": "Game", "iconUrl": "https://svgl.app/library/discord.svg"}	\N	\N	\N	2026-06-06 15:22:33.589
af83c738-879b-4f6d-89d2-afdb3bf5a820	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	71711987-ef35-49cf-b539-330e82e51292	{"name": "Facebook"}	\N	\N	\N	\N	2026-06-06 15:22:41.645
73f29e5d-b057-4be6-a268-ed85d13f51c6	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	419bc0f9-85c4-4ede-a5b0-cc52b7a6277f	{"name": "Tiktok"}	\N	\N	\N	\N	2026-06-06 15:22:43.69
5061894a-5a35-4a38-ab82-06bc33997c06	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	e43b3fe4-5e35-43e6-900b-4c7f012de236	{"name": "Intagram"}	\N	\N	\N	\N	2026-06-06 15:22:45.599
867a2e30-df07-442b-bf0d-ce47109754a2	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	1b8b64a6-180a-443f-8311-ef806002b028	{"name": "Telegram"}	\N	\N	\N	\N	2026-06-06 15:22:47.562
e2913e58-717e-4e85-817b-05dabb404580	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	10317a5d-cdd2-4739-bb58-9ba1412cabad	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 15:22:49.734
411b1ae4-b2f8-4df9-a1f4-73b91071b700	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	db70abee-03c1-4208-810b-81d28e28290f	{"name": "TOOL MMO"}	\N	\N	\N	\N	2026-06-06 15:22:51.65
b6f93f58-7293-455b-b34b-60934cc28f47	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	0fa33473-2d75-4a9a-9fc2-76271dfa8e50	{"name": "Game"}	\N	\N	\N	\N	2026-06-06 15:22:54.432
434ca49d-2657-487e-b4e0-c0c0ef123455	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	5f939196-fba1-41fb-930e-a12293a336be	{"name": "Youtube"}	\N	\N	\N	\N	2026-06-06 15:22:55.914
a38b2474-ce90-43d5-8c38-1aa73912c70d	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	ad1a3184-4a2b-4029-b3fa-8063074f2f77	\N	{"name": "Facebook", "iconUrl": "https://svgl.app/library/facebook-icon.svg"}	\N	\N	\N	2026-06-06 15:23:03.083
46bab789-b39f-4786-8732-dca72e51730c	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	d98e03fb-feec-4455-8aaa-893fbccaf9a7	\N	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:23:09.876
f8952b2d-e935-4c75-a646-965ce84db9cb	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	6ca6cdb1-0183-4dd6-a348-f264e2a33512	\N	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-06 15:23:18.589
431bafdc-ff3d-4ff8-a1ee-c30a113ecb32	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	8f4f7ad2-7f34-43b0-ae38-935e0758e82b	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:23:26.876
d5b44e59-ecac-4c02-8d13-2660d7e23871	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	78e57057-c212-4537-96d4-9d2394da5df4	\N	{"name": "Telegram", "iconUrl": "https://svgl.app/library/telegram.svg"}	\N	\N	\N	2026-06-06 15:23:53.422
97b2ac13-2c79-4fcd-9c2f-873fbb61f25f	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	2ea180f3-e393-46f7-b0cf-3586c758e1c7	\N	{"name": "Tool Telegram", "iconUrl": "https://svgl.app/library/wordpress.svg"}	\N	\N	\N	2026-06-06 15:24:04.9
91623365-988f-453f-b2fa-32825513ba61	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	39588a82-d0c1-491a-ba88-652868b25fef	\N	{"name": "TikTok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:24:21.587
65dc10d4-c061-46dc-adb6-0311e39afdd0	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	52a61ea7-7047-48c5-ba8c-6ea1e893e0c1	\N	{"name": "Game", "iconUrl": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/resource-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780759657943.png"}	\N	\N	\N	2026-06-06 15:27:40.782
79c198e2-c3dd-4336-8ad8-26883ee618ca	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SERVICE_CATEGORY	ServiceCategory	314a50b6-1fcd-45da-88ea-80fb6e31274c	{"name": "Goole", "iconUrl": "https://svgl.app/library/google.svg"}	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:41:53.687
7b87be7e-8e87-4cf8-b819-e3df5344f44a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SERVICE_CATEGORY	ServiceCategory	75261ce4-87c0-4447-8ee8-1f362ef473b5	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:42:00.332
e5d7c609-9950-41ae-b413-24b112e1b3c3	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	314a50b6-1fcd-45da-88ea-80fb6e31274c	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 15:42:04.872
93d3e129-ce86-43d3-95d5-2ca3d3b5ae6d	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	47ac02aa-34d0-4557-9e24-3333a89ee8fe	{"name": "Youtube"}	\N	\N	\N	\N	2026-06-06 15:42:12.793
89104aac-1efd-46aa-9946-eae164c2ec18	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	836babc6-6e6a-456e-9dca-091c49c2ed62	\N	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:42:18.22
d16d2fce-1b64-4106-9d1c-11ca7ebb2140	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	ed072890-2b5e-440b-a248-19de9dd310c4	\N	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-06 15:42:28.781
b67fdffa-e8c0-4ad2-9aa6-244b5dde8399	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	d9fc7056-0e96-4184-8f52-10e494d01bff	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:42:36.55
4c626f33-6162-40ea-96d0-5ada83e9a14b	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	bd783349-7a97-4dba-b969-d346a8fd0a3f	\N	{"name": "Icloud", "iconUrl": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780760568205.png"}	\N	\N	\N	2026-06-06 15:42:51.43
f1e8931f-5dd7-4793-b03b-257bfe89e5ba	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	b3d4bf87-fe9d-4dd6-bc29-fe9c49a50bd5	{"name": "Xóa Đánh Gía GG MAP", "slug": "xoa-danh-gia-gg-map", "price": "1500000"}	{"name": "Xóa Đánh Gía GG MAP", "slug": "xoa-danh-gia-gg-map", "price": 1500000, "rating": 5, "category": "Google", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780047000131.png", "isFeatured": true, "totalViews": 21422, "productList": [], "reviewCount": 124, "successRate": 100, "totalOrders": 240, "displayOrder": 1, "requiresCccd": true, "customerCount": 423, "processingTime": "1 NGÀY", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-06 15:43:18.829
c77166e3-05eb-46a9-9a50-17d1ebe2ec48	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	f2251457-dd7e-464f-8942-85447bf0fe95	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": "600000"}	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": 600000, "rating": 5, "category": "Google", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428783583.png", "isFeatured": false, "totalViews": 241, "description": "30 đánh giá gg map 5 sao ngay lập tực cho gg map khi thanh toán chỉ cần link gg map cho chúng tôi. ", "productList": [], "reviewCount": 86, "successRate": 100, "totalOrders": 45, "displayOrder": 2, "requiresCccd": false, "customerCount": 132, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": false}	\N	\N	\N	2026-06-06 15:43:25.501
f03abcac-42e3-4994-8cff-6706e9245eee	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	c8f14b74-fff9-46ee-b36b-93fa0e33287f	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": "2500000"}	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": 2500000, "rating": 5, "category": "Instagram", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428759528.png", "isFeatured": false, "totalViews": 32123, "description": "Mở khóa những tài khoản instagram chính chủ", "productList": [], "reviewCount": 3242, "successRate": 100, "totalOrders": 2134, "displayOrder": 0, "requiresCccd": false, "customerCount": 4124, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-06 15:43:48.339
1b09be8a-3131-4242-923e-b2d159cec0eb	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	d58b451d-8402-4f2d-987d-9f007ef03fa8	\N	{"name": "Intagram", "iconUrl": null}	\N	\N	\N	2026-06-06 15:46:09.245
524fded0-8b2d-402e-ad34-93511e24bef8	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	7a270438-cff5-4f5c-93a7-30d1e771bf9b	{"name": "Tài khoản intagram cổ trust 2021", "slug": "tai-khoan-intagram-co-trust-2021"}	{"name": "Tài khoản intagram cổ trust 2021", "slug": "tai-khoan-intagram-co-trust-2021", "price": 259000, "category": "intagram", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780244746727.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Instagram", "requiresAccountType": false}	\N	\N	\N	2026-06-06 15:46:25.464
eab7b866-b59c-4ddd-9365-4577eee1e6ef	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	7418205f-3c53-4823-ab68-d5c9a1b17f6a	{"name": "TOOL JOIN BOX TELEGRAM", "slug": "tool-join-box-telegram"}	{"name": "TOOL JOIN BOX TELEGRAM", "slug": "tool-join-box-telegram", "price": 500000, "category": "tool telegram", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780684116099.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Tool Telegram", "requiresAccountType": false}	\N	\N	\N	2026-06-06 15:46:40.167
bb0e6cb8-53a6-475f-81a3-adcc3dd6f43c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 16:13:44.675
25628046-eb88-4667-b525-081c891f4da6	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	USER	\N	{"permissions": {"don-hang": true, "nap-tien": true, "tro-chuyen": true, "lich-su-giao-dich": true, "thong-tin-ca-nhan": true}}	\N	\N	\N	2026-06-06 16:13:55.989
a69f5dc4-5560-4e20-9fb5-188c4ebfb7e6	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	{"name": "VIA", "slug": "via"}	{"name": "VIA Trust Us", "slug": "via", "price": 99000, "category": "Via 1m1", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779642138078.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Facebook", "requiresAccountType": false}	\N	\N	\N	2026-06-06 16:16:02.441
f53174b8-92f5-4ffa-a60d-b1abe16e68fc	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	2729244b-ae96-4a23-9703-180bb075df0a	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq"}	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq", "tier": "Miễn phí", "price": 1000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780762576912.png", "isFeatured": false, "successRate": 100, "totalOrders": 234, "displayOrder": 3, "requiresCccd": false, "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-06 16:16:22.592
0840be45-8346-4638-b097-b6ab8016e9f1	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	d58b451d-8402-4f2d-987d-9f007ef03fa8	{"name": "Intagram"}	\N	\N	\N	\N	2026-06-06 16:16:42.524
09e6fb8f-23b3-43a0-b95d-ea684d2f1641	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_ADJUST_BALANCE	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"balance": 0}	{"amount": 500000, "balance": 500000}	\N	\N	\N	2026-06-06 16:22:46.601
4256285b-4c2b-4d1e-96a0-c43d34bc6333	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	b02bd798-3e00-4b18-b2ec-5c6f2b99272a	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:33.81
668a1d3b-87c0-47b3-be00-064db7533568	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	fb17d681-5f52-4792-9c2e-c5f8c77f12d9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:44.955
539b259a-e8cd-4dc5-b9c2-4934ad15953b	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	0413bfac-9275-4f8b-a143-2e30066e9bc9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:54.023
513839e6-4f61-4c81-b881-02230bb4357a	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	fa22247f-ec6f-435b-b070-57419639397d	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:55.584
a0f97c0b-25a3-45f3-8400-7affa67a1595	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	b34e9db7-b2de-41a5-8ecb-a0301ead185f	{"status": "FROZEN"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:24:51.625
dd847648-1f77-441d-ab0c-252c8e086e50	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	{"status": "FROZEN"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:25:00.797
f2e78f25-4cc5-4bc1-8bce-d81f9489b3f4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 17:55:30.408
41d8d02f-ee10-4c39-a25d-892d0fa7f157	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 17:57:13.148
314ea32b-e360-4e47-adec-f66369e4eda1	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 18:05:33.514
0d03eaaa-4369-4fb4-a8c4-33aa7ddd3b05	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 18:37:27.357
08bae780-eb9c-460f-9263-e04b88df6e7b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-08 03:04:35.137
1d716d5a-4288-40ba-a797-d456f76ac5aa	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": false, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-08 08:55:01.625
\.


--
-- Data for Name: bank_change_requests; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."bank_change_requests" ("id", "seller_id", "bank_name_enc", "bank_account_number_enc", "bank_account_holder_enc", "status", "reject_reason", "reviewed_by_user_id", "reviewed_at", "created_at") FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."chat_messages" ("id", "room_id", "sender_id", "sender_name", "sender_label", "content", "created_at") FROM stdin;
c55b524a-7459-4816-9d58-3b4310c2b8f3	43a125a9-fa00-4d9e-aa46-0a56f038acd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Xin chào	2026-05-26 15:52:55.232
528fe7bc-840c-43df-ae3c-890b993876c0	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	Mình cần xử lý đơn hàng	2026-05-26 16:01:14.341
9fc1b925-3c44-484d-a725-c54826923b39	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	ama	2026-05-26 16:02:00.672
fea386d1-da86-4a86-8a3b-e300288133a4	43a125a9-fa00-4d9e-aa46-0a56f038acd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Hỗ trợ xử lý đơn hàng	2026-05-26 16:33:28.119
a8ba9cbd-3c42-4eb6-8577-4eab4aa03b59	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	đấ	2026-05-26 16:34:10.353
92ca08d2-73a5-40fa-a656-cd1b8d2dc164	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Hỗ trợ  xử lý  đơn hàng khách hàng công khai !	2026-05-26 16:34:54.473
8adbe392-5ad7-47b3-9d90-13c755b7165c	3fec273c-4e76-43fe-9160-375ea69bad9d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	Xử  lý ngay	2026-05-26 16:35:59.888
16fa778f-8411-4be1-88c6-3d4b3a601967	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	a	2026-05-26 16:42:20.494
52022327-2505-4ea8-a928-cd7385bf514d	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	a	2026-05-26 16:42:32.059
70c009bd-cb3f-4bf4-80db-7c4e73a7061c	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	a	2026-05-26 16:42:40.662
e9584a07-daf6-42dc-9186-8dde4d408fad	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Của bạn gặp vaansd dề gì	2026-05-26 16:46:32.588
0b0e212e-fe14-4599-a1bf-c10d9513116f	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	chúng tôi sẽ hỗ trợ xử lý ngay cho bạn	2026-05-26 16:46:40.816
db829c24-dc42-4021-91f5-6048656015fb	137076b5-d499-4115-b753-1699ba023dc9	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	addad	2026-05-26 17:41:16.203
dc24101f-7454-4b0b-be7c-aa5e719d27e7	f1700988-9793-4b43-b824-f1edc99a108a	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	aa	2026-05-26 18:14:53.647
13402385-6572-4541-b5f9-ab0a4ee04422	f1700988-9793-4b43-b824-f1edc99a108a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	hello	2026-05-26 18:15:39.215
c45449e0-190a-4b49-8d2e-77e72dd67145	55f9caf9-090f-4d97-b026-4d23f75ad69d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Đơn hàng của  bạn đã được xác nhận thành công không thể hoàn  tiền	2026-05-26 20:22:20.822
c6481b0a-90fa-410c-bbbb-6e6d91cb1476	406c1105-43bd-4e65-a0b2-82940747ce7f	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	XỬ LÝ  NGAY	2026-05-27 07:35:24.185
8b658916-c9dd-4b01-9c2c-debeb2db5665	406c1105-43bd-4e65-a0b2-82940747ce7f	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Chuquangdoanh	Nhà bán hàng	1	2026-05-27 07:35:34.599
d7f5aa30-8159-49eb-bcfd-afd1d6bfff39	406c1105-43bd-4e65-a0b2-82940747ce7f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	2	2026-05-27 07:35:45.759
\.


--
-- Data for Name: chat_participants; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."chat_participants" ("id", "room_id", "user_id", "label", "joined_at") FROM stdin;
0af5a9dc-2949-4557-b2f8-e5fb66e84655	43a125a9-fa00-4d9e-aa46-0a56f038acd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 15:52:51.067
a155d0e8-6693-4206-9663-be16a94ef4b9	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 15:52:51.067
2c20d0c4-d9bc-4db4-92a6-ea72bbaea1d2	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 16:34:43.855
4a06bb0f-b9f6-4c99-80f9-4d48c95d6ae8	3fec273c-4e76-43fe-9160-375ea69bad9d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 16:34:43.855
17621fc5-c541-4a61-8e48-112d8af5d3bd	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 16:42:16.156
ea428b82-6bbd-4b31-b4d4-8b2d5b58478e	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 16:42:16.156
42b4bc99-f820-435d-94bc-07b8a45dc80e	137076b5-d499-4115-b753-1699ba023dc9	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 17:41:06.387
d1186846-50eb-46a8-9874-6195b776253f	137076b5-d499-4115-b753-1699ba023dc9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 17:41:06.387
67a63d7d-eac2-41d2-9a21-f2986e394cd0	f1700988-9793-4b43-b824-f1edc99a108a	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 18:14:18.128
30fa5c0c-d551-4686-9148-68a4a01bb35b	f1700988-9793-4b43-b824-f1edc99a108a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 18:14:18.128
b6d2dbbe-55f7-44c3-b960-8896fe20db57	dad82d96-9d0f-4742-a384-b070659416ad	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 20:14:21.278
d4692abe-7bc1-4447-83a5-5e90176fe7dd	dad82d96-9d0f-4742-a384-b070659416ad	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 20:14:21.278
6b3d419b-9de8-4a29-a87b-c24c545c735b	55f9caf9-090f-4d97-b026-4d23f75ad69d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 20:21:50.027
01f7d461-c930-4f9f-b946-e661f8fb2dae	55f9caf9-090f-4d97-b026-4d23f75ad69d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 20:21:50.027
fe413b31-f2fe-4046-8e27-293bb8172c4b	2b6ee792-3409-4c34-b675-5c4ea1dfd94c	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 20:24:40.094
92c3ae04-d465-428f-bf71-752b21ea6be5	2b6ee792-3409-4c34-b675-5c4ea1dfd94c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 20:24:40.094
005dc447-aaa4-40f1-9515-5a826dd29886	406c1105-43bd-4e65-a0b2-82940747ce7f	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-27 07:35:06.528
b1adbe48-5f44-4aa0-a8fc-bbc18731f204	406c1105-43bd-4e65-a0b2-82940747ce7f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-27 07:35:06.528
aabfb05e-f36d-4b7a-acdc-2d5c75a0944c	406c1105-43bd-4e65-a0b2-82940747ce7f	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Nhà bán hàng	2026-05-27 07:35:06.528
\.


--
-- Data for Name: chat_rooms; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."chat_rooms" ("id", "complaint_id", "created_at") FROM stdin;
43a125a9-fa00-4d9e-aa46-0a56f038acd8	5d6ad5ab-7fcd-452f-8546-2fd338dc9128	2026-05-26 15:52:51.067
3fec273c-4e76-43fe-9160-375ea69bad9d	2cb7f08b-8193-4319-b249-946a92ff29b2	2026-05-26 16:34:43.855
b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	81444c36-4596-4aff-9797-3bd13051fc07	2026-05-26 16:42:16.156
137076b5-d499-4115-b753-1699ba023dc9	577b1d94-2ec5-4b2a-8f40-ee1013d3491b	2026-05-26 17:41:06.387
f1700988-9793-4b43-b824-f1edc99a108a	dc87e547-2db2-44b1-a85d-4f7766d77352	2026-05-26 18:14:18.128
dad82d96-9d0f-4742-a384-b070659416ad	77359dd4-9b9c-4ca0-8ec2-ff589ecb8358	2026-05-26 20:14:21.278
55f9caf9-090f-4d97-b026-4d23f75ad69d	fd9addea-3163-415e-820d-e4e16970da61	2026-05-26 20:21:50.027
2b6ee792-3409-4c34-b675-5c4ea1dfd94c	4959b6d7-24ad-4f97-ad3f-643dc3a6b422	2026-05-26 20:24:40.094
406c1105-43bd-4e65-a0b2-82940747ce7f	bb3a017f-1e5c-44d0-b032-ffd8645d8e1b	2026-05-27 07:35:06.528
\.


--
-- Data for Name: complaints; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."complaints" ("id", "user_id", "order_id", "subject", "content", "status", "resolution", "resolved_by_user_id", "resolved_at", "created_at", "updated_at") FROM stdin;
5d6ad5ab-7fcd-452f-8546-2fd338dc9128	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fc287ba1-28b3-4daa-b4eb-f159632298b5	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 16:33:48.855	2026-05-26 14:37:07.064	2026-05-26 16:33:48.855
81444c36-4596-4aff-9797-3bd13051fc07	3ad147cc-59c4-4623-ba0d-59011dcb6b93	f5986697-1fe9-4778-9f32-540d877b9813	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 16:43:30.285	2026-05-26 16:42:06.538	2026-05-26 16:43:30.288
2cb7f08b-8193-4319-b249-946a92ff29b2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	90604f49-f398-4a4e-8660-e7225e19d6cc	Không nhận được hàng	addd	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 16:48:54.722	2026-05-26 14:30:43.148	2026-05-26 16:48:54.723
577b1d94-2ec5-4b2a-8f40-ee1013d3491b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b34e9db7-b2de-41a5-8ecb-a0301ead185f	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 17:41:28.813	2026-05-26 17:40:55.498	2026-05-26 17:41:28.814
dc87e547-2db2-44b1-a85d-4f7766d77352	3ad147cc-59c4-4623-ba0d-59011dcb6b93	287872ad-aaba-4d2c-941c-dc2b8806d4ce	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 18:16:55.102	2026-05-26 18:14:01.647	2026-05-26 18:16:55.102
77359dd4-9b9c-4ca0-8ec2-ff589ecb8358	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 20:14:25.972	2026-05-26 20:14:09.065	2026-05-26 20:14:25.974
fd9addea-3163-415e-820d-e4e16970da61	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4f2127c4-9914-4e8e-8d09-d312f2286323	Khác	Tôi    muốn hoàn  tiền	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 20:22:24.1	2026-05-26 20:21:32.328	2026-05-26 20:22:24.1
4959b6d7-24ad-4f97-ad3f-643dc3a6b422	3ad147cc-59c4-4623-ba0d-59011dcb6b93	373ca467-4600-4dfa-a72e-76b20d5abb52	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 20:28:34.817	2026-05-26 20:24:29.129	2026-05-26 20:28:34.818
bb3a017f-1e5c-44d0-b032-ffd8645d8e1b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	47951cf1-b33a-407e-8853-705086363659	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-27 07:36:42.11	2026-05-27 07:33:57.315	2026-05-27 07:36:42.111
53f04ea0-9b5e-4f15-8a3a-76572bb81859	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 03:10:58.354	2026-06-02 09:36:47.287	2026-06-04 03:10:58.357
80270900-1509-4867-96a3-c1402df7412d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2ec9ccff-7621-4925-a6df-6a6dc48a961a	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:36:11.913	2026-06-02 12:35:08.234	2026-06-04 08:36:11.914
89b3932c-59f2-4d51-abfa-c40ced675fc8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0334e4cd-2a86-4638-b18b-2665b94c0143	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 12:13:31.488	2026-06-04 11:39:13.429	2026-06-04 12:13:31.49
57acac26-5f8e-4822-b755-d3db1017d7de	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e075b268-818d-41dc-9a2a-4f89177f1acf	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 14:21:56.167	2026-06-06 14:21:41.81	2026-06-06 14:21:56.173
\.


--
-- Data for Name: course_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_categories" ("id", "name", "icon", "display_order", "created_at", "updated_at") FROM stdin;
77dc5824-4df0-47a8-9d39-df6f15d5ee03	Facebook	https://svgl.app/library/facebook-icon.svg	1	2026-05-29 08:43:30.948	2026-05-29 08:43:30.948
1b1b5275-03bf-432a-a8db-c271ac35832c	Tiktok	https://svgl.app/library/tiktok-icon-light.svg	2	2026-05-29 08:43:37.191	2026-05-29 08:43:37.191
6d6941df-146b-4d74-92c2-80c2b6f0229c	Google	https://svgl.app/library/google.svg	3	2026-05-29 08:43:48.524	2026-05-29 08:43:48.524
17e7f260-7123-4117-aaaa-84a0ff9ce385	Intagram	https://svgl.app/library/instagram-icon.svg	4	2026-06-06 14:58:23.685	2026-06-06 14:58:23.685
\.


--
-- Data for Name: course_faq_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_faq_categories" ("id", "course_id", "name", "display_order", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: course_faqs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_faqs" ("id", "course_id", "category_id", "question", "answer", "display_order", "is_active", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: course_support_items; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_support_items" ("id", "course_id", "icon", "title", "description", "display_order", "is_active", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."courses" ("id", "slug", "name", "thumbnail", "description", "category", "learning_format", "original_price", "sale_price", "duration", "student_count", "instructor_name", "rating", "content_list", "platform_variants", "badge", "sale_deadline", "youtube_url", "seo_title", "seo_description", "total_orders", "total_views", "is_active", "display_order", "created_at", "updated_at", "deleted_at", "requires_account_type", "requires_cccd", "commitments", "registration_procedure") FROM stdin;
4447b4b5-91b3-4226-8089-638faa948030	khoa-hoc-mmo	KHÓA HỌC MMO	https://cdn.hethongmmo.vn/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png	Khóa học mới của chúng tôi	Facebook	ONLINE	1999000.00	1599000.00	5 buổi	54	\N	5	["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"]	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}, {"icon": "https://svgl.app/library/tiktok-icon-light.svg", "name": "TikTok"}]	NEW	2026-05-31	https://youtu.be/pfatajwTL4I	Khóa học online	Khóa học 2	4	231	t	2	2026-05-25 03:39:33.624	2026-06-02 19:38:18.083	\N	f	f	["Hỗ trợ nhanh 1:1", "Đào tạo chuyên sâu"]	Sử lý toàn bộ các thông tin và đăng kí học trực tiếp
cbf81219-3e12-4060-9303-dca020c2e798	khoa-hoc-chay-quang-cao-tiktok	Khóa Học Chạy Quảng Cáo Tiktok	https://cdn.hethongmmo.vn/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png	Khóa Đào Tạo Chuyên Sâu	Tiktok	ONLINE	15000000.00	12999000.00	7 Buổi Online chuyên sâu	431	Chu Quang Doanh	5	["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"]	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	HOT	2026-06-09	\N	Khóa học quảng cáo tiktok	\N	2131	1214	t	1	2026-06-01 03:31:35.134	2026-06-08 04:31:14.18	\N	f	f	["Hoàn Tiền", "Dạy có cộng động học viên"]	Nộp tiền là done
6e646372-6751-49d3-9ccd-1fc78e96c2bd	fba	Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1	https://cdn.hethongmmo.vn/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png	kHÓA HỌC THỰC CHIẾN MMO \nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook	Facebook	OFFLINE	100000000.00	99000000.00	12 NGÀY	123	\N	5	["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"]	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	VIP	2026-06-09	https://youtu.be/pfatajwTL4I	Khóa học trực tiếp	Cam kết  hiểu  cv	5412	1323	t	2	2026-05-23 16:18:31.239	2026-06-08 04:31:41.259	\N	f	f	[]	\N
\.


--
-- Data for Name: fanpage_registrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."fanpage_registrations" ("id", "name", "phone", "service_type", "service_name", "description", "created_at", "status", "note") FROM stdin;
48a93408-8bff-4bb7-b758-294b61ad6f8a	Chuquangdoanh	0929990999	MUA_PAGE	Cài Đặt Payout Chuyên Nghiệp	Dịch vụ Cài Đặt Payout hỗ trợ bạn kết nối tài khoản nhận tiền từ Facebook Creator Studio một cách an toàn và đúng quy trình. Bao gồm: xác minh danh tính, cài đặt ngưỡng thanh toán, kết nối ví/ngân hàng và theo dõi lịch sử chi trả. DNET Media đảm bảo toàn bộ dữ liệu cá nhân được bảo mật theo tiêu chuẩn cao nhất.	2026-06-06 08:22:45.309	DONE	\N
8faf4ca8-0b8e-448e-a8a3-e494f7373a1d	Chu Quang Doanh	0929990999	MUA_PAGE	Cài Đặt Payout Chuyên Nghiệp	Dịch vụ Cài Đặt Payout hỗ trợ bạn kết nối tài khoản nhận tiền từ Facebook Creator Studio một cách an toàn và đúng quy trình. Bao gồm: xác minh danh tính, cài đặt ngưỡng thanh toán, kết nối ví/ngân hàng và theo dõi lịch sử chi trả. DNET Media đảm bảo toàn bộ dữ liệu cá nhân được bảo mật theo tiêu chuẩn cao nhất.	2026-06-08 08:53:21.418	PENDING	\N
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."login_attempts" ("id", "user_id", "email", "ip_address", "user_agent", "success", "fail_reason", "created_at") FROM stdin;
c27d97e4-9436-4e37-a29e-c7c1fee51b75	\N	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-05-23 16:10:00.188
7499d92a-16df-43ce-8d9d-0e88ed7dfbeb	\N	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-05-23 16:10:09.006
2f538334-fd58-4899-9088-07cdb06ae6fe	\N	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-05-23 16:10:26.489
75baaab2-d438-4d3e-b778-63c71cc7c488	15bbcf73-c01d-4730-85d7-a1cca3730c83	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-23 16:16:51.47
76b62a1e-0e1d-4aa5-8b74-cddc4b35ceae	3ad147cc-59c4-4623-ba0d-59011dcb6b93	chudoanh107@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-25 08:13:28.583
42c13cfd-edca-4726-b3fe-d4127291f35c	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-25 11:20:33.619
6ba25af5-0ceb-4077-964b-cc9c1bb014e5	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:30.032
f9029236-d5d2-43a5-a743-a72fb8594c07	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:36.511
e499d57c-baa6-4c42-97f0-b36c4586f21a	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:53.997
19029948-3fe9-40bd-a025-aff9308b3ffc	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:55.784
ec4d03ca-5b25-45cb-8cf2-9014cdee4c96	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:56.334
83454012-0397-4e17-bb53-ddefe044de7c	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_LOCKED	2026-05-27 07:22:56.771
4819607b-9808-4e92-baee-b0fe3dff5dde	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_LOCKED	2026-05-27 07:22:56.947
33c5c282-707f-47a7-b7a2-831eeba24caf	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_LOCKED	2026-05-27 07:22:57.096
e62b9662-988d-44dc-82e3-391f18312b13	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	doanh123@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-27 07:24:31.449
7e8475da-faa1-4c37-99c2-cb1231de90dd	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-28 02:22:23.34
9a8e4cc8-0fbe-4072-b280-65de2e30f5e1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	chudoanh107@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-29 19:03:40.713
af08ff97-551e-4431-b4c0-641a3e561e03	\N	ad@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-06-02 18:54:36.453
258f2207-d6eb-4899-8151-cf06bc051bc0	\N	chuquangdoanh@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-06-02 19:24:38.871
4a9fce4c-7b4a-4d25-bcf3-4acdbb35227c	e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-06-02 19:24:54.628
e8cc2eaf-6b67-443d-bcae-0e9758c34cb5	55d1694a-443e-4f08-8875-8dadff9cbf62	nhanvien@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-06-02 19:27:19.264
2da0b8bf-1111-4471-82e5-0aa0a81ca03f	\N	lasvergasblackmeta@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_BANNED	2026-05-25 11:23:30.132
64ca07e8-324a-432f-9c02-1e699950a716	\N	lasvergasblackmeta@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_BANNED	2026-06-02 19:23:07.017
\.


--
-- Data for Name: mmo_product_items; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."mmo_product_items" ("id", "product_id", "value_enc", "status", "sold_to_user_id", "order_id", "sold_at", "created_at", "updated_at") FROM stdin;
e5b6563f-af22-4325-920c-2cb477347ae1	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x21aed8bae84ce28df394aff2b66697eecd2a1cbda7e1e6765248f4091e7c3d2080	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2fafd37b-5d19-4e88-b3b0-76402374e4e1	2026-05-25 18:30:36.603	2026-05-24 14:44:09.22	2026-05-25 18:30:36.603
af6d05a8-c83d-4ba7-82c7-885e3a409426	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\x8fd71ea4079f0880b713839b8710d88f3b0e2ce4ffa2b7a621aa596a0337e6	AVAILABLE	\N	\N	\N	2026-05-25 18:49:16.893	2026-05-25 18:49:16.893
a18da2c4-9d5f-4946-b4fe-9b130d8eb83e	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\xc8d7eea90dc535b4d6c0d449373eda36a73d79ae7d915ed46a4f5bd834a082a150	AVAILABLE	\N	\N	\N	2026-05-25 18:49:16.893	2026-05-25 18:49:16.893
4d4885a3-8917-4ca8-beba-fb4e1a3638ce	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\x5a7abe142ace9ee785ab3890dd5ee544601b8a8567ae90607fc2fa92855a435a85dcae	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	ac56e421-5f6b-4277-93eb-a9e1cfc831b7	2026-05-26 08:31:10.699	2026-05-25 18:49:16.893	2026-05-26 08:31:10.699
f9e8f5cf-68d3-4e54-8d1c-5a1a45544a21	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\xf074f0644094f1b0ddcce82fdb5eca6f3c30ab384de075bd6114ee398e855f9a2f	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	55cd38b0-cd40-4d86-b883-9893f7c4f9c6	2026-05-26 13:47:37.46	2026-05-24 14:44:09.22	2026-05-26 13:47:37.46
ccbaa773-bf85-48f1-bb22-25562302965c	9446f730-205a-42f2-ad8c-7d7b035e638f	\\xbdb747d25ee30475d8f785d65ab14b4459fcebad4e1a48943830357d5c	AVAILABLE	\N	\N	\N	2026-05-29 08:36:19.396	2026-05-29 08:36:19.396
5f04a7df-52b1-41b7-8d44-49d92489bbd3	ee1eeca5-490a-462b-8be7-e4b14f61513f	\\x78d859af7b101c491035489604f4927328871cf41f92d2eaaf01c3a12b	AVAILABLE	\N	\N	\N	2026-05-31 15:56:03.52	2026-05-31 15:56:03.52
4692de6f-f920-4a8b-b202-a158220e0df3	ee1eeca5-490a-462b-8be7-e4b14f61513f	\\xca1746a279e0ae7606d533679b910b92f80387225997b6b22deee43a3a	AVAILABLE	\N	\N	\N	2026-05-31 15:56:03.52	2026-05-31 15:56:03.52
149cb505-ba90-4cea-ad19-f6aaa584cac5	ee1eeca5-490a-462b-8be7-e4b14f61513f	\\x22bc19dce29e3849488d5705ec4c91659648cbf31ba1baf847b06222bb	AVAILABLE	\N	\N	\N	2026-05-31 15:56:03.52	2026-05-31 15:56:03.52
15b3795e-0c2b-4447-b611-774f0316e61d	c0828411-0c17-4fdb-a37c-67c101879466	\\x4dabeda2f9d295c7a5288e2aac93bf632c0a3658ba98c5a74d99b2d2e1	AVAILABLE	\N	\N	\N	2026-05-31 15:56:53.824	2026-05-31 15:56:53.824
4031ad9d-1b06-4e37-971f-0dad912ef32b	c0828411-0c17-4fdb-a37c-67c101879466	\\x62c1831d5250e161eb51262a24aa298792bc9df816d1dfc72b6a48da39	AVAILABLE	\N	\N	\N	2026-05-31 15:56:53.824	2026-05-31 15:56:53.824
43ab65c5-2fb9-4e44-af06-c217aada91c1	c0828411-0c17-4fdb-a37c-67c101879466	\\xc05e008f8d28620276729b9ec1f146b8f87a31beea13265972cabd9d4c	AVAILABLE	\N	\N	\N	2026-05-31 15:56:53.824	2026-05-31 15:56:53.824
1cc5a876-7232-44ef-bfef-82046eb6b048	44e26368-8fad-47ec-bafc-5ce03123a5b0	\\x166b94f269eb74679a0baf3cce88aecf27352e511425bd3af3a893efac	AVAILABLE	\N	\N	\N	2026-05-31 15:57:39.988	2026-05-31 15:57:39.988
392df6c5-f780-4d15-86b1-dae04dce4ff6	44e26368-8fad-47ec-bafc-5ce03123a5b0	\\x7d6f1207fecbea30fc393aeef27a681c41b39513dc6d93570d47d1270e	AVAILABLE	\N	\N	\N	2026-05-31 15:57:39.988	2026-05-31 15:57:39.988
878e9626-0810-46b0-83a3-efc18b3a4b54	4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	\\x872db9fe7934330c227554c404b59674380b29095047f7a88af07f6023	AVAILABLE	\N	\N	\N	2026-05-31 15:58:51.279	2026-05-31 15:58:51.279
24893b3a-16c9-4f80-8fe1-6b91a7cb22be	4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	\\x7c6c6130a7406c2a1070f1e2958d39bdc5e5362feec899a6cbbee21fbe	AVAILABLE	\N	\N	\N	2026-05-31 15:58:51.279	2026-05-31 15:58:51.279
7915c972-3ba1-4f64-af80-b594c22e964b	4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	\\x2be94a85a26215d985bcfa56d52b0949650d186f99cbe03b6dce4625ee	AVAILABLE	\N	\N	\N	2026-05-31 15:58:51.279	2026-05-31 15:58:51.279
0a9c1255-7cfc-4e8d-9348-187f3126dc3f	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\\xdd63ff05a863b6bc8b89284fb9a96595dc4c48ceda1e525a60b5a3637e	AVAILABLE	\N	\N	\N	2026-05-31 16:25:54.582	2026-05-31 16:25:54.582
6d8badd8-caf8-420b-a4f0-2e5ef368aa2f	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\\x4dae94954c077a03fbf11ff397f05689133b3fd07588c21c21dfb67dda	AVAILABLE	\N	\N	\N	2026-05-31 16:25:54.582	2026-05-31 16:25:54.582
141b6996-caf8-496e-a9bf-a75dacfa9afe	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x36fb381efe3b5bb237d738f5c00f542b723df5e3b01ec654a9ee7c3527abb88a98	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b2e08071-f6dd-4e59-bb9b-5e7108897372	2026-06-01 08:01:02.958	2026-05-24 14:44:09.22	2026-06-01 08:01:02.958
8edb52a0-ba37-4bf0-9dde-e7a6d2706db7	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x71c4f56de0bcb68962d6ae511904d85d64ba1604086d35cb0638ad07b52f413f12abe5a672e0d827b8ab33fe375dcfd9576db55638bd998dc46c11265a1618768794ab6e572a9d36be0a9e9d0dd98d65e6016dd7930f2e73bbbd6ad07789f1d44aa8f590007dc79374a4f36638daf6572e6040f4b4565180099a4fa46e0229a96d04739bcc7f60096b42658f0cb52f7fc9f0fba0fbf86ee7722f866eab4707452af667a0c70ae1bd648b45c941a1f464a7fac263c3bd57579be3e913266dd92d50c97b690e78dcb740e5d0d556c60bcfb212d2fe6a2613f674a8ef4ca02b9d3a2aac729e51bd787278c7674504f4bc17354584614a2a198f5e2f9a3fb28c7262dd4569862b169d0c8772f2291be31940d90cc2937bd430745b36f6a729076676981039e730fe22b00988b6fa2107f90df20e4cffec1ac43a15ce2bf0b35effdf73d5217fe38e3c29ab691ffa2eb38e36c1626cb05728c34d74dbda6102c667076a85a4a3b8680c4798c39a6027d23e0ff459c108059149fac4d72d48a74e2fd6f2248e38699160dfb4b5f604d96bacfa856ba9e785876d80abf7d60a931facc67c156b883b2f8f281dca62a43b6bfe5c09923ad7a820aaf9db0a6941cd367ffbac26900247afed1ccbd3ad6019db4cacdb41509be577691397f7f99527b87cf7bd28d0988de679f4269bdc4f4abfb6280619140d2347b7dc262a17a23d1a226d7c934ec18df3fb300aaec516cffb1e2e44237bff6f8c9727dc3068870a715d79a4c6d32f9cc85d999316f3388b42bc9630da64acf6798c446e48de5090857dac6bc0816fc787abf8d7238186b5a688754da0da461511684b79c31200e1d03b672e3eba25d5836b3d638a5b21aedd2e56092ed30de160872740afc5dcb9045354b092f91cd9f48167fb33f6b52eac1c95032c35c5e0a38c2fbac60fa2e48ecfd4465e3c2b6a6507644400daadc0facddafd2392a07fd6a86fb0f973119f0cd51064539e54a2a70c046ce92f1d30fec48464121d9d2aa6fa470b2d3326c45a8bf5faa2735d2248f3994f2af2fb15dc35e7596ad0500ab424bf431818570ccc0a82a9871112d3521d7a065219be23fe7663f4f39b3461745b5ae2a514f3b6a2f2634c80651306629497ecb04d1db846d8dfba6c837e9725555af41a4348c5e32f7200840c18ad53989a46d5acd7c82d908c6b0b6d5b150c3a117b7919894e0571d1684b505c9b026110680268da9cfe43eaf9dd83eb77c7a9d32cd7bec9ec204edf0afe314c75b41328ba2d4159fe8ed1464e0f896bab36ae94fa98d33b046ef1a757cdfb0104dd74cd3f53b1d16aadbc59f3a4ca275da54e2fd2fbb1776cae9ea6c77e8f89dabb00b15ba9902a575a2d7e9e44140f8c9de737a933903c6095ea023e37b039fcf798b485ddb088c7978083c0304a556e9b035701230d88ad63cd26d9930458be2de479967d1ccc5a8e6548ce69629c2f9cbde145dd5bce00362c06fbb19131d43f9b88403f	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	de7c53c8-069b-410a-83d3-fbbfe131cf95	2026-06-01 08:01:06.526	2026-06-01 07:59:52.356	2026-06-01 08:01:06.526
e76c41b2-0fca-4797-89bd-ad6182b2c44a	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x59e68c7f8485fc50cf8c1d84a206673a9f6d8aa4e1b2513c24d25eeaa364375915e3cb4f3c50b5679814ab6dc6c45c3ae921bb6806635e694fd4478da5adfe209e4cf468aacdbe24f257d2708960e03e733a9efc2056ce8c002e85970e1c5db7f67547c75cc74314c09e388b994b2ae309c88955429f2e2b783d721a9f53b3c7653962a1ce3e43c2595cf280c9449c4b7e8b89f5dd6dff2f7935bd7c41997238b60d4e50fa1ff5af624ab59ff2cf0f422167921646412044d94e43666675e98fa474af63bbdaf5ddf1c5fe9de477a6ba55472682cefe92907bffc2e4c37e83d28ea593b5a8ca9fdd075b935579420e03124ea1ae89c446d6378b559144e7519151f78bca387e252a6650312a19d7fe73b0ae9bcee14c999b3d60ba9573fb6f4ad11f02c19228f767f46544236670bf07aa0c687fea464d41b3a69e2c2aef9a9715f86c665d0d2815b2d1fdd221b901df35a8c1b8514ba151f6412f158677f934d313d8619cd2e4f165d43b963199f3196ff9f13eefe38158fcd6b815b24912cb295176cb6aac3a532c781f9f5c916e9e6c67de32baf27af787cbbbe0c0d3f4347792da2da49c9a561b365f37507377dc9cc2c3b9032dc254113cfbbf28fac06b2e2ed1474b12fe6d4f86a443c699e1fb2390bb0966cb9d2ac1473be172b79cdba22571b1c5b290ebe8735ff79bf78d3a56a61dd1edd2941a9fe47a4ec75c54a01734e6e6701b49a73704a951b714b0288ebbb0ee186df0af7df3f3223c2a484dcabd6fe0e036837da818155fa61acf042826ba4e1fbdb4337ffe6c99682d74aacd1d2bed04dd698639822efa89d678014086c521ff20023f059f8c09835d5aed8f55cb764ce253696d5a67eb062ab5e7cf95767af023167b959170543cec3d7132493a463ff51fcdcacfcbffd2987f16cdbab259e8d6d0aa5989e25f7735de6291d999b90bf3c9572fd05bd13c5e3a450db9d5cdb8cdc5a8120de5522124790cf3d9d2115bfd91f51fbea1f867b26cdf5eaedf071c3b8cdff7c44f2c1ba95b083c523c54f13840c5629b2436e8e8efa57f5b09b6865ec8345687ed125d53bbdd06049b42ab2759d1ab11fcdcee540bfd73e692862cb13f996f0fcb334ec09271e68845a125e5f143dac3afddcc56c8fa2a005be6afb5cc3a9d42a9a40cc0d4f5177c325c5d0b57df980d2d12d5e47c9341e3b8648b2cec5ed13cb57afccfc8aafc515f5cf9bd85cae14b014ebea3d03c336cbf368b376d21a7a77e3b131a2bf32c85752980a85489b0edae0ddefe14e668c8536b310c59e2802ee6844d1590c22e75059e22596a669f246c1140203090596bf3005889ede8001a30263792ccac87dc4d976e8603ed4c0d5affbfa20dfeb9654571971dfa3a9cc620dd744d072eee3b6281825b79c18ed2433e7412c17d35dfa987b09ffe16b1551cb20395593fccf9c284252a3ff1d5290ab49577cf620ca5edf0369ec84078da0b4ab41cbd59af0908f9cbc5d79b271a	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	48c5a877-2769-4dfb-8f15-226b75bbe391	2026-06-01 08:05:00.41	2026-06-01 08:04:39.524	2026-06-01 08:05:00.41
07c1e75d-c61e-44a6-8483-58deed22e179	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\xfc859b667594a2aa6d8417b9069dd1f0e23432979dc5220fffccbabe4fe28b26c6e6815c66ae9ff777694ab2398bfb9461ae7be9aaa55ef8f979e9e35b9dacbd0bef558be0aeb59681c8cfd5f9947a06ae9551c556e85f04b47cc122cfcc294b717c55773d23edc308ca1257ae954733141599a6271b3dc9e763cadd1a725a849705ee82a749a39fc1497d966c35936d77e617ec671f7ab8a51a453a954acbe31d16be5cf1a7306c3f411f90268648b07597e5e83caada6279dac8858be23dd36f3a8318a62d6f7bfc0bf521ec2650c12175b4c181838a9450892ad0a1de4d21a1fce8a1c762b4b4ff3a2daabc405ac48f756e0f502e302b151def398a90655f4cfd4aef8f4d23c342e1be9b5fa4a71d6964799c05dcb254274ec36a7bfb3e8d513b1efab0550a8e009993b847ab415d17fce818c987a9647003e125e4aaae21564fbbfd3986e7cc354c07be16f55e6a8245e27e61b53ac5785653f3572cde9b71a617f7fd4899e33a8ca31fb8345bef9cc9ec17b0fb40daf2349791c7ea9c38323b5742746e42225085855e1629727ac479c0948a2061cd1e1b096d3f0067146542a592985d8596072b384a2e9e12ae2f73848f7fc4e9cf5e9b17e940054b03ad1f1da46a0100d5e38c0a5bdeefdf420d448b59ffda1c6b254fb477f8a583e9ca9766eb222764b448546ea3791738c83998a5192e7d61778e5ce3a8d4fcb9ec426a30ac6c47920b31d3799403f9cd2c52712c3f2ff71f55a27e33bd3e7c5510c2038cd7544681ef1d1791afd9c7d793275258bed76a06d7da1d5147be0d1c5d65008af09670e15e4f9d53159f0faa2d9abb7a979615b52febb9d32aa2bda41abc483883d168967416b383928f5f2b777c669d34198f99d5512d00e6f561b3280352412b69a4c0338be1f346a736286de05773e7b854cf833a85e2ba0ad10fdace3b12b3034d1c7da2346eaab50d54503f6bd3364fe18d68ea3f908e76e37601d6656e020c3736d43cb02a2678ab00e7e5c1ccfaa502f0ff03c2b212289d028c00bd14ee0c4081f0452bad25ad42d4b4589f47d0b252ca371ecdf7c6abb7a8b76df7afd316554aa66b326c0519a9ca9337f3a276b55aa3a724bb1f32d0426a7b97d5bee0be1caecc2bc722e111657acdd345a021d1a1ae30a3045742acbe5a8f018f2c82ecdfaccff5d1a72ebdad49b4c88eb6a6d56992010f965ce16e8cf050b86d8e5c615249ab3ea223f783e269a8b7456a20a31da113f4ebc7effd826d8fdaebca4b6227fc0590c352d492088c2ddda2e6d267b5d3f82c4d3e7c85fd09759d3e2a49f6f2955918b9c53584c4e9ecc93ff6c4f38ab7380e98d4f5f11c63baac0f3300d5f299afe26f9c1983e6b59d2b9eedfffac88d76a19a3ffc5c7d760df9c283c57bfcdc7ca596499a631944e2d33b53aed83b085e6c64ae7fde61973cc267c5636967774c6eceea386299a54cf02648726d942ede35dcf4054341167fd3d1f84bcd95a9bc5468	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d680918e-f4bd-4608-9f6e-8516126cc5a0	2026-06-02 09:58:27.322	2026-06-01 08:04:44.981	2026-06-02 09:58:27.322
8338df82-f2c0-4060-b075-712fd9772714	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x5aeff841243a8d3772a2f1a4b581d84e57f80b7cc4803d852a6b60b2ee	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	36a1261a-339c-4226-98d6-cd3ec9867bdf	2026-06-05 16:43:55.473	2026-06-04 12:28:03.997	2026-06-05 16:43:55.473
4783f567-a617-46e4-9a59-853c48b304dc	44e26368-8fad-47ec-bafc-5ce03123a5b0	\\x075a27b07c397d213f0cf06d1f4db2e0fbf1ca14b232a482d996866337	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e37704de-5da0-4c00-98f4-6a62aaec35bc	2026-06-05 18:09:09.946	2026-05-31 15:57:39.988	2026-06-05 18:09:09.946
10ebce0f-898a-4679-ada1-4fef82d84cd8	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\x5d0b53d9295d75f922f602ca9a939904615c4ecad09c3f830466f04470	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	542b5e5d-ad27-4eb1-93e0-92b53bab03ec	2026-06-06 03:59:24.678	2026-06-05 18:29:08.377	2026-06-06 03:59:24.678
6924aaf5-d660-4f4d-9a57-4294d3f15b54	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\xdfe2e2ef98ba1d2dfad86cdca9f45df9fad8bdc144f7da24dadfef2f1b	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0d50ba32-07c2-42c8-bb2e-5d40f148cd20	2026-06-06 03:59:43.098	2026-06-05 18:29:08.377	2026-06-06 03:59:43.098
2352678b-6afd-4154-90cf-8cfe3056f281	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\xcbda65c1af49c7f895d420f2286ebec8e2d933c123e0d9e278dbd11052	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	df1e2b85-e049-4c78-a468-2af9db41391c	2026-06-06 03:59:45.475	2026-06-05 18:29:08.377	2026-06-06 03:59:45.475
bea50305-c46d-49e8-b545-f7fc28e26a87	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\\x16dbd7f855602e61f68ca3d21e14fbe5f132688b42561ca6159d73d07e	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fc918566-99d5-494d-8e4f-4281ecc30df6	2026-06-06 04:04:07.211	2026-05-31 16:25:54.582	2026-06-06 04:04:07.211
724a986a-379d-41d4-bd39-46fcf1bd3407	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\x6941110d4bbadf072975ebd6a2ef8cd2fd93bfd624b68336d1443792d4	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	59668832-2a45-418f-869f-6e1bef691fce	2026-06-06 04:04:20.41	2026-06-05 18:29:08.377	2026-06-06 04:04:20.41
b9ad1692-804c-4bae-9c64-baafc7444550	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\x3d9d3a1720c4b50e4faf22b6b70cf9b35245a503d3b5b0b1b9a082a43a	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4417f9ed-16e4-4213-968a-92e61b80e4e5	2026-06-06 04:04:28.476	2026-06-05 18:29:08.377	2026-06-06 04:04:28.476
ca28272d-cb32-46f3-84a3-8de7ee734921	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\xe14e1e79ef94898b54038d990ee40bc4a3919b60d8bcdee175b024ed7dc61468acfd	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b107e371-602b-441d-9e28-a1b434c15b38	2026-06-07 17:50:10.079	2026-05-25 18:49:16.893	2026-06-07 17:50:10.079
31e1ddc0-885c-4a9d-a0c0-eabe988191bb	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\xf8cf6a74ae00c552d1eca55de25b1a9365c9f67fc238c80ff8b1cb7103	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	12c769df-87b3-47f6-9b36-dca0750a1889	2026-06-07 17:50:22.882	2026-06-05 18:29:08.377	2026-06-07 17:50:22.882
\.


--
-- Data for Name: mmo_products; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."mmo_products" ("id", "slug", "name", "thumbnail", "category", "category_group", "price", "description", "is_active", "is_featured", "display_order", "created_at", "updated_at", "deleted_at", "rating", "total_orders", "total_views", "requires_account_type", "requires_cccd") FROM stdin;
9446f730-205a-42f2-ad8c-7d7b035e638f	tai-khoan-game	Tài Khoản Game	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780043767935.png	Game Liên Quân	Game	900000.00	\N	t	f	2	2026-05-29 08:36:14.095	2026-05-29 08:36:14.095	\N	0	0	0	f	f
ee1eeca5-490a-462b-8be7-e4b14f61513f	tai-khoan-tiktok-1	Tài khoản tiktok 1	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780242940045.png	Tk tiktok	Tiktok	300000.00	Tài khoản reg mail trust hỗ trợ truy câp	t	f	3	2026-05-31 15:55:55.408	2026-05-31 15:55:55.408	\N	0	0	0	f	f
c0828411-0c17-4fdb-a37c-67c101879466	tai-khoan-tiktok-2	Tài khoản tiktok 2	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780243007643.png	Tài khoản tiktok 2	Tiktok	200000.00	Tài khoản tiktok 2	t	f	3	2026-05-31 15:56:49.593	2026-05-31 15:56:49.593	\N	0	0	0	f	f
44e26368-8fad-47ec-bafc-5ce03123a5b0	game-lien-quan	Game Liên quân	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780243053682.png	Liên quân	Game	200000.00	Game liên quân	t	f	2	2026-05-31 15:57:35.85	2026-05-31 15:57:35.85	\N	0	0	0	f	f
4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	game-lol	Game LOL	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780243099202.png	lol mobile	Game	1500000.00	Full skin hỗ trợ login	t	f	4	2026-05-31 15:58:47.536	2026-05-31 15:58:47.536	\N	0	0	0	f	f
7a270438-cff5-4f5c-93a7-30d1e771bf9b	tai-khoan-intagram-co-trust-2021	Tài khoản intagram cổ trust 2021	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780244746727.png	intagram	Instagram	259000.00	Tài khoản intagram cổ trust 2021	t	f	1	2026-05-31 16:25:49.14	2026-06-06 15:46:25.445	\N	0	1	0	f	f
f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	via	VIA Trust Us	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779642138078.png	Via 1m1	Facebook	99000.00	Via mới	t	f	1	2026-05-24 14:43:38.883	2026-06-06 16:16:02.434	\N	0	0	0	f	f
3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	tai-khoan-tiktok	Tài khoản tiktok	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779734932645.png	Tài khoản tiktok 	Tiktok	360000.00	Tài khoản tiktok ...	t	f	1	2026-05-25 18:48:59.12	2026-06-07 17:50:10.079	\N	0	1	0	f	f
7418205f-3c53-4823-ab68-d5c9a1b17f6a	tool-join-box-telegram	TOOL JOIN BOX TELEGRAM	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780684116099.png	tool telegram	Tool Telegram	500000.00	TOOL join box telegram trỏ thông tin nhóm đẩy data quản lý 	t	f	1	2026-06-05 18:28:49.913	2026-06-07 17:50:22.882	\N	0	3	0	f	f
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."notifications" ("id", "user_id", "title", "body", "type", "is_read", "meta", "created_at") FROM stdin;
7cdfaed3-5376-4e0b-bbe3-d5f29d5bd111	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Facebook đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-05-25 08:59:46.604
24aeb9c2-7ce9-426b-a4fc-e898529aa7ed	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL0OIT1-96CB - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL0OIT1-96CB", "orderType": "SELLER_PRODUCT"}	2026-05-25 09:41:42.354
36b62fd1-62c8-4920-b2f9-7452411a623e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL0OWX2-4F48 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL0OWX2-4F48", "orderType": "SELLER_PRODUCT"}	2026-05-25 09:42:00.625
2de16ff5-ea27-4887-8857-7979746e35fc	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL0W1I1-89E1 - adđ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPL0W1I1-89E1", "orderType": "SELLER_PRODUCT"}	2026-05-25 09:47:33.16
6fc302ca-f6c4-49df-9043-c834f46d1a11	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL3W9S1-3A8F - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL3W9S1-3A8F", "orderType": "SELLER_PRODUCT"}	2026-05-25 11:11:42.747
08da2c7b-0763-47d0-bbce-ef00046b2e7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL3WE9E-1846 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL3WE9E-1846", "orderType": "SELLER_PRODUCT"}	2026-05-25 11:11:48.542
b415729b-b848-435e-b060-bc2e5fea30d7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL3WHTW-D670 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL3WHTW-D670", "orderType": "SELLER_PRODUCT"}	2026-05-25 11:11:53.165
44b26f53-096c-48a8-b8a7-4351c5ff01a0	f15fef1f-7843-44b0-b983-72068d1647c6	Tài khoản bị khóa	Tài khoản của bạn đã bị khóa bởi quản trị viên. Vui lòng liên hệ hỗ trợ để biết thêm chi tiết.	SYSTEM	f	\N	2026-05-25 11:21:08.9
de6deb8d-c421-4092-a2ec-9dbe6fbac1aa	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-25 18:19:07.582
5c6057a3-23ee-4a81-b8f4-eba0409df0d6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-25 18:19:15.375
14e0fc85-ef19-4e64-aaed-d42a70f25155	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-25 18:19:17.386
cccf8343-782e-4c7b-8160-32e79d04ca1f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-25 18:19:47.612
dc27bfc2-2e18-4d83-bf42-af5f150a988b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJKP5E-BCC5 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPLJKP5E-BCC5", "orderType": "MMO_PRODUCT"}	2026-05-25 18:30:36.651
6a10e3e9-c692-4841-9de8-d94dbe5181c9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJQHSA-4DA4 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPLJQHSA-4DA4", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:35:07.032
b18d7a6d-559f-4ce1-8b3b-77442eb2d150	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJQNSG-D1EF - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPLJQNSG-D1EF", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:35:14.811
d3f32a80-8502-4eae-8bac-627ff3d7339b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJR013-E5AA - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPLJR013-E5AA", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:35:30.676
56f299a4-210f-4b2a-9326-106d2b6450d4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLK63X9-0789 - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPLK63X9-0789", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:47:15.565
206478e1-72a8-4b97-a18a-95fcc74aec5d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLX1VSQ-A7B6 - addad đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPLX1VSQ-A7B6", "orderType": "TUTTRICK"}	2026-05-26 00:47:53.416
6090e1d3-2a0e-45a2-b584-75fb1c5f64f4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM39U3T-D7D3 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM39U3T-D7D3", "orderType": "COURSE"}	2026-05-26 03:42:02.186
5f8060e8-e01a-4d27-8759-9c65bbd54682	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM39ZGY-D66B - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM39ZGY-D66B", "orderType": "COURSE"}	2026-05-26 03:42:09.122
81b111a4-3786-475b-8f69-a36ee48fd0c4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3A2JB-8ED7 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3A2JB-8ED7", "orderType": "COURSE"}	2026-05-26 03:42:13.093
9d7f5811-75a5-4ef0-b528-54585a2f9663	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3IYUY-54B2 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3IYUY-54B2", "orderType": "COURSE"}	2026-05-26 03:49:08.238
bfd7d243-5bcc-4af3-b3fc-b5e220063f92	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3JSTG-9C76 - Mở Khóa 282 đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3JSTG-9C76", "orderType": "SERVICE"}	2026-05-26 03:49:47.065
44ea059c-0e2f-47d8-b081-05e0663b4c83	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3PGY9-8FE4 - Mở Khóa 282 đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3PGY9-8FE4", "orderType": "SERVICE"}	2026-05-26 03:54:11.621
5a58c5a7-e26d-4a7b-b42b-e6173a052cee	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3Q7Y5-ECA1 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3Q7Y5-ECA1", "orderType": "SERVICE"}	2026-05-26 03:54:46.61
412dfa49-b10b-4212-844c-d187141f6c18	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3QSLD-FF3A - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3QSLD-FF3A", "orderType": "SERVICE"}	2026-05-26 03:55:13.361
f241eb75-0642-40d8-9299-b72dd8096f5f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3VR0N-2D53 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3VR0N-2D53", "orderType": "SERVICE"}	2026-05-26 03:59:04.603
1e13bd2d-c373-45c2-bb06-6a3b70fd7c9d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3XWWO-FC8B - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3XWWO-FC8B", "orderType": "SERVICE"}	2026-05-26 04:00:45.539
bbdbe939-4413-4f7b-9b00-8b22a234c9ef	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3YN6L-EEAF - Mở Khóa Icloud (IPHONE 11) đã được xử lý.	PURCHASE	f	{"amount": "3500000.00", "orderCode": "ORD-MPM3YN6L-EEAF", "orderType": "SERVICE"}	2026-05-26 04:01:19.594
ed370ec5-746f-405d-b4e4-fab5da0a5425	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3YPQR-0620 - Mở Khóa Icloud (IPHONE 11) đã được xử lý.	PURCHASE	f	{"amount": "3500000.00", "orderCode": "ORD-MPM3YPQR-0620", "orderType": "SERVICE"}	2026-05-26 04:01:22.908
4805cdef-e7a5-45dd-9052-da0698a667e0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM461QM-C459 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM461QM-C459", "orderType": "SERVICE"}	2026-05-26 04:07:05.053
83f14783-7ac0-4c50-95d2-8e19852c45ca	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM4C203-D695 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM4C203-D695", "orderType": "SERVICE"}	2026-05-26 04:11:45.334
8e6b88ee-4df0-440e-89db-8984b7ebd96c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMCIPU1-CD72 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPMCIPU1-CD72", "orderType": "SERVICE"}	2026-05-26 08:00:53.12
b64a8d3a-5507-4cdd-85fb-f003b30c65f0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMDLOCH-B175 - Tài khoản tiktok đã được xử lý.	PURCHASE	f	{"amount": "360000.00", "orderCode": "ORD-MPMDLOCH-B175", "orderType": "MMO_PRODUCT"}	2026-05-26 08:31:10.742
78f472c4-4b48-4be5-b543-59591b7a7e75	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản bị khóa	Tài khoản của bạn đã bị khóa bởi quản trị viên. Vui lòng liên hệ hỗ trợ để biết thêm chi tiết.	SYSTEM	f	\N	2026-05-26 08:44:34.695
14bb58b9-9c12-463f-9053-dd7c8a0581ac	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMLI8NH-90FE - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPMLI8NH-90FE", "orderType": "SELLER_PRODUCT"}	2026-05-26 12:12:27.364
136f3306-caa7-429c-b3fc-f382c0e4dc1c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMM60OP-0B88 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPMM60OP-0B88", "orderType": "TUTTRICK"}	2026-05-26 12:30:56.776
ab47d936-cea1-4da2-84d3-f67c9a00cef6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMOWMMF-B02B - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPMOWMMF-B02B", "orderType": "MMO_PRODUCT"}	2026-05-26 13:47:37.495
ff433a65-ff7a-48bb-a65f-60297330a92e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPMOWMMF-B02B (VIA) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 14:36:24.665
7547b8fc-9b0f-482b-98c7-933b8affc084	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPMLI8NH-90FE (Tài khoản 250$) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 15:52:43.787
273a7af8-e8b7-4338-938e-3a5b067a48ea	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPLK63X9-0789 (BM FACEBOOK) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 17:40:05.03
8cac5d2e-ea72-40c2-aead-71b1b585e222	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Yêu cầu rút tiền bị từ chối	Yêu cầu rút tiền bị từ chối. Bạn có thể gửi yêu cầu mới. Lý do: Chưa xác  nhận thông tin	WITHDRAWAL_STATUS	f	\N	2026-05-26 20:01:06.256
63b5211f-73c5-4e77-8145-5340bb60402f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPMDLOCH-B175 (Tài khoản tiktok) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 20:23:02.781
0c9fa7fc-26bd-4c66-9979-68889fbd791a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPN3EO7U-AD0A - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPN3EO7U-AD0A", "orderType": "TUTTRICK"}	2026-05-26 20:33:33.996
850439f8-b950-4e97-b1f4-6cde7be99afa	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Game đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-05-27 07:31:01.867
ee7c331c-470a-46fe-93f7-cfd43c5ee297	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPNQYA6M-0093 - GAME LQMB đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPNQYA6M-0093", "orderType": "SELLER_PRODUCT"}	2026-05-27 07:32:40.095
c41f3e1e-ddf0-44f2-a93c-a7213ce92e88	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-27 07:37:39.869
ebf72fc9-cfbd-4d40-8bd9-f97ae34b212f	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-27 07:38:08.041
578d7365-94e8-4f72-90e5-c41ee5d35cb8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Yêu cầu bán hàng bị từ chối	Lý do: a	SYSTEM	f	\N	2026-05-29 10:00:33.219
ed946dc9-5bce-4b36-b223-7a23e7811704	f15fef1f-7843-44b0-b983-72068d1647c6	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Facebook: a đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-05-29 10:02:37.815
aaf8691b-f620-4de2-ab5e-f12e872e1c2f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Yêu cầu rút tiền được duyệt	Yêu cầu rút 187.000đ đã được chấp thuận. Admin sẽ chuyển khoản cho bạn.	WITHDRAWAL_STATUS	f	\N	2026-05-29 19:04:47.167
4643ad6b-55d4-4a15-8f9d-e6fd0e955637	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Rút tiền hoàn thành	Đã chuyển khoản 187.000đ thành công.	WITHDRAWAL_STATUS	f	\N	2026-05-29 19:04:53.987
ba0586b6-ae62-4708-b7ba-dec3625d3e84	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPRANUOS-C863 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPRANUOS-C863", "orderType": "SELLER_PRODUCT"}	2026-05-29 19:07:44.321
894b1d1b-a68b-4b48-928a-eab2e3cb2c4a	f15fef1f-7843-44b0-b983-72068d1647c6	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-30 04:16:22.73
ccd011ac-dfb3-4a18-9092-e7ab0e3d6e0e	f15fef1f-7843-44b0-b983-72068d1647c6	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-30 04:16:25.764
a6c7c52d-76b0-4ca2-a562-e736b21f16cd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPT963BS-BA1A - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPT963BS-BA1A", "orderType": "COURSE"}	2026-05-31 04:01:28.46
e0e6ddf0-7347-445c-8162-3b9d596568fa	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPTAN5R2-3F44 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPTAN5R2-3F44", "orderType": "COURSE"}	2026-05-31 04:42:44.345
065e2c7c-e06e-4bec-b184-643e285c8134	15bbcf73-c01d-4730-85d7-a1cca3730c83	Đơn hàng hoàn thành	Đơn hàng ORD-MPTAN5R2-3F44 (Khóa mmo) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-31 06:53:39.571
fbfad40e-a376-4838-9d78-e0ba055435c6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPT963BS-BA1A (Khóa mmo) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-31 06:53:51.605
4769a5e9-6b9e-4172-876d-901faeaf31d8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPTFGZ6F-8A3E - Via Facebook Clone 2019 đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPTFGZ6F-8A3E", "orderType": "SELLER_PRODUCT"}	2026-05-31 06:57:53.958
8138d419-d727-40f0-8583-173db961651d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUMX1FC-DB2D - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPUMX1FC-DB2D", "orderType": "SELLER_PRODUCT"}	2026-06-01 03:14:06.871
d840cf30-75a0-4702-be8d-e55edd152d4e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUMXD13-5470 - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPUMXD13-5470", "orderType": "SELLER_PRODUCT"}	2026-06-01 03:14:21.892
720de727-34b0-443e-bcc7-407ab077527b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX61HR-7845 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUX61HR-7845", "orderType": "MMO_PRODUCT"}	2026-06-01 08:01:03.017
a180e71f-d36d-462f-99a2-188efd8f1af8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX648F-D916 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUX648F-D916", "orderType": "MMO_PRODUCT"}	2026-06-01 08:01:06.556
f5b1b1c6-dccc-4a57-a147-1f3dd5b753bd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX7A14-253D - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPUX7A14-253D", "orderType": "TUTTRICK"}	2026-06-01 08:02:00.728
71950e69-69f5-4505-8509-75eef6eaf48d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX89MH-B3A6 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUX89MH-B3A6", "orderType": "TUTTRICK"}	2026-06-01 08:02:46.862
cd67d357-53a5-4547-abd5-8b0e7430c363	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXB4P5-C1D1 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXB4P5-C1D1", "orderType": "MMO_PRODUCT"}	2026-06-01 08:05:00.444
867ccf35-a7d1-40fd-9b44-ab0841186f85	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXE1C5-19AD - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXE1C5-19AD", "orderType": "TUTTRICK"}	2026-06-01 08:07:16.055
92f97643-0b63-490d-9926-19b926f3366f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXE6OB-E73A - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXE6OB-E73A", "orderType": "TUTTRICK"}	2026-06-01 08:07:22.971
c3c3032a-5acb-477e-8ebf-847a14236b1c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXEX0Q-5AF7 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPUXEX0Q-5AF7", "orderType": "TUTTRICK"}	2026-06-01 08:07:57.12
9b57939c-0ca7-4a48-82f9-a8127aeb40ba	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXJL8I-59AB - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXJL8I-59AB", "orderType": "TUTTRICK"}	2026-06-01 08:11:35.123
19116d20-a8fb-4bbd-bb3c-eb3a056def47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXJQRT-0AC3 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPUXJQRT-0AC3", "orderType": "TUTTRICK"}	2026-06-01 08:11:42.293
49de450d-3cfd-4b81-9df4-4a0066ceac85	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPV71IR1-20B9 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPV71IR1-20B9", "orderType": "TUTTRICK"}	2026-06-01 12:37:28.259
8622b17c-0792-4550-8900-4696003ee7f7	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPV71PPA-F2DD - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPV71PPA-F2DD", "orderType": "TUTTRICK"}	2026-06-01 12:37:37.259
7b98700f-5f41-4e4d-b177-9aad113bbffe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWFPP28-E993 - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPWFPP28-E993", "orderType": "SELLER_PRODUCT"}	2026-06-02 09:27:59.299
27c9ea0c-29d6-44a7-b5d6-2fbf01d78e96	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWFZ86P-BA58 - Via Facebook Clone 2019 đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPWFZ86P-BA58", "orderType": "SELLER_PRODUCT"}	2026-06-02 09:35:24.019
b5514670-3b4b-45a7-85b4-3bb0fb478bdb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWGSVM5-BB6C - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPWGSVM5-BB6C", "orderType": "MMO_PRODUCT"}	2026-06-02 09:58:27.36
162fb144-912e-4416-b4d8-58fdb98f7784	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWMD2BA-DD81 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPWMD2BA-DD81", "orderType": "TUTTRICK"}	2026-06-02 12:34:07.245
986676fd-6c10-4c79-bc5a-5acf135db16c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWMDBKR-95C7 - GAME LQMB đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPWMDBKR-95C7", "orderType": "SELLER_PRODUCT"}	2026-06-02 12:34:19.238
4ebee96d-a3d6-407a-be05-6afaf8aae86e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWMDI04-90DA - KHÓA HỌC MMO đã được xử lý.	PURCHASE	f	{"amount": "1599000.00", "orderCode": "ORD-MPWMDI04-90DA", "orderType": "COURSE"}	2026-06-02 12:34:27.568
f5f6cf05-41da-4cc3-8c47-cc58454f464b	15bbcf73-c01d-4730-85d7-a1cca3730c83	Yêu cầu bán hàng bị từ chối	Lý do: ad	SYSTEM	f	\N	2026-06-02 19:19:27.024
3080a5ea-411a-4dc7-a26b-8f095afc5e7e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPX17R5I-CBA2 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPX17R5I-CBA2", "orderType": "TUTTRICK"}	2026-06-02 19:29:53.746
fa3bfc56-1ad8-4d1b-bbe2-ee39ec48db5e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZ75MTQ-E24D - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MPZ75MTQ-E24D", "orderType": "TUTTRICK"}	2026-06-04 07:51:44.871
3fa6b70f-a64d-4c2c-a6c0-f9ec80447d2e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZ773EE-3590 - Mở Khóa Icloud (IPHONE 12) đã được xử lý.	PURCHASE	f	{"amount": "3800000.00", "orderCode": "ORD-MPZ773EE-3590", "orderType": "SERVICE"}	2026-06-04 07:52:52.996
b5691817-52b8-47c6-a89a-4b613ce3e4c0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-06-04 11:28:30.131
e8940f35-e3a3-4a04-abe2-fa4b9293b4d5	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-06-04 11:36:05.927
e8b6af3e-059f-4702-9f4a-e89a427b6a13	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZF6L8O-9ACC - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPZF6L8O-9ACC", "orderType": "SELLER_PRODUCT"}	2026-06-04 11:36:26.395
1a1992c0-a3bf-42db-a794-f1237bde68ea	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZGYUMW-90E2 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MPZGYUMW-90E2", "orderType": "TUTTRICK"}	2026-06-04 12:26:24.55
610b3cd9-14af-404d-94f2-0d89e95e4f33	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPZ773EE-3590 (Mở Khóa Icloud (IPHONE 12)) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:00:59.631
5427af95-2b71-4c21-8829-20294345782a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPZ773EE-3590 (Mở Khóa Icloud (IPHONE 12)) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:02:08.522
fa0d1915-15d2-4ce9-ae21-fbf18edd4f31	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPWMDI04-90DA (KHÓA HỌC MMO) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:03:14.447
d428d30d-93f1-4452-897a-8689a6ba4ef8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPWMDI04-90DA (KHÓA HỌC MMO) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:03:29.451
bbed9e15-2012-4938-bd4c-6daf061e1745	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14L0VC-C244 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ14L0VC-C244", "orderType": "TUTTRICK"}	2026-06-05 16:15:16.411
9ce2b7ed-7c3a-4544-9f1a-b6059c957414	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14M885-60D8 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ14M885-60D8", "orderType": "TUTTRICK"}	2026-06-05 16:16:12.593
f030ef62-7f4b-40ad-8c34-e3430a7288a6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14RY9L-29D2 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ14RY9L-29D2", "orderType": "TUTTRICK"}	2026-06-05 16:20:39.631
b01f5b53-d481-4296-9ed2-6f744005b6d8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14S3XN-6367 - TUT Mở khóa tài khoản Faq đã được xử lý.	PURCHASE	f	{"amount": "950.00", "orderCode": "ORD-MQ14S3XN-6367", "orderType": "TUTTRICK"}	2026-06-05 16:20:46.967
4541ac24-228f-4988-941f-363edea2392b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14SORE-139D - TUT Mở khóa tài khoản Faq đã được xử lý.	PURCHASE	f	{"amount": "950.00", "orderCode": "ORD-MQ14SORE-139D", "orderType": "TUTTRICK"}	2026-06-05 16:21:13.96
5e78f325-64e8-4a17-a513-56f2f3cadd1b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ150QYR-3056 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ150QYR-3056", "orderType": "TUTTRICK"}	2026-06-05 16:27:30.075
12ccd949-3cee-473e-bd5e-bf5c2752771a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ153DAQ-7E07 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "95000.00", "orderCode": "ORD-MQ153DAQ-7E07", "orderType": "TUTTRICK"}	2026-06-05 16:29:32.33
13d5cdac-29fd-48a8-8bdb-53f31a4df6a3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ157SRS-212D - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ157SRS-212D", "orderType": "TUTTRICK"}	2026-06-05 16:32:58.997
161f548d-8336-46ac-b4b6-cfdb0d96d080	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ158E6W-DD42 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "95000.00", "orderCode": "ORD-MQ158E6W-DD42", "orderType": "TUTTRICK"}	2026-06-05 16:33:26.766
ee21f6bb-9161-4c58-88db-1ed9bf9a0c4e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ158IDK-7E3C - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "95000.00", "orderCode": "ORD-MQ158IDK-7E3C", "orderType": "TUTTRICK"}	2026-06-05 16:33:32.178
79b27d5d-0ea9-4ce4-a6dd-26672ef8ee7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15APIE-7D78 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15APIE-7D78", "orderType": "TUTTRICK"}	2026-06-05 16:35:14.736
5e113462-fc6f-4181-9cab-4cbefb81b3bb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15DQ08-2B1B - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15DQ08-2B1B", "orderType": "TUTTRICK"}	2026-06-05 16:37:35.359
f17f63a2-12c2-47dd-87d0-65394ec373e4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15E5C1-7536 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15E5C1-7536", "orderType": "TUTTRICK"}	2026-06-05 16:37:55.211
84262be7-6798-4b7f-a809-709963e377fe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15G40X-E560 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15G40X-E560", "orderType": "TUTTRICK"}	2026-06-05 16:39:26.838
70ba364a-bc37-4d02-b7fb-f0c33ec14b19	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15GH4S-63FA - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15GH4S-63FA", "orderType": "TUTTRICK"}	2026-06-05 16:39:43.814
66bb4d09-f7af-48fd-8f33-55f789063746	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15LVC4-C082 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MQ15LVC4-C082", "orderType": "MMO_PRODUCT"}	2026-06-05 16:43:55.517
dca86d13-3c3f-47cf-8242-c4267d046e09	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ18NHPR-B453 - Game Liên quân đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MQ18NHPR-B453", "orderType": "MMO_PRODUCT"}	2026-06-05 18:09:10.08
70d8d0ab-7564-40e1-b394-224d97b99443	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TQJVF-241A - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TQJVF-241A", "orderType": "MMO_PRODUCT"}	2026-06-06 03:59:24.727
cb8f8575-4fd6-4b09-a989-4d4ca3901c32	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TQY2R-7433 - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TQY2R-7433", "orderType": "MMO_PRODUCT"}	2026-06-06 03:59:43.118
b0ff9fbb-4df8-454d-bcc0-4c24b4776f86	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TQZWL-06F0 - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TQZWL-06F0", "orderType": "MMO_PRODUCT"}	2026-06-06 03:59:45.486
a98e5adf-87bf-463b-b970-ec1f58375dcb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TWLVU-E312 - Tài khoản intagram cổ trust 2021 đã được xử lý.	PURCHASE	f	{"amount": "259000.00", "orderCode": "ORD-MQ1TWLVU-E312", "orderType": "MMO_PRODUCT"}	2026-06-06 04:04:07.256
af782809-4c01-4221-ae64-5f41c7031d27	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TWW20-C01C - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TWW20-C01C", "orderType": "MMO_PRODUCT"}	2026-06-06 04:04:20.435
8f744aec-199c-42c1-80ad-bb068f896dfe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TX2A2-617D - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TX2A2-617D", "orderType": "MMO_PRODUCT"}	2026-06-06 04:04:28.501
6ecf555c-ae34-4ea2-a20d-a5ef0b6ebf39	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ24NLH2-BC97 - Đánh giá GG MAP VIP đã được xử lý.	PURCHASE	f	{"amount": "570000.00", "orderCode": "ORD-MQ24NLH2-BC97", "orderType": "SERVICE"}	2026-06-06 09:05:02.61
7aabf0f0-2501-41f3-b9d3-c1db79b670cd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ24OPTI-87C7 - KHÓA HỌC MMO đã được xử lý.	PURCHASE	f	{"amount": "1519050.00", "orderCode": "ORD-MQ24OPTI-87C7", "orderType": "COURSE"}	2026-06-06 09:05:54.884
bd0ef247-f45c-43ff-a80e-b041f83f02be	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2FYIH0-35D0 - GAME LQMB đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MQ2FYIH0-35D0", "orderType": "SELLER_PRODUCT"}	2026-06-06 14:21:27.726
789b7360-aae2-41fd-b849-57e2ccd53625	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2H1ZS6-EE65 - Mở Khóa Icloud (IPHONE 15 PLUS) đã được xử lý.	PURCHASE	f	{"amount": "11875000.00", "orderCode": "ORD-MQ2H1ZS6-EE65", "orderType": "SERVICE"}	2026-06-06 14:52:09.715
2364fdb7-f9a9-43f1-8b8f-ef2cc12bdbf0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2H2LWE-5F51 - Khóa Học Chạy Quảng Cáo Tiktok đã được xử lý.	PURCHASE	f	{"amount": "12349050.00", "orderCode": "ORD-MQ2H2LWE-5F51", "orderType": "COURSE"}	2026-06-06 14:52:38.38
8adff912-5730-4951-b8fc-b44d1de0b4fd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2H2VO4-2430 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ2H2VO4-2430", "orderType": "TUTTRICK"}	2026-06-06 14:52:51.04
08bf9dc5-9a16-490c-ab8b-b08fc84af542	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H1ZS6-EE65 (Mở Khóa Icloud (IPHONE 15 PLUS)) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:33.804
15cffe80-5cd6-4ca6-8df5-e46c55087972	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ24NLH2-BC97 (Đánh giá GG MAP VIP) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:44.95
311ed61c-42b7-41ff-a480-678c64972016	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2LWE-5F51 (Khóa Học Chạy Quảng Cáo Tiktok) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:54.017
54e91cf1-e979-4839-8f21-6efe8fdb7462	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ24OPTI-87C7 (KHÓA HỌC MMO) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:55.58
240b99d1-7f66-4241-80ab-e94225d8159d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPLJR013-E5AA (Tài khoản 250$) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:24:51.62
8ae1d3d0-fd2c-4950-b735-34c0008899f8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPL0W1I1-89E1 (adđ) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:25:00.791
1051a367-08fe-4e38-9f30-848bd6e12dea	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2VO4-2430 (TUT MỞ KHÓA CHAT META) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 18:05:33.508
1a04856d-dbe5-43ac-bd7e-828d7c6a82f8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2VO4-2430 (TUT MỞ KHÓA CHAT META) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 18:45:48.414
d1ff6ac5-4520-4013-b860-efb6c6c9827f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2VO4-2430 (TUT MỞ KHÓA CHAT META) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 18:48:02.567
d276fd0f-d639-402f-ac3a-b59e9f4be058	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ42URI7-1630 - Tài khoản tiktok đã được xử lý.	PURCHASE	f	{"amount": "360000.00", "orderCode": "ORD-MQ42URI7-1630", "orderType": "MMO_PRODUCT"}	2026-06-07 17:50:10.144
4164c3db-cb3f-47e2-becc-e607beee9d71	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ42V1DG-3B3E - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ42V1DG-3B3E", "orderType": "MMO_PRODUCT"}	2026-06-07 17:50:22.913
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."orders" ("id", "order_code", "user_id", "order_type", "service_id", "course_id", "tut_trick_id", "mmo_product_id", "seller_product_id", "seller_id", "item_name", "original_price", "final_price", "warranty_variant", "payment_method", "status", "delivered_item_id", "idempotency_key", "created_at", "updated_at", "completed_at", "customer_note", "withdrawn", "tut_trick_content_url_enc", "tut_trick_docs") FROM stdin;
70855275-0c52-41a1-98b8-9f1364f119c5	ORD-MPLX1VSQ-A7B6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	addad	100000.00	100000.00	\N	BALANCE	DONE	\N	afdfc054-eb93-4e4d-965b-db838c025208	2026-05-26 00:47:53.404	2026-05-26 00:47:53.404	2026-05-26 00:47:53.402	\N	f	\N	\N
6da836ad-b3b7-45d6-8825-fc6fa2621f3e	ORD-MPM39U3T-D7D3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	622a0e6b-aa57-4bd0-8902-9c6ffce62f3e	2026-05-26 03:42:02.158	2026-05-26 03:42:02.158	2026-05-26 03:42:02.154	{"name":"Chuquangdoanh"}	f	\N	\N
82e4ba46-1263-4f62-96cb-8462ea8f5ae7	ORD-MPM39ZGY-D66B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	1ab85dbb-6049-490b-91fb-5f9a5b07be39	2026-05-26 03:42:09.107	2026-05-26 03:42:09.107	2026-05-26 03:42:09.106	{"phone":"0929990999","name":"Chuquangdoanh"}	f	\N	\N
6d45fd7c-1ffe-4f1e-9de0-7db36147c12a	ORD-MPM3A2JB-8ED7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	9a2e4453-6513-4d3f-af0a-409b9bab835a	2026-05-26 03:42:13.08	2026-05-26 03:42:13.08	2026-05-26 03:42:13.079	{"phone":"0939990999","name":"Chuquangdoanh"}	f	\N	\N
a182c6df-0a9e-4418-998c-60862168023b	ORD-MPM3IYUY-54B2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	ae17d81d-7d1a-4994-a474-8b220cf364ee	2026-05-26 03:49:08.22	2026-05-26 03:49:08.22	2026-05-26 03:49:08.219	{"phone":"0992999000","name":"Chuquangdoanh"}	f	\N	\N
963438b7-fb49-4e25-a2bf-c1894bd1a00d	ORD-MPM3JSTG-9C76	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	1700c5db-6a48-48bf-9c5c-57037050267d	\N	\N	\N	\N	\N	Mở Khóa 282	200000.00	200000.00	\N	BALANCE	DONE	\N	1d80036a-7108-4d26-8beb-8d447ed10d1d	2026-05-26 03:49:47.047	2026-05-26 03:49:47.047	2026-05-26 03:49:47.045	{"link":"a","accountPass":"a","gmailPass":"a","zaloPhone":"098765422345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767380916.jpg"}	f	\N	\N
91387efa-602f-4240-b366-7d26464b3eb9	ORD-MPM3PGY9-8FE4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	1700c5db-6a48-48bf-9c5c-57037050267d	\N	\N	\N	\N	\N	Mở Khóa 282	200000.00	200000.00	\N	BALANCE	DONE	\N	069d76e6-9dc7-42b3-872b-de309c14b976	2026-05-26 03:54:11.602	2026-05-26 03:54:11.602	2026-05-26 03:54:11.601	{"link":"a","accountPass":"a","gmailPass":"a","zaloPhone":"098765422345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767380916.jpg"}	f	\N	\N
a4b0ce0c-67b8-43df-8998-42e8634fb403	ORD-MPM3Q7Y5-ECA1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	de90cdb1-275b-4438-85f9-347846ff3f33	2026-05-26 03:54:46.592	2026-05-26 03:54:46.592	2026-05-26 03:54:46.59	{"link":"á","accountPass":"q","gmailPass":"q","zaloPhone":"0987654345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767682906.jpg"}	f	\N	\N
1d3d9688-8042-4381-ad04-ffa209c312ec	ORD-MPM3QSLD-FF3A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	f96167e4-2dea-4297-a0df-88d8d092070b	2026-05-26 03:55:13.346	2026-05-26 03:55:13.346	2026-05-26 03:55:13.345	{"link":"http://localhost:3000/dich-vu","accountPass":"àdsds","gmailPass":"ad@gmail.com","zaloPhone":"0987654345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767682906.jpg"}	f	\N	\N
63c430ef-bd77-4eb2-ae85-bdc782c9f5d7	ORD-MPM3VR0N-2D53	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	a86933d9-2176-4a15-953a-bb75da73d22f	2026-05-26 03:59:04.584	2026-05-26 03:59:04.584	2026-05-26 03:59:04.583	{"link":"http://localhost:3000/dich-vu","accountPass":"àdsds","gmailPass":"ad@gmail.com","zaloPhone":"0987654345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767682906.jpg"}	f	\N	\N
821c5caf-09f4-4071-b258-aecc86aa7701	ORD-MPM3XWWO-FC8B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	b761888c-5715-48db-bf8f-27dd1595bdb5	2026-05-26 04:00:45.529	2026-05-26 04:00:45.529	2026-05-26 04:00:45.529	{"link":"424234","accountPass":"adsd","gmailPass":"ad","zaloPhone":"09876544567","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767962668.jpg"}	f	\N	\N
e9662536-42f5-4b78-86a5-2207088c8a0d	ORD-MPM3YN6L-EEAF	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 11)	3500000.00	3500000.00	24 GIỜ	BALANCE	DONE	\N	6ae6e18a-bb82-4c1c-a6a7-8ecba1ff0391	2026-05-26 04:01:19.583	2026-05-26 04:01:19.583	2026-05-26 04:01:19.582	{"imei":"3453345323424321","zaloPhone":"0393118789"}	f	\N	\N
1aaff007-ccf1-453c-93f7-a0e8114e876a	ORD-MPM3YPQR-0620	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 11)	3500000.00	3500000.00	24 GIỜ	BALANCE	DONE	\N	595b34de-16b4-4ede-be4d-6beaff7f3b4c	2026-05-26 04:01:22.9	2026-05-26 04:01:22.9	2026-05-26 04:01:22.899	{"imei":"3453345323424321","zaloPhone":"0393118789","note":"312"}	f	\N	\N
1816facb-ba21-4fd9-a765-b62ed9c6e934	ORD-MPM461QM-C459	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	287ef7e7-6ff6-4b2b-84f8-08845451f16a	2026-05-26 04:07:05.04	2026-05-26 04:07:05.04	2026-05-26 04:07:05.039	{"link":"dádadasda","accountPass":"dfsgsdgsg","gmailPass":"fsg@gmail.com","zaloPhone":"09874567654","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779768421599.jpg"}	f	\N	\N
373ca467-4600-4dfa-a72e-76b20d5abb52	ORD-MPLJKP5E-BCC5	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	e5b6563f-af22-4325-920c-2cb477347ae1	c2810faa-7301-4d6f-af35-87a8d880ec0b	2026-05-25 18:30:36.629	2026-05-26 20:28:34.823	2026-05-25 18:30:36.627	\N	f	\N	\N
7c9cddea-a5d2-4c01-9ad9-74f88917b4c4	ORD-MPL0OIT1-96CB	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	98634793-a566-4c0d-b09f-5595edda622d	e512afaa-5243-486c-8b0d-010fc129c4fc	2026-05-25 09:41:42.332	2026-05-29 19:04:47.09	2026-05-25 09:41:42.326	\N	t	\N	\N
33ba99d2-4f44-4cf5-a5e5-fbe849a5991d	ORD-MPWGSVM5-BB6C	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	07c1e75d-c61e-44a6-8483-58deed22e179	08ec90c0-e0fe-4056-8a3a-9432ee6812ae	2026-06-02 09:58:27.347	2026-06-02 09:58:27.347	2026-06-02 09:58:27.342	\N	f	\N	\N
3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05	ORD-MPWFZ86P-BA58	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	a4a52a6a-5914-4f9d-9c07-606b73a5e842	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Via Facebook Clone 2019	79000.00	79000.00	\N	BALANCE	DONE	1750c1f0-5345-45ff-9ddd-79fa723c458a	8c1debbc-85f6-43ee-87b2-7acee0d1f431	2026-06-02 09:35:23.956	2026-06-04 03:10:58.376	2026-06-02 09:35:23.954	\N	f	\N	\N
b34e9db7-b2de-41a5-8ecb-a0301ead185f	ORD-MPLJR013-E5AA	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	3b4e4d9d-e186-4649-a234-947e02fd0589	42b4a39f-488a-4f03-aa40-e9024d82df62	2026-05-25 18:35:30.666	2026-06-06 16:24:51.616	2026-06-06 16:24:51.615	\N	f	\N	\N
d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	ORD-MPL0W1I1-89E1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	adđ	50000.00	50000.00	\N	BALANCE	DONE	f940b9bc-f26e-40e8-936b-5ae39ac8062c	e4dd425f-b725-4517-a06c-3eb9fdbd06ac	2026-05-25 09:47:33.148	2026-06-06 16:25:00.787	2026-06-06 16:25:00.787	\N	f	\N	\N
18af19f0-0422-4858-b7a4-6a6f7a7cc21e	ORD-MPM4C203-D695	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	c839da86-3edf-4610-9e21-148648b0201c	2026-05-26 04:11:45.316	2026-05-26 04:11:45.316	2026-05-26 04:11:45.315	{"link":"ghỳgbn","accountPass":"dgshmg","gmailPass":"fgd@gmail.com","zaloPhone":"0987654567","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779768702519.jpg"}	f	\N	\N
238fe35c-1d5d-427f-b77e-cbb7cac2f379	ORD-MPMCIPU1-CD72	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	27444133-8f0f-4b9b-871c-1d4936dcd238	2026-05-26 08:00:53.072	2026-05-26 08:00:53.072	2026-05-26 08:00:53.066	{"link":"fhfhf","accountPass":"adsf","gmailPass":"sfdg@gmail.com","zaloPhone":"0987654567","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779782448522.jpg"}	f	\N	\N
5f16e9e8-ff23-46cc-918b-cdb591870c6b	ORD-MPMM60OP-0B88	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	37e22ff4-153b-4737-921c-657a6ec183db	2026-05-26 12:30:56.763	2026-05-26 12:30:56.763	2026-05-26 12:30:56.761	\N	f	\N	\N
90604f49-f398-4a4e-8660-e7225e19d6cc	ORD-MPMOWMMF-B02B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	f9e8f5cf-68d3-4e54-8d1c-5a1a45544a21	694be0b2-e1c0-4264-84dd-ac9313c2f481	2026-05-26 13:47:37.482	2026-05-26 16:48:54.728	2026-05-26 14:36:24.653	\N	f	\N	\N
4f2127c4-9914-4e8e-8d09-d312f2286323	ORD-MPMDLOCH-B175	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\N	\N	Tài khoản tiktok	360000.00	360000.00	\N	BALANCE	DONE	4d4885a3-8917-4ca8-beba-fb4e1a3638ce	c7c3caf6-459f-4b28-86a1-8c30818bf86a	2026-05-26 08:31:10.726	2026-05-26 20:23:02.775	2026-05-26 20:23:02.774	\N	f	\N	\N
4e8f2cc9-e39e-4f21-8042-9919b38cdaff	ORD-MPN3EO7U-AD0A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	dfea36d0-042e-46ee-bcf2-e6d4eb9ad132	2026-05-26 20:33:33.98	2026-05-26 20:33:33.98	2026-05-26 20:33:33.978	\N	f	\N	\N
47951cf1-b33a-407e-8853-705086363659	ORD-MPNQYA6M-0093	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	GAME LQMB	79000.00	79000.00	\N	BALANCE	DONE	7f6ee20c-0252-43a8-85ba-e0c9081a8820	18fb3da6-1dfb-40bc-84cf-7bafbd3d0a16	2026-05-27 07:32:40.08	2026-05-27 07:36:42.116	2026-05-27 07:32:40.078	\N	f	\N	\N
0751a761-71b9-448e-84df-841b9cd772e2	ORD-MPL0OWX2-4F48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	f5a2b518-2cd6-4df8-960a-7a857f75c661	5eb55a7e-f9ca-42ea-911f-d7e7b6d3d07b	2026-05-25 09:42:00.615	2026-05-29 19:04:47.09	2026-05-25 09:42:00.614	\N	t	\N	\N
26622a2c-2286-44ea-b60d-99a8655c86c2	ORD-MPL3W9S1-3A8F	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	2255dcef-a060-4b4d-a817-696879154bb6	d1dc8812-0a46-4faa-9c99-266c81701672	2026-05-25 11:11:42.73	2026-05-29 19:04:47.09	2026-05-25 11:11:42.722	\N	t	\N	\N
b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf	ORD-MPL3WE9E-1846	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	d50c2a98-8488-491d-a30b-cf5d6580a231	e05a4d84-3542-426b-8112-b1888aa0d325	2026-05-25 11:11:48.531	2026-05-29 19:04:47.09	2026-05-25 11:11:48.531	\N	t	\N	\N
479458ec-e829-4b69-983a-2880dc884ef5	ORD-MPL3WHTW-D670	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	2d1dc460-f5d4-43ba-bf00-06d96d7dae71	1593a02d-5d0f-401d-9a4d-6a25966ef77b	2026-05-25 11:11:53.157	2026-05-29 19:04:47.09	2026-05-25 11:11:53.156	\N	t	\N	\N
a4293674-897d-4645-8e0a-ca3b6cb5988b	ORD-MPLJQHSA-4DA4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	aa8f512c-5808-4caf-a8b3-8e20e467cd8a	11edb467-be45-478f-bf99-9872e4d43f78	2026-05-25 18:35:07.02	2026-05-29 19:04:47.09	2026-05-25 18:35:07.019	\N	t	\N	\N
f5986697-1fe9-4778-9f32-540d877b9813	ORD-MPLK63X9-0789	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	f1194ced-7572-4ea7-80da-8886cad60ee5	cca58176-5cf2-4f1b-9ea5-5ae783b0a56b	2026-05-25 18:47:15.551	2026-05-29 19:04:47.09	2026-05-26 17:40:05.024	\N	t	\N	\N
287872ad-aaba-4d2c-941c-dc2b8806d4ce	ORD-MPLJQNSG-D1EF	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	1a2258ce-3ab6-4ab1-8fbb-ed09f2f4a837	8c39e379-ee05-43c7-a789-16597319ba5e	2026-05-25 18:35:14.801	2026-05-29 19:04:47.09	2026-05-25 18:35:14.801	\N	t	\N	\N
fc287ba1-28b3-4daa-b4eb-f159632298b5	ORD-MPMLI8NH-90FE	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	b78bff62-948d-4261-b043-953886e2dc2a	fabe060d-a2bc-4627-8aba-497669dfd755	2026-05-26 12:12:27.348	2026-05-29 19:04:47.09	2026-05-26 15:52:43.755	\N	t	\N	\N
46c1d333-5e35-4297-867c-a0d04c61bd7b	ORD-MPRANUOS-C863	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	4b259378-4811-4a07-8ce2-52b777f23427	1912ab44-d9ef-480c-b6a5-f16c35a71d22	2026-05-29 19:07:44.29	2026-05-29 19:07:44.29	2026-05-29 19:07:44.285	\N	f	\N	\N
da31c0f9-d65e-4f7b-b01e-e2c65ca10d5a	ORD-MPTAN5R2-3F44	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	e2e64bca-a62e-4fa0-aa12-8157f9f185c3	2026-05-31 04:42:44.32	2026-05-31 06:53:39.562	2026-05-31 06:53:39.56	{"name":"Chu Quang Doanh"}	f	\N	\N
605a39a1-7e5c-42b8-9aa2-637b96a29b63	ORD-MPT963BS-BA1A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	90f749bd-e604-4bf7-b0fd-d413d14f5715	2026-05-31 04:01:28.43	2026-05-31 06:53:51.6	2026-05-31 06:53:51.6	{"name":"Chuquangdoanh"}	f	\N	\N
0bc64cf9-58a5-48a5-9275-92d81dd83200	ORD-MPTFGZ6F-8A3E	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	a4a52a6a-5914-4f9d-9c07-606b73a5e842	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Via Facebook Clone 2019	79000.00	79000.00	\N	BALANCE	DONE	f2c680fc-f10b-4642-bd1b-a772c1c626ca	297d4a03-1d40-41a2-b092-19a4fd3032cf	2026-05-31 06:57:53.946	2026-05-31 06:57:53.946	2026-05-31 06:57:53.944	\N	f	\N	\N
bce1fd9f-46f6-43f8-afc6-ac7e1828b47c	ORD-MPUMX1FC-DB2D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	258e1849-79f8-4217-bfe9-0ed185e56ba5	c69da14f-e291-4ebd-8adc-ddd0efc19d8c	2026-06-01 03:14:06.851	2026-06-01 03:14:06.851	2026-06-01 03:14:06.84	\N	f	\N	\N
df4dd4cb-0be4-4eda-b7d8-930f1cfc3c44	ORD-MPUMXD13-5470	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	ee6968f0-9de8-4e94-9637-3c91b62c73d9	629edd42-9cb3-4f83-99b8-4d0d10333efc	2026-06-01 03:14:21.881	2026-06-01 03:14:21.881	2026-06-01 03:14:21.879	\N	f	\N	\N
dbc4681f-fab6-40d7-b33d-68fbaf8e0ff6	ORD-MPUX61HR-7845	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	141b6996-caf8-496e-a9bf-a75dacfa9afe	fd69cb72-ffd4-4b51-be2c-431cfa8a54ee	2026-06-01 08:01:02.996	2026-06-01 08:01:02.996	2026-06-01 08:01:02.991	\N	f	\N	\N
3d06aecb-2b49-47f9-8d5f-94720e48cc5e	ORD-MPUX648F-D916	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	8edb52a0-ba37-4bf0-9dde-e7a6d2706db7	7e3ba48d-785f-406b-836f-6ebef5838846	2026-06-01 08:01:06.544	2026-06-01 08:01:06.544	2026-06-01 08:01:06.543	\N	f	\N	\N
0ff04e93-84f1-4ef1-bcab-476e9a5fdbfc	ORD-MPUX7A14-253D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	5c66cf4f-6c9b-4271-b22f-8a10d125c339	2026-06-01 08:02:00.714	2026-06-01 08:02:00.714	2026-06-01 08:02:00.712	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
d277e481-1f37-44a0-bc9b-32ea59491e30	ORD-MPV71PPA-F2DD	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	86032c08-6516-48f1-9294-18ffa1414360	2026-06-01 12:37:37.247	2026-06-01 12:37:37.247	2026-06-01 12:37:37.246	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
1928e3fb-0e2c-46e5-b5b6-01e180c2f569	ORD-MPUX89MH-B3A6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	0c8362c7-2a48-4f54-9d75-18fbeb23e9da	2026-06-01 08:02:46.845	2026-06-01 08:02:46.845	2026-06-01 08:02:46.841	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
690a9668-7a57-4275-9207-516b4b9faf50	ORD-MPUXB4P5-C1D1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	e76c41b2-0fca-4797-89bd-ad6182b2c44a	17466b9e-5731-4463-83f5-7677c847930b	2026-06-01 08:05:00.426	2026-06-01 08:05:00.426	2026-06-01 08:05:00.425	\N	f	\N	\N
e20c58c8-08f9-4c46-8032-bc1e9180b357	ORD-MPUXE1C5-19AD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	c5a8281d-9ea4-4601-9d30-e15a4352e962	2026-06-01 08:07:16.038	2026-06-01 08:07:16.038	2026-06-01 08:07:16.038	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
1313ab6a-de81-467d-9c1a-ad655e207fac	ORD-MPUXE6OB-E73A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	0f2e0a95-e7ab-4195-baf1-a5a525e86e71	2026-06-01 08:07:22.957	2026-06-01 08:07:22.957	2026-06-01 08:07:22.956	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
d5cbf671-ed55-4752-a74c-1fcd095a305f	ORD-MPUXEX0Q-5AF7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	b4de7577-3c70-4838-8293-2c4d75f57ba6	2026-06-01 08:07:57.099	2026-06-01 08:07:57.099	2026-06-01 08:07:57.099	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
c8253d47-289c-4ac6-b905-0eeb1167ccd6	ORD-MPUXJL8I-59AB	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	11f0ff3c-3a79-4bc8-995e-a6f5ec7510eb	2026-06-01 08:11:35.108	2026-06-01 08:11:35.108	2026-06-01 08:11:35.106	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
94eabca6-5e5d-43aa-bf36-9a5a773fd29f	ORD-MPUXJQRT-0AC3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	7612c1ef-3039-4131-ab02-986f16cb0d4b	2026-06-01 08:11:42.282	2026-06-01 08:11:42.282	2026-06-01 08:11:42.281	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
7c9f520c-80d0-4bdb-9995-87287d80af1d	ORD-MPV71IR1-20B9	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	e059c577-6ee8-4299-bc91-79762c9fb300	2026-06-01 12:37:28.24	2026-06-01 12:37:28.24	2026-06-01 12:37:28.238	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
61ed19d4-72cb-40d3-a018-9e963b80952a	ORD-MPWFPP28-E993	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	965fd401-a209-4b43-a17b-7bbcbd42c716	91d0c4f1-6d3b-428d-a7de-72aef129e201	2026-06-02 09:27:59.279	2026-06-02 09:27:59.279	2026-06-02 09:27:59.264	\N	f	\N	\N
84643e15-e06f-4f5d-a029-62058737dde8	ORD-MPWMD2BA-DD81	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	f6c9f573-4a6b-49a8-9315-12ee69dd3de1	2026-06-02 12:34:07.227	2026-06-02 12:34:07.227	2026-06-02 12:34:07.224	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
0c24f7af-f8ab-4da7-a05c-549dd7335f2b	ORD-MPX17R5I-CBA2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	09df96a8-3048-4321-9c84-1f3f45d3f9d3	2026-06-02 19:29:53.722	2026-06-02 19:29:53.722	2026-06-02 19:29:53.719	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
c4b8ea04-b1a9-4fbb-be7c-fdd66640f3d7	ORD-MPZ75MTQ-E24D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	e62c5bed-8859-44ab-b398-f26f846355f7	2026-06-04 07:51:44.849	2026-06-04 07:51:44.849	2026-06-04 07:51:44.846	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
2ec9ccff-7621-4925-a6df-6a6dc48a961a	ORD-MPWMDBKR-95C7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	GAME LQMB	79000.00	79000.00	\N	BALANCE	DONE	86a47279-1c0b-45c1-83c9-d0f932ea5ce2	c28bdb51-fa19-4f31-85c1-c49e3bdf9a67	2026-06-02 12:34:19.229	2026-06-04 08:36:11.931	2026-06-02 12:34:19.227	\N	f	\N	\N
0334e4cd-2a86-4638-b18b-2665b94c0143	ORD-MPZF6L8O-9ACC	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	d467a4b2-c65d-4bbd-92e9-74a0be9387b0	640eaae4-32d0-4742-86fe-14744674835a	2026-06-04 11:36:26.378	2026-06-04 12:13:31.503	2026-06-04 11:36:26.377	\N	f	\N	\N
5fe5505f-e4bb-4c2f-88f6-b647051a3ec7	ORD-MPZGYUMW-90E2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	f370438f-aa51-4720-b2a0-0e23d3cbae15	2026-06-04 12:26:24.537	2026-06-04 12:26:24.537	2026-06-04 12:26:24.537	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	ORD-MPZ773EE-3590	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 12)	4000000.00	3800000.00	24 GIỜ	BALANCE	DONE	\N	fe3d6b81-daf1-45cd-9793-01965096d07b	2026-06-04 07:52:52.984	2026-06-04 13:02:08.518	2026-06-04 13:02:08.518	{"imei":"12222222222222","zaloPhone":"0976454523"}	f	\N	\N
5470e985-5cf3-4179-bfea-2bc3ea6065c8	ORD-MPWMDI04-90DA	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	4447b4b5-91b3-4226-8089-638faa948030	\N	\N	\N	\N	KHÓA HỌC MMO	1599000.00	1599000.00	\N	BALANCE	DONE	\N	5a2feeb0-4c13-4c40-af44-529671be5106	2026-06-02 12:34:27.559	2026-06-04 13:03:29.447	2026-06-04 13:03:29.446	{"name":"Chuquangdoanh"}	f	\N	\N
e890d75e-2f4b-4e55-9f85-02ab7fc9a152	ORD-MQ14L0VC-C244	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	13a22904-adf4-4f91-8068-76b37e2e20ef	2026-06-05 16:15:16.395	2026-06-05 16:15:16.395	2026-06-05 16:15:16.393	\N	f	\N	TUT VIP
621bcefe-6099-43a5-be50-4f1b123f01ad	ORD-MQ14M885-60D8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	65443bbf-5e24-4641-9549-2db9cbf6e9a8	2026-06-05 16:16:12.583	2026-06-05 16:16:12.583	2026-06-05 16:16:12.582	\N	f	\N	TUT VIP
bd3f526c-1d84-4585-a680-d049ae7f2a58	ORD-MQ14RY9L-29D2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	3450e78e-e3ef-4d5e-8d96-738073e6cda6	2026-06-05 16:20:39.61	2026-06-05 16:20:39.61	2026-06-05 16:20:39.609	\N	f	\N	TUT VIP
dcba1098-37fc-4c91-8615-abb46720d953	ORD-MQ14S3XN-6367	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	2729244b-ae96-4a23-9703-180bb075df0a	\N	\N	\N	TUT Mở khóa tài khoản Faq	1000.00	950.00	\N	BALANCE	DONE	\N	67ce3a51-95b0-49c6-8475-e65d86b8bc14	2026-06-05 16:20:46.957	2026-06-05 16:20:46.957	2026-06-05 16:20:46.956	\N	f	\N	TUT ĐÂY
7f2ea2ba-ac75-492f-ad9b-ae5869be3230	ORD-MQ14SORE-139D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	2729244b-ae96-4a23-9703-180bb075df0a	\N	\N	\N	TUT Mở khóa tài khoản Faq	1000.00	950.00	\N	BALANCE	DONE	\N	2c6bc3e9-a19c-4ae0-9c12-1804f89cab8f	2026-06-05 16:21:13.949	2026-06-05 16:21:13.949	2026-06-05 16:21:13.947	\N	f	\\xdd5bc81180d6911e08220ce51da2cf34d5911222c886ad522bbb9e11feb624d9fe49e83d9e8679d1ab02b473de707d6f46ba1e20137162b4eba6f5ef649208e43c2a19d1cecc199e086d8c64fe91674ea50040377b4e844d1b0207aa7c4865f1ae8700bd6aa0b7996784ae	TUT ĐÂY
d6375185-eef8-49c5-af68-e6e755dd68c9	ORD-MQ150QYR-3056	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	72b59e72-ab81-4698-902f-6969b1a2eff8	2026-06-05 16:27:30.053	2026-06-05 16:27:30.053	2026-06-05 16:27:30.051	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
7fabd2c4-3744-4ea6-a692-80889dc10401	ORD-MQ153DAQ-7E07	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	95000.00	\N	BALANCE	DONE	\N	4379117c-3895-4746-b2dc-9c684646b460	2026-06-05 16:29:32.309	2026-06-05 16:29:32.309	2026-06-05 16:29:32.307	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
4631775d-d81f-4a2f-b904-72c228aef56b	ORD-MQ157SRS-212D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	f1f2338e-3fd9-4fe2-83a1-ed41c4e3cd0c	2026-06-05 16:32:58.986	2026-06-05 16:32:58.986	2026-06-05 16:32:58.985	\N	f	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
4967f83b-6fa3-48cb-a5f8-b87467e4c6d2	ORD-MQ158E6W-DD42	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	95000.00	\N	BALANCE	DONE	\N	5472c2b5-1cac-436e-b28e-3a7f66dc7eb8	2026-06-05 16:33:26.744	2026-06-05 16:33:26.744	2026-06-05 16:33:26.744	\N	f	\\x69bcd44587bad931f3fc6838771f92035e50fc1921741ef9918e5fd464	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
9aaac224-b238-4fd6-94fd-d80f3ecb7f4b	ORD-MQ158IDK-7E3C	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	95000.00	\N	BALANCE	DONE	\N	aabd840d-6c09-4708-9923-24f953f2250d	2026-06-05 16:33:32.169	2026-06-05 16:33:32.169	2026-06-05 16:33:32.168	\N	f	\\x69bcd44587bad931f3fc6838771f92035e50fc1921741ef9918e5fd464	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
5133bc8c-63b3-4271-93a0-f3e5d0f36ac7	ORD-MQ15APIE-7D78	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	f92d3987-0428-4566-b726-9d41607d0914	2026-06-05 16:35:14.726	2026-06-05 16:35:14.726	2026-06-05 16:35:14.726	\N	f	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
4e3ed6dc-ae65-4915-9a07-1de00512b25a	ORD-MQ15DQ08-2B1B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	e0a1817d-30c8-4c19-9cbb-dc8b44c91a15	2026-06-05 16:37:35.337	2026-06-05 16:37:35.337	2026-06-05 16:37:35.336	\N	f	\\x50b09ada569ee27c2c3371efc813c7e0bb6b4e92b7308c1098fb5a71651c21	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
83b3f010-bbfd-437a-be1a-8237a6f2c578	ORD-MQ15E5C1-7536	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	03414679-8cd3-4804-a567-a7a2d72e964c	2026-06-05 16:37:55.202	2026-06-05 16:37:55.202	2026-06-05 16:37:55.201	\N	f	\\x50b09ada569ee27c2c3371efc813c7e0bb6b4e92b7308c1098fb5a71651c21	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
cf95309a-dc00-4dd6-87f5-96b86d133752	ORD-MQ15G40X-E560	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	490e4b3e-3603-4e80-965e-5fb54f17d273	2026-06-05 16:39:26.818	2026-06-05 16:39:26.818	2026-06-05 16:39:26.818	\N	f	\\x83df1d7cf4c9054191dffae6973075783765cc154b6afbf88a2fa43106bb53	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
cdb6d997-7957-4011-a5b0-582bf512902e	ORD-MQ15GH4S-63FA	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	d856ad56-50cb-4126-923e-171705cc8795	2026-06-05 16:39:43.805	2026-06-05 16:39:43.805	2026-06-05 16:39:43.804	\N	f	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
4f10d6f9-4b1f-40da-b12a-09667907560c	ORD-MQ15LVC4-C082	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	8338df82-f2c0-4060-b075-712fd9772714	a1be558c-5bb7-4088-b82e-b934f8ef3cee	2026-06-05 16:43:55.495	2026-06-05 16:43:55.495	2026-06-05 16:43:55.493	\N	f	\N	\N
d48f9bf8-ee42-4b79-8740-431b3bb96552	ORD-MQ18NHPR-B453	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	44e26368-8fad-47ec-bafc-5ce03123a5b0	\N	\N	Game Liên quân	200000.00	200000.00	\N	BALANCE	DONE	4783f567-a617-46e4-9a59-853c48b304dc	40052d03-3786-4967-bfca-9225a240ca39	2026-06-05 18:09:10.02	2026-06-05 18:09:10.02	2026-06-05 18:09:10	\N	f	\N	\N
44e47a6e-f082-4ce7-adb6-aace5b5b8777	ORD-MQ1TQJVF-241A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	10ebce0f-898a-4679-ada1-4fef82d84cd8	4ab5d15f-4c17-4c4e-9ca1-aa0bac302816	2026-06-06 03:59:24.71	2026-06-06 03:59:24.71	2026-06-06 03:59:24.7	\N	f	\N	\N
df05a069-48b7-4762-8680-4e9090095065	ORD-MQ1TQY2R-7433	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	6924aaf5-d660-4f4d-9a57-4294d3f15b54	5a2fa2c5-7ea6-46e1-bc9f-1149af9af179	2026-06-06 03:59:43.108	2026-06-06 03:59:43.108	2026-06-06 03:59:43.107	\N	f	\N	\N
cae36b9b-3dff-4d84-9bec-20a648d37366	ORD-MQ1TQZWL-06F0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	2352678b-6afd-4154-90cf-8cfe3056f281	a687c3de-b361-4505-894b-f47aa5c9a1ba	2026-06-06 03:59:45.478	2026-06-06 03:59:45.478	2026-06-06 03:59:45.478	\N	f	\N	\N
2db67bdc-13e9-490e-9666-0482129daf4b	ORD-MQ1TWLVU-E312	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\N	\N	Tài khoản intagram cổ trust 2021	259000.00	259000.00	\N	BALANCE	DONE	bea50305-c46d-49e8-b545-f7fc28e26a87	20087702-71dc-4c47-a203-42bcd8ed8a46	2026-06-06 04:04:07.245	2026-06-06 04:04:07.245	2026-06-06 04:04:07.243	\N	f	\N	\N
e83a2e30-a9cd-4226-bea3-ee6fb26e70db	ORD-MQ1TWW20-C01C	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	724a986a-379d-41d4-bd39-46fcf1bd3407	c59e8a28-2f3a-4d9e-bf3f-afd265094c7d	2026-06-06 04:04:20.425	2026-06-06 04:04:20.425	2026-06-06 04:04:20.424	\N	f	\N	\N
7333b0d0-9fb1-4de6-a162-6d1b883aa1bc	ORD-MQ1TX2A2-617D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	b9ad1692-804c-4bae-9c64-baafc7444550	253b609d-760b-433d-b51b-37a1c9a12eb9	2026-06-06 04:04:28.491	2026-06-06 04:04:28.491	2026-06-06 04:04:28.49	\N	f	\N	\N
e075b268-818d-41dc-9a2a-4f89177f1acf	ORD-MQ2FYIH0-35D0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	GAME LQMB	79000.00	79000.00	\N	BALANCE	DONE	2ccc37d2-00c3-4bfc-abd6-4dcf738d653a	2d57f29e-9d1e-4202-a321-636e763877fd	2026-06-06 14:21:27.7	2026-06-06 14:21:56.181	2026-06-06 14:21:27.685	\N	f	\N	\N
b02bd798-3e00-4b18-b2ec-5c6f2b99272a	ORD-MQ2H1ZS6-EE65	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 15 PLUS)	12500000.00	11875000.00	1 THÁNG	BALANCE	DONE	\N	980c3a21-3926-444e-b54c-51e0b2f79f2b	2026-06-06 14:52:09.704	2026-06-06 16:23:33.798	2026-06-06 16:23:33.797	{"imei":"12332213421424","zaloPhone":"0987654334"}	f	\N	\N
fb17d681-5f52-4792-9c2e-c5f8c77f12d9	ORD-MQ24NLH2-BC97	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	f2251457-dd7e-464f-8942-85447bf0fe95	\N	\N	\N	\N	\N	Đánh giá GG MAP VIP	600000.00	570000.00	\N	BALANCE	DONE	\N	bb09cd48-a342-43c3-ad51-7d2498d3bb4e	2026-06-06 09:05:02.588	2026-06-06 16:23:44.946	2026-06-06 16:23:44.945	{"link":"http://localhost:3000/dich-vu","zaloPhone":"0989787856"}	f	\N	\N
0413bfac-9275-4f8b-a143-2e30066e9bc9	ORD-MQ2H2LWE-5F51	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	cbf81219-3e12-4060-9303-dca020c2e798	\N	\N	\N	\N	Khóa Học Chạy Quảng Cáo Tiktok	12999000.00	12349050.00	\N	BALANCE	DONE	\N	9cd63914-919f-4eb0-9fd4-261b6b42fb8c	2026-06-06 14:52:38.368	2026-06-06 16:23:54.012	2026-06-06 16:23:54.012	{"phone":"09876556754","name":"Chuquangdoanh"}	f	\N	\N
fa22247f-ec6f-435b-b070-57419639397d	ORD-MQ24OPTI-87C7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	4447b4b5-91b3-4226-8089-638faa948030	\N	\N	\N	\N	KHÓA HỌC MMO	1599000.00	1519050.00	\N	BALANCE	DONE	\N	658cb499-b58a-4c6a-af2b-8eb456004e30	2026-06-06 09:05:54.872	2026-06-06 16:23:55.577	2026-06-06 16:23:55.577	{"phone":"0989999888","name":"Chuquangdoanh"}	f	\N	\N
9dcf0cbf-ea8f-4e80-8349-95da399773a9	ORD-MQ2H2VO4-2430	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	023a4573-81ef-46ae-914d-27cb7258c3f6	2026-06-06 14:52:51.03	2026-06-06 18:48:02.564	2026-06-06 18:48:02.563	\N	f	\N	TUT VIP
a8255c9d-4ba5-44c1-81c4-3389c541eef6	ORD-MQ42URI7-1630	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\N	\N	Tài khoản tiktok	360000.00	360000.00	\N	BALANCE	DONE	ca28272d-cb32-46f3-84a3-8de7ee734921	843005df-3f17-467e-a131-bc5f0297c56d	2026-06-07 17:50:10.123	2026-06-07 17:50:10.123	2026-06-07 17:50:10.112	\N	f	\N	\N
ef41ab50-c8b8-4c41-8887-3f911434987d	ORD-MQ42V1DG-3B3E	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	31e1ddc0-885c-4a9d-a0c0-eabe988191bb	846f6a69-4487-4b63-ab4c-bc655db6f632	2026-06-07 17:50:22.902	2026-06-07 17:50:22.902	2026-06-07 17:50:22.9	\N	f	\N	\N
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."otp_codes" ("id", "email", "user_id", "purpose", "code_hash", "attempts", "max_attempts", "ip_address", "expires_at", "used_at", "created_at") FROM stdin;
3e2fc9d8-4c7e-40c8-ad5f-4024dffe6fda	test_923627132@example.com	\N	REGISTER	$2b$12$D9AaJ0XvNcnnA6oetotj9OLnyQV/B2QPl3TEuLMVAOdIH65TVANSO	0	5	::1	2026-05-25 08:12:40.11	\N	2026-05-25 08:02:40.126
ecd03727-a895-44e7-82f7-9c0fea0a0920	testfull_996932857@example.com	\N	REGISTER	$2b$12$1xHFZVDPO4cS29sflA8JHu5HtXH3H2tgtADB7ye8fOsLpaPE5wMa2	0	5	::1	2026-05-25 08:13:01.074	\N	2026-05-25 08:03:01.08
3cd04309-0b34-40c3-8898-8e07a13dc6e9	test@example.com	\N	REGISTER	$2b$12$0KCJ.3sCIccEUin4/DOCfOtQkMS9dYH6byqWc0wjUIWG5m9B43SeK	0	5	::1	2026-05-25 08:21:16.715	\N	2026-05-25 08:11:16.722
\.


--
-- Data for Name: page_permissions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."page_permissions" ("id", "role", "page_key", "is_enabled", "updated_by_user_id", "updated_at") FROM stdin;
384565e6-c9ba-4d0c-a510-c79b2e6ed73a	STAFF	admin/dashboard	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.43
f5571e11-a189-4289-b1e0-75c5f9932681	STAFF	admin/orders	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.439
1ba2fcc2-2a58-47a7-aecb-4e0d6b497658	STAFF	admin/deposits	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.442
0678f28c-0226-46dc-8070-13fdfc427e9c	STAFF	admin/withdrawals	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.444
e0f78cad-898a-4005-abaf-b30b5ea870fb	STAFF	admin/complaints	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.446
33a1512c-7423-4585-98ba-1b736b4c7f39	STAFF	admin/chats	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.448
285b69cc-19cf-4787-917e-5771a82b7e97	STAFF	admin/reviews	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.45
e06f3126-da90-4ebc-97e7-875a5aabec93	STAFF	admin/danh-gia	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.452
98786e96-e6ab-4b40-b363-175749e853f3	STAFF	admin/tickers	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.454
f9440d12-1c4b-45e7-9000-0b43aa204f7a	STAFF	admin/services	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.455
4ef8b59b-5ce9-4820-9a29-d561a0ec217e	STAFF	admin/courses	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.457
4b278f4d-402d-4b78-849c-b00ff2b8d87c	STAFF	admin/tut-tricks	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.46
f019f579-b3a0-4202-8f5d-b312817cbb25	STAFF	admin/mmo-products	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.462
46df95b2-db38-4f0c-a5d8-98ea1ef1b987	STAFF	admin/service-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.464
cba1f6bb-ccef-44bf-877b-28436a1c4b2d	STAFF	admin/course-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.467
71651a6a-f4de-4082-a776-99857b8dc945	STAFF	admin/resource-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.469
04173518-ee0e-433b-9fe7-e8cfe348323f	STAFF	admin/tut-trick-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.472
106f3800-c0fd-422d-9a24-d257022c69fe	STAFF	admin/sellers	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.475
19546361-3604-49b3-a36e-4806ac3d67d9	STAFF	admin/san-pham-ban	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.477
08cb7a55-5e7f-4d5a-9382-e825d16e564d	STAFF	admin/cai-dat-ban-hang	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.48
8b7d3c4b-273d-4f5b-bcd5-f655251a17fd	STAFF	admin/users	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.483
a4cdbe26-5953-4ac5-9dfb-2453ab629d5b	STAFF	admin/audit-log	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.485
fe0f0925-cb5f-4d9b-8595-0db7e05fc8a3	USER	thong-tin-ca-nhan	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.667
d8707c3b-4489-4371-b82b-d2b92df4a0e9	USER	nap-tien	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.673
52ab11c1-1b21-4881-b853-b06778ffcab4	USER	lich-su-giao-dich	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.675
1c9c0f67-6620-42e4-8b1d-37742b67e7a3	USER	don-hang	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.677
ba0f3ccd-bbe9-4b10-bee8-96fee25772ae	USER	tro-chuyen	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.679
\.


--
-- Data for Name: pending_registrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."pending_registrations" ("id", "email", "full_name", "phone", "otp_code_hash", "attempts", "ip_address", "expires_at", "created_at") FROM stdin;
afc73c88-396e-4ce9-adcc-aa1f1e38ff65	test_923627132@example.com	Test User	0912345678	\N	0	::1	2026-05-25 08:12:39.799	2026-05-25 08:02:39.819
ed5ac539-2464-4d42-af7e-9701b5e3dfa3	testfull_996932857@example.com	Test Full	0912345678	\N	0	::1	2026-05-25 08:13:00.808	2026-05-25 08:03:00.808
0f7436e6-fd75-47c4-a7e3-3e5b29e6416c	test@example.com	Nguyen Van A	0912345678	\N	0	::1	2026-05-25 08:21:16.444	2026-05-25 08:11:16.444
\.


--
-- Data for Name: public_page_configs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."public_page_configs" ("id", "page_key", "is_visible", "is_featured", "custom_label", "updated_at") FROM stdin;
65313a2e-19d4-4759-b8a9-9c96bf37641b		t	f	\N	2026-06-08 04:15:59.696
c5c67dd2-7b12-4f8c-ac52-27c6e5bb6068	dich-vu	t	t	\N	2026-06-08 04:15:59.706
fa557d60-be0d-417b-8c57-074793e36b72	khoa-hoc	t	t	\N	2026-06-08 04:15:59.709
9604fd90-16ff-4fbc-af02-88975eaa83d6	tut-tricks	t	t	\N	2026-06-08 04:15:59.711
fc6f0187-6acb-46c9-bbf9-41460393c2b4	tai-nguyen-mmo	t	t	\N	2026-06-08 04:15:59.713
1de31c54-90c0-43d1-96c9-93973aebe890	NetWorks	t	f	\N	2026-06-08 04:15:59.715
65e95397-26c4-4396-93f3-03732e7cb920	quang-cao	t	f	\N	2026-06-08 04:15:59.717
36dbf340-330c-4f75-8de7-0b31c8d2c9b5	chinh-sach	t	f	\N	2026-06-08 04:15:59.718
5f3057f3-df37-43b1-927d-5c9b093e05c0	dieu-khoan	t	f	\N	2026-06-08 04:15:59.72
8ea75765-036b-4a74-b02a-0c607eb7f709	chinh-sach-nha-ban-hang	t	f	\N	2026-06-08 04:15:59.722
91174e4a-2a44-4fe6-bf06-abb09547912e	fanpage-ads	t	f	\N	2026-06-06 18:37:46.654
decf83e3-56fa-497f-81c1-40dde9c61bfa	gioi-thieu	t	f	\N	2026-06-06 03:34:30.981
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."refresh_tokens" ("id", "user_id", "token_hash", "family", "revoked", "expires_at", "created_at") FROM stdin;
\.


--
-- Data for Name: resource_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."resource_categories" ("id", "name", "icon_url", "created_at", "updated_at", "display_order") FROM stdin;
ad1a3184-4a2b-4029-b3fa-8063074f2f77	Facebook	https://svgl.app/library/facebook-icon.svg	2026-06-06 15:23:03.076	2026-06-06 15:23:03.076	1
d98e03fb-feec-4455-8aaa-893fbccaf9a7	Tiktok	https://svgl.app/library/tiktok-icon-light.svg	2026-06-06 15:23:09.87	2026-06-06 15:23:09.87	2
6ca6cdb1-0183-4dd6-a348-f264e2a33512	Instagram	https://svgl.app/library/instagram-icon.svg	2026-06-06 15:23:18.571	2026-06-06 15:23:18.571	3
8f4f7ad2-7f34-43b0-ae38-935e0758e82b	Google	https://svgl.app/library/google.svg	2026-06-06 15:23:26.858	2026-06-06 15:23:26.858	4
78e57057-c212-4537-96d4-9d2394da5df4	Telegram	https://svgl.app/library/telegram.svg	2026-06-06 15:23:53.401	2026-06-06 15:23:53.401	5
2ea180f3-e393-46f7-b0cf-3586c758e1c7	Tool Telegram	https://svgl.app/library/wordpress.svg	2026-06-06 15:24:04.894	2026-06-06 15:24:04.894	6
52a61ea7-7047-48c5-ba8c-6ea1e893e0c1	Game	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/resource-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780759657943.png	2026-06-06 15:27:40.773	2026-06-06 15:27:40.773	7
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."reviews" ("id", "user_id", "product_type", "product_id", "rating", "comment", "created_at", "updated_at", "order_id") FROM stdin;
b093435a-6c96-4df8-a369-914ec271bd9b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	5	addd	2026-05-26 12:57:07.095	2026-05-26 12:57:07.095	373ca467-4600-4dfa-a72e-76b20d5abb52
d459d559-2761-4156-8e72-1b7441649ab5	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	45a65117-624f-4e87-b2cc-add4714bc25e	5	addadad	2026-05-26 12:57:17.952	2026-05-26 12:57:17.952	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51
d8912e2e-2ab4-497b-b727-efda12f33a91	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	46d8319b-f7a2-488d-9c21-08a6891c7e67	4	adadasd	2026-05-26 12:57:25.244	2026-05-26 12:57:25.244	f5986697-1fe9-4778-9f32-540d877b9813
bc4418e0-033d-4e5d-bf5a-6f56c584f56d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	5	\N	2026-05-26 12:57:38.517	2026-05-26 12:57:38.517	4f2127c4-9914-4e8e-8d09-d312f2286323
3c952c55-4a80-4361-b8df-f604f7348124	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	5	\N	2026-05-26 20:29:22.399	2026-05-26 20:29:22.399	90604f49-f398-4a4e-8660-e7225e19d6cc
10ca681f-3bfc-4d82-baed-8e8fb3d56e04	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_PRODUCT	8000aac0-41a3-49f4-801e-1a12191721c7	5	OK ngay	2026-05-29 19:07:55.492	2026-05-29 19:07:55.492	46c1d333-5e35-4297-867c-a0d04c61bd7b
425f5f54-c044-4fa2-9b76-6894e5fd6c91	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	8000aac0-41a3-49f4-801e-1a12191721c7	5	\N	2026-05-29 19:08:32.071	2026-05-29 19:08:32.071	7c9cddea-a5d2-4c01-9ad9-74f88917b4c4
4ff8f41a-580e-4a06-ada8-257492ee1b00	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	a4a52a6a-5914-4f9d-9c07-606b73a5e842	5	giao hàng nhanh	2026-05-31 06:58:25.088	2026-05-31 06:58:25.088	0bc64cf9-58a5-48a5-9275-92d81dd83200
33212fce-536f-4b54-ad55-955a881dacee	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	0fbf8797-e5c2-493a-b175-61f2b6b412ef	5	\N	2026-05-27 07:32:56.815	2026-06-04 12:21:36.239	47951cf1-b33a-407e-8853-705086363659
23c34290-62da-4a7c-9c85-4bd75c6cf779	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	44e26368-8fad-47ec-bafc-5ce03123a5b0	5	Quyas ok	2026-06-05 18:19:47.105	2026-06-05 18:19:47.105	d48f9bf8-ee42-4b79-8740-431b3bb96552
76330d0b-6f15-4b77-9592-693974ad539e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	7418205f-3c53-4823-ab68-d5c9a1b17f6a	5	\N	2026-06-06 04:00:43.941	2026-06-06 04:00:43.941	44e47a6e-f082-4ce7-adb6-aace5b5b8777
\.


--
-- Data for Name: seller_product_stock; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_product_stock" ("id", "product_id", "content_enc", "status", "sold_to_user_id", "order_id", "sold_at", "created_at") FROM stdin;
98634793-a566-4c0d-b09f-5595edda622d	8000aac0-41a3-49f4-801e-1a12191721c7	\\x9883675b2f451a494bff2df112780ac1711651765347b49bec5950af23	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	984b82dd-1f99-4de6-a4f8-9b0946d61829	2026-05-25 09:41:42.293	2026-05-25 09:21:32.274
f5a2b518-2cd6-4df8-960a-7a857f75c661	8000aac0-41a3-49f4-801e-1a12191721c7	\\xa946516f547f7ca6213a716fd5ceac6c1f820c48fc8cde3267005e1a55	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	db4a6df0-e805-4fd8-9a66-7f5309a671a0	2026-05-25 09:42:00.592	2026-05-25 09:21:32.274
f940b9bc-f26e-40e8-936b-5ae39ac8062c	45a65117-624f-4e87-b2cc-add4714bc25e	\\x70af146b51d0d11833d451c5367cb72b0aa9e893563c1c32c1f1c0e302	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b64a3d2e-bd2d-4b14-b963-75afb970c4e4	2026-05-25 09:47:33.123	2026-05-25 09:46:03.471
2255dcef-a060-4b4d-a817-696879154bb6	8000aac0-41a3-49f4-801e-1a12191721c7	\\xcad08f9a0719ee163ef99046a6335507be16244c0b09634ac7223a8aa4	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	00fea6b5-485e-4fed-8cf5-1904f1343963	2026-05-25 11:11:42.692	2026-05-25 09:46:23.733
d50c2a98-8488-491d-a30b-cf5d6580a231	8000aac0-41a3-49f4-801e-1a12191721c7	\\x6aa7025d51406bb40fcb68487b61b88c05ab87568e0c49f6659fe2df0b	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3b19b2bd-4d8c-4015-ab1a-5170d48ab0a6	2026-05-25 11:11:48.511	2026-05-25 09:46:23.733
2d1dc460-f5d4-43ba-bf00-06d96d7dae71	8000aac0-41a3-49f4-801e-1a12191721c7	\\xd1ff3165dba088a9b4be4c76966b06a8f49ca445cac28299553252b4e4	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b9dc0c73-5e69-4536-b885-abdd81496f66	2026-05-25 11:11:53.142	2026-05-25 09:46:23.733
aa8f512c-5808-4caf-a8b3-8e20e467cd8a	8000aac0-41a3-49f4-801e-1a12191721c7	\\x481eb4fd379aa727bb1b2279ee93aba0b0a45daa0efcfd6ffadc3c3a43	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5d2b161e-c073-4518-9687-d0280099ca90	2026-05-25 18:35:06.994	2026-05-25 09:46:23.733
1a2258ce-3ab6-4ab1-8fbb-ed09f2f4a837	8000aac0-41a3-49f4-801e-1a12191721c7	\\x14d4c9407bf87434e2f23215937a23ce85218b4b5431fd6249bbf91f28	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	6a8db83c-f71c-4d5a-929a-50a4d7838b60	2026-05-25 18:35:14.785	2026-05-25 09:46:23.733
3b4e4d9d-e186-4649-a234-947e02fd0589	45a65117-624f-4e87-b2cc-add4714bc25e	\\x328fcbfb79e7e773315cfa954d5d75f74dd99fd7c46d11cd1f1519b644	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fd7ece0b-a926-48cd-b475-67572d1f1dfb	2026-05-25 18:35:30.642	2026-05-25 09:46:03.471
f1194ced-7572-4ea7-80da-8886cad60ee5	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x03433c4cd1767beb8fdcc305aa31a1d5fd51a737c47b70fa62a1b681530ddce6215e908ef5d5cc561cc5a8	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b3c9f1b2-9cb9-4ce5-9e16-d3cb8264be64	2026-05-25 18:47:15.525	2026-05-25 17:45:04.69
b78bff62-948d-4261-b043-953886e2dc2a	45a65117-624f-4e87-b2cc-add4714bc25e	\\xc524e53f9ec8cc10a23db482500186d61903d5b5bbdcaa9839b58612d3	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b0310ece-0018-4a24-809c-aa3c234f276b	2026-05-26 12:12:27.319	2026-05-25 09:46:03.471
60ec1dab-b307-40de-aaf7-9b228f23bd43	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x5f9f995395d4ff51b679aa4589e949fd24b4f7cd8a31929de5f391992d	AVAILABLE	\N	\N	\N	2026-05-27 07:32:05.41
c243318a-5fde-4b3f-9ba8-28a6fe3bb97a	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x13c025f1acba42dac925a6b19fdf93b4fe6115a4a0280809e65d94454f	AVAILABLE	\N	\N	\N	2026-05-27 07:32:05.41
7f6ee20c-0252-43a8-85ba-e0c9081a8820	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\xe26f02e1797f7d8df7e064b2457479d86ecdd5ab2e3af2d354c64c85ae	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	708d0b40-804e-4cb4-b6b1-4345b7379492	2026-05-27 07:32:40.06	2026-05-27 07:32:05.41
4b259378-4811-4a07-8ce2-52b777f23427	8000aac0-41a3-49f4-801e-1a12191721c7	\\xfc5ab383cf0ac034f15eae48e3b02d3b612878729099cacc33b0daf207dd	SOLD	15bbcf73-c01d-4730-85d7-a1cca3730c83	1cd13ad6-fed8-4e00-9044-978a569caec7	2026-05-29 19:07:44.218	2026-05-27 07:20:29.939
f2c680fc-f10b-4642-bd1b-a772c1c626ca	a4a52a6a-5914-4f9d-9c07-606b73a5e842	\\x246d02643805d6624c8ef83658db452d07fe67ac3a41603e8dfaf457363bf8973518431682a13f38d660cd93a910de148ad6b61be06bf6465e71d638724edbd55440f2d93c24f0cbbb8ca5d3131660f48d7dcd8ecb57bcd2a4c795614c60de823607f028af962914cadafa2dc174147c3e5527b9f067d889e022534992c3214689de3cbc935acb3083adb6387edf2a4ad1940a00e6a6e9927784128d387a5c06659bf8dd14287346d6b2a43e797d942998c0c1b9a2af93f13b15ad525f377fbf87f5f3e7531f01070bfcdf8fe566ff7bfc76e15750d5ca1d9a8dbe83b6fd35f2863af4c3d72d18cbb03c3c67e58a52646d34f86c565f384f5accc47fb7f6ce43aa39a8ff7997062c0404a9f6b0166e7f1667f1058b54fcb99836d98964f6622cd983ec3616f617460b4f5c673bd103c78547cf10d69ca8db6a6f302347531b454e83501d6e9fc01186a053885926f45ae11b9b681202a3a5447bbbcbef5174011b81e49c93ca38d520308299bd7f212525e766f727a964edcda5513a7d4bcd48d561c769a04b61ad77c7909566eaaf1ee474dc78816ded0ccdb8d7ec2cb6cc8d7387845214732145047e2a3891d37b362d027547c7f87d5f239577318bb17471b3bd99703e56b86a951f990f70695a40ad6bc9791dae4c0a2bc08ef8d4c5bd2392b6157787673538d0eee1f2f9aa94ed247959e40330a51978e1403ba4b236d8b10baab889af40ffb2f9031340be0f7c3961b8b8169048a0d924a3fc9a9d24a704ff41776f3b5563064b911bc9f3f0606162208fb7c1f3850ccffe6e05b404a14b9256add49c7c04cc6048ad20e1cc18f8ed4406b26b5dbe789be8c0a0fd44ad907b03e9c020cc89a5640245bd9e87d41d503abcf55dce3c9bbb7599e029579ad929c574ed8c2c51448bf4cceec603b8e56d85a2cebef9d760ef1860d338a19bdef74d85838caa0750b3394193e4ee40c7118b0c34d35646d10b836ed6a4e5862d4d4f0602e0d91ea40f2d655d0e7d4c9843f2fc77e8ce454dcf283c65ca5e9a27bf3320b4da714472e9da8d01ea6e86e8f83b053a834551dfee1ddad5bc7bb8cda782f9f5310bfc1de3ef794c809e03e865b68dd55219154f833e6a0c8be6c7d32ff7783802697f367cca668796104d94a2eda64103a9308b2826b0cd4ee80c880f208c159f67351ee2d28f289f4c88719fb35fc54d657edb4ccf2db24666ebac117858f05d3e8bc582ef4c6653cf174aa90eb1d17fe21470e3bdce63ed7e2cfc17847e6bf0a5b4fd8a95773155c38eb13f0d368d7f465e1f2839b9eac7332666cc478a13bc0e35549b75d0bc9750cad37dfb692d399012cb1a9be44316603eb970ef4cb54652e9c2e9cd9585acc52930b7429e3ad39f6bd2cb90356787637dfc0d02af4d2c2f053d56ea0f899ce9bfe3b9dbdb77e3eb2af5a2a82faf0e6c79550153f28e1111f7f71b1bde8b332354dcf84256d08b11bac0d6be366c728fee10cd73cb09ed760fb24b	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	09e77744-92ce-4e23-881e-6882c6b1a0d2	2026-05-31 06:57:53.915	2026-05-29 19:59:52.488
258e1849-79f8-4217-bfe9-0ed185e56ba5	8000aac0-41a3-49f4-801e-1a12191721c7	\\xe79d8019e9a1abf4357bf73f9dd1a9f59d18cd76fcd6fe2187ccc1dea7fb	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	bdd35353-ff3d-43f6-af05-47f2b9926d32	2026-06-01 03:14:06.81	2026-05-27 07:20:29.939
ee6968f0-9de8-4e94-9637-3c91b62c73d9	45a65117-624f-4e87-b2cc-add4714bc25e	\\x0f126f46f91dd0c4a04345b175e0ee8535224ced789e54ab15714c610f	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7cc98edb-7f14-4ed8-896d-29efe2e67340	2026-06-01 03:14:21.858	2026-05-25 09:46:03.471
965fd401-a209-4b43-a17b-7bbcbd42c716	45a65117-624f-4e87-b2cc-add4714bc25e	\\x5c61478e4d2b30ead5246f7f4fa9b8f6ee242ec02062ce1805ac9126ea	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	13a92213-3eb5-43b1-80e3-c4720e105a21	2026-06-02 09:27:59.22	2026-05-25 09:46:03.471
1750c1f0-5345-45ff-9ddd-79fa723c458a	a4a52a6a-5914-4f9d-9c07-606b73a5e842	\\xb55f23c02abd387d32ca0789377b8a5c7eb5e2484e196b0f8c88a55837c619c9b25f0642dd97dcd208d2f0588e0e3f1c37de7fd9a2dec8de4d128975eb5b3b7d92ce55558d5acbcac58f1e47f9aa38c23bb218b00d3ddda48c7348a1908ea77a73f3d3484d68e43a0d79273c02121ff028f317f144b61b63ee4de5297fa603fd5914a00d9266f1cfb3ee856a5eaf09890bfa019635fa1d45204c94d0425333bae5fc95727181ce8fa22692ef7f01a190f7b4999df7f58fb03454330eaa8c29cfaf2fd1f8470a817d4dcbf52434e7a784d2102caecee763a969975cab0451ce8661abd1811b5ee25d3a087bafa55d6cff4cd40ff052c09b71fbc178912a443428de83d12299aa7d3f81486faf5bfba4cb7551ba6ca1404a1f4d065590b6dbbc25ea437841aea4d84f3002e023d9d91e83c23cc7eb84efb4257932a31cfda665f7718a13049b7a5b3ab700a6b775cbb0764241db6d036d7b4e0ecffee70264db574326b7624fc122c174a20c8c86288e7805d4a8f8b560d3c84ddb3daaa9008cdfe3277e9f1aa899abeaec8578dd3eb5b68e91a27b176300357cc6596006db13a90d8ebaa869ef123a11a13291330532ac11cef9d585cac29e828286e71ff1581c051a0fa78d9c6757cd9026d7c5c6f5abcdc94de19a83d505b8861ba9c0cd9a1d14e6e00f8efaa73493c7c700ec95aac4f99ae71cd79c771e72ad9eb88ca8d9fa14847ad320ca70a9a431f848b2d8159d1d32ee7e098cf1d0ab3555f5533b6a6b96e085bbf6344cc4e4f2164bba0e8efa655acb8bf69d9d4c762aec11550a2fb935ce031765441ce12f91b53deb32c48e442b1f8243025d58a085a2d3d02221402245662344ac0553e9035ae0edb120ed6388a8b2872bc5e157e31262c153ec8996deaa9365e5b0aa739c3b538e0794c7f46490e380d0a8121bd9c35de916164eea944bc17f740d0fc975e91d509e93da425e51073147b45a9e75cf4e1ecbf5b0a2855e4f71028340963ed6429c08d1c264f2d4ed9431dbe624b619c7beb19581a4336548544134016141f28047361be34c593aafc9d80686914f294392ada282b04718d5019277c9e506653f3ab9243cf6b93252edb7f7d213ee860c7c985f06b585436b36f58a5a2082e643b8bef1fa0a831a5cba697ae22f3f31c6ec01efc6a507d4245dd0d420ffffd2ae874156bfdc2aa14a06d2231f257f9129a7acdbcea518fec5b9728cbf2632b9eeb2106de38bee0ad1ca2b8adcdfbf05e320512bd97f36d72c701c47620f3a98ef5e442f3cd3444c85f75346fc7eb4778566c3955af97a7c9808421bb876554e601546de285d2dcfd957f8076961427c8ec28b42351cf27d1ac6d1a1cf0bec15e68c1662fd89ccd9fa3833b963d8dab39952a0935e74367120a32b49d53e0db2b23034f5c5b39db51704bf80794c7db4499e24a09e0ad6aede4734bb6d494285ad6839a772f5bcfd968dbd28f001dbfa615b7c4125b110746a8a75f483f0e1ec067d0143	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	93697e0d-f53f-4ee8-8d48-a06aa37d57c0	2026-06-02 09:35:23.715	2026-05-29 19:59:52.488
86a47279-1c0b-45c1-83c9-d0f932ea5ce2	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x1ec48c140875db49ec92cbe4ef6ca8780b91a500a789dcd3c9ff3db138	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	c6ceca88-b3e2-4f54-8095-0850838658f6	2026-06-02 12:34:19.204	2026-05-27 07:32:05.41
d467a4b2-c65d-4bbd-92e9-74a0be9387b0	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x99c7b8ddf4a5a3a59c2aa8ab243b4bd2adf074b41ed84e4b9e8a4682b3b1b0780a716e0185ab41e6	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cfb64bca-11b9-4773-8443-bdfc730a319e	2026-06-04 11:36:26.345	2026-05-25 17:45:04.69
2b8608e8-77b8-4d81-bd24-710d51e97482	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x0abd79441197045e87f094ea1a54de41b70de1fcaec5eaf98731cdf1f9	AVAILABLE	\N	\N	\N	2026-06-05 18:18:46.937
2ccc37d2-00c3-4bfc-abd6-4dcf738d653a	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x86e95c85b01b8464fae3ee7fecf8b65455f6457d5fb849788a115aa3f9	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	35075bb1-40c9-432a-900b-9e1a9e7635ca	2026-06-06 14:21:27.603	2026-05-27 07:32:05.41
2f9f5e02-52b9-4da2-a486-5fba690ba4b3	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x1f81ed4e5d9ee79282bb0207323f75cff1ac4d29281381603228dca1269cbb13b025df2fd4977af21a659c77b5a2ca44b52778b1d292fbfc8f476d2bcec1b95a76e182b8f021a241a98f548274e454a9679cc6131505e2314bad3add96d922bb2811cfe0266da3a2de1108	AVAILABLE	\N	\N	\N	2026-06-06 14:26:24.85
\.


--
-- Data for Name: seller_products; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_products" ("id", "seller_id", "seller_category", "name", "price", "description", "image_url", "publish_date", "is_active", "is_hidden", "is_restricted", "sales_count", "revenue", "created_at", "updated_at", "deleted_at", "sub_category_id") FROM stdin;
8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Tài khoản quảng cáo	10000.00	Cung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779727141249.jpg	\N	t	f	f	9	63000.00	2026-05-25 09:21:32.274	2026-06-01 03:14:06.81	\N	\N
46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	BM FACEBOOK	100000.00	🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779731088619.png	\N	t	f	f	2	140000.00	2026-05-25 17:45:04.69	2026-06-05 18:19:15.594	\N	\N
0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Game	GAME LQMB	79000.00	LQ VIP  1	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/b809ad2f-0580-4c8a-bc4c-7a2389dc6751/1779867104874.png	\N	t	f	f	3	165900.00	2026-05-27 07:32:05.41	2026-06-06 14:21:27.603	\N	\N
a4a52a6a-5914-4f9d-9c07-606b73a5e842	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Via Facebook Clone 2019	79000.00	🔥 Dịch Vụ Bảo Mật - Bảo Kê Facebook Bên DJ Media \n🔹 Gói Bảo Mật 3 Tháng Giá : 4Tr666K\n🔹 Gói Bảo Mật 6 tháng Giá : 6Tr999k\n\n🔥 Lợi Ích Bảo Mật :\n🔹 Chống Bị Kẻ Xấu Hack \n🔹 Không Bị Kẻ Xấu RIP	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1780084783200.png	\N	f	t	f	2	110600.00	2026-05-29 19:59:52.488	2026-06-04 11:31:33.169	2026-06-04 11:31:33.167	\N
45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Tài khoản 250$	50000.00	1	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779727106668.png	\N	f	t	f	5	175000.00	2026-05-25 09:46:03.471	2026-06-04 11:31:54.481	2026-06-04 11:31:54.48	\N
\.


--
-- Data for Name: seller_requests; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_requests" ("id", "user_id", "category", "fee", "status", "approved_category", "reject_reason", "reviewed_by_user_id", "created_at", "approved_at", "rejected_at") FROM stdin;
ebe7b9d3-047c-4bfe-8550-84bff34e1190	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	50000.00	APPROVED	Facebook	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-25 08:59:12.504	2026-05-25 08:59:46.592	\N
93fe7f32-cb2f-4372-bf4f-4e91b09b1465	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Tool & Phần mềm	50000.00	APPROVED	Game	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-27 07:28:20.408	2026-05-27 07:31:01.854	\N
6d105e38-d100-4656-bc21-2dfdcf6dedb9	f15fef1f-7843-44b0-b983-72068d1647c6	Facebook: a	50000.00	APPROVED	Facebook: a	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-29 10:02:19.879	2026-05-29 10:02:37.775	\N
d7f444d4-7577-4561-a630-6908916d41d7	15bbcf73-c01d-4730-85d7-a1cca3730c83	Canva: a	50000.00	REJECTED	\N	ad	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-29 09:51:05.258	\N	2026-06-02 19:19:27.012
\.


--
-- Data for Name: seller_sub_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_sub_categories" ("id", "name", "category_name", "display_order", "is_active", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: seller_tier_definitions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_tier_definitions" ("id", "key", "label", "description", "badge_color", "fee_percent", "min_withdrawal", "hold_days", "benefits", "upgrade_min_revenue", "upgrade_min_orders", "display_order", "is_built_in", "is_active", "created_at", "updated_at") FROM stdin;
9033a6a8-f624-4b37-af6c-d907a82dab11	GOLD	Cấp 3	Seller có doanh thu tốt	amber	11	5000000	7	["Hỗ trợ cskh nhanh tỉ lệ đơn cao"]	20000000	100	3	t	t	2026-06-04 03:26:44.294	2026-06-04 08:31:47.195
77f20ddc-fd13-4ba5-b536-30f12353c35d	SILVER	Cấp 2	Nhà bán hàng hoạt động tích cực	slate	13	3500000	7	["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"]	3000000	20	2	t	t	2026-06-04 03:26:44.294	2026-06-04 08:33:01.442
0dd8c092-7df3-4f05-8ef1-29b690aef4a8	STANDARD	Cấp 1	Hạng mặc định khi được duyệt	gray	20	1000000	2	["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"]	500000	0	1	t	t	2026-06-04 03:26:44.294	2026-06-07 14:40:48.335
1208edbf-e67b-42f8-a0c2-f115e20aacc3	VIP	Cấp 4	Seller xuất sắc — ưu đãi cao nhất	violet	9	5000000	0	["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"]	100000000	500	4	t	t	2026-06-04 03:26:44.294	2026-06-08 02:54:05.884
1c149d14-f5c4-43e4-93b5-f6f0c467c8da	SUPPER	Cấp 5	Nhà bán hàng kinh nghiệm	blue	8	1000000	3	[]	0	0	4	f	t	2026-06-04 13:05:38.539	2026-06-08 02:54:11.995
\.


--
-- Data for Name: seller_withdrawals; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_withdrawals" ("id", "seller_id", "amount", "fee_percent", "fee_amount", "net_amount", "bank_name_enc", "bank_account_number_enc", "bank_account_holder_enc", "status", "qualifying_order_ids", "reject_reason", "processed_by_user_id", "created_at", "processed_at") FROM stdin;
3ae0f920-365e-4412-84eb-427b532c7f8d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	220000.00	10	22000.00	198000.00	\\xf94550d4f934743f4d0846b64015fe08b2ce621215e3abbce4b00d65490d9469b3964a	\\x746518ec39d185a9ed95c2326e015d19827de57c7fc24e262df58465309ad8693672069b5852	\\x0b10ce2a5c0fd166c6368a96a9ceeff3d918230ddea141a55c6560f9283ec62b4e04ffa6	REJECTED	["f5986697-1fe9-4778-9f32-540d877b9813", "287872ad-aaba-4d2c-941c-dc2b8806d4ce", "a4293674-897d-4645-8e0a-ca3b6cb5988b", "479458ec-e829-4b69-983a-2880dc884ef5", "b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf", "26622a2c-2286-44ea-b60d-99a8655c86c2", "d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51", "0751a761-71b9-448e-84df-841b9cd772e2", "7c9cddea-a5d2-4c01-9ad9-74f88917b4c4"]	Chưa xác  nhận thông tin	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 19:59:36.463	2026-05-26 20:01:06.236
c8515907-0aab-4498-91e0-70c217a64847	3ad147cc-59c4-4623-ba0d-59011dcb6b93	220000.00	15	33000.00	187000.00	\\xf94550d4f934743f4d0846b64015fe08b2ce621215e3abbce4b00d65490d9469b3964a	\\x746518ec39d185a9ed95c2326e015d19827de57c7fc24e262df58465309ad8693672069b5852	\\x0b10ce2a5c0fd166c6368a96a9ceeff3d918230ddea141a55c6560f9283ec62b4e04ffa6	COMPLETED	["fc287ba1-28b3-4daa-b4eb-f159632298b5", "f5986697-1fe9-4778-9f32-540d877b9813", "287872ad-aaba-4d2c-941c-dc2b8806d4ce", "a4293674-897d-4645-8e0a-ca3b6cb5988b", "479458ec-e829-4b69-983a-2880dc884ef5", "b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf", "26622a2c-2286-44ea-b60d-99a8655c86c2", "0751a761-71b9-448e-84df-841b9cd772e2", "7c9cddea-a5d2-4c01-9ad9-74f88917b4c4"]	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-29 19:04:18.893	2026-05-29 19:04:53.967
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."service_categories" ("id", "name", "icon_url", "created_at", "updated_at", "display_order") FROM stdin;
c8487ef6-2b1e-432b-97fe-7cb74733d7fe	Facebook	https://svgl.app/library/facebook-icon.svg	2026-05-29 09:11:15.465	2026-06-06 15:20:19.783	1
836babc6-6e6a-456e-9dca-091c49c2ed62	Tiktok	https://svgl.app/library/tiktok-icon-light.svg	2026-06-06 15:42:18.203	2026-06-06 15:42:18.203	2
ed072890-2b5e-440b-a248-19de9dd310c4	Instagram	https://svgl.app/library/instagram-icon.svg	2026-06-06 15:42:28.735	2026-06-06 15:42:28.735	3
d9fc7056-0e96-4184-8f52-10e494d01bff	Google	https://svgl.app/library/google.svg	2026-06-06 15:42:36.542	2026-06-06 15:42:36.542	4
bd783349-7a97-4dba-b969-d346a8fd0a3f	Icloud	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780760568205.png	2026-06-06 15:42:51.421	2026-06-06 15:42:51.421	5
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."services" ("id", "slug", "name", "thumbnail", "platform", "category", "price", "success_rate", "processing_time", "rating", "total_orders", "total_views", "is_active", "is_featured", "description", "seo_title", "seo_description", "warranty_options", "product_list", "display_order", "created_at", "updated_at", "deleted_at", "customer_count", "platform_variants", "review_count", "requires_account_type", "requires_cccd") FROM stdin;
7a7ad9e2-9cf6-4551-a063-f247e1dbcf41	mo-khoa-gio-hang-tittok	Mở Khóa Giỏ Hàng Tittok	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780244366919.png	OTHER	Tiktok	30000000.00	100	1 ngày	5	21	453	t	f	mở khóa chỉ trong 1 ngày	\N	\N	[]	[]	1	2026-05-31 16:19:20.394	2026-05-31 16:19:31.374	\N	123	[{"icon": "https://svgl.app/library/tiktok-icon-light.svg", "name": "TikTok"}]	92	t	f
7d6cafc1-de27-4831-b383-6fb4fdf53e4c	tai-khoan-tiktok-han-che-de-xuat	Tài khoản tiktok hạn chế đề xuất	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428774308.png	OTHER	Tiktok	1500000.00	100	1 ngày	4.9	243	4321	t	f	Kháng nghị tài khoản tiktok hạn chế đề xuất kênh vi phạm cảnh báo đỏ	\N	\N	[]	[]	2	2026-06-02 12:08:25.727	2026-06-02 19:32:56.827	\N	1231	[]	1231	t	f
a71bbf5c-913d-4232-b1e9-cd37f54b3a05	unlock	Mở Khóa Icloud	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png	ICLOUD	Icloud	100000.00	100	1-3 ngày	5	12	13213	t	t	DỊCH VỤ CHẤT LƯỢNG	\N	\N	[{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}]	[{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}]	1	2026-05-24 17:22:28.488	2026-06-08 08:55:01.613	\N	32	[]	124	t	f
d11fa0ca-9935-441c-9f62-d46cf4d45999	adadad	Mở Khóa Fanpage Bị Đình Chỉ Đăng	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779618629337.png	FACEBOOK	Facebook	3500000.00	100	3 Ngày	5	212	2543	t	t	Update siêu tut khôi phục những fanpage thời gian nhanh nhất qua hệ thống meta ai auto tools !	\N	\N	[{"name": "24 giờ", "price": 0}, {"name": "1 tháng", "price": 3000000}]	[]	3	2026-05-24 10:30:42.979	2026-06-02 12:05:10.778	\N	241	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	21	t	t
1700c5db-6a48-48bf-9c5c-57037050267d	dvfb	Mở Khóa 282	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779616281373.png	FACEBOOK	Facebook	200000.00	100	1-3 ngày	5	132	1323123	t	t	abc	\N	\N	[{"name": "1 Tháng", "price": 150000}, {"name": "2 tháng", "price": 500000}]	[]	4	2026-05-23 16:22:38.098	2026-06-02 12:05:18.136	\N	123	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	2144	t	t
c8f14b74-fff9-46ee-b36b-93fa0e33287f	mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay	Mở khóa tài khoản instagram chính chủ 180 ngày	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428759528.png	OTHER	Instagram	2500000.00	100	1 ngày	5	2134	32123	t	f	Mở khóa những tài khoản instagram chính chủ	\N	\N	[]	[]	0	2026-06-02 12:11:50.312	2026-06-06 15:43:48.316	\N	4124	[]	3242	t	f
914a7223-ade0-464f-aeb8-2506fd1bd252	mo-khoa-tai-khoan-vo-hieu-hoa	Mở Khóa Tài Khoản Vô Hiệu Hóa	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401699924.png	OTHER	Facebook	4500000.00	100	1-7 ngày	4.8	423	4231	t	f	Mở Khóa Tài khoản vô hiệu hóa vĩnh viễn dạng 583, 811, 035 ...	\N	\N	[]	[]	1	2026-06-02 12:01:32.495	2026-06-02 12:01:44.37	\N	3213	[]	342	t	t
e22e8ca8-9c91-4573-b152-e532c6f3bc28	mo-khoa-tai-khoan-xac-thuc-2-yeu-to	Mở khóa tài khoản xác thực 2 yếu tố	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401804344.png	OTHER	Facebook	600000.00	100	1 ngày	5	2312	1243	t	f	Tài khoản dính xác thực 2 yếu tố, mã xác minh ... 	\N	\N	[]	[]	2	2026-06-02 12:03:26.37	2026-06-02 12:03:26.37	\N	213	[]	231	t	f
6b802cb2-5052-4578-9e7b-1b0281d6e820	mo-khoa-tai-khoan-956	Mở khóa Tài khoản 956	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401926201.png	OTHER	Facebook	900000.00	100	1 ngày	4.9	212	1412	t	f	Mở khóa những tài khoản bị dạng khóa két sắt tím và dạng khóa 956 két sắt mở	\N	\N	[]	[]	5	2026-06-02 12:04:49.509	2026-06-02 12:05:27.849	\N	324	[]	123	t	t
39484b26-a985-4dcb-bccd-87aa3904aa9b	mo-khoa-video-tiktok-vi-pham	Mở khóa video tiktok vi phạm	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428792008.png	OTHER	Tiktok	1500000.00	100	1 ngày	5	124	123	t	f	\N	\N	\N	[]	[]	3	2026-06-02 12:10:39.591	2026-06-02 19:33:15.215	\N	3423	[]	324	t	f
870c3504-944a-4833-a0ee-a25bef4c21e1	xoa-tai-khoan-tiktok-mao-danh	Xóa tài khoản tiktok mao danh	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428801249.png	OTHER	Tiktok	1500000.00	100	1 ngày	5	34	212	t	f	Xóa tai khoản tiktok mạo danh chính chủ, yêu cầu cccd trùng thông tin 	\N	\N	[]	[]	3	2026-06-02 12:09:51.848	2026-06-02 19:33:23.903	\N	412	[]	54	f	t
b3d4bf87-fe9d-4dd6-bc29-fe9c49a50bd5	xoa-danh-gia-gg-map	Xóa Đánh Gía GG MAP	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780047000131.png	OTHER	Google	1500000.00	100	1 NGÀY	5	240	21422	t	t	\N	\N	\N	[]	[]	1	2026-05-29 09:30:17.869	2026-06-06 15:43:18.808	\N	423	[]	124	t	t
f2251457-dd7e-464f-8942-85447bf0fe95	danh-gia-gg-map-vip	Đánh giá GG MAP VIP	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428783583.png	OTHER	Google	600000.00	100	1 ngày	5	45	241	t	f	30 đánh giá gg map 5 sao ngay lập tực cho gg map khi thanh toán chỉ cần link gg map cho chúng tôi. 	\N	\N	[]	[]	2	2026-06-02 12:07:13.977	2026-06-06 15:43:25.483	\N	132	[]	86	f	f
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."sessions" ("id", "user_id", "session_token", "ip_address", "user_agent", "expires_at", "created_at") FROM stdin;
\.


--
-- Data for Name: site_content; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."site_content" ("id", "key", "content", "updated_at", "updated_by_id") FROM stdin;
\.


--
-- Data for Name: staff_permissions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."staff_permissions" ("id", "user_id", "permission") FROM stdin;
\.


--
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."system_config" ("key", "value", "description", "updated_by_user_id", "updated_at") FROM stdin;
seller_settings	{"slot_packages": [{"price": 50000, "slots": 1}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 1000000, "withdrawal_fee_percent": 20}	Cấu hình rút tiền nhà bán hàng	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-07 14:40:48.331
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."testimonials" ("id", "type", "course_id", "category", "reviewer_name", "reviewer_role", "reviewer_avatar", "reviewer_initials", "reviewer_color", "content", "rating", "is_active", "display_order", "created_at", "updated_at", "service_id") FROM stdin;
493da2e8-5cfc-4f1f-8efd-4c0f4a278d9f	SERVICE	\N	Facebook	Lê tài	\N	\N	LT	#0066ff	Qúa tốt mình đã được hỗ trợ nha chóng	5	t	2	2026-06-04 12:23:35.803	2026-06-04 12:23:35.803	d11fa0ca-9935-441c-9f62-d46cf4d45999
71ca10b6-3a28-43ab-bbee-1ce42830aba3	SERVICE	\N	Facebook	Lê Văn linh	quản lý mkt	\N	LVN	#ef4444	qá tuyệt vời	5	t	0	2026-06-02 08:23:33.258	2026-06-04 12:24:12.82	1700c5db-6a48-48bf-9c5c-57037050267d
7151d2de-207c-43b4-95bb-cc60c48a70f6	COURSE	4447b4b5-91b3-4226-8089-638faa948030	\N	uy	\N	\N	AA	#0066ff	aaaa	5	t	0	2026-06-08 08:15:07.8	2026-06-08 08:15:07.8	\N
4ff19537-5d0a-47e1-9d40-db0597c7ab39	SERVICE	\N	Facebook	Chu Qunag DOanh	\N	https://cdn.hethongmmo.vn/testimonial-avatar/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780907659836.png	CQD	#0066ff	quá tuyệt	5	t	0	2026-06-08 08:34:29.087	2026-06-08 08:34:29.087	1700c5db-6a48-48bf-9c5c-57037050267d
\.


--
-- Data for Name: ticker_notifications; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."ticker_notifications" ("id", "phone", "amount", "display_order", "is_active", "created_at") FROM stdin;
\.


--
-- Data for Name: ticker_texts; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."ticker_texts" ("id", "text", "display_order", "is_active", "created_at", "updated_at") FROM stdin;
33077ab6-7ed8-4db9-950d-cd10d376fe5c	Chu Quang Doanh |  Tele :@BossMeta789 | Chạy quảng cáo | Thiết Kế Website	0	t	2026-05-30 10:33:54.347	2026-05-30 10:33:54.347
19bae89f-f56a-4911-9d55-de083febd857	Ra  Mắt | Công Bố Website Hệ Thống MMO Toàn  Quốc	0	t	2026-05-30 10:34:45.316	2026-05-30 10:34:45.316
5cff9073-1c34-4ae4-a1a9-67ee33a7b594	Đăng Kí seller bán hàng tại Fanpage để được hướng dẫn và xác nhận chi tiết	0	t	2026-06-03 02:58:25.782	2026-06-03 02:58:25.782
9c356e58-e215-4313-970e-3c26f0d205f5	Tặng 50k khi nạp 1.000.000đ mua TUT và sử dụng dịch vụ	0	t	2026-06-05 18:24:00.634	2026-06-05 18:24:00.634
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."transactions" ("id", "user_id", "order_id", "type", "amount", "description", "balance_before", "balance_after", "reference_code", "created_at", "metadata", "account_number", "transaction_date") FROM stdin;
920aacda-404a-468c-ab00-3eaf4c904dec	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	50000.00	Admin điều chỉnh số dư: +50000	0.00	50000.00	\N	2026-05-25 08:57:52.612	\N	\N	\N
da77594e-8246-465c-93d2-15c344173c59	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	50000.00	0.00	\N	2026-05-25 08:59:12.512	\N	\N	\N
dc06cf2c-28a6-4ea2-9737-e3b353825482	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	100000.00	Trả tiền thanh toán	0.00	100000.00	\N	2026-05-25 09:40:57.58	\N	\N	\N
cbd7162b-c0d8-41ed-909c-f030d2c2094c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7c9cddea-a5d2-4c01-9ad9-74f88917b4c4	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	100000.00	90000.00	\N	2026-05-25 09:41:42.348	\N	\N	\N
1a302ae3-2f86-4c8e-aa3a-8cab80ce9956	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0751a761-71b9-448e-84df-841b9cd772e2	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	90000.00	80000.00	\N	2026-05-25 09:42:00.62	\N	\N	\N
3e4a402d-9abc-4a9c-8ae5-6a6d4badf90a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	BUY_SELLER_PRODUCT	-50000.00	Mua: adđ	80000.00	30000.00	\N	2026-05-25 09:47:33.154	\N	\N	\N
ae347e1c-18ea-4593-a5e1-a5f8c5482c2c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	26622a2c-2286-44ea-b60d-99a8655c86c2	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	30000.00	20000.00	\N	2026-05-25 11:11:42.739	\N	\N	\N
0053aa8b-95ab-4c2f-8409-610d58acd391	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	20000.00	10000.00	\N	2026-05-25 11:11:48.537	\N	\N	\N
b93537d4-a23a-401c-ad38-820d5342a19f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	479458ec-e829-4b69-983a-2880dc884ef5	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10000.00	0.00	\N	2026-05-25 11:11:53.161	\N	\N	\N
406aa134-5472-43d2-8c02-532582f4a5e7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	1000000.00	Nạp tiền user	0.00	1000000.00	\N	2026-05-25 17:57:06.864	\N	\N	\N
0ed4df27-bd35-440a-8d39-dab5c32460d4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	373ca467-4600-4dfa-a72e-76b20d5abb52	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	1000000.00	901000.00	\N	2026-05-25 18:30:36.642	\N	\N	\N
5bf8b7e6-7600-4406-8304-51175f0e5226	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a4293674-897d-4645-8e0a-ca3b6cb5988b	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	901000.00	891000.00	\N	2026-05-25 18:35:07.026	\N	\N	\N
1c670452-b323-4308-857a-8e497059dc5b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	287872ad-aaba-4d2c-941c-dc2b8806d4ce	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	891000.00	881000.00	\N	2026-05-25 18:35:14.807	\N	\N	\N
5a2c6148-68cc-4711-b47f-0a7d047b1e18	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b34e9db7-b2de-41a5-8ecb-a0301ead185f	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	881000.00	831000.00	\N	2026-05-25 18:35:30.671	\N	\N	\N
ea69d32f-929c-4ff5-a77f-32967131cf5a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	f5986697-1fe9-4778-9f32-540d877b9813	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	831000.00	731000.00	\N	2026-05-25 18:47:15.559	\N	\N	\N
3e9c34df-e835-46ee-9ed9-b63ab305425c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	70855275-0c52-41a1-98b8-9f1364f119c5	BUY_TUTTRICK	-100000.00	Mua: addad	731000.00	631000.00	\N	2026-05-26 00:47:53.41	\N	\N	\N
2872c646-3aa8-483e-9d51-2790b15f24f2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	6da836ad-b3b7-45d6-8825-fc6fa2621f3e	BUY_COURSE	-200000.00	Mua: Khóa mmo	631000.00	431000.00	\N	2026-05-26 03:42:02.177	\N	\N	\N
64594b55-910e-4c36-be57-e795af6723cb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	82e4ba46-1263-4f62-96cb-8462ea8f5ae7	BUY_COURSE	-200000.00	Mua: Khóa mmo	431000.00	231000.00	\N	2026-05-26 03:42:09.115	\N	\N	\N
a067e44d-bca6-460d-82d6-2c5c8409c744	3ad147cc-59c4-4623-ba0d-59011dcb6b93	6d45fd7c-1ffe-4f1e-9de0-7db36147c12a	BUY_COURSE	-200000.00	Mua: Khóa mmo	231000.00	31000.00	\N	2026-05-26 03:42:13.088	\N	\N	\N
4902a8fb-69aa-40ba-a5af-1daa0b89b87a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	1000000.00	Admin điều chỉnh số dư: +1000000	31000.00	1031000.00	\N	2026-05-26 03:48:45.477	\N	\N	\N
f06afabb-ff39-42f3-af38-515c55608efe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a182c6df-0a9e-4418-998c-60862168023b	BUY_COURSE	-200000.00	Mua: Khóa mmo	1031000.00	831000.00	\N	2026-05-26 03:49:08.229	\N	\N	\N
f438b0e1-a710-45e5-842e-73d8726be6a8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	963438b7-fb49-4e25-a2bf-c1894bd1a00d	BUY_SERVICE	-200000.00	Mua: Mở Khóa 282	831000.00	631000.00	\N	2026-05-26 03:49:47.057	\N	\N	\N
f32844a3-2a01-43c5-8f88-bb764bd865fe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	91387efa-602f-4240-b366-7d26464b3eb9	BUY_SERVICE	-200000.00	Mua: Mở Khóa 282	631000.00	431000.00	\N	2026-05-26 03:54:11.613	\N	\N	\N
0f3903a1-6f05-4225-860c-83f9d3cfc283	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a4b0ce0c-67b8-43df-8998-42e8634fb403	BUY_SERVICE	-123213.00	Mua: ADADAD	431000.00	307787.00	\N	2026-05-26 03:54:46.601	\N	\N	\N
2b64c3e8-b0ad-4c0c-95f9-f2dc978794f0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1d3d9688-8042-4381-ad04-ffa209c312ec	BUY_SERVICE	-123213.00	Mua: ADADAD	307787.00	184574.00	\N	2026-05-26 03:55:13.355	\N	\N	\N
e114aa0e-d1ea-4006-b0c7-1d4d0bffe233	3ad147cc-59c4-4623-ba0d-59011dcb6b93	63c430ef-bd77-4eb2-ae85-bdc782c9f5d7	BUY_SERVICE	-123213.00	Mua: ADADAD	184574.00	61361.00	\N	2026-05-26 03:59:04.594	\N	\N	\N
0d45e2bf-b4fc-4b7e-a594-1916f4bea5a7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	10000000.00	Admin điều chỉnh số dư: +10000000	61361.00	10061361.00	\N	2026-05-26 04:00:37.22	\N	\N	\N
3d0b58b2-68a1-46f9-89bd-db83874f9380	3ad147cc-59c4-4623-ba0d-59011dcb6b93	821c5caf-09f4-4071-b258-aecc86aa7701	BUY_SERVICE	-123213.00	Mua: ADADAD	10061361.00	9938148.00	\N	2026-05-26 04:00:45.535	\N	\N	\N
662e10be-4684-4cf8-a1ff-d493c51b075a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e9662536-42f5-4b78-86a5-2207088c8a0d	BUY_SERVICE	-3500000.00	Mua: Mở Khóa Icloud (IPHONE 11)	9938148.00	6438148.00	\N	2026-05-26 04:01:19.589	\N	\N	\N
a2dff25e-41ba-4811-af25-c132382647bb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1aaff007-ccf1-453c-93f7-a0e8114e876a	BUY_SERVICE	-3500000.00	Mua: Mở Khóa Icloud (IPHONE 11)	6438148.00	2938148.00	\N	2026-05-26 04:01:22.904	\N	\N	\N
5a8b7d78-b6a3-4aac-9b2d-0051dab479c6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1816facb-ba21-4fd9-a765-b62ed9c6e934	BUY_SERVICE	-123213.00	Mua: ADADAD	2938148.00	2814935.00	\N	2026-05-26 04:07:05.047	\N	\N	\N
25ebcea9-8e57-4f80-9c2d-9affee56623c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	18af19f0-0422-4858-b7a4-6a6f7a7cc21e	BUY_SERVICE	-123213.00	Mua: ADADAD	2814935.00	2691722.00	\N	2026-05-26 04:11:45.329	\N	\N	\N
7b11e81f-074b-4743-84c6-4ac1b4e4dc08	3ad147cc-59c4-4623-ba0d-59011dcb6b93	238fe35c-1d5d-427f-b77e-cbb7cac2f379	BUY_SERVICE	-123213.00	Mua: ADADAD	2691722.00	2568509.00	\N	2026-05-26 08:00:53.102	\N	\N	\N
5562acfc-b7f5-4023-b658-67a74c89ff0b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4f2127c4-9914-4e8e-8d09-d312f2286323	BUY_MMO_PRODUCT	-360000.00	Mua: Tài khoản tiktok	2568509.00	2208509.00	\N	2026-05-26 08:31:10.734	\N	\N	\N
1bbd1bc3-1cd2-4ffa-acd1-32498b09fb71	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fc287ba1-28b3-4daa-b4eb-f159632298b5	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	2208509.00	2158509.00	\N	2026-05-26 12:12:27.358	\N	\N	\N
0a1208bf-210a-4bd6-84bf-3fda119b2446	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5f16e9e8-ff23-46cc-918b-cdb591870c6b	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	2158509.00	2058509.00	\N	2026-05-26 12:30:56.77	\N	\N	\N
a816e13b-efca-4bbd-bd60-7f438cd67b51	3ad147cc-59c4-4623-ba0d-59011dcb6b93	90604f49-f398-4a4e-8660-e7225e19d6cc	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	2058509.00	1959509.00	\N	2026-05-26 13:47:37.49	\N	\N	\N
cfcba64c-d7d7-4cdd-a58d-a0e2301e320c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4e8f2cc9-e39e-4f21-8042-9919b38cdaff	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	1959509.00	1859509.00	\N	2026-05-26 20:33:33.987	\N	\N	\N
7f82b861-85d3-4891-88d2-db69608c263b	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	\N	ADMIN_ADJUSTMENT	10000000.00	Nạp tiền hệ  thống	0.00	10000000.00	\N	2026-05-27 07:25:02.431	\N	\N	\N
047ddc23-bd19-487c-a9a1-2228e17c66c5	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	10000000.00	9950000.00	\N	2026-05-27 07:28:20.415	\N	\N	\N
149215ad-9365-48c3-8daa-19b7092a23a7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	47951cf1-b33a-407e-8853-705086363659	BUY_SELLER_PRODUCT	-79000.00	Mua: GAME LQMB	1859509.00	1780509.00	\N	2026-05-27 07:32:40.089	\N	\N	\N
7cadc9ca-2761-4094-952e-3173ef4d46aa	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	ADMIN_ADJUSTMENT	500000.00	Admin điều chỉnh số dư: +500000	0.00	500000.00	\N	2026-05-29 09:49:42.208	\N	\N	\N
7ee35e64-3940-4f4b-826b-82b219baf0a9	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	500000.00	450000.00	\N	2026-05-29 09:51:05.272	\N	\N	\N
7054d9ea-7900-4d6b-bc06-179cc5d53a0f	f15fef1f-7843-44b0-b983-72068d1647c6	\N	ADMIN_ADJUSTMENT	500000.00	Admin điều chỉnh số dư: +500000	0.00	500000.00	\N	2026-05-29 10:01:48.55	\N	\N	\N
79cfdfb6-d2bc-4945-91e2-b8b57368932f	f15fef1f-7843-44b0-b983-72068d1647c6	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	500000.00	450000.00	\N	2026-05-29 10:02:19.892	\N	\N	\N
f046d572-b145-4d05-a1b2-57698dd0dee9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	WITHDRAWAL_FEE	-220000.00	Rút tiền duyệt — 9 đơn hàng	1780509.00	1560509.00	\N	2026-05-29 19:04:47.143	\N	\N	\N
b1cd41a6-04c2-42f9-8cb4-de53ae9114bd	15bbcf73-c01d-4730-85d7-a1cca3730c83	46c1d333-5e35-4297-867c-a0d04c61bd7b	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	450000.00	440000.00	\N	2026-05-29 19:07:44.311	\N	\N	\N
17a7f042-a7a6-428f-bc62-e211f0dc57d2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_SLOT_PURCHASE	-50000.00	Mua gói 5 slot sản phẩm	1560509.00	1510509.00	\N	2026-05-29 19:53:32.705	\N	\N	\N
2c1ec05a-7833-4e13-82d5-8c70b0390e62	3ad147cc-59c4-4623-ba0d-59011dcb6b93	605a39a1-7e5c-42b8-9aa2-637b96a29b63	BUY_COURSE	-200000.00	Mua: Khóa mmo	1510509.00	1310509.00	\N	2026-05-31 04:01:28.448	\N	\N	\N
777a11b5-2917-40df-86fd-4799b8e06996	15bbcf73-c01d-4730-85d7-a1cca3730c83	da31c0f9-d65e-4f7b-b01e-e2c65ca10d5a	BUY_COURSE	-200000.00	Mua: Khóa mmo	440000.00	240000.00	\N	2026-05-31 04:42:44.339	\N	\N	\N
3bc0d4ff-c54e-49b1-954f-0216c0672864	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	100000.00	Quà tặng hệ thống	1310509.00	1410509.00	\N	2026-05-31 06:51:55.667	\N	\N	\N
0a1687c9-12f1-41b1-bf49-f8c96459f41b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0bc64cf9-58a5-48a5-9275-92d81dd83200	BUY_SELLER_PRODUCT	-79000.00	Mua: Via Facebook Clone 2019	1410509.00	1331509.00	\N	2026-05-31 06:57:53.953	\N	\N	\N
53300cf6-54ad-4066-9877-cd4b480563f1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	bce1fd9f-46f6-43f8-afc6-ac7e1828b47c	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	1331509.00	1321509.00	\N	2026-06-01 03:14:06.863	\N	\N	\N
56f3ca54-249b-493f-b063-67bc79370aec	3ad147cc-59c4-4623-ba0d-59011dcb6b93	df4dd4cb-0be4-4eda-b7d8-930f1cfc3c44	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	1321509.00	1271509.00	\N	2026-06-01 03:14:21.887	\N	\N	\N
1557b3d9-133e-401d-934f-0d9d29495271	3ad147cc-59c4-4623-ba0d-59011dcb6b93	dbc4681f-fab6-40d7-b33d-68fbaf8e0ff6	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	1271509.00	1172509.00	\N	2026-06-01 08:01:03.009	\N	\N	\N
8cef8063-e232-408a-a8c8-be3a59eb65b3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3d06aecb-2b49-47f9-8d5f-94720e48cc5e	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	1172509.00	1073509.00	\N	2026-06-01 08:01:06.551	\N	\N	\N
4b67739e-03e9-4059-b4d5-1d5bae536b23	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0ff04e93-84f1-4ef1-bcab-476e9a5fdbfc	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	1073509.00	973509.00	\N	2026-06-01 08:02:00.722	\N	\N	\N
3354c378-8000-453c-9b01-0e9ebe2d4aa9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1928e3fb-0e2c-46e5-b5b6-01e180c2f569	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	973509.00	874509.00	\N	2026-06-01 08:02:46.856	\N	\N	\N
bbb77ee1-61aa-4ecd-a173-334a20062d2e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	690a9668-7a57-4275-9207-516b4b9faf50	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	874509.00	775509.00	\N	2026-06-01 08:05:00.438	\N	\N	\N
44002aab-c699-4152-902b-436caee50c57	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e20c58c8-08f9-4c46-8032-bc1e9180b357	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	775509.00	676509.00	\N	2026-06-01 08:07:16.045	\N	\N	\N
6e2a3b0f-ae4e-4637-9290-02e00982068f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1313ab6a-de81-467d-9c1a-ad655e207fac	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	676509.00	577509.00	\N	2026-06-01 08:07:22.965	\N	\N	\N
104a0d62-8d5e-484e-95b4-41c93f26dfa3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d5cbf671-ed55-4752-a74c-1fcd095a305f	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	577509.00	477509.00	\N	2026-06-01 08:07:57.106	\N	\N	\N
506789a9-8ac6-4f8d-9e6f-82bdc0933bbe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	c8253d47-289c-4ac6-b905-0eeb1167ccd6	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	477509.00	378509.00	\N	2026-06-01 08:11:35.116	\N	\N	\N
e5f36393-1966-43ed-82fe-d63cdbf4b889	3ad147cc-59c4-4623-ba0d-59011dcb6b93	94eabca6-5e5d-43aa-bf36-9a5a773fd29f	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	378509.00	278509.00	\N	2026-06-01 08:11:42.288	\N	\N	\N
a7e221bc-e41b-4296-b921-19b4a3a54399	15bbcf73-c01d-4730-85d7-a1cca3730c83	7c9f520c-80d0-4bdb-9995-87287d80af1d	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	240000.00	141000.00	\N	2026-06-01 12:37:28.251	\N	\N	\N
704ae5fe-8f4d-463c-b885-abb8527144d4	15bbcf73-c01d-4730-85d7-a1cca3730c83	d277e481-1f37-44a0-bc9b-32ea59491e30	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	141000.00	41000.00	\N	2026-06-01 12:37:37.255	\N	\N	\N
871d72eb-7c4e-4092-be61-6657475f8abb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	61ed19d4-72cb-40d3-a018-9e963b80952a	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	278509.00	228509.00	\N	2026-06-02 09:27:59.291	\N	\N	\N
125e2c7b-48fc-489b-82bb-421b6cdffd3a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05	BUY_SELLER_PRODUCT	-79000.00	Mua: Via Facebook Clone 2019	228509.00	149509.00	\N	2026-06-02 09:35:23.989	\N	\N	\N
fb2dbc45-b9c5-4bfc-b19c-9a6854dd8cab	3ad147cc-59c4-4623-ba0d-59011dcb6b93	33ba99d2-4f44-4cf5-a5e5-fbe849a5991d	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	149509.00	50509.00	\N	2026-06-02 09:58:27.355	\N	\N	\N
74fd72ec-c7fc-4aa1-a378-0f7322225f2a	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	ADMIN_ADJUSTMENT	5000000.00	Admin điều chỉnh số dư: +5000000	41000.00	5041000.00	\N	2026-06-02 10:04:43.055	\N	\N	\N
516123d0-1c57-4740-a6ca-4bd3da067431	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	6666666.00	Admin điều chỉnh số dư: +6666666	50509.00	6717175.00	\N	2026-06-02 12:33:50.533	\N	\N	\N
7d63f6fc-0b56-4286-91b8-abd242a440e1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	84643e15-e06f-4f5d-a029-62058737dde8	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	6717175.00	6618175.00	\N	2026-06-02 12:34:07.24	\N	\N	\N
a1976802-179e-4df2-ae25-e8f48d341d3d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2ec9ccff-7621-4925-a6df-6a6dc48a961a	BUY_SELLER_PRODUCT	-79000.00	Mua: GAME LQMB	6618175.00	6539175.00	\N	2026-06-02 12:34:19.234	\N	\N	\N
93195eed-9769-4331-9bb3-e7a0aa03c98a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5470e985-5cf3-4179-bfea-2bc3ea6065c8	BUY_COURSE	-1599000.00	Mua: KHÓA HỌC MMO	6539175.00	4940175.00	\N	2026-06-02 12:34:27.564	\N	\N	\N
09a1c960-1a4d-4934-9669-1c02b18ca301	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_SLOT_PURCHASE	-120000.00	Mua gói 10 slot sản phẩm	4940175.00	4820175.00	\N	2026-06-02 19:05:28.853	\N	\N	\N
22190494-c5f0-408d-8a8b-7966a91c62bf	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	5041000.00	4991000.00	\N	2026-06-02 19:19:02.305	\N	\N	\N
b854e2aa-b4f1-48ca-855d-65154bd21178	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0c24f7af-f8ab-4da7-a05c-549dd7335f2b	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	4820175.00	4720175.00	\N	2026-06-02 19:29:53.74	\N	\N	\N
90b57e97-f333-4267-bb6d-04b3dfe7214e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	c4b8ea04-b1a9-4fbb-be7c-fdd66640f3d7	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	4720175.00	4626125.00	\N	2026-06-04 07:51:44.861	\N	\N	\N
4c514bbe-4d28-49e7-b646-7a5e4518b76e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	BUY_SERVICE	-3800000.00	Mua: Mở Khóa Icloud (IPHONE 12) (giảm 5%)	4626125.00	826125.00	\N	2026-06-04 07:52:52.99	\N	\N	\N
2797935f-d7a8-4076-9c67-c53109963deb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0334e4cd-2a86-4638-b18b-2665b94c0143	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	826125.00	726125.00	\N	2026-06-04 11:36:26.389	\N	\N	\N
5538412f-ac4d-4520-ab87-0e0931ff5b13	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5fe5505f-e4bb-4c2f-88f6-b647051a3ec7	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	726125.00	632075.00	\N	2026-06-04 12:26:24.544	\N	\N	\N
95e43885-6e50-4684-85b8-60c5b7442665	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e890d75e-2f4b-4e55-9f85-02ab7fc9a152	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	632075.00	442075.00	\N	2026-06-05 16:15:16.405	\N	\N	\N
56a0029a-ca96-4494-9f5e-918b4d5944fe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	621bcefe-6099-43a5-be50-4f1b123f01ad	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	442075.00	252075.00	\N	2026-06-05 16:16:12.588	\N	\N	\N
fb22496c-e1ac-42d3-b701-d37a8609d8b1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	bd3f526c-1d84-4585-a680-d049ae7f2a58	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	252075.00	62075.00	\N	2026-06-05 16:20:39.616	\N	\N	\N
d0022431-1ad4-40f8-8c79-554a039c6402	3ad147cc-59c4-4623-ba0d-59011dcb6b93	dcba1098-37fc-4c91-8615-abb46720d953	BUY_TUTTRICK	-950.00	Mua: TUT Mở khóa tài khoản Faq (giảm 5%)	62075.00	61125.00	\N	2026-06-05 16:20:46.962	\N	\N	\N
dd78f0fe-a047-4631-9da0-3772fa1f9f72	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7f2ea2ba-ac75-492f-ad9b-ae5869be3230	BUY_TUTTRICK	-950.00	Mua: TUT Mở khóa tài khoản Faq (giảm 5%)	61125.00	60175.00	\N	2026-06-05 16:21:13.954	\N	\N	\N
1b8aa424-85ff-4868-9766-dceb250bf6b9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	500000000.00	Admin điều chỉnh số dư: +500000000	60175.00	500060175.00	\N	2026-06-05 16:27:13.768	\N	\N	\N
30144bb7-8495-4198-9da9-0b35557c6c80	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d6375185-eef8-49c5-af68-e6e755dd68c9	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	500060175.00	499966125.00	\N	2026-06-05 16:27:30.07	\N	\N	\N
180b6bfb-1c48-421b-8279-53bda2b2c635	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7fabd2c4-3744-4ea6-a692-80889dc10401	BUY_TUTTRICK	-95000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ (giảm 5%)	499966125.00	499871125.00	\N	2026-06-05 16:29:32.326	\N	\N	\N
d24d3120-b40f-46a5-b353-dc0fae55162a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4631775d-d81f-4a2f-b904-72c228aef56b	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499871125.00	499777075.00	\N	2026-06-05 16:32:58.992	\N	\N	\N
5961eebe-6303-4860-82fe-30f4f6da200e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4967f83b-6fa3-48cb-a5f8-b87467e4c6d2	BUY_TUTTRICK	-95000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ (giảm 5%)	499777075.00	499682075.00	\N	2026-06-05 16:33:26.762	\N	\N	\N
e257c012-10d5-4870-a26b-3234d9133bf0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	9aaac224-b238-4fd6-94fd-d80f3ecb7f4b	BUY_TUTTRICK	-95000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ (giảm 5%)	499682075.00	499587075.00	\N	2026-06-05 16:33:32.174	\N	\N	\N
c6e636c1-8685-46af-834b-85eb8553b32d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5133bc8c-63b3-4271-93a0-f3e5d0f36ac7	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499587075.00	499493025.00	\N	2026-06-05 16:35:14.733	\N	\N	\N
a6b55203-11c3-4918-80a3-e47dec8f3c3d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4e3ed6dc-ae65-4915-9a07-1de00512b25a	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499493025.00	499398975.00	\N	2026-06-05 16:37:35.344	\N	\N	\N
4732cd73-d8a6-4d99-91e4-a47874c9ba52	3ad147cc-59c4-4623-ba0d-59011dcb6b93	83b3f010-bbfd-437a-be1a-8237a6f2c578	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499398975.00	499304925.00	\N	2026-06-05 16:37:55.207	\N	\N	\N
ecf3ca8b-467f-4e68-9381-33e3d7b301ec	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cf95309a-dc00-4dd6-87f5-96b86d133752	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499304925.00	499210875.00	\N	2026-06-05 16:39:26.824	\N	\N	\N
3ed17e1a-5af6-45b0-a2db-137db316eee1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cdb6d997-7957-4011-a5b0-582bf512902e	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499210875.00	499116825.00	\N	2026-06-05 16:39:43.809	\N	\N	\N
42f9808e-13be-4ae6-8494-0547611bc9d4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4f10d6f9-4b1f-40da-b12a-09667907560c	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	499116825.00	499017825.00	\N	2026-06-05 16:43:55.512	\N	\N	\N
ba9c72ae-204b-4aa3-ab23-9a395a2f99ef	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d48f9bf8-ee42-4b79-8740-431b3bb96552	BUY_MMO_PRODUCT	-200000.00	Mua: Game Liên quân	499017825.00	498817825.00	\N	2026-06-05 18:09:10.065	\N	\N	\N
02ef383e-99d9-43d1-96ea-dc689d0c2a39	3ad147cc-59c4-4623-ba0d-59011dcb6b93	44e47a6e-f082-4ce7-adb6-aace5b5b8777	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	498817825.00	498317825.00	\N	2026-06-06 03:59:24.721	\N	\N	\N
303b1c97-d3a7-4ad6-b601-16d2e8c4bc8c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	df05a069-48b7-4762-8680-4e9090095065	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	498317825.00	497817825.00	\N	2026-06-06 03:59:43.114	\N	\N	\N
f3682580-ae54-4ecf-a621-38144732c962	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cae36b9b-3dff-4d84-9bec-20a648d37366	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	497817825.00	497317825.00	\N	2026-06-06 03:59:45.483	\N	\N	\N
609a56b7-67ab-49a0-bf8e-0abe7b91345b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2db67bdc-13e9-490e-9666-0482129daf4b	BUY_MMO_PRODUCT	-259000.00	Mua: Tài khoản intagram cổ trust 2021	497317825.00	497058825.00	\N	2026-06-06 04:04:07.251	\N	\N	\N
d081ac92-69db-4a76-8116-c3da53e6bda8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e83a2e30-a9cd-4226-bea3-ee6fb26e70db	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	497058825.00	496558825.00	\N	2026-06-06 04:04:20.431	\N	\N	\N
2da14fd9-81f9-4362-956c-e7843bf1ca91	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7333b0d0-9fb1-4de6-a162-6d1b883aa1bc	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	496558825.00	496058825.00	\N	2026-06-06 04:04:28.496	\N	\N	\N
07565c2e-181d-4166-8345-d009a4d613bf	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fb17d681-5f52-4792-9c2e-c5f8c77f12d9	BUY_SERVICE	-570000.00	Mua: Đánh giá GG MAP VIP (giảm 5%)	496058825.00	495488825.00	\N	2026-06-06 09:05:02.601	\N	\N	\N
c6546f2b-5f6c-4d2f-b5c7-74b246d8acc8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fa22247f-ec6f-435b-b070-57419639397d	BUY_COURSE	-1519050.00	Mua: KHÓA HỌC MMO (giảm 5%)	495488825.00	493969775.00	\N	2026-06-06 09:05:54.879	\N	\N	\N
0d70019c-f27a-4bb7-bc84-f6a7e80c63b3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e075b268-818d-41dc-9a2a-4f89177f1acf	BUY_SELLER_PRODUCT	-79000.00	Mua: GAME LQMB	493969775.00	493890775.00	\N	2026-06-06 14:21:27.716	\N	\N	\N
d94ac763-1601-4316-90e1-0c47dde8d790	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b02bd798-3e00-4b18-b2ec-5c6f2b99272a	BUY_SERVICE	-11875000.00	Mua: Mở Khóa Icloud (IPHONE 15 PLUS) (giảm 5%)	493890775.00	482015775.00	\N	2026-06-06 14:52:09.71	\N	\N	\N
9bfcb06b-8be5-44cc-8c8d-ade685f48ff7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0413bfac-9275-4f8b-a143-2e30066e9bc9	BUY_COURSE	-12349050.00	Mua: Khóa Học Chạy Quảng Cáo Tiktok (giảm 5%)	482015775.00	469666725.00	\N	2026-06-06 14:52:38.374	\N	\N	\N
a0d0449a-0f4c-427a-8a38-39c3c16dd107	3ad147cc-59c4-4623-ba0d-59011dcb6b93	9dcf0cbf-ea8f-4e80-8349-95da399773a9	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	469666725.00	469476725.00	\N	2026-06-06 14:52:51.036	\N	\N	\N
9d343579-26bd-4295-a48e-ce18669846e9	e580851a-de0a-48bc-b0a0-922784cbbd2c	\N	ADMIN_ADJUSTMENT	500000.00	Admin điều chỉnh số dư: +500000	0.00	500000.00	\N	2026-06-06 16:22:46.593	\N	\N	\N
9b0b3a16-f940-4b4f-b662-f9ad8e8f30b2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_SLOT_PURCHASE	-50000.00	Mua gói 5 slot sản phẩm	469476725.00	469426725.00	\N	2026-06-07 11:11:32.879	\N	\N	\N
a25c290a-1232-457c-b259-64a039a059e0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a8255c9d-4ba5-44c1-81c4-3389c541eef6	BUY_MMO_PRODUCT	-360000.00	Mua: Tài khoản tiktok	469426725.00	469066725.00	\N	2026-06-07 17:50:10.135	\N	\N	\N
0851e73b-7297-4aba-ba93-73f46c27ff58	3ad147cc-59c4-4623-ba0d-59011dcb6b93	ef41ab50-c8b8-4c41-8887-3f911434987d	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	469066725.00	468566725.00	\N	2026-06-07 17:50:22.908	\N	\N	\N
\.


--
-- Data for Name: tut_trick_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."tut_trick_categories" ("id", "name", "created_at", "updated_at", "icon_url", "display_order") FROM stdin;
1113abc4-9877-487d-82b4-588cf58f029b	Facebook	2026-06-02 13:40:25.415	2026-06-06 15:20:19.841	https://svgl.app/library/facebook-icon.svg	1
39588a82-d0c1-491a-ba88-652868b25fef	TikTok	2026-06-06 15:24:21.579	2026-06-06 15:24:21.579	https://svgl.app/library/tiktok-icon-light.svg	2
\.


--
-- Data for Name: tut_tricks; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."tut_tricks" ("id", "slug", "name", "thumbnail", "platform", "category", "price", "description", "content_url_enc", "docs", "seo_title", "seo_description", "is_active", "is_featured", "total_orders", "total_views", "success_rate", "rating", "display_order", "published_date", "created_at", "updated_at", "deleted_at", "processing_time", "warranty_policy", "requires_account_type", "requires_cccd", "tier") FROM stdin;
f978b336-1afc-4d93-ae65-0417bce2040d	addad	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png	TIKTOK	Facebook	100000.00	TUT ĐẲNG CẤP THẾ GIỚI	\\x69bcd44587bad931f3fc6838771f92035e50fc1921741ef9918e5fd464	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n	Mở khóa hạn chế	2026	t	f	242	0	100	5	1	2026-05-24	2026-05-24 14:24:12.335	2026-06-05 16:33:18.275	\N	giao ngay	3 ngày	f	f	Có phí
165f87a9-d530-48aa-beb9-c94995d60aae	tut-mo-khoa-chat-meta	TUT MỞ KHÓA CHAT META	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780676088566.png	OTHER	Facebook	200000.00	\N	\N	TUT VIP	\N	\N	t	f	213	0	80	5	3	2026-06-05	2026-06-05 16:14:51.046	2026-06-05 16:14:51.046	\N	GIAO NGAY	1 NGÀY	f	f	Có phí
a5e5093b-abdc-4ec6-b888-72085054523a	tut-unlock-282	TUT UNLOCK 282	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png	FACEBOOK	Facebook	99000.00	TUT NÀY SỞ HỮU MỞ KHÓA ĐƯỢC MỌI DẠNG 282 TREO 282 CHƯA ẤN KHÁNG NGHỊ	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 	TUT MỚI NHẤT	Tut này chỉ sử dụng cho mở khóa	t	f	523	0	100	5	1	2026-05-26	2026-05-26 12:29:58.967	2026-06-05 16:43:28.923	\N	Giao ngay	Không bảo hành	f	f	Có phí
15ef906b-fe34-43a9-83a8-b1a542251db3	tut-change-pass-facebook-khong-dinh-sdt-va-gmail	TUT Change Pass Facebook Không Dính SDT và Gmail	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png	FACEBOOK	Facebook	600000.00	TUT SIÊU VIP DÀNH CHO AE MMO	\\x3909e4d541631a52793943397a62ca99b20e45caaa1fd2d1edca07ea4d2dde6962ece1a5dd48ddc3b614362f80b6f8f7ce168db0bc	IB ZALO 0393118789 ( MK : TUT VIP CHANGE PASS FACEBOOK ) 	\N	\N	t	f	123	0	100	5	3	2026-06-01	2026-06-01 12:35:04.36	2026-06-02 14:03:29.081	\N	Giao ngay	Bảo hàng 3 Ngày	f	f	Có phí
2729244b-ae96-4a23-9703-180bb075df0a	tut-mo-khoa-tai-khoan-faq	TUT Mở khóa tài khoản Faq	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780762576912.png	OTHER	Facebook	1000.00	TUT VIP	\\xb3b22b4de6b2dbc6363507e211db291b3522ca76518772b0368d5803930bbfede18819e0135868e3bb31f8f8e354ef2fbe436efc6c2869204f20a661b8be5fd622138d0a84ef5c5cc00b42458e3d42e06bdd515dc6ac34cb4a34baca4c08e08ebe391fdc783459049f0996	TUT ĐÂY	\N	\N	t	f	234	0	100	5	3	2026-06-02	2026-06-02 13:56:54.167	2026-06-06 16:16:22.571	\N	1 ngày	Không bảo hành	f	f	Miễn phí
\.


--
-- Data for Name: unmatched_transfers; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."unmatched_transfers" ("id", "content", "amount", "reference_code", "raw_payload", "candidates_tried", "status", "resolved_by_user_id", "resolved_at", "created_at") FROM stdin;
\.


--
-- Data for Name: user_sub_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."user_sub_categories" ("user_id", "sub_category_id") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."users" ("id", "email", "email_verified_at", "password_hash", "full_name", "phone", "role", "status", "balance", "total_deposited", "total_spent", "seller_status", "seller_category", "max_seller_products", "bank_name_enc", "bank_account_number_enc", "bank_account_holder_enc", "cccd_image_url", "portrait_image_url", "two_factor_secret_enc", "two_factor_enabled", "last_login_at", "last_login_ip", "failed_login_count", "locked_until", "uid_prefix", "created_at", "updated_at", "deleted_at", "facebook_url", "telegram_username", "shop_locked", "seller_tier", "discount_percent", "avatar_url") FROM stdin;
b809ad2f-0580-4c8a-bc4c-7a2389dc6751	doanh123@gmail.com	2026-05-27 07:24:16.268	$argon2id$v=19$m=65536,t=3,p=4$wjo2zUoQjuN3yXcqcQhU0g$kamElZK6MYoF45atgWiGsdkv7G+zpu96Hd4tjnbIH8Q	Chuquangdoanh	0989888999	SELLER	ACTIVE	9950000.00	0.00	0.00	APPROVED	Game	3	\\xc8af03c63647c987a6444f6b1be61019a4b1fbdd0c0f278a3c799d90a5d81adb316e18	\\x1a1cc71c2ba6dab5d3837f56911e12553dafac1a1e17ffa1944b719eb63d0522df5e611250	\\x040aaeefa2948bfa3bffc6858936333b49329aec44baac2d98fd0e4b5eeba59f	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/b809ad2f-0580-4c8a-bc4c-7a2389dc6751/1779866898388.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/b809ad2f-0580-4c8a-bc4c-7a2389dc6751/1779866898410.jpg	\N	f	2026-05-27 07:24:31.44	::1	0	\N	b809ad2f	2026-05-27 07:24:16.27	2026-05-27 07:31:01.861	\N	\N	\N	f	STANDARD	0	\N
b490690a-17bd-4b8b-8e8a-88f060bbbd9c	 lasvergasblackmeta@gmail.com	2026-06-02 19:22:43.3	$argon2id$v=19$m=65536,t=3,p=4$p1FSXVhPb/0AQKv+QZki8Q$fR1PT75vQ3Pd1zBJsiJqfFAdAFNFZlKhrIhEM85p7BQ	Chu Quang doanh	\N	USER	ACTIVE	0.00	0.00	0.00	NONE	\N	3	\N	\N	\N	\N	\N	\N	f	\N	\N	0	\N	b490690a	2026-06-03 02:22:43.278	2026-06-02 19:25:45.265	\N	\N	\N	f	STANDARD	0	\N
55d1694a-443e-4f08-8875-8dadff9cbf62	nhanvien@gmail.com	2026-06-02 19:26:23.855	$argon2id$v=19$m=65536,t=3,p=4$Jh5x4kA8XQ4cRisv3i++GQ$qmpcxC9QxIx1LiqJHPaevNzNM8+YB4yrawP3dzT3734	chu quang doanh	0929990999	STAFF	ACTIVE	0.00	0.00	0.00	NONE	\N	3	\N	\N	\N	\N	\N	\N	f	2026-06-02 19:27:19.254	::1	0	\N	55d1694a	2026-06-02 19:26:23.857	2026-06-02 19:27:19.254	\N	\N	\N	f	STANDARD	0	\N
15bbcf73-c01d-4730-85d7-a1cca3730c83	chudoanhofficial@gmail.com	2026-05-23 16:16:24.356	$argon2id$v=19$m=65536,t=3,p=4$gx7ysfeIt17rztFzVgF1jw$5mmRNT7u9tTeS+AveEUlA9oe5cZ8q49bsrsv0Vag3rQ	Chu Quang Doanh	0393118789	ADMIN	ACTIVE	4991000.00	0.00	409000.00	REJECTED	\N	3	\\x8fbe08cd3787c05b4462da78ae78089810bf7e06c06561d20870b2b64b18e293a9180b22a49f72	\\x53513ee69b2c5f8a0ffdd75978bed22c908335b0ea3f8d51ed0bf2aab9	\\xaba7e6cea3c90476df0384870ffc62c008bc716c527878eca85529412a	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780427940659.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780427940670.jpg	\N	f	2026-05-23 16:16:51.453	::1	0	\N	15bbcf73	2026-05-23 23:16:24.334	2026-06-03 07:23:43.872	\N	https://www.facebook.com/Chu.Quang.Doanh.Media88/	BossMeta789	f	STANDARD	0	\N
e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	2026-06-02 19:24:16.113	$argon2id$v=19$m=65536,t=3,p=4$zfE8TgVAEBxQbSCmyo7NRg$WxeYTVnkhNBLJpgkwip6H0nDNHVFCg9RweLp1hl8sQY	ADMIN CHU QUANG DOANH	\N	ADMIN	ACTIVE	500000.00	0.00	0.00	NONE	\N	3	\N	\N	\N	\N	\N	\N	f	2026-06-02 19:24:54.612	::1	0	\N	e580851a	2026-06-03 02:24:16.048	2026-06-06 16:22:46.582	\N	\N	\N	f	STANDARD	0	\N
f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	2026-05-25 11:20:10.604	$argon2id$v=19$m=65536,t=3,p=4$LdpXCifpY0oKLUYXuIbJaw$WbX77aa3fSR652k0IypvWp+YgRnP7AVkJef29RPFLfQ	Chu quang doanh	\N	SELLER	ACTIVE	450000.00	0.00	0.00	APPROVED	Facebook: a	3	\\xe94cc48c290f3bdfa09877ad4560b7010056b9db1286cf170cc13c66a94915aedee5	\\x794e365c0e9a4d9e85a8edf8aa03c16ee17fb660b912e7478c5396d418f4	\\xfbb82149c9d2208cfb8eb3e64a0b41014abb6ed12a25c0871fb46e2fa6	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/f15fef1f-7843-44b0-b983-72068d1647c6/1780048936052.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/f15fef1f-7843-44b0-b983-72068d1647c6/1780048936089.png	\N	f	2026-05-28 02:22:23.333	::1	0	\N	f15fef1f	2026-05-25 11:20:10.606	2026-06-04 12:15:31.347	\N	\N	\N	f	STANDARD	0	\N
3ad147cc-59c4-4623-ba0d-59011dcb6b93	chudoanh107@gmail.com	2026-05-25 08:13:19.365	$argon2id$v=19$m=65536,t=3,p=4$ijXPCOyCiOK8VVYp2BDNtA$z2cNBpjvOWVrUpZjU9EOJk1yosUDJ35K2KLAreiIW1A	Chu Quang Doanh	0929990999	SELLER	ACTIVE	468566725.00	0.00	49859941.00	APPROVED	Facebook	5	\\xf94550d4f934743f4d0846b64015fe08b2ce621215e3abbce4b00d65490d9469b3964a	\\x746518ec39d185a9ed95c2326e015d19827de57c7fc24e262df58465309ad8693672069b5852	\\x0b10ce2a5c0fd166c6368a96a9ceeff3d918230ddea141a55c6560f9283ec62b4e04ffa6	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779699549835.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779699549807.jpg	\N	f	2026-05-29 19:03:40.67	::1	0	\N	3ad147cc	2026-05-25 08:13:19.367	2026-06-08 08:40:10.382	\N	https://web.facebook.com/Chu.Quang.Doanh.Media88/	BossMeta789	f	VIP	5	https://cdn.hethongmmo.vn/avatar/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1780908006606.png
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."_prisma_migrations"
    ADD CONSTRAINT "_prisma_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: ads_registrations ads_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."ads_registrations"
    ADD CONSTRAINT "ads_registrations_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."audit_logs"
    ADD CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id");


--
-- Name: bank_change_requests bank_change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."bank_change_requests"
    ADD CONSTRAINT "bank_change_requests_pkey" PRIMARY KEY ("id");


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_pkey" PRIMARY KEY ("id");


--
-- Name: chat_participants chat_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_participants"
    ADD CONSTRAINT "chat_participants_pkey" PRIMARY KEY ("id");


--
-- Name: chat_rooms chat_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_rooms"
    ADD CONSTRAINT "chat_rooms_pkey" PRIMARY KEY ("id");


--
-- Name: complaints complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."complaints"
    ADD CONSTRAINT "complaints_pkey" PRIMARY KEY ("id");


--
-- Name: course_categories course_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_categories"
    ADD CONSTRAINT "course_categories_pkey" PRIMARY KEY ("id");


--
-- Name: course_faq_categories course_faq_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faq_categories"
    ADD CONSTRAINT "course_faq_categories_pkey" PRIMARY KEY ("id");


--
-- Name: course_faqs course_faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faqs"
    ADD CONSTRAINT "course_faqs_pkey" PRIMARY KEY ("id");


--
-- Name: course_support_items course_support_items_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_support_items"
    ADD CONSTRAINT "course_support_items_pkey" PRIMARY KEY ("id");


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."courses"
    ADD CONSTRAINT "courses_pkey" PRIMARY KEY ("id");


--
-- Name: fanpage_registrations fanpage_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."fanpage_registrations"
    ADD CONSTRAINT "fanpage_registrations_pkey" PRIMARY KEY ("id");


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."login_attempts"
    ADD CONSTRAINT "login_attempts_pkey" PRIMARY KEY ("id");


--
-- Name: mmo_product_items mmo_product_items_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."mmo_product_items"
    ADD CONSTRAINT "mmo_product_items_pkey" PRIMARY KEY ("id");


--
-- Name: mmo_products mmo_products_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."mmo_products"
    ADD CONSTRAINT "mmo_products_pkey" PRIMARY KEY ("id");


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_pkey" PRIMARY KEY ("id");


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."otp_codes"
    ADD CONSTRAINT "otp_codes_pkey" PRIMARY KEY ("id");


--
-- Name: page_permissions page_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."page_permissions"
    ADD CONSTRAINT "page_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: pending_registrations pending_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."pending_registrations"
    ADD CONSTRAINT "pending_registrations_pkey" PRIMARY KEY ("id");


--
-- Name: public_page_configs public_page_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."public_page_configs"
    ADD CONSTRAINT "public_page_configs_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: resource_categories resource_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."resource_categories"
    ADD CONSTRAINT "resource_categories_pkey" PRIMARY KEY ("id");


--
-- Name: reviews reviews_order_id_key; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_order_id_key" UNIQUE ("order_id");


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_pkey" PRIMARY KEY ("id");


--
-- Name: seller_product_stock seller_product_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_product_stock"
    ADD CONSTRAINT "seller_product_stock_pkey" PRIMARY KEY ("id");


--
-- Name: seller_products seller_products_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_products"
    ADD CONSTRAINT "seller_products_pkey" PRIMARY KEY ("id");


--
-- Name: seller_requests seller_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_requests"
    ADD CONSTRAINT "seller_requests_pkey" PRIMARY KEY ("id");


--
-- Name: seller_sub_categories seller_sub_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_sub_categories"
    ADD CONSTRAINT "seller_sub_categories_pkey" PRIMARY KEY ("id");


--
-- Name: seller_tier_definitions seller_tier_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_tier_definitions"
    ADD CONSTRAINT "seller_tier_definitions_pkey" PRIMARY KEY ("id");


--
-- Name: seller_withdrawals seller_withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_withdrawals"
    ADD CONSTRAINT "seller_withdrawals_pkey" PRIMARY KEY ("id");


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."service_categories"
    ADD CONSTRAINT "service_categories_pkey" PRIMARY KEY ("id");


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."services"
    ADD CONSTRAINT "services_pkey" PRIMARY KEY ("id");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: site_content site_content_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."site_content"
    ADD CONSTRAINT "site_content_pkey" PRIMARY KEY ("id");


--
-- Name: staff_permissions staff_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."staff_permissions"
    ADD CONSTRAINT "staff_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."system_config"
    ADD CONSTRAINT "system_config_pkey" PRIMARY KEY ("key");


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."testimonials"
    ADD CONSTRAINT "testimonials_pkey" PRIMARY KEY ("id");


--
-- Name: ticker_notifications ticker_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."ticker_notifications"
    ADD CONSTRAINT "ticker_notifications_pkey" PRIMARY KEY ("id");


--
-- Name: ticker_texts ticker_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."ticker_texts"
    ADD CONSTRAINT "ticker_texts_pkey" PRIMARY KEY ("id");


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_pkey" PRIMARY KEY ("id");


--
-- Name: tut_trick_categories tut_trick_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."tut_trick_categories"
    ADD CONSTRAINT "tut_trick_categories_pkey" PRIMARY KEY ("id");


--
-- Name: tut_tricks tut_tricks_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."tut_tricks"
    ADD CONSTRAINT "tut_tricks_pkey" PRIMARY KEY ("id");


--
-- Name: unmatched_transfers unmatched_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."unmatched_transfers"
    ADD CONSTRAINT "unmatched_transfers_pkey" PRIMARY KEY ("id");


--
-- Name: user_sub_categories user_sub_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."user_sub_categories"
    ADD CONSTRAINT "user_sub_categories_pkey" PRIMARY KEY ("user_id", "sub_category_id");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: ads_registrations_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ads_registrations_created_at_idx" ON "public"."ads_registrations" USING "btree" ("created_at");


--
-- Name: ads_registrations_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ads_registrations_status_idx" ON "public"."ads_registrations" USING "btree" ("status");


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "audit_logs_action_idx" ON "public"."audit_logs" USING "btree" ("action");


--
-- Name: audit_logs_actor_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "audit_logs_actor_id_created_at_idx" ON "public"."audit_logs" USING "btree" ("actor_id", "created_at");


--
-- Name: audit_logs_target_type_target_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "audit_logs_target_type_target_id_idx" ON "public"."audit_logs" USING "btree" ("target_type", "target_id");


--
-- Name: bank_change_requests_seller_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "bank_change_requests_seller_id_status_idx" ON "public"."bank_change_requests" USING "btree" ("seller_id", "status");


--
-- Name: bank_change_requests_status_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "bank_change_requests_status_created_at_idx" ON "public"."bank_change_requests" USING "btree" ("status", "created_at");


--
-- Name: chat_messages_room_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "chat_messages_room_id_created_at_idx" ON "public"."chat_messages" USING "btree" ("room_id", "created_at");


--
-- Name: chat_participants_room_id_user_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "chat_participants_room_id_user_id_key" ON "public"."chat_participants" USING "btree" ("room_id", "user_id");


--
-- Name: chat_participants_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "chat_participants_user_id_idx" ON "public"."chat_participants" USING "btree" ("user_id");


--
-- Name: chat_rooms_complaint_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "chat_rooms_complaint_id_key" ON "public"."chat_rooms" USING "btree" ("complaint_id");


--
-- Name: complaints_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "complaints_status_idx" ON "public"."complaints" USING "btree" ("status");


--
-- Name: complaints_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "complaints_user_id_idx" ON "public"."complaints" USING "btree" ("user_id");


--
-- Name: course_categories_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_categories_display_order_idx" ON "public"."course_categories" USING "btree" ("display_order");


--
-- Name: course_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "course_categories_name_key" ON "public"."course_categories" USING "btree" ("name");


--
-- Name: course_faq_categories_course_id_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_faq_categories_course_id_display_order_idx" ON "public"."course_faq_categories" USING "btree" ("course_id", "display_order");


--
-- Name: course_faqs_course_id_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_faqs_course_id_display_order_idx" ON "public"."course_faqs" USING "btree" ("course_id", "display_order");


--
-- Name: course_support_items_course_id_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_support_items_course_id_display_order_idx" ON "public"."course_support_items" USING "btree" ("course_id", "display_order");


--
-- Name: courses_category_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "courses_category_idx" ON "public"."courses" USING "btree" ("category");


--
-- Name: courses_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "courses_is_active_display_order_idx" ON "public"."courses" USING "btree" ("is_active", "display_order");


--
-- Name: courses_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "courses_slug_idx" ON "public"."courses" USING "btree" ("slug");


--
-- Name: courses_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "courses_slug_key" ON "public"."courses" USING "btree" ("slug");


--
-- Name: fanpage_registrations_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "fanpage_registrations_created_at_idx" ON "public"."fanpage_registrations" USING "btree" ("created_at");


--
-- Name: fanpage_registrations_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "fanpage_registrations_status_idx" ON "public"."fanpage_registrations" USING "btree" ("status");


--
-- Name: login_attempts_email_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "login_attempts_email_created_at_idx" ON "public"."login_attempts" USING "btree" ("email", "created_at");


--
-- Name: login_attempts_ip_address_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "login_attempts_ip_address_created_at_idx" ON "public"."login_attempts" USING "btree" ("ip_address", "created_at");


--
-- Name: mmo_product_items_order_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_product_items_order_id_idx" ON "public"."mmo_product_items" USING "btree" ("order_id");


--
-- Name: mmo_product_items_product_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_product_items_product_id_status_idx" ON "public"."mmo_product_items" USING "btree" ("product_id", "status");


--
-- Name: mmo_products_category_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_products_category_idx" ON "public"."mmo_products" USING "btree" ("category");


--
-- Name: mmo_products_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_products_is_active_idx" ON "public"."mmo_products" USING "btree" ("is_active");


--
-- Name: mmo_products_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_products_slug_idx" ON "public"."mmo_products" USING "btree" ("slug");


--
-- Name: mmo_products_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "mmo_products_slug_key" ON "public"."mmo_products" USING "btree" ("slug");


--
-- Name: notifications_user_id_is_read_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "notifications_user_id_is_read_created_at_idx" ON "public"."notifications" USING "btree" ("user_id", "is_read", "created_at");


--
-- Name: orders_idempotency_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "orders_idempotency_key_key" ON "public"."orders" USING "btree" ("idempotency_key");


--
-- Name: orders_order_code_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_order_code_idx" ON "public"."orders" USING "btree" ("order_code");


--
-- Name: orders_order_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "orders_order_code_key" ON "public"."orders" USING "btree" ("order_code");


--
-- Name: orders_order_type_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_order_type_idx" ON "public"."orders" USING "btree" ("order_type");


--
-- Name: orders_seller_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_seller_id_idx" ON "public"."orders" USING "btree" ("seller_id");


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_status_idx" ON "public"."orders" USING "btree" ("status");


--
-- Name: orders_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_user_id_created_at_idx" ON "public"."orders" USING "btree" ("user_id", "created_at");


--
-- Name: otp_codes_email_purpose_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "otp_codes_email_purpose_idx" ON "public"."otp_codes" USING "btree" ("email", "purpose");


--
-- Name: otp_codes_expires_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "otp_codes_expires_at_idx" ON "public"."otp_codes" USING "btree" ("expires_at");


--
-- Name: page_permissions_role_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "page_permissions_role_idx" ON "public"."page_permissions" USING "btree" ("role");


--
-- Name: page_permissions_role_page_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "page_permissions_role_page_key_key" ON "public"."page_permissions" USING "btree" ("role", "page_key");


--
-- Name: pending_registrations_email_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "pending_registrations_email_key" ON "public"."pending_registrations" USING "btree" ("email");


--
-- Name: public_page_configs_page_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "public_page_configs_page_key_key" ON "public"."public_page_configs" USING "btree" ("page_key");


--
-- Name: refresh_tokens_family_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "refresh_tokens_family_idx" ON "public"."refresh_tokens" USING "btree" ("family");


--
-- Name: refresh_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "refresh_tokens_token_hash_key" ON "public"."refresh_tokens" USING "btree" ("token_hash");


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "refresh_tokens_user_id_idx" ON "public"."refresh_tokens" USING "btree" ("user_id");


--
-- Name: resource_categories_name_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "resource_categories_name_idx" ON "public"."resource_categories" USING "btree" ("name");


--
-- Name: resource_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "resource_categories_name_key" ON "public"."resource_categories" USING "btree" ("name");


--
-- Name: reviews_product_type_product_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "reviews_product_type_product_id_idx" ON "public"."reviews" USING "btree" ("product_type", "product_id");


--
-- Name: reviews_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "reviews_user_id_idx" ON "public"."reviews" USING "btree" ("user_id");


--
-- Name: seller_product_stock_product_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_product_stock_product_id_status_idx" ON "public"."seller_product_stock" USING "btree" ("product_id", "status");


--
-- Name: seller_products_is_active_is_hidden_is_restricted_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_products_is_active_is_hidden_is_restricted_idx" ON "public"."seller_products" USING "btree" ("is_active", "is_hidden", "is_restricted");


--
-- Name: seller_products_seller_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_products_seller_id_idx" ON "public"."seller_products" USING "btree" ("seller_id");


--
-- Name: seller_products_sub_category_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_products_sub_category_id_idx" ON "public"."seller_products" USING "btree" ("sub_category_id");


--
-- Name: seller_requests_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_requests_status_idx" ON "public"."seller_requests" USING "btree" ("status");


--
-- Name: seller_requests_user_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "seller_requests_user_id_key" ON "public"."seller_requests" USING "btree" ("user_id");


--
-- Name: seller_sub_categories_category_name_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_sub_categories_category_name_is_active_idx" ON "public"."seller_sub_categories" USING "btree" ("category_name", "is_active");


--
-- Name: seller_sub_categories_category_name_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "seller_sub_categories_category_name_name_key" ON "public"."seller_sub_categories" USING "btree" ("category_name", "name");


--
-- Name: seller_tier_definitions_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_tier_definitions_is_active_display_order_idx" ON "public"."seller_tier_definitions" USING "btree" ("is_active", "display_order");


--
-- Name: seller_tier_definitions_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "seller_tier_definitions_key_key" ON "public"."seller_tier_definitions" USING "btree" ("key");


--
-- Name: seller_withdrawals_seller_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_withdrawals_seller_id_status_idx" ON "public"."seller_withdrawals" USING "btree" ("seller_id", "status");


--
-- Name: seller_withdrawals_status_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_withdrawals_status_created_at_idx" ON "public"."seller_withdrawals" USING "btree" ("status", "created_at");


--
-- Name: service_categories_name_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "service_categories_name_idx" ON "public"."service_categories" USING "btree" ("name");


--
-- Name: service_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "service_categories_name_key" ON "public"."service_categories" USING "btree" ("name");


--
-- Name: services_category_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_category_idx" ON "public"."services" USING "btree" ("category");


--
-- Name: services_is_active_is_featured_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_is_active_is_featured_idx" ON "public"."services" USING "btree" ("is_active", "is_featured");


--
-- Name: services_platform_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_platform_idx" ON "public"."services" USING "btree" ("platform");


--
-- Name: services_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_slug_idx" ON "public"."services" USING "btree" ("slug");


--
-- Name: services_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "services_slug_key" ON "public"."services" USING "btree" ("slug");


--
-- Name: sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "sessions_expires_at_idx" ON "public"."sessions" USING "btree" ("expires_at");


--
-- Name: sessions_session_token_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "sessions_session_token_idx" ON "public"."sessions" USING "btree" ("session_token");


--
-- Name: sessions_session_token_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "sessions_session_token_key" ON "public"."sessions" USING "btree" ("session_token");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "sessions_user_id_idx" ON "public"."sessions" USING "btree" ("user_id");


--
-- Name: site_content_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "site_content_key_key" ON "public"."site_content" USING "btree" ("key");


--
-- Name: staff_permissions_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "staff_permissions_user_id_idx" ON "public"."staff_permissions" USING "btree" ("user_id");


--
-- Name: staff_permissions_user_id_permission_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "staff_permissions_user_id_permission_key" ON "public"."staff_permissions" USING "btree" ("user_id", "permission");


--
-- Name: testimonials_course_id_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "testimonials_course_id_is_active_idx" ON "public"."testimonials" USING "btree" ("course_id", "is_active");


--
-- Name: testimonials_service_id_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "testimonials_service_id_is_active_idx" ON "public"."testimonials" USING "btree" ("service_id", "is_active");


--
-- Name: testimonials_type_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "testimonials_type_is_active_display_order_idx" ON "public"."testimonials" USING "btree" ("type", "is_active", "display_order");


--
-- Name: ticker_notifications_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ticker_notifications_is_active_display_order_idx" ON "public"."ticker_notifications" USING "btree" ("is_active", "display_order");


--
-- Name: ticker_texts_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ticker_texts_is_active_display_order_idx" ON "public"."ticker_texts" USING "btree" ("is_active", "display_order");


--
-- Name: transactions_reference_code_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "transactions_reference_code_idx" ON "public"."transactions" USING "btree" ("reference_code");


--
-- Name: transactions_reference_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "transactions_reference_code_key" ON "public"."transactions" USING "btree" ("reference_code");


--
-- Name: transactions_type_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "transactions_type_idx" ON "public"."transactions" USING "btree" ("type");


--
-- Name: transactions_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "transactions_user_id_created_at_idx" ON "public"."transactions" USING "btree" ("user_id", "created_at");


--
-- Name: tut_trick_categories_name_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_trick_categories_name_idx" ON "public"."tut_trick_categories" USING "btree" ("name");


--
-- Name: tut_trick_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "tut_trick_categories_name_key" ON "public"."tut_trick_categories" USING "btree" ("name");


--
-- Name: tut_tricks_is_active_is_featured_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_tricks_is_active_is_featured_idx" ON "public"."tut_tricks" USING "btree" ("is_active", "is_featured");


--
-- Name: tut_tricks_platform_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_tricks_platform_idx" ON "public"."tut_tricks" USING "btree" ("platform");


--
-- Name: tut_tricks_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_tricks_slug_idx" ON "public"."tut_tricks" USING "btree" ("slug");


--
-- Name: tut_tricks_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "tut_tricks_slug_key" ON "public"."tut_tricks" USING "btree" ("slug");


--
-- Name: unmatched_transfers_reference_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "unmatched_transfers_reference_code_key" ON "public"."unmatched_transfers" USING "btree" ("reference_code");


--
-- Name: unmatched_transfers_status_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "unmatched_transfers_status_created_at_idx" ON "public"."unmatched_transfers" USING "btree" ("status", "created_at");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_email_idx" ON "public"."users" USING "btree" ("email");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "users_email_key" ON "public"."users" USING "btree" ("email");


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_role_idx" ON "public"."users" USING "btree" ("role");


--
-- Name: users_seller_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_seller_status_idx" ON "public"."users" USING "btree" ("seller_status");


--
-- Name: users_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_status_idx" ON "public"."users" USING "btree" ("status");


--
-- Name: users_uid_prefix_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_uid_prefix_idx" ON "public"."users" USING "btree" ("uid_prefix");


--
-- Name: audit_logs audit_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."audit_logs"
    ADD CONSTRAINT "audit_logs_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bank_change_requests bank_change_requests_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."bank_change_requests"
    ADD CONSTRAINT "bank_change_requests_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_messages chat_messages_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "public"."chat_rooms"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_participants chat_participants_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_participants"
    ADD CONSTRAINT "chat_participants_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "public"."chat_rooms"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_participants chat_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_participants"
    ADD CONSTRAINT "chat_participants_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_rooms chat_rooms_complaint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_rooms"
    ADD CONSTRAINT "chat_rooms_complaint_id_fkey" FOREIGN KEY ("complaint_id") REFERENCES "public"."complaints"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: complaints complaints_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."complaints"
    ADD CONSTRAINT "complaints_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: course_faq_categories course_faq_categories_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faq_categories"
    ADD CONSTRAINT "course_faq_categories_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: course_faqs course_faqs_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faqs"
    ADD CONSTRAINT "course_faqs_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."course_faq_categories"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: course_faqs course_faqs_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faqs"
    ADD CONSTRAINT "course_faqs_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: course_support_items course_support_items_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_support_items"
    ADD CONSTRAINT "course_support_items_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: login_attempts login_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."login_attempts"
    ADD CONSTRAINT "login_attempts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: mmo_product_items mmo_product_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."mmo_product_items"
    ADD CONSTRAINT "mmo_product_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."mmo_products"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_mmo_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_mmo_product_id_fkey" FOREIGN KEY ("mmo_product_id") REFERENCES "public"."mmo_products"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_seller_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_seller_product_id_fkey" FOREIGN KEY ("seller_product_id") REFERENCES "public"."seller_products"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_service_id_fkey" FOREIGN KEY ("service_id") REFERENCES "public"."services"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tut_trick_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_tut_trick_id_fkey" FOREIGN KEY ("tut_trick_id") REFERENCES "public"."tut_tricks"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reviews reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: seller_product_stock seller_product_stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_product_stock"
    ADD CONSTRAINT "seller_product_stock_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."seller_products"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_products seller_products_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_products"
    ADD CONSTRAINT "seller_products_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_products seller_products_sub_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_products"
    ADD CONSTRAINT "seller_products_sub_category_id_fkey" FOREIGN KEY ("sub_category_id") REFERENCES "public"."seller_sub_categories"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: seller_requests seller_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_requests"
    ADD CONSTRAINT "seller_requests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_sub_categories seller_sub_categories_category_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_sub_categories"
    ADD CONSTRAINT "seller_sub_categories_category_name_fkey" FOREIGN KEY ("category_name") REFERENCES "public"."resource_categories"("name") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_withdrawals seller_withdrawals_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_withdrawals"
    ADD CONSTRAINT "seller_withdrawals_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: site_content site_content_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."site_content"
    ADD CONSTRAINT "site_content_updated_by_id_fkey" FOREIGN KEY ("updated_by_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: staff_permissions staff_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."staff_permissions"
    ADD CONSTRAINT "staff_permissions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: testimonials testimonials_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."testimonials"
    ADD CONSTRAINT "testimonials_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: testimonials testimonials_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."testimonials"
    ADD CONSTRAINT "testimonials_service_id_fkey" FOREIGN KEY ("service_id") REFERENCES "public"."services"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_sub_categories user_sub_categories_sub_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."user_sub_categories"
    ADD CONSTRAINT "user_sub_categories_sub_category_id_fkey" FOREIGN KEY ("sub_category_id") REFERENCES "public"."seller_sub_categories"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_sub_categories user_sub_categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."user_sub_categories"
    ADD CONSTRAINT "user_sub_categories_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: app_user
--

REVOKE USAGE ON SCHEMA "public" FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict mViOf6PhMW6hzkIt6GdG01fvt483JKgvprsXsTkBxmj3qc7PyNf8uf6ypsC0yz8

