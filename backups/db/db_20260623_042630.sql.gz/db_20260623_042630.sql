--
-- PostgreSQL database dump
--

\restrict wZWledRND31AmLVKCHgEmSt3lx2cXJECEf75gm9I7LkEaRANxjpIcoU60tiBWgw

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY "public"."user_sub_categories" DROP CONSTRAINT IF EXISTS "user_sub_categories_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."user_sub_categories" DROP CONSTRAINT IF EXISTS "user_sub_categories_sub_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."transactions" DROP CONSTRAINT IF EXISTS "transactions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."transactions" DROP CONSTRAINT IF EXISTS "transactions_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."testimonials" DROP CONSTRAINT IF EXISTS "testimonials_service_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."testimonials" DROP CONSTRAINT IF EXISTS "testimonials_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."staff_permissions" DROP CONSTRAINT IF EXISTS "staff_permissions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."staff_permissions" DROP CONSTRAINT IF EXISTS "staff_permissions_permission_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."site_content" DROP CONSTRAINT IF EXISTS "site_content_updated_by_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_withdrawals" DROP CONSTRAINT IF EXISTS "seller_withdrawals_seller_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_sub_categories" DROP CONSTRAINT IF EXISTS "seller_sub_categories_category_name_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_requests" DROP CONSTRAINT IF EXISTS "seller_requests_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_products" DROP CONSTRAINT IF EXISTS "seller_products_sub_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_products" DROP CONSTRAINT IF EXISTS "seller_products_seller_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_product_stock" DROP CONSTRAINT IF EXISTS "seller_product_stock_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."permissions" DROP CONSTRAINT IF EXISTS "permissions_module_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_tut_trick_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_service_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_seller_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_mmo_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."notifications" DROP CONSTRAINT IF EXISTS "notifications_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."mmo_product_items" DROP CONSTRAINT IF EXISTS "mmo_product_items_product_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."login_attempts" DROP CONSTRAINT IF EXISTS "login_attempts_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_support_items" DROP CONSTRAINT IF EXISTS "course_support_items_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faqs" DROP CONSTRAINT IF EXISTS "course_faqs_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faqs" DROP CONSTRAINT IF EXISTS "course_faqs_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faq_categories" DROP CONSTRAINT IF EXISTS "course_faq_categories_course_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."complaints" DROP CONSTRAINT IF EXISTS "complaints_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_rooms" DROP CONSTRAINT IF EXISTS "chat_rooms_complaint_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_participants" DROP CONSTRAINT IF EXISTS "chat_participants_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_participants" DROP CONSTRAINT IF EXISTS "chat_participants_room_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_messages" DROP CONSTRAINT IF EXISTS "chat_messages_sender_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_messages" DROP CONSTRAINT IF EXISTS "chat_messages_room_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."bank_change_requests" DROP CONSTRAINT IF EXISTS "bank_change_requests_seller_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."audit_logs" DROP CONSTRAINT IF EXISTS "audit_logs_actor_id_fkey";
DROP INDEX IF EXISTS "public"."users_uid_prefix_idx";
DROP INDEX IF EXISTS "public"."users_status_idx";
DROP INDEX IF EXISTS "public"."users_seller_status_idx";
DROP INDEX IF EXISTS "public"."users_role_idx";
DROP INDEX IF EXISTS "public"."users_email_key";
DROP INDEX IF EXISTS "public"."users_email_idx";
DROP INDEX IF EXISTS "public"."unmatched_transfers_status_created_at_idx";
DROP INDEX IF EXISTS "public"."unmatched_transfers_reference_code_key";
DROP INDEX IF EXISTS "public"."tut_tricks_slug_key";
DROP INDEX IF EXISTS "public"."tut_tricks_slug_idx";
DROP INDEX IF EXISTS "public"."tut_tricks_platform_idx";
DROP INDEX IF EXISTS "public"."tut_tricks_is_active_is_featured_idx";
DROP INDEX IF EXISTS "public"."tut_trick_categories_name_key";
DROP INDEX IF EXISTS "public"."tut_trick_categories_name_idx";
DROP INDEX IF EXISTS "public"."transactions_user_id_created_at_idx";
DROP INDEX IF EXISTS "public"."transactions_type_idx";
DROP INDEX IF EXISTS "public"."transactions_reference_code_key";
DROP INDEX IF EXISTS "public"."transactions_reference_code_idx";
DROP INDEX IF EXISTS "public"."ticker_texts_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."ticker_notifications_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."testimonials_type_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."testimonials_service_id_is_active_idx";
DROP INDEX IF EXISTS "public"."testimonials_course_id_is_active_idx";
DROP INDEX IF EXISTS "public"."staff_permissions_user_id_idx";
DROP INDEX IF EXISTS "public"."staff_permissions_permission_id_idx";
DROP INDEX IF EXISTS "public"."site_content_key_key";
DROP INDEX IF EXISTS "public"."sessions_user_id_idx";
DROP INDEX IF EXISTS "public"."sessions_session_token_key";
DROP INDEX IF EXISTS "public"."sessions_session_token_idx";
DROP INDEX IF EXISTS "public"."sessions_expires_at_idx";
DROP INDEX IF EXISTS "public"."services_slug_key";
DROP INDEX IF EXISTS "public"."services_slug_idx";
DROP INDEX IF EXISTS "public"."services_platform_idx";
DROP INDEX IF EXISTS "public"."services_is_active_is_featured_idx";
DROP INDEX IF EXISTS "public"."services_category_idx";
DROP INDEX IF EXISTS "public"."service_categories_name_key";
DROP INDEX IF EXISTS "public"."service_categories_name_idx";
DROP INDEX IF EXISTS "public"."seller_withdrawals_status_created_at_idx";
DROP INDEX IF EXISTS "public"."seller_withdrawals_seller_id_status_idx";
DROP INDEX IF EXISTS "public"."seller_tier_definitions_key_key";
DROP INDEX IF EXISTS "public"."seller_tier_definitions_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."seller_sub_categories_category_name_name_key";
DROP INDEX IF EXISTS "public"."seller_sub_categories_category_name_is_active_idx";
DROP INDEX IF EXISTS "public"."seller_requests_user_id_key";
DROP INDEX IF EXISTS "public"."seller_requests_status_idx";
DROP INDEX IF EXISTS "public"."seller_products_sub_category_id_idx";
DROP INDEX IF EXISTS "public"."seller_products_seller_id_idx";
DROP INDEX IF EXISTS "public"."seller_products_is_active_is_hidden_is_restricted_idx";
DROP INDEX IF EXISTS "public"."seller_product_stock_product_id_status_idx";
DROP INDEX IF EXISTS "public"."reviews_user_id_idx";
DROP INDEX IF EXISTS "public"."reviews_product_type_product_id_idx";
DROP INDEX IF EXISTS "public"."resource_categories_name_key";
DROP INDEX IF EXISTS "public"."resource_categories_name_idx";
DROP INDEX IF EXISTS "public"."refresh_tokens_user_id_idx";
DROP INDEX IF EXISTS "public"."refresh_tokens_token_hash_key";
DROP INDEX IF EXISTS "public"."refresh_tokens_family_idx";
DROP INDEX IF EXISTS "public"."public_page_configs_page_key_key";
DROP INDEX IF EXISTS "public"."permissions_module_id_idx";
DROP INDEX IF EXISTS "public"."permissions_is_active_idx";
DROP INDEX IF EXISTS "public"."permissions_code_key";
DROP INDEX IF EXISTS "public"."permissions_code_idx";
DROP INDEX IF EXISTS "public"."pending_registrations_email_key";
DROP INDEX IF EXISTS "public"."page_permissions_role_page_key_key";
DROP INDEX IF EXISTS "public"."page_permissions_role_idx";
DROP INDEX IF EXISTS "public"."otp_codes_expires_at_idx";
DROP INDEX IF EXISTS "public"."otp_codes_email_purpose_idx";
DROP INDEX IF EXISTS "public"."orders_user_id_created_at_idx";
DROP INDEX IF EXISTS "public"."orders_status_idx";
DROP INDEX IF EXISTS "public"."orders_seller_id_idx";
DROP INDEX IF EXISTS "public"."orders_order_type_idx";
DROP INDEX IF EXISTS "public"."orders_order_code_key";
DROP INDEX IF EXISTS "public"."orders_order_code_idx";
DROP INDEX IF EXISTS "public"."orders_idempotency_key_key";
DROP INDEX IF EXISTS "public"."notifications_user_id_is_read_created_at_idx";
DROP INDEX IF EXISTS "public"."modules_sort_order_idx";
DROP INDEX IF EXISTS "public"."modules_code_key";
DROP INDEX IF EXISTS "public"."modules_code_idx";
DROP INDEX IF EXISTS "public"."mmo_products_slug_key";
DROP INDEX IF EXISTS "public"."mmo_products_slug_idx";
DROP INDEX IF EXISTS "public"."mmo_products_section_idx";
DROP INDEX IF EXISTS "public"."mmo_products_is_active_idx";
DROP INDEX IF EXISTS "public"."mmo_products_category_idx";
DROP INDEX IF EXISTS "public"."mmo_product_items_product_id_value_hash_key";
DROP INDEX IF EXISTS "public"."mmo_product_items_product_id_status_idx";
DROP INDEX IF EXISTS "public"."mmo_product_items_order_id_idx";
DROP INDEX IF EXISTS "public"."login_attempts_ip_address_created_at_idx";
DROP INDEX IF EXISTS "public"."login_attempts_email_created_at_idx";
DROP INDEX IF EXISTS "public"."fanpage_registrations_status_idx";
DROP INDEX IF EXISTS "public"."fanpage_registrations_created_at_idx";
DROP INDEX IF EXISTS "public"."courses_slug_key";
DROP INDEX IF EXISTS "public"."courses_slug_idx";
DROP INDEX IF EXISTS "public"."courses_is_active_display_order_idx";
DROP INDEX IF EXISTS "public"."courses_category_idx";
DROP INDEX IF EXISTS "public"."course_support_items_course_id_display_order_idx";
DROP INDEX IF EXISTS "public"."course_faqs_course_id_display_order_idx";
DROP INDEX IF EXISTS "public"."course_faq_categories_course_id_display_order_idx";
DROP INDEX IF EXISTS "public"."course_categories_name_key";
DROP INDEX IF EXISTS "public"."course_categories_display_order_idx";
DROP INDEX IF EXISTS "public"."complaints_user_id_idx";
DROP INDEX IF EXISTS "public"."complaints_status_idx";
DROP INDEX IF EXISTS "public"."chat_rooms_complaint_id_key";
DROP INDEX IF EXISTS "public"."chat_participants_user_id_idx";
DROP INDEX IF EXISTS "public"."chat_participants_room_id_user_id_key";
DROP INDEX IF EXISTS "public"."chat_messages_room_id_created_at_idx";
DROP INDEX IF EXISTS "public"."bank_change_requests_status_created_at_idx";
DROP INDEX IF EXISTS "public"."bank_change_requests_seller_id_status_idx";
DROP INDEX IF EXISTS "public"."audit_logs_target_type_target_id_idx";
DROP INDEX IF EXISTS "public"."audit_logs_actor_id_created_at_idx";
DROP INDEX IF EXISTS "public"."audit_logs_action_idx";
DROP INDEX IF EXISTS "public"."ads_registrations_status_idx";
DROP INDEX IF EXISTS "public"."ads_registrations_created_at_idx";
ALTER TABLE IF EXISTS ONLY "public"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "public"."user_sub_categories" DROP CONSTRAINT IF EXISTS "user_sub_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."unmatched_transfers" DROP CONSTRAINT IF EXISTS "unmatched_transfers_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tut_tricks" DROP CONSTRAINT IF EXISTS "tut_tricks_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tut_trick_categories" DROP CONSTRAINT IF EXISTS "tut_trick_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."transactions" DROP CONSTRAINT IF EXISTS "transactions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ticker_texts" DROP CONSTRAINT IF EXISTS "ticker_texts_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ticker_notifications" DROP CONSTRAINT IF EXISTS "ticker_notifications_pkey";
ALTER TABLE IF EXISTS ONLY "public"."testimonials" DROP CONSTRAINT IF EXISTS "testimonials_pkey";
ALTER TABLE IF EXISTS ONLY "public"."system_config" DROP CONSTRAINT IF EXISTS "system_config_pkey";
ALTER TABLE IF EXISTS ONLY "public"."staff_permissions" DROP CONSTRAINT IF EXISTS "staff_permissions_user_id_permission_id_key";
ALTER TABLE IF EXISTS ONLY "public"."staff_permissions" DROP CONSTRAINT IF EXISTS "staff_permissions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."site_content" DROP CONSTRAINT IF EXISTS "site_content_pkey";
ALTER TABLE IF EXISTS ONLY "public"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."services" DROP CONSTRAINT IF EXISTS "services_pkey";
ALTER TABLE IF EXISTS ONLY "public"."service_categories" DROP CONSTRAINT IF EXISTS "service_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_withdrawals" DROP CONSTRAINT IF EXISTS "seller_withdrawals_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_tier_definitions" DROP CONSTRAINT IF EXISTS "seller_tier_definitions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_sub_categories" DROP CONSTRAINT IF EXISTS "seller_sub_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_requests" DROP CONSTRAINT IF EXISTS "seller_requests_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_products" DROP CONSTRAINT IF EXISTS "seller_products_pkey";
ALTER TABLE IF EXISTS ONLY "public"."seller_product_stock" DROP CONSTRAINT IF EXISTS "seller_product_stock_pkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_pkey";
ALTER TABLE IF EXISTS ONLY "public"."reviews" DROP CONSTRAINT IF EXISTS "reviews_order_id_key";
ALTER TABLE IF EXISTS ONLY "public"."resource_categories" DROP CONSTRAINT IF EXISTS "resource_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "public"."public_page_configs" DROP CONSTRAINT IF EXISTS "public_page_configs_pkey";
ALTER TABLE IF EXISTS ONLY "public"."permissions" DROP CONSTRAINT IF EXISTS "permissions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."pending_registrations" DROP CONSTRAINT IF EXISTS "pending_registrations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."page_permissions" DROP CONSTRAINT IF EXISTS "page_permissions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."otp_codes" DROP CONSTRAINT IF EXISTS "otp_codes_pkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_pkey";
ALTER TABLE IF EXISTS ONLY "public"."notifications" DROP CONSTRAINT IF EXISTS "notifications_pkey";
ALTER TABLE IF EXISTS ONLY "public"."modules" DROP CONSTRAINT IF EXISTS "modules_pkey";
ALTER TABLE IF EXISTS ONLY "public"."mmo_products" DROP CONSTRAINT IF EXISTS "mmo_products_pkey";
ALTER TABLE IF EXISTS ONLY "public"."mmo_product_items" DROP CONSTRAINT IF EXISTS "mmo_product_items_pkey";
ALTER TABLE IF EXISTS ONLY "public"."login_attempts" DROP CONSTRAINT IF EXISTS "login_attempts_pkey";
ALTER TABLE IF EXISTS ONLY "public"."fanpage_registrations" DROP CONSTRAINT IF EXISTS "fanpage_registrations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."courses" DROP CONSTRAINT IF EXISTS "courses_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_support_items" DROP CONSTRAINT IF EXISTS "course_support_items_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faqs" DROP CONSTRAINT IF EXISTS "course_faqs_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_faq_categories" DROP CONSTRAINT IF EXISTS "course_faq_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."course_categories" DROP CONSTRAINT IF EXISTS "course_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."complaints" DROP CONSTRAINT IF EXISTS "complaints_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_rooms" DROP CONSTRAINT IF EXISTS "chat_rooms_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_participants" DROP CONSTRAINT IF EXISTS "chat_participants_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chat_messages" DROP CONSTRAINT IF EXISTS "chat_messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."bank_change_requests" DROP CONSTRAINT IF EXISTS "bank_change_requests_pkey";
ALTER TABLE IF EXISTS ONLY "public"."audit_logs" DROP CONSTRAINT IF EXISTS "audit_logs_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ads_registrations" DROP CONSTRAINT IF EXISTS "ads_registrations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."_prisma_migrations" DROP CONSTRAINT IF EXISTS "_prisma_migrations_pkey";
DROP TABLE IF EXISTS "public"."users";
DROP TABLE IF EXISTS "public"."user_sub_categories";
DROP TABLE IF EXISTS "public"."unmatched_transfers";
DROP TABLE IF EXISTS "public"."tut_tricks";
DROP TABLE IF EXISTS "public"."tut_trick_categories";
DROP TABLE IF EXISTS "public"."transactions";
DROP TABLE IF EXISTS "public"."ticker_texts";
DROP TABLE IF EXISTS "public"."ticker_notifications";
DROP TABLE IF EXISTS "public"."testimonials";
DROP TABLE IF EXISTS "public"."system_config";
DROP TABLE IF EXISTS "public"."staff_permissions";
DROP TABLE IF EXISTS "public"."site_content";
DROP TABLE IF EXISTS "public"."sessions";
DROP TABLE IF EXISTS "public"."services";
DROP TABLE IF EXISTS "public"."service_categories";
DROP TABLE IF EXISTS "public"."seller_withdrawals";
DROP TABLE IF EXISTS "public"."seller_tier_definitions";
DROP TABLE IF EXISTS "public"."seller_sub_categories";
DROP TABLE IF EXISTS "public"."seller_requests";
DROP TABLE IF EXISTS "public"."seller_products";
DROP TABLE IF EXISTS "public"."seller_product_stock";
DROP TABLE IF EXISTS "public"."reviews";
DROP TABLE IF EXISTS "public"."resource_categories";
DROP TABLE IF EXISTS "public"."refresh_tokens";
DROP TABLE IF EXISTS "public"."public_page_configs";
DROP TABLE IF EXISTS "public"."permissions";
DROP TABLE IF EXISTS "public"."pending_registrations";
DROP TABLE IF EXISTS "public"."page_permissions";
DROP TABLE IF EXISTS "public"."otp_codes";
DROP TABLE IF EXISTS "public"."orders";
DROP TABLE IF EXISTS "public"."notifications";
DROP TABLE IF EXISTS "public"."modules";
DROP TABLE IF EXISTS "public"."mmo_products";
DROP TABLE IF EXISTS "public"."mmo_product_items";
DROP TABLE IF EXISTS "public"."login_attempts";
DROP TABLE IF EXISTS "public"."fanpage_registrations";
DROP TABLE IF EXISTS "public"."courses";
DROP TABLE IF EXISTS "public"."course_support_items";
DROP TABLE IF EXISTS "public"."course_faqs";
DROP TABLE IF EXISTS "public"."course_faq_categories";
DROP TABLE IF EXISTS "public"."course_categories";
DROP TABLE IF EXISTS "public"."complaints";
DROP TABLE IF EXISTS "public"."chat_rooms";
DROP TABLE IF EXISTS "public"."chat_participants";
DROP TABLE IF EXISTS "public"."chat_messages";
DROP TABLE IF EXISTS "public"."bank_change_requests";
DROP TABLE IF EXISTS "public"."audit_logs";
DROP TABLE IF EXISTS "public"."ads_registrations";
DROP TABLE IF EXISTS "public"."_prisma_migrations";
DROP TYPE IF EXISTS "public"."WithdrawalStatus";
DROP TYPE IF EXISTS "public"."TxType";
DROP TYPE IF EXISTS "public"."TestimonialType";
DROP TYPE IF EXISTS "public"."StoreType";
DROP TYPE IF EXISTS "public"."StockItemStatus";
DROP TYPE IF EXISTS "public"."SellerStatus";
DROP TYPE IF EXISTS "public"."Role";
DROP TYPE IF EXISTS "public"."Platform";
DROP TYPE IF EXISTS "public"."OtpPurpose";
DROP TYPE IF EXISTS "public"."OrderType";
DROP TYPE IF EXISTS "public"."OrderStatus";
DROP TYPE IF EXISTS "public"."NotificationType";
DROP TYPE IF EXISTS "public"."LearningFormat";
DROP TYPE IF EXISTS "public"."CourseBadge";
DROP TYPE IF EXISTS "public"."ComplaintStatus";
DROP TYPE IF EXISTS "public"."BankChangeStatus";
DROP TYPE IF EXISTS "public"."AccountStatus";
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: app_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA "public" OWNER TO "app_user";

--
-- Name: AccountStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."AccountStatus" AS ENUM (
    'ACTIVE',
    'PENDING_VERIFICATION',
    'BANNED',
    'DELETED'
);


ALTER TYPE "public"."AccountStatus" OWNER TO "app_user";

--
-- Name: BankChangeStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."BankChangeStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE "public"."BankChangeStatus" OWNER TO "app_user";

--
-- Name: ComplaintStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."ComplaintStatus" AS ENUM (
    'IN_REVIEW',
    'PENDING_ADMIN',
    'RESOLVED',
    'REJECTED'
);


ALTER TYPE "public"."ComplaintStatus" OWNER TO "app_user";

--
-- Name: CourseBadge; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."CourseBadge" AS ENUM (
    'NONE',
    'HOT',
    'POPULAR',
    'TREND',
    'NEW',
    'VIP'
);


ALTER TYPE "public"."CourseBadge" OWNER TO "app_user";

--
-- Name: LearningFormat; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."LearningFormat" AS ENUM (
    'ONLINE',
    'OFFLINE',
    'HYBRID'
);


ALTER TYPE "public"."LearningFormat" OWNER TO "app_user";

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."NotificationType" AS ENUM (
    'DEPOSIT',
    'PURCHASE',
    'ORDER_STATUS',
    'SELLER_APPROVED',
    'WITHDRAWAL_STATUS',
    'SYSTEM',
    'PROMOTION'
);


ALTER TYPE "public"."NotificationType" OWNER TO "app_user";

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."OrderStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'DONE',
    'CANCELLED',
    'REFUNDED',
    'DISPUTED',
    'FROZEN'
);


ALTER TYPE "public"."OrderStatus" OWNER TO "app_user";

--
-- Name: OrderType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."OrderType" AS ENUM (
    'SERVICE',
    'COURSE',
    'TUTTRICK',
    'MMO_PRODUCT',
    'SELLER_PRODUCT'
);


ALTER TYPE "public"."OrderType" OWNER TO "app_user";

--
-- Name: OtpPurpose; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."OtpPurpose" AS ENUM (
    'REGISTER',
    'LOGIN_2FA',
    'RESET_PASSWORD',
    'EMAIL_VERIFY',
    'WITHDRAWAL_CONFIRM',
    'SENSITIVE_ACTION'
);


ALTER TYPE "public"."OtpPurpose" OWNER TO "app_user";

--
-- Name: Platform; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."Platform" AS ENUM (
    'FACEBOOK',
    'TIKTOK',
    'GOOGLE',
    'INSTAGRAM',
    'YOUTUBE',
    'ICLOUD',
    'ZALO',
    'TELEGRAM',
    'TWITTER',
    'OTHER'
);


ALTER TYPE "public"."Platform" OWNER TO "app_user";

--
-- Name: Role; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."Role" AS ENUM (
    'USER',
    'SELLER',
    'STAFF',
    'ADMIN'
);


ALTER TYPE "public"."Role" OWNER TO "app_user";

--
-- Name: SellerStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."SellerStatus" AS ENUM (
    'NONE',
    'PENDING',
    'APPROVED',
    'REJECTED',
    'REVOKED'
);


ALTER TYPE "public"."SellerStatus" OWNER TO "app_user";

--
-- Name: StockItemStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."StockItemStatus" AS ENUM (
    'AVAILABLE',
    'RESERVED',
    'SOLD'
);


ALTER TYPE "public"."StockItemStatus" OWNER TO "app_user";

--
-- Name: StoreType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."StoreType" AS ENUM (
    'TAI_NGUYEN_MMO',
    'KHO_TAI_NGUYEN'
);


ALTER TYPE "public"."StoreType" OWNER TO "app_user";

--
-- Name: TestimonialType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."TestimonialType" AS ENUM (
    'COURSE',
    'SERVICE'
);


ALTER TYPE "public"."TestimonialType" OWNER TO "app_user";

--
-- Name: TxType; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."TxType" AS ENUM (
    'DEPOSIT_AUTO',
    'DEPOSIT_MANUAL',
    'BUY_SERVICE',
    'BUY_COURSE',
    'BUY_TUTTRICK',
    'BUY_MMO_PRODUCT',
    'BUY_SELLER_PRODUCT',
    'REFUND',
    'SELLER_REGISTRATION',
    'SELLER_PAYOUT',
    'WITHDRAWAL_FEE',
    'ADMIN_ADJUSTMENT',
    'COMPLAINT_DEDUCTION',
    'SELLER_SLOT_PURCHASE'
);


ALTER TYPE "public"."TxType" OWNER TO "app_user";

--
-- Name: WithdrawalStatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE "public"."WithdrawalStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'PROCESSING',
    'COMPLETED'
);


ALTER TYPE "public"."WithdrawalStatus" OWNER TO "app_user";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."_prisma_migrations" (
    "id" character varying(36) NOT NULL,
    "checksum" character varying(64) NOT NULL,
    "finished_at" timestamp with time zone,
    "migration_name" character varying(255) NOT NULL,
    "logs" "text",
    "rolled_back_at" timestamp with time zone,
    "started_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "applied_steps_count" integer DEFAULT 0 NOT NULL
);


ALTER TABLE "public"."_prisma_migrations" OWNER TO "app_user";

--
-- Name: ads_registrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."ads_registrations" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "service_name" "text" NOT NULL,
    "service_tab" "text" NOT NULL,
    "fanpage_status" "text" NOT NULL,
    "has_content" "text" NOT NULL,
    "ads_experience" "text" NOT NULL,
    "product_category" "text" NOT NULL,
    "budget" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "status" "text" DEFAULT 'PENDING'::"text" NOT NULL,
    "note" "text"
);


ALTER TABLE "public"."ads_registrations" OWNER TO "app_user";

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."audit_logs" (
    "id" "uuid" NOT NULL,
    "actor_id" "uuid",
    "action" "text" NOT NULL,
    "target_type" "text",
    "target_id" "text",
    "before" "jsonb",
    "after" "jsonb",
    "metadata" "jsonb",
    "ip_address" "text",
    "user_agent" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."audit_logs" OWNER TO "app_user";

--
-- Name: bank_change_requests; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."bank_change_requests" (
    "id" "uuid" NOT NULL,
    "seller_id" "uuid" NOT NULL,
    "bank_name_enc" "bytea" NOT NULL,
    "bank_account_number_enc" "bytea" NOT NULL,
    "bank_account_holder_enc" "bytea" NOT NULL,
    "status" "public"."BankChangeStatus" DEFAULT 'PENDING'::"public"."BankChangeStatus" NOT NULL,
    "reject_reason" "text",
    "reviewed_by_user_id" "uuid",
    "reviewed_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."bank_change_requests" OWNER TO "app_user";

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."chat_messages" (
    "id" "uuid" NOT NULL,
    "room_id" "uuid" NOT NULL,
    "sender_id" "uuid" NOT NULL,
    "sender_name" "text" NOT NULL,
    "sender_label" "text" NOT NULL,
    "content" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."chat_messages" OWNER TO "app_user";

--
-- Name: chat_participants; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."chat_participants" (
    "id" "uuid" NOT NULL,
    "room_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "label" "text" NOT NULL,
    "joined_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."chat_participants" OWNER TO "app_user";

--
-- Name: chat_rooms; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."chat_rooms" (
    "id" "uuid" NOT NULL,
    "complaint_id" "uuid" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "total_messages" integer DEFAULT 0 NOT NULL,
    "user_turn_count" integer DEFAULT 0 NOT NULL,
    "first_seller_msg_at" timestamp(3) without time zone,
    "seller_confirmed" boolean DEFAULT false NOT NULL,
    "seller_confirmed_at" timestamp(3) without time zone,
    "user_done" boolean,
    "round_two_opened" boolean DEFAULT false NOT NULL
);


ALTER TABLE "public"."chat_rooms" OWNER TO "app_user";

--
-- Name: complaints; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."complaints" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_id" "uuid",
    "subject" "text" NOT NULL,
    "content" "text" NOT NULL,
    "status" "public"."ComplaintStatus" DEFAULT 'IN_REVIEW'::"public"."ComplaintStatus" NOT NULL,
    "resolution" "text",
    "resolved_by_user_id" "uuid",
    "resolved_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."complaints" OWNER TO "app_user";

--
-- Name: course_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "icon" "text" DEFAULT ''::"text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_categories" OWNER TO "app_user";

--
-- Name: course_faq_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_faq_categories" (
    "id" "uuid" NOT NULL,
    "course_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_faq_categories" OWNER TO "app_user";

--
-- Name: course_faqs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_faqs" (
    "id" "uuid" NOT NULL,
    "course_id" "uuid" NOT NULL,
    "category_id" "uuid",
    "question" "text" NOT NULL,
    "answer" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_faqs" OWNER TO "app_user";

--
-- Name: course_support_items; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."course_support_items" (
    "id" "uuid" NOT NULL,
    "course_id" "uuid" NOT NULL,
    "icon" "text" DEFAULT '✅'::"text" NOT NULL,
    "title" "text" NOT NULL,
    "description" "text",
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."course_support_items" OWNER TO "app_user";

--
-- Name: courses; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."courses" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "description" "text",
    "category" "text" NOT NULL,
    "learning_format" "public"."LearningFormat" NOT NULL,
    "original_price" numeric(18,2) NOT NULL,
    "sale_price" numeric(18,2) NOT NULL,
    "duration" "text",
    "student_count" integer DEFAULT 0 NOT NULL,
    "instructor_name" "text",
    "rating" double precision DEFAULT 0 NOT NULL,
    "content_list" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "platform_variants" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "badge" "public"."CourseBadge" DEFAULT 'NONE'::"public"."CourseBadge" NOT NULL,
    "sale_deadline" "date",
    "youtube_url" "text",
    "seo_title" "text",
    "seo_description" "text",
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL,
    "commitments" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "registration_procedure" "text"
);


ALTER TABLE "public"."courses" OWNER TO "app_user";

--
-- Name: fanpage_registrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."fanpage_registrations" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "service_type" "text" NOT NULL,
    "service_name" "text" NOT NULL,
    "description" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "status" "text" DEFAULT 'PENDING'::"text" NOT NULL,
    "note" "text"
);


ALTER TABLE "public"."fanpage_registrations" OWNER TO "app_user";

--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."login_attempts" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "email" "text" NOT NULL,
    "ip_address" "text" NOT NULL,
    "user_agent" "text",
    "success" boolean NOT NULL,
    "fail_reason" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."login_attempts" OWNER TO "app_user";

--
-- Name: mmo_product_items; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."mmo_product_items" (
    "id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "value_enc" "bytea" NOT NULL,
    "status" "public"."StockItemStatus" DEFAULT 'AVAILABLE'::"public"."StockItemStatus" NOT NULL,
    "sold_to_user_id" "uuid",
    "order_id" "uuid",
    "sold_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "value_hash" "text"
);


ALTER TABLE "public"."mmo_product_items" OWNER TO "app_user";

--
-- Name: mmo_products; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."mmo_products" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "category" "text" NOT NULL,
    "category_group" "text" NOT NULL,
    "price" numeric(18,2) NOT NULL,
    "description" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "rating" double precision DEFAULT 0 NOT NULL,
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL,
    "section" "public"."StoreType" DEFAULT 'TAI_NGUYEN_MMO'::"public"."StoreType" NOT NULL
);


ALTER TABLE "public"."mmo_products" OWNER TO "app_user";

--
-- Name: modules; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."modules" (
    "id" "uuid" NOT NULL,
    "code" character varying(64) NOT NULL,
    "label" character varying(255) NOT NULL,
    "icon" character varying(255),
    "description" "text",
    "sort_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."modules" OWNER TO "app_user";

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."notifications" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "title" "text" NOT NULL,
    "body" "text" NOT NULL,
    "type" "public"."NotificationType" DEFAULT 'SYSTEM'::"public"."NotificationType" NOT NULL,
    "is_read" boolean DEFAULT false NOT NULL,
    "meta" "jsonb",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."notifications" OWNER TO "app_user";

--
-- Name: orders; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."orders" (
    "id" "uuid" NOT NULL,
    "order_code" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_type" "public"."OrderType" NOT NULL,
    "service_id" "uuid",
    "course_id" "uuid",
    "tut_trick_id" "uuid",
    "mmo_product_id" "uuid",
    "seller_product_id" "uuid",
    "seller_id" "uuid",
    "item_name" "text" NOT NULL,
    "original_price" numeric(18,2) NOT NULL,
    "final_price" numeric(18,2) NOT NULL,
    "warranty_variant" "text",
    "payment_method" "text" DEFAULT 'BALANCE'::"text" NOT NULL,
    "status" "public"."OrderStatus" DEFAULT 'PENDING'::"public"."OrderStatus" NOT NULL,
    "delivered_item_id" "uuid",
    "idempotency_key" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "completed_at" timestamp(3) without time zone,
    "customer_note" "text",
    "withdrawn" boolean DEFAULT false NOT NULL,
    "tut_trick_content_url_enc" "bytea",
    "tut_trick_docs" "text"
);


ALTER TABLE "public"."orders" OWNER TO "app_user";

--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."otp_codes" (
    "id" "uuid" NOT NULL,
    "email" "text" NOT NULL,
    "user_id" "uuid",
    "purpose" "public"."OtpPurpose" NOT NULL,
    "code_hash" "text" NOT NULL,
    "attempts" integer DEFAULT 0 NOT NULL,
    "max_attempts" integer DEFAULT 5 NOT NULL,
    "ip_address" "text",
    "expires_at" timestamp(3) without time zone NOT NULL,
    "used_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."otp_codes" OWNER TO "app_user";

--
-- Name: page_permissions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."page_permissions" (
    "id" "uuid" NOT NULL,
    "role" "public"."Role" NOT NULL,
    "page_key" character varying(100) NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    "updated_by_user_id" "uuid",
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."page_permissions" OWNER TO "app_user";

--
-- Name: pending_registrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."pending_registrations" (
    "id" "uuid" NOT NULL,
    "email" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "phone" "text",
    "otp_code_hash" "text",
    "attempts" integer DEFAULT 0 NOT NULL,
    "ip_address" "text",
    "expires_at" timestamp(3) without time zone NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."pending_registrations" OWNER TO "app_user";

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."permissions" (
    "id" "uuid" NOT NULL,
    "module_id" "uuid" NOT NULL,
    "code" character varying(64) NOT NULL,
    "action" character varying(64),
    "label" character varying(255) NOT NULL,
    "description" "text",
    "sort_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."permissions" OWNER TO "app_user";

--
-- Name: public_page_configs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."public_page_configs" (
    "id" "uuid" NOT NULL,
    "page_key" character varying(100) NOT NULL,
    "is_visible" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "custom_label" character varying(200),
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."public_page_configs" OWNER TO "app_user";

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."refresh_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_hash" character varying(128) NOT NULL,
    "family" character varying(64) NOT NULL,
    "revoked" boolean DEFAULT false NOT NULL,
    "expires_at" timestamp(3) without time zone NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."refresh_tokens" OWNER TO "app_user";

--
-- Name: resource_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."resource_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "icon_url" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "show_in_kho_tai_nguyen" boolean DEFAULT true NOT NULL,
    "show_in_tai_nguyen_mmo" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."resource_categories" OWNER TO "app_user";

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."reviews" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "product_type" "text" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "rating" integer NOT NULL,
    "comment" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "order_id" "uuid" NOT NULL
);


ALTER TABLE "public"."reviews" OWNER TO "app_user";

--
-- Name: seller_product_stock; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_product_stock" (
    "id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "content_enc" "bytea" NOT NULL,
    "status" "public"."StockItemStatus" DEFAULT 'AVAILABLE'::"public"."StockItemStatus" NOT NULL,
    "sold_to_user_id" "uuid",
    "order_id" "uuid",
    "sold_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."seller_product_stock" OWNER TO "app_user";

--
-- Name: seller_products; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_products" (
    "id" "uuid" NOT NULL,
    "seller_id" "uuid" NOT NULL,
    "seller_category" "text" NOT NULL,
    "name" "text" NOT NULL,
    "price" numeric(18,2) NOT NULL,
    "description" "text",
    "image_url" "text",
    "publish_date" timestamp(3) without time zone,
    "is_active" boolean DEFAULT true NOT NULL,
    "is_hidden" boolean DEFAULT false NOT NULL,
    "is_restricted" boolean DEFAULT false NOT NULL,
    "sales_count" integer DEFAULT 0 NOT NULL,
    "revenue" numeric(18,2) DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "sub_category_id" "uuid",
    "store_type" "public"."StoreType" DEFAULT 'TAI_NGUYEN_MMO'::"public"."StoreType" NOT NULL
);


ALTER TABLE "public"."seller_products" OWNER TO "app_user";

--
-- Name: seller_requests; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_requests" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "category" "text" NOT NULL,
    "fee" numeric(18,2) DEFAULT 50000 NOT NULL,
    "status" "public"."SellerStatus" DEFAULT 'PENDING'::"public"."SellerStatus" NOT NULL,
    "approved_category" "text",
    "reject_reason" "text",
    "reviewed_by_user_id" "uuid",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approved_at" timestamp(3) without time zone,
    "rejected_at" timestamp(3) without time zone,
    "store_type" "public"."StoreType" DEFAULT 'TAI_NGUYEN_MMO'::"public"."StoreType" NOT NULL
);


ALTER TABLE "public"."seller_requests" OWNER TO "app_user";

--
-- Name: seller_sub_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_sub_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "category_name" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "show_in_kho_tai_nguyen" boolean DEFAULT true NOT NULL,
    "show_in_tai_nguyen_mmo" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."seller_sub_categories" OWNER TO "app_user";

--
-- Name: seller_tier_definitions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_tier_definitions" (
    "id" "uuid" NOT NULL,
    "key" character varying(50) NOT NULL,
    "label" character varying(30) NOT NULL,
    "description" character varying(200),
    "badge_color" character varying(30) DEFAULT 'gray'::character varying NOT NULL,
    "fee_percent" double precision DEFAULT 5 NOT NULL,
    "min_withdrawal" integer DEFAULT 200000 NOT NULL,
    "hold_days" integer DEFAULT 3 NOT NULL,
    "benefits" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "upgrade_min_revenue" integer DEFAULT 0 NOT NULL,
    "upgrade_min_orders" integer DEFAULT 0 NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_built_in" boolean DEFAULT false NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."seller_tier_definitions" OWNER TO "app_user";

--
-- Name: seller_withdrawals; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."seller_withdrawals" (
    "id" "uuid" NOT NULL,
    "seller_id" "uuid" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "fee_percent" double precision NOT NULL,
    "fee_amount" numeric(18,2) NOT NULL,
    "net_amount" numeric(18,2) NOT NULL,
    "bank_name_enc" "bytea" NOT NULL,
    "bank_account_number_enc" "bytea" NOT NULL,
    "bank_account_holder_enc" "bytea" NOT NULL,
    "status" "public"."WithdrawalStatus" DEFAULT 'PENDING'::"public"."WithdrawalStatus" NOT NULL,
    "qualifying_order_ids" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "reject_reason" "text",
    "processed_by_user_id" "uuid",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "processed_at" timestamp(3) without time zone
);


ALTER TABLE "public"."seller_withdrawals" OWNER TO "app_user";

--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."service_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "icon_url" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE "public"."service_categories" OWNER TO "app_user";

--
-- Name: services; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."services" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "platform" "public"."Platform" NOT NULL,
    "category" "text" NOT NULL,
    "price" numeric(18,2) NOT NULL,
    "success_rate" integer DEFAULT 100 NOT NULL,
    "processing_time" "text",
    "rating" double precision DEFAULT 0 NOT NULL,
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "description" "text",
    "seo_title" "text",
    "seo_description" "text",
    "warranty_options" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "product_list" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "customer_count" integer DEFAULT 0 NOT NULL,
    "platform_variants" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "review_count" integer DEFAULT 0 NOT NULL,
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL
);


ALTER TABLE "public"."services" OWNER TO "app_user";

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "session_token" character varying(128) NOT NULL,
    "ip_address" "text",
    "user_agent" "text",
    "expires_at" timestamp(3) without time zone NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."sessions" OWNER TO "app_user";

--
-- Name: site_content; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."site_content" (
    "id" "uuid" NOT NULL,
    "key" character varying(64) NOT NULL,
    "content" "jsonb" NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "updated_by_id" "uuid"
);


ALTER TABLE "public"."site_content" OWNER TO "app_user";

--
-- Name: staff_permissions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."staff_permissions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "permission_id" "uuid" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."staff_permissions" OWNER TO "app_user";

--
-- Name: system_config; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."system_config" (
    "key" "text" NOT NULL,
    "value" "jsonb" NOT NULL,
    "description" "text",
    "updated_by_user_id" "uuid",
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."system_config" OWNER TO "app_user";

--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."testimonials" (
    "id" "uuid" NOT NULL,
    "type" "public"."TestimonialType" NOT NULL,
    "course_id" "uuid",
    "category" "text",
    "reviewer_name" "text" NOT NULL,
    "reviewer_role" "text",
    "reviewer_avatar" "text",
    "reviewer_initials" "text",
    "reviewer_color" "text",
    "content" "text" NOT NULL,
    "rating" integer DEFAULT 5 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "service_id" "uuid"
);


ALTER TABLE "public"."testimonials" OWNER TO "app_user";

--
-- Name: ticker_notifications; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."ticker_notifications" (
    "id" "uuid" NOT NULL,
    "phone" "text" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."ticker_notifications" OWNER TO "app_user";

--
-- Name: ticker_texts; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."ticker_texts" (
    "id" "uuid" NOT NULL,
    "text" "text" NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public"."ticker_texts" OWNER TO "app_user";

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."transactions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_id" "uuid",
    "type" "public"."TxType" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "description" "text" NOT NULL,
    "balance_before" numeric(18,2) NOT NULL,
    "balance_after" numeric(18,2) NOT NULL,
    "reference_code" "text",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "metadata" "jsonb",
    "account_number" character varying(50),
    "transaction_date" character varying(30)
);


ALTER TABLE "public"."transactions" OWNER TO "app_user";

--
-- Name: tut_trick_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."tut_trick_categories" (
    "id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "icon_url" "text",
    "display_order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE "public"."tut_trick_categories" OWNER TO "app_user";

--
-- Name: tut_tricks; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."tut_tricks" (
    "id" "uuid" NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "thumbnail" "text",
    "platform" "public"."Platform" NOT NULL,
    "category" "text" NOT NULL,
    "price" numeric(18,2) DEFAULT 0 NOT NULL,
    "description" "text",
    "content_url_enc" "bytea",
    "docs" "text",
    "seo_title" "text",
    "seo_description" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "total_orders" integer DEFAULT 0 NOT NULL,
    "total_views" integer DEFAULT 0 NOT NULL,
    "success_rate" integer DEFAULT 100 NOT NULL,
    "rating" double precision DEFAULT 0 NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "published_date" "date",
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "processing_time" "text",
    "warranty_policy" "text",
    "requires_account_type" boolean DEFAULT false NOT NULL,
    "requires_cccd" boolean DEFAULT false NOT NULL,
    "tier" "text" DEFAULT 'Miễn phí'::"text" NOT NULL
);


ALTER TABLE "public"."tut_tricks" OWNER TO "app_user";

--
-- Name: unmatched_transfers; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."unmatched_transfers" (
    "id" "uuid" NOT NULL,
    "content" "text" NOT NULL,
    "amount" numeric(18,2) NOT NULL,
    "reference_code" "text" NOT NULL,
    "raw_payload" "jsonb" NOT NULL,
    "candidates_tried" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "status" "text" DEFAULT 'PENDING'::"text" NOT NULL,
    "resolved_by_user_id" "uuid",
    "resolved_at" timestamp(3) without time zone,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."unmatched_transfers" OWNER TO "app_user";

--
-- Name: user_sub_categories; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."user_sub_categories" (
    "user_id" "uuid" NOT NULL,
    "sub_category_id" "uuid" NOT NULL
);


ALTER TABLE "public"."user_sub_categories" OWNER TO "app_user";

--
-- Name: users; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE "public"."users" (
    "id" "uuid" NOT NULL,
    "email" character varying(255) NOT NULL,
    "email_verified_at" timestamp(3) without time zone,
    "password_hash" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "phone" "text",
    "role" "public"."Role" DEFAULT 'USER'::"public"."Role" NOT NULL,
    "status" "public"."AccountStatus" DEFAULT 'PENDING_VERIFICATION'::"public"."AccountStatus" NOT NULL,
    "balance" numeric(18,2) DEFAULT 0 NOT NULL,
    "total_deposited" numeric(18,2) DEFAULT 0 NOT NULL,
    "total_spent" numeric(18,2) DEFAULT 0 NOT NULL,
    "seller_status" "public"."SellerStatus" DEFAULT 'NONE'::"public"."SellerStatus" NOT NULL,
    "seller_category" "text",
    "max_seller_products" integer DEFAULT 3 NOT NULL,
    "bank_name_enc" "bytea",
    "bank_account_number_enc" "bytea",
    "bank_account_holder_enc" "bytea",
    "cccd_image_url" "text",
    "portrait_image_url" "text",
    "two_factor_secret_enc" "bytea",
    "two_factor_enabled" boolean DEFAULT false NOT NULL,
    "last_login_at" timestamp(3) without time zone,
    "last_login_ip" "text",
    "failed_login_count" integer DEFAULT 0 NOT NULL,
    "locked_until" timestamp(3) without time zone,
    "uid_prefix" character varying(8) NOT NULL,
    "created_at" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp(3) without time zone NOT NULL,
    "deleted_at" timestamp(3) without time zone,
    "facebook_url" character varying(500),
    "telegram_username" character varying(100),
    "shop_locked" boolean DEFAULT false NOT NULL,
    "seller_tier" character varying(50) DEFAULT 'STANDARD'::character varying NOT NULL,
    "discount_percent" integer DEFAULT 0 NOT NULL,
    "avatar_url" character varying(500)
);


ALTER TABLE "public"."users" OWNER TO "app_user";

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."_prisma_migrations" ("id", "checksum", "finished_at", "migration_name", "logs", "rolled_back_at", "started_at", "applied_steps_count") FROM stdin;
4bf06588-1274-4681-9d88-30eb77fa2353	bb95ce68bd4bf15bdd467ed7075f60c8b4f42398daabe2e348e661d8bdee2ac8	2026-05-23 12:39:16.45714+00	20260523123915_init	\N	\N	2026-05-23 12:39:15.716735+00	1
f8498d12-a4e5-44c8-898a-aa9a7f753e34	9fdebf45d780b78105ebc7ec97b00b6f227880ce62fd9fa5248344776c42ab7c	2026-05-23 17:07:16.311501+00	20260523170716_add_service_customer_review_platform_variants	\N	\N	2026-05-23 17:07:16.292612+00	1
7e962818-f2b9-43ef-b410-2274175f5be9	56b9543d7614ab846e30e8288a15122aeb34045bbf3def8c4e33bbd8205aac25	2026-05-29 08:04:52.387718+00	20260529080452_add_resource_categories	\N	\N	2026-05-29 08:04:52.33563+00	1
4d574ae2-a062-4b99-82bd-31ad5ecc72b5	a3788a19196c5319118f04ff09e82405d404b188ad055acbc69a2ca4028d5261	2026-05-24 10:02:11.351339+00	20260524100211_add_course_categories	\N	\N	2026-05-24 10:02:11.309535+00	1
dd81d1b3-5f8d-4a00-85dd-56281d0c6168	e68c6194095cf1e5b857d199d7ed62cc9b2002bc0647879993a2652bd04fe7d8	2026-05-24 14:51:03.593432+00	20260524145103_add_mmo_stats	\N	\N	2026-05-24 14:51:03.57079+00	1
62865735-f765-47d6-a476-0618c4b35a0a	bd67af39e1e789ffc8d66f49f388ad9823dfb1302fb2d1f292b34ab252b34d17	2026-06-03 19:39:59.051392+00	20260603193958_add_page_permissions	\N	\N	2026-06-03 19:39:59.002114+00	1
bc045ead-0b9d-4687-b2a1-c4ac918a1abd	ed28f184c13712e8e60ab1e01f57e71aebf3f1d1257adc8c23e5f4adfaef7d54	2026-05-24 16:23:23.602139+00	20260524162323_add_customer_note_to_orders	\N	\N	2026-05-24 16:23:23.565639+00	1
25b232c0-407f-4300-bb22-86f740f397eb	5acbf9a1a548cf9f82b910bd3bc5ee380f1f286fe9a63591e2e447f65c1a6421	2026-05-29 08:59:06.054982+00	20260529085905_add_service_categories	\N	\N	2026-05-29 08:59:06.012642+00	1
096a35d1-43bf-4b8b-8bd5-1693732113f3	4700aae7643d3f8a352ac56960dbaab891f03172186b117580893850426ff06c	2026-05-25 11:00:43.671227+00	20260525110043_add_withdrawn_to_orders	\N	\N	2026-05-25 11:00:43.654762+00	1
1b2ab19e-9d2c-4e91-bbd5-e3b9ed99e48b	8e8997000a57f917e6d13e4fcc4248b5a027529ca6b3b6f7bdc9292d46c71057	2026-05-25 17:18:49.158558+00	20260525171849_add_social_links_to_users	\N	\N	2026-05-25 17:18:49.13712+00	1
eddb0d9e-3eac-425f-a28e-6894375724b1	fa6e4760c64a350f72e94f506058120a93cf3d3e1533dfbfba942768c9200e1f	2026-06-02 04:03:16.17697+00	20260602040316_add_service_id_to_testimonials	\N	\N	2026-06-02 04:03:16.138953+00	1
eed01c4c-bd91-4b4a-945b-e65a4175fa15	361d11f8c7a6ea405fafb1ff87928d70756f44c07a33889c7530656e6d515262	2026-05-25 18:04:28.640465+00	20260525180428_add_shop_locked_to_users	\N	\N	2026-05-25 18:04:28.621835+00	1
66a527bf-0a10-4893-959f-ecb15520a27a	b65ca580b8c8878688c95cb0643c782c0cace880901ccb66c6b9b1d5dfcbd096	2026-05-29 18:50:13.262518+00	20260529185013_add_seller_slot_purchase_tx_type	\N	\N	2026-05-29 18:50:13.247579+00	1
2a6ad5a0-46bf-4570-9b08-d157f8151894	a8a826036ca31c6f8fbc0e9f7cb96ffd7d6190548de11e450a7508d758359e15	2026-05-26 12:22:39.438939+00	20260526000001_add_order_id_to_reviews	\N	\N	2026-05-26 12:22:39.388298+00	1
79b40c94-888c-4bbe-9ed8-6156e6e5a0cd	6d35ce6af9f6cc3181cd71c3b6da38530668ebb881053f6af847b7427a323cb6	2026-05-26 14:52:23.632365+00	20260526145223_add_chat_system	\N	\N	2026-05-26 14:52:23.522281+00	1
518e0150-b5c3-4f27-a4c2-e8fa09d8ec28	07546c6bfed76b7ed0106c22b182228544f7025b1eaa7f1f48240599a2f151c3	2026-05-26 16:25:16.929131+00	20260526162516_add_frozen_order_status	\N	\N	2026-05-26 16:25:16.913553+00	1
21811c23-39ec-42ba-abfa-30a78d998bd9	29687602d957ef08e40467d052da3c289a7ccfb6ae09250e57d65beb23276071	2026-05-30 03:43:47.285485+00	20260530034347_add_seller_tier	\N	\N	2026-05-30 03:43:47.26439+00	1
5fb42ea5-ddfa-4941-9800-563c87aefedc	acc5cb066c45c8ec91482a014056158bb85209bd1a1246d9c7ef25a09878703f	2026-05-27 02:38:41.417746+00	20260527023841_snapshot_tuttrick_content_on_order	\N	\N	2026-05-27 02:38:41.403233+00	1
ac7f2b29-5dde-417a-a1c7-4a9bc818c951	23336b899701cf6271d4acc09e0ce99ab45061e34862281f44afa1293fd97713	2026-05-27 02:42:55.212247+00	20260527024255_add_warranty_processing_to_tut_tricks	\N	\N	2026-05-27 02:42:55.202232+00	1
90bd64e7-e4de-4a6d-9a3f-b2639c08ffec	b5dd452883e89f398bbb841e39e86cfee8dd385778400b1ea9a7c17c315aa099	2026-06-03 08:03:54.737715+00	20260603080354_add_transaction_date_account_number	\N	\N	2026-06-03 08:03:54.719549+00	1
40f557bb-7574-4710-96c2-30cc470e844f	00560b0fd845d00d70cc4ad4144af21bc4d1cf38f2e7df0e991d6e32973f7260	2026-05-30 08:47:43.071865+00	20260530084743_add_requires_account_type_cccd_to_services	\N	\N	2026-05-30 08:47:43.040186+00	1
2df9c5bd-e558-4445-877d-422e76ae4651	7aa092130babe8add95759d697013174664f2ba5e1d7982765ff878803d67c8e	2026-06-02 10:11:42.934133+00	20260602101142_add_tut_trick_category	\N	\N	2026-06-02 10:11:42.885988+00	1
10123860-b220-436f-86c5-2bf5e83083b0	7cb3c7f2251f4a71092c8923fa8af0199be2c037e4dc6df3026a4c71bc3ef0ec	2026-05-31 17:55:18.382087+00	20260531175518_add_order_requirements_to_all_products	\N	\N	2026-05-31 17:55:18.35545+00	1
990d04e8-8fd2-440b-a7c6-eca7aea504e9	13c848e2e2f53aaf97a2965d3060f35c2e4de133137315075b456599c9c19ca5	2026-06-02 03:11:38.739314+00	20260602031138_add_commitments_registration_procedure_to_courses	\N	\N	2026-06-02 03:11:38.723798+00	1
4c027591-17ad-49b9-815f-41170df2e26d	d6b6a00b06c01dc7ec6f61036961cea88b2c0e280cdfbc08c2c7a16f966096bd	2026-06-02 03:44:53.597197+00	20260602034453_add_testimonials	\N	\N	2026-06-02 03:44:53.524958+00	1
15c9d908-2118-4117-9a42-be0e295ddc73	e627dadc7929934d42e4932db0c9f4d75acb262683de1a89cab0d8d69da58bd0	2026-06-02 13:28:04.317392+00	20260602132804_add_icon_url_to_tut_trick_category	\N	\N	2026-06-02 13:28:04.304545+00	1
e0834f9c-a4d9-4185-b16e-1c7639f39cde	efff1efe0f3b459a6ed710f09f6d9b6a77a5aa00bf382de59c3ebee46e30f192	2026-06-04 03:26:55.993445+00	20260604000000_add_seller_tier_definitions		\N	2026-06-04 03:26:55.993445+00	0
730747d3-df0d-4509-b007-c7470d622c8b	29bbaff949c9e87da33bd28ac8a7db2a6b6e44414360feba7f9edc4b54aa7d4c	2026-06-02 13:50:01.723999+00	20260602135001_add_tier_to_tut_tricks	\N	\N	2026-06-02 13:50:01.711484+00	1
ab071d8b-4029-4ed1-901b-a991694fe12a	ad030afc8f08d654eff9980fd587475b163fab9120c03b9da1253fb809a47628	2026-06-03 08:46:22.599939+00	20260603084622_change_transaction_varchar_to_text	\N	\N	2026-06-03 08:46:22.568952+00	1
3d205362-dcc5-4fa3-ae53-1718b3393375	0defb9ccdc149d041172f26b82f2f338aefe7ff82c2ef04083edd76d78c66425	2026-06-03 07:59:14.877573+00	20260603075914_add_metadata_to_transactions	\N	\N	2026-06-03 07:59:14.864165+00	1
d199992b-11f5-4678-816d-740aff533cff	c8f1cc707f5147e235758faa78e4e320156303401c286e3711cffe7f57e8623d	2026-06-03 08:49:12.468802+00	20260603084912_restore_varchar_annotations	\N	\N	2026-06-03 08:49:12.337183+00	1
2dfec399-fc2b-424c-9607-abd714f0ccd6	5730f31d4d345db403dde07c1008dd73da6b7155fccf96ec8a2bbda94b70f4dd	2026-06-05 16:54:50.906359+00	20260605165450_add_public_page_configs	\N	\N	2026-06-05 16:54:50.870847+00	1
ce231f92-414e-41a0-b85e-620a8b98fdee	fe0bf71634960eb7142e6eb2127e185de7b57ac48c3b834fc68b84eee591a6ff	2026-06-04 03:28:12.713175+00	20260604032812_add_discount_percent_to_users	\N	\N	2026-06-04 03:28:12.676529+00	1
0213cc68-0439-4a62-8eda-e767290ad4ba	e5e4e35e7140265ec1ea31aa71a1e41a20b126ae42f96e39dddcdb12c7c2fdf8	2026-06-06 07:31:49.882401+00	20260606073149_add_fanpage_registration	\N	\N	2026-06-06 07:31:49.851421+00	1
c0a3f882-88be-465e-83be-0ffefa87ab73	56bee881a72fca7e492650511e2f7cd0b4fe14885eda0fc46025de93471dda35	2026-06-06 08:04:56.797823+00	20260606080456_add_ads_registration	\N	\N	2026-06-06 08:04:56.763591+00	1
a267d75e-5fe6-488f-a677-16cf584d7a2f	79c42022cc3f1eb46e10667bb59fa366090ddf4a690b0c4cb39516522d24c9ee	2026-06-06 09:27:46.644189+00	20260606092746_add_status_to_registrations	\N	\N	2026-06-06 09:27:46.610742+00	1
05f44480-f93e-4f77-a346-4c95ba16bea1	91b9f93a79c74453321489cb38ff234487af5de5617a1cf144bb1a8ea4ed7993	2026-06-06 15:01:37.400222+00	20260606150137_add_display_order_to_service_resource_tuttrick_categories	\N	\N	2026-06-06 15:01:37.381367+00	1
f2ea9727-3d7a-4039-af22-7bb7739f0c0c	6cf716a93022a96af9782b01192fd5fd1c8dfcf4e961ce86b3eb50bf15f10b8a	2026-06-07 11:01:50.307294+00	20260607110150_add_note_to_registrations	\N	\N	2026-06-07 11:01:50.292408+00	1
17ce4c68-315e-4861-89f9-bb30277773f1	e41d5b42bdc35b0d948de8ea75f81d6df453574e3e4cd241cb82718ee26b5381	2026-06-08 03:20:01.420266+00	20260608032001_add_avatar_url_to_users	\N	\N	2026-06-08 03:20:01.405738+00	1
3e402490-f16b-485f-86b3-a4f0e6e182cb	f5cd525182c15c698aed8430ec6d1f7592627d2a1d3487e5e7d5b46ef54e2fb7	2026-06-12 14:15:16.200667+00	20260612120000_add_seller_sub_categories	\N	\N	2026-06-12 14:15:16.066361+00	1
d3c95852-66b8-4c04-8ee1-ca9095e00511	37e968345ea00183baac250cbc323eab8dd256fc76ea8f9bcf016ae6e01d52ad	2026-06-12 14:15:16.233791+00	20260612150000_add_sub_category_to_seller_products	\N	\N	2026-06-12 14:15:16.205274+00	1
65a8da3e-b438-4a20-8187-a1d9f0b60fa8	47840172d3bd3dbe0cfa0953530b0e0992d2e1180f5f3772eb942752072a0bda	2026-06-21 18:40:52.282275+00	20260621184052_add_round_two_opened_to_chat_rooms	\N	\N	2026-06-21 18:40:52.26806+00	1
a1c4fb23-7571-42aa-954a-e715c869047f	55cef7b60a075487d87f84d953360f227b936fcf2ddee22e32f2b8f36d302d93	2026-06-14 10:21:25.132208+00	20260614102125_add_staff_permissions	\N	\N	2026-06-14 10:21:25.080458+00	1
f525eced-1bf7-44d8-bf3d-4d100e156e37	7790915d61092097d222766277ac2fcdd3664fdfd5b5d79b94624d9703ca0f56	2026-06-22 05:59:00.936705+00	20260622000001_seed_modules_and_permissions		\N	2026-06-22 05:59:00.936705+00	0
972efc5d-7cf1-4e38-8a14-4a162fae2e0d	0831bfcc7b6d2af908cf9a29d42470cb2022c3bed9b31c22d020b2fc46365323	2026-06-14 15:19:23.144002+00	20260614151923_add_site_content	\N	\N	2026-06-14 15:19:23.103958+00	1
b4e82d8b-01af-49c8-8590-8f2a669b47c3	e73c4aed28a9c09171e6c3058ac843e2c9c6a7a8754b08cb8302f40f87f8bf8c	2026-06-14 20:28:44.957012+00	20260614202844_add_bank_change_requests	\N	\N	2026-06-14 20:28:44.899489+00	1
ecd9c8ca-9978-4514-aee0-c76770ad26c4	61c2e15aa278c3bcb790e7fc3318d47a01dc534883f597227c1a66270da17e02	2026-06-15 09:57:28.829543+00	20260615095728_add_course_faq_support	\N	\N	2026-06-15 09:57:28.745194+00	1
81f2d03b-9479-4d23-8d33-e9ff05e474db	9f101c02f19c49b6054b0266635ecfc34b5a2934d71a127856091eb74a8f27ee	2026-06-22 06:11:59.659833+00	20260622120000_add_value_hash_to_mmo_product_items	\N	\N	2026-06-22 06:11:59.632824+00	1
b1cb71ec-a53b-4822-a722-839dd7a20611	255995bfc1930cb51b7b571642adb097c6f725ccacd43fb4dc51df727d3e71aa	2026-06-19 03:55:16.740554+00	20260619035516_add_store_type	\N	\N	2026-06-19 03:55:16.720453+00	1
15070c67-d1e5-4aba-bf2e-7fd34b867f09	4ddffdf2b6c4343402061deff4f2f23a62826c10252bef029e4aae05f8391ab6	2026-06-19 08:39:23.621707+00	20260619120000_chat_quota_auto_resolution	\N	\N	2026-06-19 08:39:23.527904+00	1
c64a755f-db45-443a-a2c4-79ba881ac405	705a5a044387540973b7fef31842bfc205f65ba38c56aab497cffb85373aa36e	2026-06-19 14:13:32.640402+00	20260619141332_add_store_type_flags_to_resource_categories	\N	\N	2026-06-19 14:13:32.627485+00	1
f6c99b91-2c16-4e62-b6e4-08be2a611b97	6583f65b162978b5c5c67f5f975c333cf74426c7a9106424b04ad4e31abea8df	2026-06-19 15:56:11.116889+00	20260619155611_add_store_type_flags_to_seller_sub_categories	\N	\N	2026-06-19 15:56:11.105237+00	1
c00dbec1-1414-4298-adeb-26bda6d91075	8ac9f8de7fa5e6e246c3616b5548375fad7b6919ccb10a2dc7979001017abbb6	2026-06-20 10:06:31.535448+00	20260620000001_add_modules_and_permissions	\N	\N	2026-06-20 10:06:31.409121+00	1
e526221b-2d43-475a-b439-6b295c0090f3	c93a26f6e67353ada3f9e05e6111fea9e0da87dc4e678f37ab5206cc4bbc1c3a	2026-06-21 10:10:54.112177+00	20260621101054_add_section_to_mmo_products	\N	\N	2026-06-21 10:10:54.076906+00	1
\.


--
-- Data for Name: ads_registrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."ads_registrations" ("id", "name", "phone", "service_name", "service_tab", "fanpage_status", "has_content", "ads_experience", "product_category", "budget", "created_at", "status", "note") FROM stdin;
c5152f02-99bb-4beb-815e-3dff14611a8d	Chuquangdoanh	0929990999	Cung Cấp Tài Nguyên Ads	facebook	none	has	never	my-pham	100-300m	2026-06-06 08:22:35.914	DONE	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."audit_logs" ("id", "actor_id", "action", "target_type", "target_id", "before", "after", "metadata", "ip_address", "user_agent", "created_at") FROM stdin;
e3eb770f-325d-4c03-9301-543bea9cf4ba	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 18:37:46.679
8eefab82-d989-4382-bfa1-130f240e1c56	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-08 03:04:38.712
aa2e1c39-0e21-4d0d-9ab2-2c23d0b43b43	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["dashboard:read", "products:read", "products:create", "chat:read", "chat:reply", "sellers:read", "sellers:approve", "sellers:update", "sellers:delete"]}	{"permissions": ["dashboard:read", "products:read", "products:create", "finance:read", "chat:read", "chat:reply", "sellers:read", "sellers:approve", "sellers:update", "sellers:delete"]}	\N	\N	\N	2026-06-20 13:48:27.425
4c4fdc9f-2a84-4483-a79e-1ddbdca3952a	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_BULK_DELETE	Course	cbf81219-3e12-4060-9303-dca020c2e798	\N	{"ids": ["cbf81219-3e12-4060-9303-dca020c2e798"], "count": 1}	\N	\N	\N	2026-06-20 18:39:11.985
6ca53e40-3787-45a3-a73a-eb3e24f021e5	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_RESOURCE_CATEGORY	ResourceCategory	6ca6cdb1-0183-4dd6-a348-f264e2a33512	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-21 11:53:06.069
251d3245-1d8c-4263-8d5a-84b8a95177bb	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_ADJUST_BALANCE	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"balance": 78889}	{"amount": 10000000, "balance": 10078889}	\N	\N	\N	2026-06-21 17:26:08.821
42818fa4-d810-4cb7-8164-0de286cfab99	15bbcf73-c01d-4730-85d7-a1cca3730c83	MMO_PRODUCT_CREATE	MmoProduct	9267c748-0bd9-4837-865e-6284602dce02	\N	{"id": "9267c748-0bd9-4837-865e-6284602dce02", "name": "FANPAGE 20K USER", "slug": "fanpage-20k-user"}	\N	\N	\N	2026-06-21 19:19:12.113
31f6f78f-cc61-4d73-9f94-af0a1e6b83e0	15bbcf73-c01d-4730-85d7-a1cca3730c83	MMO_PRODUCT_CREATE	MmoProduct	b9384472-6f75-4161-a94a-c6230c026dc9	\N	{"id": "b9384472-6f75-4161-a94a-c6230c026dc9", "name": "adada", "slug": "adada"}	\N	\N	\N	2026-06-22 06:33:49.5
b89e793f-e57c-4988-b8b0-6ff73797d5da	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_DEPOSIT_BANK_CONFIG	SystemConfig	deposit_bank_config	{"bank_bin": "970422", "bank_name": "MB Bank", "account_holder": "CHU QUANG DOANH", "account_number": "1536238386"}	{"bank_bin": "970422", "bank_name": "MB Bank", "ip_whitelist": [], "account_holder": "CHU QUANG DOANH", "account_number": "1536238386"}	\N	\N	\N	2026-06-22 18:25:30.007
1ffff6f8-1c95-46e3-a966-71ee7ffc5309	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 18:44:43.36
fcf631d8-838b-4afb-ac57-e98655e106f8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_SLOT_PURCHASE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	\N	{"price": 50000, "slots": 5}	\N	\N	2026-06-07 11:11:32.887
01395536-bc02-4d3a-8b97-61e38ce23c2c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 20}	{"slot_packages": [{"price": 50000, "slots": 1}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 1000000, "withdrawal_fee_percent": 20}	\N	\N	\N	2026-06-07 14:40:48.345
abf6578c-0a1b-4ad2-bd8b-616e02bb9b84	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 14:42:20.688
4ccc426c-781f-4865-8d84-15141a85555b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-08 04:15:59.738
fa03cc77-5345-47c9-9b80-ab8398bd9af1	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	55d1694a-443e-4f08-8875-8dadff9cbf62	{"permissions": []}	{"permissions": ["products:read", "products:create"]}	\N	\N	\N	2026-06-20 10:47:29.425
edcceb23-03db-4291-a0a4-12414ea53323	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	55d1694a-443e-4f08-8875-8dadff9cbf62	{"permissions": ["products:read", "products:create"]}	{"permissions": ["dashboard:read", "products:read", "products:create"]}	\N	\N	\N	2026-06-20 10:47:39.936
b6dfea73-4b09-46ae-95b7-923bfdeb73cd	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["dashboard:read", "products:read", "products:create", "finance:read", "chat:read", "chat:reply", "sellers:read", "sellers:approve", "sellers:update", "sellers:delete"]}	{"permissions": ["dashboard:read", "products:read", "products:create", "finance:read", "complaints:read", "complaints:reply", "complaints:update", "complaints:close", "chat:read", "chat:reply", "content:read", "content:create", "content:update", "sellers:read", "sellers:approve", "sellers:update", "sellers:delete"]}	\N	\N	\N	2026-06-20 13:49:49.362
cbf987d1-8906-4b90-85be-031e83da9fda	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_BULK_DELETE	TutTrick	a0db9bb3-dc95-443f-acd6-2160c90576de	\N	{"ids": ["a0db9bb3-dc95-443f-acd6-2160c90576de"], "count": 1}	\N	\N	\N	2026-06-20 18:42:06.254
5df68364-713a-4b32-9ed1-91375b7fedc1	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_RESOURCE_CATEGORY	ResourceCategory	78e57057-c212-4537-96d4-9d2394da5df4	{"name": "Telegram", "iconUrl": "https://svgl.app/library/telegram.svg"}	{"name": "Telegram", "iconUrl": "https://svgl.app/library/telegram.svg"}	\N	\N	\N	2026-06-21 11:53:08.479
41766649-afa8-4c5b-8a1b-5aee4091e231	15bbcf73-c01d-4730-85d7-a1cca3730c83	RESOLVE_COMPLAINT_FREEZE	Complaint	56dc4a32-7a5d-43bf-9965-01111b84c9ef	\N	{"frozenOrderId": "27773527-36ef-4544-9c57-643149bb66ff", "deductedAmount": 0, "sellerDeducted": false}	\N	\N	\N	2026-06-21 17:33:55.037
bc4e0238-ff50-4543-a295-33ab2c8945fa	15bbcf73-c01d-4730-85d7-a1cca3730c83	MMO_STOCK_ADD	MmoProduct	9267c748-0bd9-4837-865e-6284602dce02	\N	{"count": 2}	\N	\N	\N	2026-06-21 19:19:20.667
a2f993c4-6d17-495a-bc98-7178d9a10555	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_REGISTRATION_REQUESTED	SellerRequest	e580851a-de0a-48bc-b0a0-922784cbbd2c	\N	\N	{"ip": "::1", "category": "Instagram", "storeType": "KHO_TAI_NGUYEN", "subCategoryCount": 2}	\N	\N	2026-06-22 07:21:33.144
5af49321-af9d-458c-bd3a-1ac7186e8e06	15bbcf73-c01d-4730-85d7-a1cca3730c83	DEPOSIT_MANUAL	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"balance": "9693889.00"}	{"balance": "19693889.00"}	{"note": "Cộng", "adminId": "15bbcf73-c01d-4730-85d7-a1cca3730c83"}	\N	\N	2026-06-22 18:30:21.868
2330ef12-2cb2-4f4c-bdfe-4c073cdd4dec	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-06 18:45:41.272
f799f7b2-132b-428f-92b3-ef64881a64f3	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 18:45:46.282
089baeca-621d-4201-90f7-96c57ef45429	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 18:45:48.419
900ce982-aada-4c3e-845a-2aca185da37f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 14:41:29.959
4bef0132-ef5b-4b13-ab90-eb54b1fbf999	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 2, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "seoDescription": "Cam kết  hiểu  cv", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:28:20.846
730e4451-8a2d-41a6-925d-2fbcb643b945	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_CHANGE_ROLE	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"role": "ADMIN"}	{"role": "SELLER"}	\N	\N	\N	2026-06-20 10:50:19.141
fd963c3f-87ea-4cd6-b7a3-91b3cf70ae17	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["dashboard:read", "products:read", "products:create", "finance:read", "complaints:read", "complaints:reply", "complaints:update", "complaints:close", "chat:read", "chat:reply", "content:read", "content:create", "content:update", "sellers:read", "sellers:approve", "sellers:update", "sellers:delete"]}	{"permissions": []}	\N	\N	\N	2026-06-20 13:52:04.86
e811ff69-5778-4051-aad8-cdacccd2d9ee	15bbcf73-c01d-4730-85d7-a1cca3730c83	MMO_PRODUCT_CREATE	MmoProduct	f7e18809-6daa-4cc4-8522-2b1b94f4f03b	\N	{"id": "f7e18809-6daa-4cc4-8522-2b1b94f4f03b", "name": "aaaa", "slug": "aaaa"}	\N	\N	\N	2026-06-21 10:26:37.832
ef17b3a1-6f54-4007-9dd7-bba0f77003b2	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_RESOURCE_CATEGORY	ResourceCategory	7d8d51be-7709-4b46-9f0a-037f70281103	\N	{"name": "Facebook", "iconUrl": "https://svgl.app/library/facebook-icon.svg", "showInKhoTaiNguyen": true, "showInTaiNguyenMmo": false}	\N	\N	\N	2026-06-21 13:55:29.154
38354b30-3cc1-48b0-89a9-abfa239b672e	15bbcf73-c01d-4730-85d7-a1cca3730c83	RESOLVE_COMPLAINT_FREEZE	Complaint	7e3e716a-83c2-4390-86b3-68dfce733df6	\N	{"frozenOrderId": "8b52fa9a-a367-49dc-b5ae-a219a48ffc1a", "deductedAmount": 0, "sellerDeducted": false}	\N	\N	\N	2026-06-21 17:35:30.714
052e4dc4-46bd-4607-aae5-7167b15e070c	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	17615619-f682-407a-a5c1-9312261c47e6	\N	{"status": "RESOLVED", "orderId": "c7793e2e-97d8-43b1-b731-2896dce51db1", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 19:23:23.225
28c2a662-b3d5-4829-a4d1-ca34cfd37dc3	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_REQUEST_APPROVED	SellerRequest	1a2fbc54-0ab7-4789-8aa4-52ef6448b93c	{"sellerStatus": "PENDING"}	{"sellerStatus": "APPROVED", "approvedCategory": "Instagram"}	{"approvedCategory": "Instagram"}	\N	\N	2026-06-22 07:22:03.56
74ef2999-8d56-4b38-b175-84f3642bac78	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_DEPOSIT_BANK_CONFIG	SystemConfig	deposit_bank_config	{"bank_bin": "970422", "bank_name": "MB Bank", "ip_whitelist": [], "account_holder": "CHU QUANG DOANH", "account_number": "1536238386"}	{"bank_bin": "970422", "bank_name": "MB Bank", "ip_whitelist": [], "account_holder": "CHU QUANG DOANH", "account_number": "1536238386"}	\N	\N	\N	2026-06-22 18:51:53.378
22758e34-4e8a-4f07-bec6-194681464c4d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 18:47:53.69
71a6bad4-7eed-4a90-93b1-bd4db9505440	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 18:48:02.572
831c858c-1427-440e-a398-b44ffeb27f5c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 14:56:43.169
cab2197b-a383-404b-9646-ce823785927f	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:28:47.002
22d064db-3d43-4560-9a1e-a4547cd4ebcf	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_CHANGE_ROLE	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"role": "SELLER"}	{"role": "STAFF"}	\N	\N	\N	2026-06-20 10:50:22.658
28a02ae0-aa84-488d-9e92-cc231cfe3919	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": []}	{"permissions": ["services:read", "services:create", "tut_tricks:read", "tut_tricks:create"]}	\N	\N	\N	2026-06-20 18:00:04.56
a06b9ba1-4558-4992-b490-ab7bb0448120	15bbcf73-c01d-4730-85d7-a1cca3730c83	MMO_STOCK_ADD	MmoProduct	f7e18809-6daa-4cc4-8522-2b1b94f4f03b	\N	{"count": 1}	\N	\N	\N	2026-06-21 10:26:44.123
0a7003f9-1a57-4ccb-adc9-f4e363768d78	15bbcf73-c01d-4730-85d7-a1cca3730c83	REORDER_RESOURCE_CATEGORIES	ResourceCategory	batch	\N	{"count": 4}	\N	\N	\N	2026-06-21 13:55:33.903
cffe342b-e018-44f7-b18c-b234c29823ee	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_REJECT_COMPLAINT	Complaint	e2415682-2d5d-4355-8e24-6ee5bb223444	\N	{"outcome": "user_wins", "refundedAmount": 10000}	\N	\N	\N	2026-06-21 17:59:22.007
3dda1d02-2cf6-48ae-aa58-a76335c9ebff	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_OPEN_ROUND_2	Complaint	d4251f69-bb14-4282-9159-d22ee9cf169a	\N	{"action": "round_2_opened_reset_chat"}	\N	\N	\N	2026-06-21 19:26:44.801
a4633d15-9e3d-4cb8-bf79-f1585ffbf47e	9c652e2d-15d7-42d8-9b96-1179145dd096	USER_REGISTERED	User	9c652e2d-15d7-42d8-9b96-1179145dd096	\N	\N	{"ip": "::1", "email": "khachhangtrungtamfb@gmail.com"}	\N	\N	2026-06-22 07:50:14.471
e8463d70-8074-4293-bc20-687b0c30a628	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-06T03:30:27.058Z", "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 10000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	\N	\N	\N	2026-06-06 19:20:17.893
b1dab639-27a2-4b5f-836a-005a8779a99a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 17:35:01.261
80bd982e-f715-43d3-bfb5-b83912a4074d	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:29:30.178
304284fc-5edc-4616-b9f2-f78dabc78870	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	55d1694a-443e-4f08-8875-8dadff9cbf62	{"permissions": ["dashboard:read", "products:read", "products:create"]}	{"permissions": ["products:read", "products:create"]}	\N	\N	\N	2026-06-20 10:54:22.417
62507667-9aef-4901-947a-daf254ecbb4e	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["services:read", "services:create", "tut_tricks:read", "tut_tricks:create"]}	{"permissions": ["services:read", "services:create", "tut_tricks:read", "tut_tricks:create"]}	\N	\N	\N	2026-06-20 18:00:12.643
8eae90f9-6674-41a0-9eef-1fa6eb3c9ff9	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["services:read", "services:create", "tut_tricks:read", "tut_tricks:create"]}	{"permissions": ["dashboard:read", "services:read", "services:create", "tut_tricks:read", "tut_tricks:create"]}	\N	\N	\N	2026-06-20 18:00:20.962
8e263f72-4a55-472e-9ebe-7da68034a943	15bbcf73-c01d-4730-85d7-a1cca3730c83	REORDER_RESOURCE_CATEGORIES	ResourceCategory	batch	\N	{"count": 7}	\N	\N	\N	2026-06-21 10:42:21.563
63fc54e5-686d-494d-9824-8013fbe5a635	15bbcf73-c01d-4730-85d7-a1cca3730c83	REORDER_RESOURCE_CATEGORIES	ResourceCategory	batch	\N	{"count": 7}	\N	\N	\N	2026-06-21 10:42:22.753
ff28be15-9df6-4984-928d-adced6f028da	\N	AUTO_RESOLVE_COMPLAINT	Complaint	f30977b4-4e23-4122-9d56-c52a3fa65f6e	\N	{"orderId": "d02e9b91-0db8-4f4a-9194-61a745e3f301", "resolution": "Người mua không xác nhận trong 60 phút. Hệ thống tự động xác nhận đơn hàng."}	\N	\N	\N	2026-06-21 14:00:43.47
c9afb1dc-1bf3-47bc-ae0f-f3d8d9a39195	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_REJECT_COMPLAINT	Complaint	e34a9d82-a789-4a26-9642-fea4f684eb15	\N	{"outcome": "user_wins", "refundedAmount": 10000}	\N	\N	\N	2026-06-21 18:04:18.515
ca75502f-fb65-4f97-8220-6a64785db999	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	d4251f69-bb14-4282-9159-d22ee9cf169a	\N	{"status": "RESOLVED", "orderId": "f446c556-1e25-44c6-9a80-08a7790c678e", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 19:35:41.129
aea32229-1a46-41b7-9f28-57f3d1ed6dd5	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_ADJUST_BALANCE	User	9c652e2d-15d7-42d8-9b96-1179145dd096	{"balance": 0}	{"amount": 5000000, "balance": 5000000}	\N	\N	\N	2026-06-22 07:50:49.937
137c85d9-422a-4a32-9c4b-97427a55339d	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-07 17:52:47.925
15cc5390-14ff-4f3b-9167-08d0be9f27ec	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:31:14.19
8e670526-9c2d-4d6e-adc0-62f31fbd265f	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	55d1694a-443e-4f08-8875-8dadff9cbf62	{"permissions": ["products:read", "products:create"]}	{"permissions": ["products:read", "products:create"]}	\N	\N	\N	2026-06-20 10:54:55.177
f746dd59-101d-432d-832d-faed6bb87ee0	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["dashboard:read", "services:read", "services:create", "tut_tricks:read", "tut_tricks:create"]}	{"permissions": ["dashboard:read", "services:read", "services:create", "courses:read", "tut_tricks:read", "tut_tricks:create", "resources:read"]}	\N	\N	\N	2026-06-20 18:00:47.113
043a5121-0af6-44f0-b70c-b19672b82fe7	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_RESOURCE_CATEGORY	ResourceCategory	ad1a3184-4a2b-4029-b3fa-8063074f2f77	{"name": "Facebook"}	\N	\N	\N	\N	2026-06-21 11:41:11.56
1f4de916-23a1-496d-9be8-2b5b5bfd50e1	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_RESOURCE_CATEGORY	ResourceCategory	d98e03fb-feec-4455-8aaa-893fbccaf9a7	{"name": "Tiktok"}	\N	\N	\N	\N	2026-06-21 11:42:13.038
ec1f0746-fcba-48ca-b718-f84baa28476a	\N	AUTO_RESOLVE_COMPLAINT	Complaint	2dae67ba-3aa3-4b36-b421-787ed068ce4c	\N	{"orderId": "179f3897-e9ad-4d55-a5c5-629b70c5e387", "resolution": "Người mua không xác nhận trong 60 phút. Hệ thống tự động xác nhận đơn hàng."}	\N	\N	\N	2026-06-21 15:40:01.801
675ae4dd-443e-4df9-a32d-695b9c680795	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	bbc55809-641a-40bb-8012-736fe9d895e4	\N	{"status": "RESOLVED", "orderId": "122f5101-4b1b-4980-8e34-147581f29ab9", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 18:05:28.637
03042fc2-ff34-4e33-9e3e-1fcd88137574	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_REJECT_COMPLAINT	Complaint	7c6a7a01-8d29-418b-b1a3-f00ff0e6eaa3	\N	{"outcome": "user_wins", "refundedAmount": 10000}	\N	\N	\N	2026-06-21 19:37:49.95
c9967b53-66a6-47b9-8e92-0c4010053da3	9c652e2d-15d7-42d8-9b96-1179145dd096	SELLER_REGISTRATION_REQUESTED	SellerRequest	9c652e2d-15d7-42d8-9b96-1179145dd096	\N	\N	{"ip": "::1", "category": "Facebook", "storeType": "TAI_NGUYEN_MMO", "subCategoryCount": 2}	\N	\N	2026-06-22 07:51:46.934
076b6cd4-6d7d-4bb4-a48f-aecffbc0d944	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	e410cf1a-2a57-4179-a9da-67a5de2ed875	{"name": "Instargram"}	\N	\N	\N	\N	2026-06-06 15:42:06.612
520af349-e199-4667-9c78-35cc49ca62f4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	1208edbf-e67b-42f8-a0c2-f115e20aacc3	{"id": "1208edbf-e67b-42f8-a0c2-f115e20aacc3", "key": "VIP", "label": "VIP", "benefits": ["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:32:34.760Z", "badgeColor": "violet", "feePercent": 9, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	{"label": "Cấp 4", "benefits": ["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "badgeColor": "violet", "feePercent": 9, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	\N	\N	\N	2026-06-08 02:54:05.908
5611be18-79ca-4ae3-8aea-4517eea998d5	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 2, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "seoDescription": "Cam kết  hiểu  cv", "requiresAccountType": false}	\N	\N	\N	2026-06-08 04:31:41.279
f75a1503-3228-4859-882b-3a610fc92cb0	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": []}	{"permissions": ["dashboard:read", "products:read", "products:create"]}	\N	\N	\N	2026-06-20 10:55:26.746
e4f29f8d-c119-4846-a6ba-7ed6f61112ec	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["dashboard:read", "services:read", "services:create", "courses:read", "tut_tricks:read", "tut_tricks:create", "resources:read"]}	{"permissions": ["dashboard:read", "services:read", "services:create", "tut_tricks:read", "tut_tricks:create", "resources:read"]}	\N	\N	\N	2026-06-20 18:05:24.156
65abec7b-fe46-4733-90c1-e06de2b0885f	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_RESOURCE_CATEGORY	ResourceCategory	6ca6cdb1-0183-4dd6-a348-f264e2a33512	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-21 11:43:28.854
f15a98c0-2778-47fc-96a9-955e5055cc7d	15bbcf73-c01d-4730-85d7-a1cca3730c83	REORDER_RESOURCE_CATEGORIES	ResourceCategory	batch	\N	{"count": 5}	\N	\N	\N	2026-06-21 11:43:53.943
b652b62f-cf57-4544-a6ee-c39ada93c0cc	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	fe85aec8-39da-40c1-a14f-32d446326807	\N	{"status": "RESOLVED", "orderId": "08b1bed9-237f-4864-bc01-03975b26b5a4", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 17:02:01.763
095fb133-8138-45f2-bcc8-d74c2fefd847	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	ac3a5767-602c-4bcb-872f-adf41c58abad	\N	{"status": "RESOLVED", "orderId": "9b97b3a3-e7af-44e0-a574-8a02cfa712dd", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 18:24:33.611
33b1721a-91c0-42fa-bbb5-5f4668a211c8	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_SERVICE_CATEGORY	ServiceCategory	d8324efb-c8a8-4714-ae30-bc56fa253614	\N	{"name": "X", "iconUrl": "https://svgl.app/library/x.svg"}	\N	\N	\N	2026-06-22 04:26:30.128
d780a794-db5d-4ae3-8f35-e811c51e0771	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_REQUEST_APPROVED	SellerRequest	ab3d7065-c4d7-41a4-aacd-bfcf5eb5b7df	{"sellerStatus": "PENDING"}	{"sellerStatus": "APPROVED", "approvedCategory": "Facebook"}	{"approvedCategory": "Facebook"}	\N	\N	2026-06-22 07:51:57.739
958126ad-b9d9-44e5-83fd-07aff54c3e6c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	1c149d14-f5c4-43e4-93b5-f6f0c467c8da	{"id": "1c149d14-f5c4-43e4-93b5-f6f0c467c8da", "key": "SUPPER", "label": "Siêu VIP", "benefits": [], "holdDays": 3, "isActive": true, "createdAt": "2026-06-04T13:05:38.539Z", "isBuiltIn": false, "updatedAt": "2026-06-04T13:05:38.539Z", "badgeColor": "blue", "feePercent": 8, "description": "Nhà bán hàng kinh nghiệm", "displayOrder": 4, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	{"label": "Cấp 5", "benefits": [], "holdDays": 3, "isActive": true, "badgeColor": "blue", "feePercent": 8, "description": "Nhà bán hàng kinh nghiệm", "displayOrder": 4, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	\N	\N	\N	2026-06-08 02:54:12.014
253a4df6-b1f6-4bcb-a067-0271399b17c7	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": true, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-08 08:46:51.706
e4920392-ca84-4702-8c9d-5b3f38c716c3	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	55d1694a-443e-4f08-8875-8dadff9cbf62	{"permissions": ["products:read", "products:create"]}	{"permissions": ["products:read"]}	\N	\N	\N	2026-06-20 11:01:10.5
79ec624b-39bc-4401-b88e-41025a304eda	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["dashboard:read", "services:read", "services:create", "tut_tricks:read", "tut_tricks:create", "resources:read"]}	{"permissions": ["dashboard:read", "tut_tricks:read", "tut_tricks:create"]}	\N	\N	\N	2026-06-20 18:05:40.811
2cdfe2e8-4435-4dd4-944a-0c6499babdf8	15bbcf73-c01d-4730-85d7-a1cca3730c83	REORDER_RESOURCE_CATEGORIES	ResourceCategory	batch	\N	{"count": 5}	\N	\N	\N	2026-06-21 11:43:51.836
aed0f8fd-b412-418b-aaf8-67eda714cee4	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_CHANGE_ROLE	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"role": "STAFF"}	{"role": "USER"}	\N	\N	\N	2026-06-21 17:23:32.799
04faaadb-88cd-43c1-ad1c-6c721f61dafb	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	a1d62628-abbe-4bc6-b5e7-0b4ffedc5b09	\N	{"status": "RESOLVED", "orderId": "7450f2da-0d9e-4a98-9e84-63811095c148", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 18:37:43.491
c0797767-5fd0-4a59-ab03-350883a86e1d	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	55d1694a-443e-4f08-8875-8dadff9cbf62	{"permissions": []}	{"permissions": ["tut_tricks:read", "tut_tricks:create"]}	\N	\N	\N	2026-06-22 05:55:50.005
aceb9910-cdd6-434e-8802-2c5f1d0f2c52	\N	AUTO_RESOLVE_COMPLAINT	Complaint	15769eba-d5ad-4820-8ed1-7821d8afb038	\N	{"orderId": "75af354a-776c-4d81-95d0-17a76a609b93", "resolution": "Người mua không xác nhận trong 60 phút. Hệ thống tự động xác nhận đơn hàng."}	\N	\N	\N	2026-06-22 11:45:51.77
ccd9b4f7-004a-4a3b-b186-eb8e921dac5a	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	b2a4ef6e-4502-4435-8d9f-78c4d4b1abcc	{"name": "Icloud"}	\N	\N	\N	\N	2026-06-06 15:42:09.138
577dc1ae-9f86-4e8b-9732-42dc6192b6bc	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "khóa học 1", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["1️⃣ ĐÀO TẠO DỊCH VỤ FACEBOOK\\n- SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\n- Lấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n- Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n- Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n- Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n- TUT TRICK Facebook | Khai Thác Tricker Update New", "2️⃣ CHẠY QUẢNG CÁO ADS FACEBOOK \\n- Thiết Kế và Làm Conten (Video + Hình Ảnh) Chuẩn Chỉnh\\n- Tối Ưu FanFanpage Chuẩn SEO + Tăng Đề Xuất Fanpage\\n- Quy Trình Sử Dụng VIA + TKQC + BM Thành Thạo\\n- SET Quảng Cáo Mess + Livestream + Chuyển Đổi\\n- Tets Sản Phẩm WIN + Bán Hàng Online Thực Chiến\\n- Đọc Chỉ Số Quảng Cáo + Tối Ưu Camp Hiệu Quả\\n- Kinh Nghiệm SET Quảng Cáo Hàng VPCS Cực Nặng\\n- Care Camp Ngân Sách Cực Lớn (Trên 500Tr/1 Ngày)\\n- Kháng Nghị VIA + TKQC + BM Bị Hạn Chế (Cảnh Báo)\\n- TUT Trick Xử Lý Các Lỗi Trong Quá Trình Chạy ADS", "3️⃣ CHẠY QUẢNG CÁO ADS TIK TOK\\n- Sử Dụng và Vận Hành Tik Tok Shop\\n- Quy Trình Thành Thạo BC + Tài Khoản Quảng Cáo\\n- Cài Pixel + Test Sự Kiện Chuyển Đổi\\n- Quy Trình SET Quảng Cáo Livestream và Chuyển Đổi Landing Page\\n- Đọc Chỉ Số + Phân Tích Quảng Cáo Hiệu Quả\\n- Kháng Nghị Tài Nguyên Bị Vô Hiệu Hóa", "4️⃣ KHAI THÁC TÀI NGUYÊN \\n- TUT Buil BM 5 đến BM 10\\n- Setup Dàn TKQC Cá Nhân + BM Siêu Trâu\\n- Thiêt Kế Landing Page Bán Hàng (Cài Tên Miền + Lưu Data)\\nMô tả 4", "5️⃣ KIẾM TIỀN TỪ FACEBOOK #ADBREAK\\n- Bật Kiếm Tiền Cho Trang Fanpage\\n- Cung Cấp Nguồn Fanpage Bật Kiếm Tiền Việt + Ngoại\\n- SETUP Cài Payout Phương Thức Rút Tiền + Khai Báo Thuế\\n- Sử Dụng Al + Làm Video Al Để Khai Thác Nội Dung"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:11:33.559
ee535f55-c295-4ab1-af6b-c386a7800918	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["1️⃣ ĐÀO TẠO DỊCH VỤ FACEBOOK\\n- SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\n- Lấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n- Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n- Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n- Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n- TUT TRICK Facebook | Khai Thác Tricker Update New", "2️⃣ CHẠY QUẢNG CÁO ADS FACEBOOK \\n- Thiết Kế và Làm Conten (Video + Hình Ảnh) Chuẩn Chỉnh\\n- Tối Ưu FanFanpage Chuẩn SEO + Tăng Đề Xuất Fanpage\\n- Quy Trình Sử Dụng VIA + TKQC + BM Thành Thạo\\n- SET Quảng Cáo Mess + Livestream + Chuyển Đổi\\n- Tets Sản Phẩm WIN + Bán Hàng Online Thực Chiến\\n- Đọc Chỉ Số Quảng Cáo + Tối Ưu Camp Hiệu Quả\\n- Kinh Nghiệm SET Quảng Cáo Hàng VPCS Cực Nặng\\n- Care Camp Ngân Sách Cực Lớn (Trên 500Tr/1 Ngày)\\n- Kháng Nghị VIA + TKQC + BM Bị Hạn Chế (Cảnh Báo)\\n- TUT Trick Xử Lý Các Lỗi Trong Quá Trình Chạy ADS", "3️⃣ CHẠY QUẢNG CÁO ADS TIK TOK\\n- Sử Dụng và Vận Hành Tik Tok Shop\\n- Quy Trình Thành Thạo BC + Tài Khoản Quảng Cáo\\n- Cài Pixel + Test Sự Kiện Chuyển Đổi\\n- Quy Trình SET Quảng Cáo Livestream và Chuyển Đổi Landing Page\\n- Đọc Chỉ Số + Phân Tích Quảng Cáo Hiệu Quả\\n- Kháng Nghị Tài Nguyên Bị Vô Hiệu Hóa", "4️⃣ KHAI THÁC TÀI NGUYÊN \\n- TUT Buil BM 5 đến BM 10\\n- Setup Dàn TKQC Cá Nhân + BM Siêu Trâu\\n- Thiêt Kế Landing Page Bán Hàng (Cài Tên Miền + Lưu Data)\\nMô tả 4", "5️⃣ KIẾM TIỀN TỪ FACEBOOK #ADBREAK\\n- Bật Kiếm Tiền Cho Trang Fanpage\\n- Cung Cấp Nguồn Fanpage Bật Kiếm Tiền Việt + Ngoại\\n- SETUP Cài Payout Phương Thức Rút Tiền + Khai Báo Thuế\\n- Sử Dụng Al + Làm Video Al Để Khai Thác Nội Dung"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:16:25.039
e9f10d03-b81f-4e47-a4cf-901625595099	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	e22e8ca8-9c91-4573-b152-e532c6f3bc28	\N	{"id": "e22e8ca8-9c91-4573-b152-e532c6f3bc28", "name": "Mở khóa tài khoản xác thực 2 yếu tố", "slug": "mo-khoa-tai-khoan-xac-thuc-2-yeu-to"}	\N	\N	\N	2026-06-02 12:03:26.376
7a616aea-ac5f-4ae4-aa8e-a64c6ece1164	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_CREATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	\N	{"id": "15ef906b-fe34-43a9-83a8-b1a542251db3", "name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "hasContentUrl": true}	\N	\N	\N	2026-06-01 12:35:04.386
9d766faa-fede-4003-b312-39682b965fd3	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "price": 99000, "rating": 5, "category": "Có phí", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "processingTime": "Giao ngay", "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "warrantyPolicy": "Không bảo hành", "requiresAccountType": false}	\N	\N	\N	2026-06-01 12:36:16.023
d1c7d315-a131-4b6a-b689-8516ffe10f5c	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "price": 100000, "rating": 5, "category": "Miễn phí", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "processingTime": "giao ngay", "seoDescription": "2026", "warrantyPolicy": "3 ngày", "requiresAccountType": false}	\N	\N	\N	2026-06-01 12:36:51.418
813286bb-3ecc-4062-8233-eaa81270149b	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": true, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-01 18:55:49.357
c101eae5-da69-423e-8a82-a088e9b11477	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "khóa học 1", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["1️⃣ ĐÀO TẠO DỊCH VỤ FACEBOOK - SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội - Lấy Lại Tài Khoản Facebook Bị Hack (Ép From) - Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 -"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-01 18:58:08.676
a2575895-545a-410b-a55f-e9257cc06392	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 3, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:16:33.469
1eec62f0-ba72-4d24-a3df-5fc4373feda1	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-01 19:22:12.202
c3d21cef-e888-43f1-b5d1-15d14bf13135	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": true, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-01 19:22:35.609
8f15b77b-8581-4c8a-9c2e-7eb8c063d5a4	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "commitments": ["Hoàn Tiền", "Dạy có cộng động học viên"], "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false, "registrationProcedure": "Nộp tiền là done"}	\N	\N	\N	2026-06-02 03:20:11.858
f95b2834-53a9-416a-a48c-ce3019d7d426	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "khóa học 1", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-02 03:31:43.971
594179f9-224b-4a1c-9ded-4cbe05c9d1a3	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_ADJUST_BALANCE	User	15bbcf73-c01d-4730-85d7-a1cca3730c83	{"balance": 41000}	{"amount": 5000000, "balance": 5041000}	\N	\N	\N	2026-06-02 10:04:43.062
a554077f-6ac8-462b-9836-de4ba3589c30	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	914a7223-ade0-464f-aeb8-2506fd1bd252	\N	{"id": "914a7223-ade0-464f-aeb8-2506fd1bd252", "name": "Mở Khóa Tài Khoản Vô Hiệu Hóa", "slug": "mo-khoa-tai-khoan-vo-hieu-hoa"}	\N	\N	\N	2026-06-02 12:01:32.512
bf146e42-2530-4610-b597-a94844b6f5a9	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	914a7223-ade0-464f-aeb8-2506fd1bd252	{"name": "Mở Khóa Tài Khoản Vô Hiệu Hóa", "slug": "mo-khoa-tai-khoan-vo-hieu-hoa", "price": "4500000"}	{"name": "Mở Khóa Tài Khoản Vô Hiệu Hóa", "slug": "mo-khoa-tai-khoan-vo-hieu-hoa", "price": 4500000, "rating": 4.8, "category": "Facebook", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401699924.png", "isFeatured": false, "totalViews": 4231, "description": "Mở Khóa Tài khoản vô hiệu hóa vĩnh viễn dạng 583, 811, 035 ...", "productList": [], "reviewCount": 342, "successRate": 100, "totalOrders": 423, "displayOrder": 1, "requiresCccd": true, "customerCount": 3213, "processingTime": "1-7 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:01:44.381
fdbfaad2-6939-4073-a47c-046297624a92	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	6b802cb2-5052-4578-9e7b-1b0281d6e820	\N	{"id": "6b802cb2-5052-4578-9e7b-1b0281d6e820", "name": "Mở khóa Tài khoản 956", "slug": "mo-khoa-tai-khoan-956"}	\N	\N	\N	2026-06-02 12:04:49.515
2166412d-f7bb-452a-90e6-bb9bc3cdfff4	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	1700c5db-6a48-48bf-9c5c-57037050267d	{"name": "Mở Khóa 282", "slug": "dvfb", "price": "200000"}	{"name": "Mở Khóa 282", "slug": "dvfb", "price": 200000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779616281373.png", "isFeatured": true, "totalViews": 1323123, "description": "abc", "productList": [], "reviewCount": 2144, "successRate": 100, "totalOrders": 132, "displayOrder": 2, "requiresCccd": true, "customerCount": 123, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "1 Tháng", "price": 150000}, {"name": "2 tháng", "price": 500000}], "platformVariants": [{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:02.993
76f5c2a5-e9fc-4959-ae1d-5dc69ea88fd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	d11fa0ca-9935-441c-9f62-d46cf4d45999	{"name": "Mở Khóa Fanpage Bị Đình Chỉ Đăng", "slug": "adadad", "price": "3500000"}	{"name": "Mở Khóa Fanpage Bị Đình Chỉ Đăng", "slug": "adadad", "price": 3500000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779618629337.png", "isFeatured": true, "totalViews": 2543, "description": "Update siêu tut khôi phục những fanpage thời gian nhanh nhất qua hệ thống meta ai auto tools !", "productList": [], "reviewCount": 21, "successRate": 100, "totalOrders": 212, "displayOrder": 3, "requiresCccd": true, "customerCount": 241, "processingTime": "3 Ngày", "warrantyOptions": [{"name": "24 giờ", "price": 0}, {"name": "1 tháng", "price": 3000000}], "platformVariants": [{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:10.784
b1df3c79-c8ce-4c7e-8e50-2f49b190bcc0	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	1700c5db-6a48-48bf-9c5c-57037050267d	{"name": "Mở Khóa 282", "slug": "dvfb", "price": "200000"}	{"name": "Mở Khóa 282", "slug": "dvfb", "price": 200000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779616281373.png", "isFeatured": true, "totalViews": 1323123, "description": "abc", "productList": [], "reviewCount": 2144, "successRate": 100, "totalOrders": 132, "displayOrder": 4, "requiresCccd": true, "customerCount": 123, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "1 Tháng", "price": 150000}, {"name": "2 tháng", "price": 500000}], "platformVariants": [{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:18.154
e2197186-43d7-45f1-a859-ec34f1ea2223	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_UPDATE	Service	6b802cb2-5052-4578-9e7b-1b0281d6e820	{"name": "Mở khóa Tài khoản 956", "slug": "mo-khoa-tai-khoan-956", "price": "900000"}	{"name": "Mở khóa Tài khoản 956", "slug": "mo-khoa-tai-khoan-956", "price": 900000, "rating": 4.9, "category": "Facebook", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401926201.png", "isFeatured": false, "totalViews": 1412, "description": "Mở khóa những tài khoản bị dạng khóa két sắt tím và dạng khóa 956 két sắt mở", "productList": [], "reviewCount": 123, "successRate": 100, "totalOrders": 212, "displayOrder": 5, "requiresCccd": true, "customerCount": 324, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 12:05:27.854
2d49d6a0-07fd-4ab6-b4ae-2c3f9ad143e1	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	f2251457-dd7e-464f-8942-85447bf0fe95	\N	{"id": "f2251457-dd7e-464f-8942-85447bf0fe95", "name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip"}	\N	\N	\N	2026-06-02 12:07:13.982
693bd851-9d1d-4e05-bc31-ca07cb76f466	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	7d6cafc1-de27-4831-b383-6fb4fdf53e4c	\N	{"id": "7d6cafc1-de27-4831-b383-6fb4fdf53e4c", "name": "Tài khoản tiktok hạn chế đề xuất", "slug": "tai-khoan-tiktok-han-che-de-xuat"}	\N	\N	\N	2026-06-02 12:08:25.734
744a26aa-3aa5-49d3-89a8-a7bac17007d3	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	870c3504-944a-4833-a0ee-a25bef4c21e1	\N	{"id": "870c3504-944a-4833-a0ee-a25bef4c21e1", "name": "Xóa tài khoản tiktok mao danh", "slug": "xoa-tai-khoan-tiktok-mao-danh"}	\N	\N	\N	2026-06-02 12:09:51.855
794eb406-4a77-4175-b273-8206fe727ae7	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	39484b26-a985-4dcb-bccd-87aa3904aa9b	\N	{"id": "39484b26-a985-4dcb-bccd-87aa3904aa9b", "name": "Mở khóa video tiktok vi phạm", "slug": "mo-khoa-video-tiktok-vi-pham"}	\N	\N	\N	2026-06-02 12:10:39.596
7545f1cf-1a79-456f-845b-10dee4a8e2fd	15bbcf73-c01d-4730-85d7-a1cca3730c83	SERVICE_CREATE	Service	c8f14b74-fff9-46ee-b36b-93fa0e33287f	\N	{"id": "c8f14b74-fff9-46ee-b36b-93fa0e33287f", "name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay"}	\N	\N	\N	2026-06-02 12:11:50.317
b5ac244b-e802-4afc-8413-50698f206fe9	15bbcf73-c01d-4730-85d7-a1cca3730c83	ADMIN_ADJUST_BALANCE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"balance": 50509}	{"amount": 6666666, "balance": 6717175}	\N	\N	\N	2026-06-02 12:33:50.541
6f5d0781-53a9-4ae7-821c-5d5057bcb45b	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	1113abc4-9877-487d-82b4-588cf58f029b	\N	{"name": "Facebook", "iconUrl": "https://svgl.app/library/facebook-icon.svg"}	\N	\N	\N	2026-06-02 13:40:25.422
a870bf98-4b5d-48e2-8b8e-9d928f44be1d	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	32b13f3d-eb0c-4ca7-998d-95fb5a8416a8	\N	{"name": "TikTok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-02 13:40:27.445
013e0079-3a05-4117-9f0b-34e4db683272	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	636885d6-4e1a-439e-9809-9deaa8040a7a	\N	{"name": "YouTube", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-02 13:40:29.727
eb07b359-07e1-4880-b894-db94c9ea2f8d	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	d09c9d63-c764-496d-b276-6ded8a3a997f	\N	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-02 13:40:31.313
51003c5a-809b-4e37-9d05-273510c767a6	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_CREATE	TutTrick	2729244b-ae96-4a23-9703-180bb075df0a	\N	{"id": "2729244b-ae96-4a23-9703-180bb075df0a", "name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq", "hasContentUrl": false}	\N	\N	\N	2026-06-02 13:56:54.175
63dca868-bf97-4372-ab60-40c691059be0	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	636885d6-4e1a-439e-9809-9deaa8040a7a	{"name": "YouTube"}	\N	\N	\N	\N	2026-06-02 14:07:28.318
1d3d009c-882c-4591-9781-55f37bb01385	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	05ba9669-f0a5-4a3b-9abe-a0de72ce2ef6	\N	{"name": "YouTube", "iconUrl": "https://svgl.app/library/youtube.svg"}	\N	\N	\N	2026-06-02 14:07:30.641
2035eefa-34e1-4ad8-9859-1ce48baa6fd9	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	75261ce4-87c0-4447-8ee8-1f362ef473b5	{"name": "Tiktok"}	\N	\N	\N	\N	2026-06-06 15:42:11.039
17737fcf-fd0e-42b4-a64a-3c04324660a8	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Miễn phí", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 13:57:10.565
378437d7-ede3-4615-a4a1-076e6bbdd381	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail"}	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "tier": "Có phí", "price": 600000, "rating": 5, "category": "Có phí", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png", "isFeatured": false, "successRate": 100, "totalOrders": 123, "displayOrder": 3, "requiresCccd": false, "requiresAccountType": false}	\N	\N	\N	2026-06-02 13:57:25.659
9a02649e-6000-4bf7-a91f-3fd4e2357bea	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Có phí", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-02 13:57:32.189
81b544f3-594f-4832-8f98-070e87538ca9	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "TikTok", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:03.93
7601b43d-577f-4717-8f73-cf8c9000ee22	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": true, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:08.15
db7d8e64-9f24-4fbf-9677-861c5d5ec484	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Miễn phí", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:12.203
297b156b-0713-4ffb-aee0-474bde488012	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Instagram", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:15.786
f194578e-8359-429e-978a-067f78ee5765	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": true, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:20.658
e476a289-6e60-4552-961e-e4ddc9db7108	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail"}	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "tier": "Có phí", "price": 600000, "rating": 5, "category": "Instagram", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png", "isFeatured": false, "successRate": 100, "totalOrders": 123, "displayOrder": 3, "requiresCccd": false, "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:25.085
524acf98-eab0-4d1e-a756-e857c1fa390f	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUT_TRICK_UPDATE	TutTrick	15ef906b-fe34-43a9-83a8-b1a542251db3	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail"}	{"name": "TUT Change Pass Facebook Không Dính SDT và Gmail", "slug": "tut-change-pass-facebook-khong-dinh-sdt-va-gmail", "tier": "Có phí", "price": 600000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png", "isFeatured": false, "successRate": 100, "totalOrders": 123, "displayOrder": 3, "requiresCccd": false, "requiresAccountType": false}	\N	\N	\N	2026-06-02 14:03:29.096
6295f87c-335c-4aa9-82f5-b0e6b639585b	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	d09c9d63-c764-496d-b276-6ded8a3a997f	{"name": "Instagram"}	\N	\N	\N	\N	2026-06-02 14:07:13.221
5ba24119-98d6-489f-91a7-6840be3c5c97	15bbcf73-c01d-4730-85d7-a1cca3730c83	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	99d356a9-4744-4678-9d73-51500d050b6a	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-02 14:07:33.435
cdafacb2-2692-4fad-afdc-34b09c6fe76a	15bbcf73-c01d-4730-85d7-a1cca3730c83	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	99d356a9-4744-4678-9d73-51500d050b6a	{"name": "Google"}	\N	\N	\N	\N	2026-06-02 14:07:39.883
8b166058-0117-4b46-afbe-c566a86b5585	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_SLOT_PURCHASE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	\N	{"price": 120000, "slots": 10}	\N	\N	2026-06-02 19:05:28.864
a8510042-7276-40a9-a732-a3aa77682e95	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_REGISTRATION_REQUESTED	SellerRequest	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	\N	{"ip": "::1", "category": "Canva: a"}	\N	\N	2026-06-02 19:19:02.313
05d97715-4fb0-4c7d-a6c2-9b5dc96b2a28	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_REQUEST_REJECTED	SellerRequest	d7f444d4-7577-4561-a630-6908916d41d7	{"sellerStatus": "PENDING"}	{"rejectReason": "ad", "sellerStatus": "REJECTED"}	{"rejectReason": "ad"}	\N	\N	2026-06-02 19:19:27.034
cebdbc23-609e-4969-b523-550a3e219c3d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	b490690a-17bd-4b8b-8e8a-88f060bbbd9c	{"role": "ADMIN"}	{"role": "USER"}	\N	\N	\N	2026-06-02 19:25:45.272
8b9fc5d2-fd08-44d7-9aae-44cff0b9d669	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CREATE_USER	User	55d1694a-443e-4f08-8875-8dadff9cbf62	\N	{"role": "STAFF", "email": "nhanvien@gmail.com", "status": "ACTIVE", "fullName": "chu quang doanh"}	\N	\N	\N	2026-06-02 19:26:23.865
5259552c-4c35-44df-b2eb-01649c587d73	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	05ba9669-f0a5-4a3b-9abe-a0de72ce2ef6	{"name": "YouTube"}	\N	\N	\N	\N	2026-06-02 19:31:58.137
04aca532-b5f8-4c7f-8165-32d64d3bd03e	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_TUT_TRICK_CATEGORY	TutTrickCategory	32b13f3d-eb0c-4ca7-998d-95fb5a8416a8	{"name": "TikTok"}	\N	\N	\N	\N	2026-06-02 19:31:59.849
eb78956f-f835-4cb5-a394-ba24767cfec1	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	4ad9b472-ceda-4b83-9d79-ddfb09c175d1	{"name": "Canva"}	\N	\N	\N	\N	2026-06-02 19:32:19.82
988a1fd4-1ffd-41fc-a3c3-06f3e051e972	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	c8f14b74-fff9-46ee-b36b-93fa0e33287f	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": "2500000"}	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": 2500000, "rating": 5, "category": "Intagram", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428759528.png", "isFeatured": false, "totalViews": 32123, "description": "Mở khóa những tài khoản instagram chính chủ", "productList": [], "reviewCount": 3242, "successRate": 100, "totalOrders": 2134, "displayOrder": 0, "requiresCccd": false, "customerCount": 4124, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 19:32:45.118
58968ca1-2353-4579-8ef5-bffd858a70db	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	7d6cafc1-de27-4831-b383-6fb4fdf53e4c	{"name": "Tài khoản tiktok hạn chế đề xuất", "slug": "tai-khoan-tiktok-han-che-de-xuat", "price": "1500000"}	{"name": "Tài khoản tiktok hạn chế đề xuất", "slug": "tai-khoan-tiktok-han-che-de-xuat", "price": 1500000, "rating": 4.9, "category": "Tiktok", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428774308.png", "isFeatured": false, "totalViews": 4321, "description": "Kháng nghị tài khoản tiktok hạn chế đề xuất kênh vi phạm cảnh báo đỏ", "productList": [], "reviewCount": 1231, "successRate": 100, "totalOrders": 243, "displayOrder": 2, "requiresCccd": false, "customerCount": 1231, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 19:32:56.836
9a373308-b56e-4573-94dc-45570b7cb4c3	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	f2251457-dd7e-464f-8942-85447bf0fe95	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": "600000"}	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": 600000, "rating": 5, "category": "Google", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428783583.png", "isFeatured": false, "totalViews": 241, "description": "30 đánh giá gg map 5 sao ngay lập tực cho gg map khi thanh toán chỉ cần link gg map cho chúng tôi. ", "productList": [], "reviewCount": 86, "successRate": 100, "totalOrders": 45, "displayOrder": 2, "requiresCccd": false, "customerCount": 132, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:33:06.238
4f29ff1f-3bd5-4506-b6a3-c91151871eee	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	39484b26-a985-4dcb-bccd-87aa3904aa9b	{"name": "Mở khóa video tiktok vi phạm", "slug": "mo-khoa-video-tiktok-vi-pham", "price": "1500000"}	{"name": "Mở khóa video tiktok vi phạm", "slug": "mo-khoa-video-tiktok-vi-pham", "price": 1500000, "rating": 5, "category": "Tiktok", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428792008.png", "isFeatured": false, "totalViews": 123, "productList": [], "reviewCount": 324, "successRate": 100, "totalOrders": 124, "displayOrder": 3, "requiresCccd": false, "customerCount": 3423, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-02 19:33:15.23
7562c5c8-4d63-4dd2-be3e-bdbaa549214f	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	870c3504-944a-4833-a0ee-a25bef4c21e1	{"name": "Xóa tài khoản tiktok mao danh", "slug": "xoa-tai-khoan-tiktok-mao-danh", "price": "1500000"}	{"name": "Xóa tài khoản tiktok mao danh", "slug": "xoa-tai-khoan-tiktok-mao-danh", "price": 1500000, "rating": 5, "category": "Tiktok", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428801249.png", "isFeatured": false, "totalViews": 212, "description": "Xóa tai khoản tiktok mạo danh chính chủ, yêu cầu cccd trùng thông tin ", "productList": [], "reviewCount": 54, "successRate": 100, "totalOrders": 34, "displayOrder": 3, "requiresCccd": true, "customerCount": 412, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:33:23.908
1a082138-15fe-4392-a6c6-9462bba1cb1c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	STAFF	\N	{"permissions": {"admin/chats": true, "admin/users": false, "admin/orders": true, "admin/courses": false, "admin/reviews": true, "admin/sellers": true, "admin/tickers": false, "admin/danh-gia": true, "admin/deposits": true, "admin/services": false, "admin/audit-log": false, "admin/dashboard": true, "admin/complaints": true, "admin/tut-tricks": false, "admin/withdrawals": false, "admin/mmo-products": false, "admin/san-pham-ban": true, "admin/cai-dat-ban-hang": false, "admin/course-categories": false, "admin/service-categories": false, "admin/resource-categories": false, "admin/tut-trick-categories": false}}	\N	\N	\N	2026-06-03 20:01:22.161
9705aebb-6060-46df-a957-6c3f516299e9	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 5}	{"discountPercent": 5}	\N	\N	\N	2026-06-04 07:50:48.497
7d8add15-9a58-47fb-aaa3-23fcfaa3ec0c	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:34:27.872
61b41d42-af8b-427b-a87c-4467ab7210c3	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	cbf81219-3e12-4060-9303-dca020c2e798	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok"}	{"name": "Khóa Học Chạy Quảng Cáo Tiktok", "slug": "khoa-hoc-chay-quang-cao-tiktok", "badge": "HOT", "rating": 5, "category": "Tiktok", "duration": "7 Buổi Online chuyên sâu", "isActive": true, "seoTitle": "Khóa học quảng cáo tiktok", "salePrice": 12999000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png", "totalViews": 1214, "contentList": ["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"], "description": "Khóa Đào Tạo Chuyên Sâu", "totalOrders": 2131, "displayOrder": 1, "requiresCccd": false, "studentCount": 431, "originalPrice": 15000000, "instructorName": "Chu Quang Doanh", "learningFormat": "ONLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:34:34.205
e8918950-cbc5-43f2-97a9-cdf1bd6e0657	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "Khóa học online", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:35:01.239
30b3db75-2254-4b2c-8232-2ccdce08ed30	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 3, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:35:12.108
a4c1439f-f269-4128-a43b-78e8385d6d7e	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	4447b4b5-91b3-4226-8089-638faa948030	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo"}	{"name": "KHÓA HỌC MMO", "slug": "khoa-hoc-mmo", "badge": "NEW", "rating": 5, "category": "Facebook", "duration": "5 buổi", "isActive": true, "seoTitle": "Khóa học online", "salePrice": 1599000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png", "totalViews": 231, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"], "description": "Khóa học mới của chúng tôi", "totalOrders": 4, "displayOrder": 2, "requiresCccd": false, "studentCount": 54, "originalPrice": 1999000, "learningFormat": "ONLINE", "seoDescription": "Khóa học 2", "requiresAccountType": false}	\N	\N	\N	2026-06-02 19:38:18.1
c00b59be-721c-4b06-9f69-e0945eca2622	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_HARD_DELETE_USER	User	c687c44b-288e-4fb7-8817-cfebb988db15	{"role": "USER", "email": "lasvergasblackmeta@gmail.com"}	{"deleted": true}	\N	\N	\N	2026-06-03 03:04:35.317
2bc4c89b-d129-442e-ae56-321556847f3b	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	15bbcf73-c01d-4730-85d7-a1cca3730c83	{"role": "USER"}	{"role": "ADMIN"}	\N	\N	\N	2026-06-03 07:23:43.892
119d2f12-8bca-43ed-87b1-ce4c9049338f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	STAFF	\N	{"permissions": {"admin/chats": true, "admin/users": false, "admin/orders": true, "admin/courses": false, "admin/reviews": true, "admin/sellers": true, "admin/tickers": false, "admin/danh-gia": true, "admin/deposits": true, "admin/services": false, "admin/audit-log": false, "admin/dashboard": true, "admin/complaints": true, "admin/tut-tricks": false, "admin/withdrawals": false, "admin/mmo-products": false, "admin/san-pham-ban": true, "admin/cai-dat-ban-hang": false, "admin/course-categories": false, "admin/service-categories": false, "admin/resource-categories": false, "admin/tut-trick-categories": false}}	\N	\N	\N	2026-06-03 19:50:06.299
fb037e25-ad66-4778-a9be-0e70c35d0ced	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"role": "SELLER"}	{"role": "STAFF"}	\N	\N	\N	2026-06-03 19:51:34.925
df000555-d84f-4918-937c-6665c1e432a3	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	53f04ea0-9b5e-4f15-8a3a-76572bb81859	\N	{"status": "RESOLVED", "orderId": "3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05", "outcome": "seller_wins"}	\N	\N	\N	2026-06-04 03:10:58.386
e717f0af-faeb-4bc9-a1cc-47358623f87f	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 0}	{"discountPercent": 5}	\N	\N	\N	2026-06-04 07:50:45.316
3d019c8b-61af-466e-b80c-8f9fd45757e0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT_DELETE	SellerProduct	45a65117-624f-4e87-b2cc-add4714bc25e	{"name": "Tài khoản 250$"}	\N	\N	\N	\N	2026-06-04 11:31:54.487
78a53b59-dbf1-4566-9653-801f2903d371	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 5}	{"discountPercent": 5}	\N	\N	\N	2026-06-04 07:50:50.081
82911a91-8727-4064-894e-d7ceda67f5f3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_RESTRICTED	SellerProduct	a4a52a6a-5914-4f9d-9c07-606b73a5e842	{"isRestricted": false}	{"reason": "", "isRestricted": true}	\N	\N	\N	2026-06-04 07:59:51.523
bd934eb0-7989-4d12-81b1-6970c9f6c723	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_UNRESTRICTED	SellerProduct	a4a52a6a-5914-4f9d-9c07-606b73a5e842	{"isRestricted": true}	{"isRestricted": false}	\N	\N	\N	2026-06-04 07:59:54.095
cef625e9-03e1-49fa-bc29-0044a6ca29ca	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_RESTRICTED	SellerProduct	0fbf8797-e5c2-493a-b175-61f2b6b412ef	{"isRestricted": false}	{"reason": "", "isRestricted": true}	\N	\N	\N	2026-06-04 08:00:02.091
474d62e9-7205-43e0-be39-a110c8507b8d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	PRODUCT_UNRESTRICTED	SellerProduct	0fbf8797-e5c2-493a-b175-61f2b6b412ef	{"isRestricted": true}	{"isRestricted": false}	\N	\N	\N	2026-06-04 08:00:18.939
72571b4d-f1ac-43c6-9f6c-6860ba071d05	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	STAFF	\N	{"permissions": {"admin/chats": true, "admin/users": true, "admin/orders": true, "admin/courses": false, "admin/reviews": true, "admin/sellers": true, "admin/tickers": true, "admin/danh-gia": true, "admin/deposits": true, "admin/services": false, "admin/audit-log": false, "admin/dashboard": true, "admin/complaints": true, "admin/tut-tricks": false, "admin/withdrawals": false, "admin/mmo-products": false, "admin/san-pham-ban": true, "admin/cai-dat-ban-hang": false, "admin/course-categories": false, "admin/service-categories": false, "admin/resource-categories": false, "admin/tut-trick-categories": false}}	\N	\N	\N	2026-06-04 08:03:44.776
28c02710-6b5b-4c89-bb3c-a66fce38966c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	USER	\N	{"permissions": {"don-hang": true, "nap-tien": true, "tro-chuyen": false, "lich-su-giao-dich": true, "thong-tin-ca-nhan": true}}	\N	\N	\N	2026-06-04 08:19:42.303
c76d1302-1c6a-4ff0-9f3f-f1126286b0ef	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Standard", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 3, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "gray", "feePercent": 5, "description": "Hạng mặc định khi được duyệt", "displayOrder": 0, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 7, "isActive": true, "badgeColor": "gray", "feePercent": 15, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 5000000}	\N	\N	\N	2026-06-04 08:29:18.835
3e491a30-a7c8-4530-851a-a7107f96c14f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	77f20ddc-fd13-4ba5-b536-30f12353c35d	{"id": "77f20ddc-fd13-4ba5-b536-30f12353c35d", "key": "SILVER", "label": "Silver", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 2, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "slate", "feePercent": 4, "description": "Seller hoạt động tích cực", "displayOrder": 1, "minWithdrawal": 150000, "upgradeMinOrders": 20, "upgradeMinRevenue": 5000000}	{"label": "Cấp 2", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 7, "isActive": true, "badgeColor": "slate", "feePercent": 13, "description": "Nhà bán hàng hoạt động tích cực", "displayOrder": 2, "minWithdrawal": 3500000, "upgradeMinOrders": 20, "upgradeMinRevenue": 5000000}	\N	\N	\N	2026-06-04 08:30:17.355
a9eb8af2-8b1d-4c7d-90e0-4d1b7438a5ee	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	9033a6a8-f624-4b37-af6c-d907a82dab11	{"id": "9033a6a8-f624-4b37-af6c-d907a82dab11", "key": "GOLD", "label": "Gold", "benefits": ["Phí rút tiền chỉ 3%", "Rút tối thiểu 100.000đ", "Badge Gold nổi bật"], "holdDays": 1, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "amber", "feePercent": 3, "description": "Seller có doanh thu tốt", "displayOrder": 2, "minWithdrawal": 100000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	{"label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	\N	\N	\N	2026-06-04 08:31:41.126
0396caf7-4040-43a7-b928-3be88862b041	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	9033a6a8-f624-4b37-af6c-d907a82dab11	{"id": "9033a6a8-f624-4b37-af6c-d907a82dab11", "key": "GOLD", "label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:31:41.111Z", "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	{"label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	\N	\N	\N	2026-06-04 08:31:44.238
27ff3dc6-ca4d-4eed-b8b8-eb0838b62a0c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	9033a6a8-f624-4b37-af6c-d907a82dab11	{"id": "9033a6a8-f624-4b37-af6c-d907a82dab11", "key": "GOLD", "label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:31:44.223Z", "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	{"label": "Cấp 3", "benefits": ["Hỗ trợ cskh nhanh tỉ lệ đơn cao"], "holdDays": 7, "isActive": true, "badgeColor": "amber", "feePercent": 11, "description": "Seller có doanh thu tốt", "displayOrder": 3, "minWithdrawal": 5000000, "upgradeMinOrders": 100, "upgradeMinRevenue": 20000000}	\N	\N	\N	2026-06-04 08:31:47.209
2fe97a6e-da7b-4e14-844f-d067629ce8f3	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_SHOP_UNLOCKED	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"shopLocked": true}	{"shopLocked": false}	\N	\N	\N	2026-06-04 11:36:05.931
b6787b10-90c8-4889-a2b3-ab652f4de328	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	89b3932c-59f2-4d51-abfa-c40ced675fc8	\N	{"status": "RESOLVED", "orderId": "0334e4cd-2a86-4638-b18b-2665b94c0143", "outcome": "seller_wins"}	\N	\N	\N	2026-06-04 12:13:31.517
b6145a2e-7cce-4223-834b-522c662c681c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "STANDARD"}	{"sellerTier": "SILVER"}	\N	\N	\N	2026-06-04 12:15:12.259
d9e7cefc-7951-42ee-9083-b7c9a484dcbb	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	1208edbf-e67b-42f8-a0c2-f115e20aacc3	{"id": "1208edbf-e67b-42f8-a0c2-f115e20aacc3", "key": "VIP", "label": "VIP", "benefits": ["Phí rút tiền chỉ 1%", "Không giữ đơn khi rút", "Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T03:26:44.294Z", "badgeColor": "violet", "feePercent": 1, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 3, "minWithdrawal": 50000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	{"label": "VIP", "benefits": ["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"], "holdDays": 0, "isActive": true, "badgeColor": "violet", "feePercent": 9, "description": "Seller xuất sắc — ưu đãi cao nhất", "displayOrder": 4, "minWithdrawal": 5000000, "upgradeMinOrders": 500, "upgradeMinRevenue": 100000000}	\N	\N	\N	2026-06-04 08:32:34.764
323bbd50-2e40-4932-9993-57e4c08ab7a5	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:29:18.813Z", "badgeColor": "gray", "feePercent": 15, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 5000000}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 7, "isActive": true, "badgeColor": "gray", "feePercent": 15, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 200000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	\N	\N	\N	2026-06-04 08:32:54.447
19bfba1c-1aa9-469c-8b8f-22bf37476476	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	77f20ddc-fd13-4ba5-b536-30f12353c35d	{"id": "77f20ddc-fd13-4ba5-b536-30f12353c35d", "key": "SILVER", "label": "Cấp 2", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 7, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-04T08:30:17.349Z", "badgeColor": "slate", "feePercent": 13, "description": "Nhà bán hàng hoạt động tích cực", "displayOrder": 2, "minWithdrawal": 3500000, "upgradeMinOrders": 20, "upgradeMinRevenue": 5000000}	{"label": "Cấp 2", "benefits": ["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"], "holdDays": 7, "isActive": true, "badgeColor": "slate", "feePercent": 13, "description": "Nhà bán hàng hoạt động tích cực", "displayOrder": 2, "minWithdrawal": 3500000, "upgradeMinOrders": 20, "upgradeMinRevenue": 3000000}	\N	\N	\N	2026-06-04 08:33:01.458
aa078c81-e15c-4557-a690-147d46644e4a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"tier_config": {"VIP": {"hold_days": 5, "fee_percent": 8, "min_withdrawal": 5000000}, "GOLD": {"hold_days": 7, "fee_percent": 10, "min_withdrawal": 600000}, "SILVER": {"hold_days": 7, "fee_percent": 13, "min_withdrawal": 7000000}, "STANDARD": {"hold_days": 10, "fee_percent": 15, "min_withdrawal": 10000000}}, "slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "min_withdrawal_amount": 50000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 3, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:34:03.927
1170b04b-495a-4649-9275-932359f79a68	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	80270900-1509-4867-96a3-c1402df7412d	\N	{"status": "RESOLVED", "orderId": "2ec9ccff-7621-4925-a6df-6a6dc48a961a", "outcome": "seller_wins"}	\N	\N	\N	2026-06-04 08:36:11.939
b0513483-1b66-40df-95d4-78b0b4905379	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_CHANGE_ROLE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"role": "STAFF"}	{"role": "SELLER"}	\N	\N	\N	2026-06-04 08:37:53.93
918432e6-2bd5-49f1-952f-4634555b68b9	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 3, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:41:05.5
28863396-a2bd-46ff-8886-54a3551ef1a0	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 500000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 100000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:46:32.905
9ece502e-b5da-4620-8ea0-303904a99faa	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 100000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-04 08:47:17.363
92591004-0c83-4b5a-a15b-37ddff68f00b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "STANDARD"}	{"sellerTier": "VIP"}	\N	\N	\N	2026-06-04 08:48:36.33
efacc5a8-4612-42a2-bfc0-a510858184c2	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "VIP"}	{"sellerTier": "STANDARD"}	\N	\N	\N	2026-06-04 08:49:00.305
60f64e1e-5338-45e3-af41-9831208a3737	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_SHOP_LOCKED	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"shopLocked": false}	{"shopLocked": true}	\N	\N	\N	2026-06-04 11:28:30.138
a8e465f1-e890-4d0c-b3b8-e2e2cabfc367	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT_DELETE	SellerProduct	a4a52a6a-5914-4f9d-9c07-606b73a5e842	{"name": "Via Facebook Clone 2019"}	\N	\N	\N	\N	2026-06-04 11:31:33.178
8c47806c-06de-42a4-abe6-7337b55e6cf3	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	f15fef1f-7843-44b0-b983-72068d1647c6	{"sellerTier": "SILVER"}	{"sellerTier": "STANDARD"}	\N	\N	\N	2026-06-04 12:15:31.353
c6c9b6d3-7328-4a0e-a43a-9e8da77d640e	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_REVIEW	Review	33212fce-536f-4b54-ad55-955a881dacee	{"rating": 2, "comment": null}	{"rating": 5, "comment": null}	\N	\N	\N	2026-06-04 12:21:36.246
50eb2e0c-04d5-47a1-8098-ed5ce5635392	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_UPDATE	Course	6e646372-6751-49d3-9ccd-1fc78e96c2bd	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba"}	{"name": "Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1", "slug": "fba", "badge": "VIP", "rating": 5, "category": "Facebook", "duration": "12 NGÀY", "isActive": true, "seoTitle": "Khóa học trực tiếp", "salePrice": 99000000, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png", "totalViews": 1323, "youtubeUrl": "https://youtu.be/pfatajwTL4I", "contentList": ["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"], "description": "kHÓA HỌC THỰC CHIẾN MMO \\nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook", "totalOrders": 5412, "displayOrder": 2, "requiresCccd": false, "studentCount": 123, "originalPrice": 100000000, "learningFormat": "OFFLINE", "seoDescription": "Cam kết  hiểu  cv", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:24:49.181
30483bc7-7b09-4d78-aabf-928c1a71f6ae	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:25:53.001
fe7f9750-b888-4236-ae99-6060a9967872	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": false, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:26:14.277
d9870cf6-3bfb-47de-b018-82fff4592a6a	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	{"name": "Tài khoản tiktok", "slug": "tai-khoan-tiktok"}	{"name": "Tài khoản tiktok", "slug": "tai-khoan-tiktok", "price": 360000, "category": "Tài khoản tiktok ", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779734932645.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Tiktok", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:27:51.95
6269001f-e829-4c8d-84b3-d0c012a29a97	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	{"name": "VIA", "slug": "via"}	{"name": "VIA", "slug": "via", "price": 99000, "category": "Via 1m1", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779642138078.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Facebook", "requiresAccountType": false}	\N	\N	\N	2026-06-04 12:27:56.808
9e73bc1e-5974-496a-8fbf-8b9c32be8569	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_STOCK_ADD	MmoProduct	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	{"count": 1}	\N	\N	\N	2026-06-04 12:28:04.01
d7e22054-6ee4-4514-9043-f7fe008614cb	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:00:59.648
5b35606f-f4ff-4e56-9160-c0f92b8f10a1	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:01:01.055
cfdb898d-db3e-432d-aecc-08aac1cc2151	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-04 13:01:03.041
bdf6c83b-a7d2-4df3-93d3-e1ad34ea6f41	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:01:37.96
664fc925-3437-4bb7-b940-e50b22f48c73	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-04 13:01:45.786
acd7eda9-aaf3-497d-b028-d080504d7be4	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:01:53.752
5e3df5a8-2ffb-4d35-bb1b-1a1e68a8b643	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:02:08.527
2d0a8f89-af71-46a7-9d59-598d7cd63009	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:03:14.451
82cd6f98-4204-4e5e-ae3c-b4d2d9abf47d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:03:19.167
510bc90f-a7e5-4989-a150-31933f0787a2	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PROCESSING"}	{"status": "PENDING"}	\N	\N	\N	2026-06-04 13:03:21.546
a4217541-7177-4056-a639-f4ac65a7f347	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PENDING"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-04 13:03:23.931
fb819915-779f-4f1d-a82f-4f6b74e51a73	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	5470e985-5cf3-4179-bfea-2bc3ea6065c8	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-04 13:03:29.454
a6b6ad0e-a9ac-4cb0-acad-3f5415f0fc68	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SELLER_TIER	SellerTierDefinition	1c149d14-f5c4-43e4-93b5-f6f0c467c8da	\N	{"key": "SUPPER", "label": "Siêu VIP", "benefits": [], "holdDays": 3, "isActive": true, "badgeColor": "blue", "feePercent": 8, "description": "Nhà bán hàng kinh nghiệm", "displayOrder": 4, "minWithdrawal": 1000000, "upgradeMinOrders": 0, "upgradeMinRevenue": 0}	\N	\N	\N	2026-06-04 13:05:38.545
d3fad4b2-9f34-4f90-8b8b-215e5fddda71	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_CREATE	TutTrick	165f87a9-d530-48aa-beb9-c94995d60aae	\N	{"id": "165f87a9-d530-48aa-beb9-c94995d60aae", "name": "TUT MỞ KHÓA CHAT META", "slug": "tut-mo-khoa-chat-meta", "hasContentUrl": false}	\N	\N	\N	2026-06-05 16:14:51.063
81c2d478-c9cc-4830-b1bd-90c340cb2d98	e580851a-de0a-48bc-b0a0-922784cbbd2c	CONFIRM_ORDER_COMPLAINT	Complaint	57acac26-5f8e-4822-b755-d3db1017d7de	\N	{"status": "RESOLVED", "orderId": "e075b268-818d-41dc-9a2a-4f89177f1acf", "outcome": "seller_wins"}	\N	\N	\N	2026-06-06 14:21:56.251
0a5734b5-1c67-4182-9cae-1522cd225725	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	2729244b-ae96-4a23-9703-180bb075df0a	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq"}	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq", "tier": "Miễn phí", "price": 1000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "OTHER", "isFeatured": false, "successRate": 100, "totalOrders": 234, "displayOrder": 3, "requiresCccd": false, "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:21:02.815
d9d572c6-a925-4355-be00-3207ddc65ab5	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_ADJUST_BALANCE	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"balance": 60175}	{"amount": 500000000, "balance": 500060175}	\N	\N	\N	2026-06-05 16:27:13.773
778b92d0-d6d0-48e9-ba0d-4d6d4b5e614b	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:32:47.251
4b398e12-0443-4869-924e-b8b926d0307e	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	f978b336-1afc-4d93-ae65-0417bce2040d	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad"}	{"name": "TUT MỞ  KHÓA TIKTOK HẠN CHẾ", "slug": "addad", "tier": "Có phí", "price": 100000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "TIKTOK", "seoTitle": "Mở khóa hạn chế", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png", "isFeatured": false, "successRate": 100, "totalOrders": 242, "displayOrder": 1, "requiresCccd": false, "seoDescription": "2026", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:33:18.281
2da80557-f33d-4fc3-a5eb-89a7ebb44697	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:37:28.885
d307eacf-665d-4123-b8cf-8f9fcb12d05a	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:39:18.747
51363895-6dc7-4908-8cee-10aa5354c3c4	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:39:39.468
bc22c220-626b-4112-8c93-e2a0b84c8003	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:43:17.955
3304c9f5-0e04-4c86-8b99-6c6070c3bb02	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:43:23.502
6c38c379-4b1f-4602-9545-1880db5ab345	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	a5e5093b-abdc-4ec6-b888-72085054523a	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282"}	{"name": "TUT UNLOCK 282", "slug": "tut-unlock-282", "tier": "Có phí", "price": 99000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "FACEBOOK", "seoTitle": "TUT MỚI NHẤT", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png", "isFeatured": false, "successRate": 100, "totalOrders": 523, "displayOrder": 1, "requiresCccd": false, "seoDescription": "Tut này chỉ sử dụng cho mở khóa", "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-05 16:43:28.929
11372430-5a3b-472e-8b79-a254d3ff648f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 7, "registration_fee": 10000, "min_withdrawal_amount": 200000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-05 16:56:46.127
4fe8a214-5cfd-4586-b8b3-28dab0b3f9c8	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 7, "registration_fee": 10000, "min_withdrawal_amount": 200000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	\N	\N	\N	2026-06-05 16:59:05.016
74e7fbfd-b169-48a8-b32b-19f4a2d2a95f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 15}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 30}	\N	\N	\N	2026-06-05 16:59:26.813
684651ec-d25c-43d4-b22e-864343344355	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"sellerTier": "STANDARD"}	{"sellerTier": "VIP"}	\N	\N	\N	2026-06-05 17:00:04.967
448a45c9-f72f-4a6d-93fa-f533e8bfda2d	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_SETTINGS	SystemConfig	seller_settings	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 1, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 30}	{"slot_packages": [{"price": 50000, "slots": 5}, {"price": 80000, "slots": 7}, {"price": 120000, "slots": 10}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 10000, "withdrawal_fee_percent": 20}	\N	\N	\N	2026-06-05 17:00:56.933
063b791f-bd46-4150-ab82-b976a8fb1ac4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:05:35.536
80ebf986-7394-4d63-b717-d312b5cabbef	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:06:01.334
f235ca65-d0ef-4b04-a276-191d367fef99	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:06:14.874
957e7665-ec7a-4130-add9-f2862f68d9c4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:07:11.936
8c69e9f0-d64d-4618-8889-f106f32e2d4c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:19:55.069
b64f6c08-7549-4dc5-a7e1-a5e55969eb8a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:19:57.12
8f65c793-2c17-40c4-9ed2-e5326f60925a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:32:36.198
42d3e9d3-ad2b-4fb7-bad6-5fdf17776ee9	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:32:58.93
acefe409-a905-46c1-8ce1-d6f47aaf66bd	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:33:00.056
25771b2b-af24-4117-9557-d8a5149132a9	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:33:17.137
5efdaaf3-4f8d-4f5e-ae71-6cfccf284400	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:33:55.909
a1df9ea2-c0f0-42e9-b3fe-00212e29b05b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:34:12.969
7d9c5e3e-9951-4c07-b203-3ae00d35b0e7	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 17:35:44.07
da51d591-5006-4457-b104-f6ded9eb2607	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 18:06:54.321
7d0db511-5ad9-491c-9639-0995a3fb7a2a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-05 18:15:51.295
64ce77e7-61d7-4827-bf2c-ce1cb305b1ba	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	db70abee-03c1-4208-810b-81d28e28290f	\N	{"name": "TOOL MMO", "iconUrl": "https://svgl.app/library/wordpress.svg"}	\N	\N	\N	2026-06-05 18:27:18.861
e66714bc-65ec-4c42-ab5a-62063cc0522d	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_CREATE	MmoProduct	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	{"id": "7418205f-3c53-4823-ab68-d5c9a1b17f6a", "name": "TOOL JOIN BOX TELEGRAM", "slug": "tool-join-box-telegram"}	\N	\N	\N	2026-06-05 18:28:49.924
57b1f915-54ec-4395-a61e-ad7c68e4e4fb	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_STOCK_ADD	MmoProduct	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	{"count": 6}	\N	\N	\N	2026-06-05 18:29:08.409
6db4ebcd-e359-4fae-b04b-cba7de3f3936	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 02:32:37.234
02840e02-d493-4904-8ccc-477b10fcfe35	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 02:52:42.17
ccc9bfad-cbe7-4e0d-9959-13c201c6121f	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 02:53:24.46
ee446086-eb78-43af-88ae-951b39ec61b1	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:04:03.517
640ac050-1f78-4046-9e7f-072c863e15aa	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:04:10.79
ce9434db-addd-4bc1-a838-937987892147	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:05:05.428
611fe0f0-52b4-4ccd-b648-9cc02f96f73c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:17:21.627
c4fbda7d-e298-4de3-b1f4-4cf9b872e98d	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SELLER_TIER	SellerTierDefinition	0dd8c092-7df3-4f05-8ef1-29b690aef4a8	{"id": "0dd8c092-7df3-4f05-8ef1-29b690aef4a8", "key": "STANDARD", "label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "createdAt": "2026-06-04T03:26:44.294Z", "isBuiltIn": true, "updatedAt": "2026-06-05T17:00:56.914Z", "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 10000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	{"label": "Cấp 1", "benefits": ["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"], "holdDays": 2, "isActive": true, "badgeColor": "gray", "feePercent": 20, "description": "Hạng mặc định khi được duyệt", "displayOrder": 1, "minWithdrawal": 10000, "upgradeMinOrders": 0, "upgradeMinRevenue": 500000}	\N	\N	\N	2026-06-06 03:30:27.075
cae40fa5-0b07-4aff-8fdc-5cab7f5301b8	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 03:34:31
ae4009ba-7e3b-440c-aab8-c72f6bb934e3	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 07:41:29.516
6a4a37e8-c429-407c-b781-9502ed923d51	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_SET_DISCOUNT	User	3ad147cc-59c4-4623-ba0d-59011dcb6b93	{"discountPercent": 5}	{"discountPercent": 5}	\N	\N	\N	2026-06-06 14:51:12.596
5670b0d2-0eef-445c-a8e8-fd6f0a5851fb	e580851a-de0a-48bc-b0a0-922784cbbd2c	COURSE_CATEGORY_CREATE	CourseCategory	17e7f260-7123-4117-aaaa-84a0ff9ce385	\N	{"icon": "https://svgl.app/library/instagram-icon.svg", "name": "Intagram"}	\N	\N	\N	2026-06-06 14:58:23.694
e1c5a5db-0d21-4587-a6b0-6bf2d96339c6	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	1ab87278-fbbc-4951-a896-d56e99d6b778	{"name": "Icloud"}	\N	\N	\N	\N	2026-06-06 14:58:30.551
c8fe438e-4980-416a-b4ed-1d361d6f3e43	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	6ab091d4-57d5-4a54-b817-6b059ace99f5	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 14:58:34.359
405889db-2fe2-4b71-a8b3-f6069bf72624	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	4aa374ce-65d3-47c8-b4ef-3d6a1aa4c42d	{"name": "Intagram"}	\N	\N	\N	\N	2026-06-06 14:58:36.697
da027773-d8c3-4cc3-945d-d5c4803d13ab	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	385c063d-63ce-414e-9793-4d9e02267b61	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 14:58:45.925
17a20277-0a90-491c-a88d-b06e61f7aed8	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	385c063d-63ce-414e-9793-4d9e02267b61	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 15:07:52.679
1f5b0258-a686-4fac-b356-df6662d649f0	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	ad51f6c1-4a8d-4237-ba55-0958fe2041af	{"name": "Tiktok"}	\N	\N	\N	\N	2026-06-06 15:07:54.643
443f8928-2c02-420b-bdb6-fa41a4c5e99b	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	75261ce4-87c0-4447-8ee8-1f362ef473b5	\N	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:08:47.083
7d5a0f78-45ed-46fb-ae40-353374616f8b	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	e410cf1a-2a57-4179-a9da-67a5de2ed875	\N	{"name": "Instargram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-06 15:09:04.468
88344cd4-4e59-48fc-9f18-7b15c8dacce3	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	314a50b6-1fcd-45da-88ea-80fb6e31274c	\N	{"name": "Goole", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:20:54.354
54df2f71-538c-48c5-8f4e-267a774b2600	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	47ac02aa-34d0-4557-9e24-3333a89ee8fe	\N	{"name": "Youtube", "iconUrl": "https://svgl.app/library/youtube.svg"}	\N	\N	\N	2026-06-06 15:21:03.601
a4fb4369-c0f8-46f9-addf-7c7fbab95052	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	b2a4ef6e-4502-4435-8d9f-78c4d4b1abcc	\N	{"name": "Icloud", "iconUrl": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780759302415.png"}	\N	\N	\N	2026-06-06 15:21:45.264
2111f0d3-ae9f-4901-a6e7-ea4a2f61f423	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_RESOURCE_CATEGORY	ResourceCategory	5f939196-fba1-41fb-930e-a12293a336be	{"name": "Youtobe", "iconUrl": "https://svgl.app/library/youtube.svg"}	{"name": "Youtube", "iconUrl": "https://svgl.app/library/youtube.svg"}	\N	\N	\N	2026-06-06 15:22:05.618
c66d0087-d17a-4054-befc-1c791ca7701e	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	50707025-9e6c-4793-a0e2-f9ea7f37b4aa	{"name": "Tài Khoản X"}	\N	\N	\N	\N	2026-06-06 15:22:09.093
826b6207-a6f9-4834-b611-df796d02caed	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	e1655a16-b14e-46c9-940f-309c29ce0865	{"name": "Linkedln"}	\N	\N	\N	\N	2026-06-06 15:22:12.538
7fc5697f-3344-4672-8fbe-4c0833503d05	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	32cbfa2a-44ad-4f67-bcc4-49e08d77f35c	{"name": "Game"}	\N	\N	\N	\N	2026-06-06 15:22:15.404
0c60a4e3-cd31-4549-979b-e450cd919843	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	0fa33473-2d75-4a9a-9fc2-76271dfa8e50	\N	{"name": "Game", "iconUrl": "https://svgl.app/library/discord.svg"}	\N	\N	\N	2026-06-06 15:22:33.589
af83c738-879b-4f6d-89d2-afdb3bf5a820	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	71711987-ef35-49cf-b539-330e82e51292	{"name": "Facebook"}	\N	\N	\N	\N	2026-06-06 15:22:41.645
73f29e5d-b057-4be6-a268-ed85d13f51c6	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	419bc0f9-85c4-4ede-a5b0-cc52b7a6277f	{"name": "Tiktok"}	\N	\N	\N	\N	2026-06-06 15:22:43.69
5061894a-5a35-4a38-ab82-06bc33997c06	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	e43b3fe4-5e35-43e6-900b-4c7f012de236	{"name": "Intagram"}	\N	\N	\N	\N	2026-06-06 15:22:45.599
867a2e30-df07-442b-bf0d-ce47109754a2	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	1b8b64a6-180a-443f-8311-ef806002b028	{"name": "Telegram"}	\N	\N	\N	\N	2026-06-06 15:22:47.562
e2913e58-717e-4e85-817b-05dabb404580	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	10317a5d-cdd2-4739-bb58-9ba1412cabad	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 15:22:49.734
411b1ae4-b2f8-4df9-a1f4-73b91071b700	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	db70abee-03c1-4208-810b-81d28e28290f	{"name": "TOOL MMO"}	\N	\N	\N	\N	2026-06-06 15:22:51.65
b6f93f58-7293-455b-b34b-60934cc28f47	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	0fa33473-2d75-4a9a-9fc2-76271dfa8e50	{"name": "Game"}	\N	\N	\N	\N	2026-06-06 15:22:54.432
434ca49d-2657-487e-b4e0-c0c0ef123455	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	5f939196-fba1-41fb-930e-a12293a336be	{"name": "Youtube"}	\N	\N	\N	\N	2026-06-06 15:22:55.914
a38b2474-ce90-43d5-8c38-1aa73912c70d	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	ad1a3184-4a2b-4029-b3fa-8063074f2f77	\N	{"name": "Facebook", "iconUrl": "https://svgl.app/library/facebook-icon.svg"}	\N	\N	\N	2026-06-06 15:23:03.083
46bab789-b39f-4786-8732-dca72e51730c	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	d98e03fb-feec-4455-8aaa-893fbccaf9a7	\N	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:23:09.876
f8952b2d-e935-4c75-a646-965ce84db9cb	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	6ca6cdb1-0183-4dd6-a348-f264e2a33512	\N	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-06 15:23:18.589
431bafdc-ff3d-4ff8-a1ee-c30a113ecb32	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	8f4f7ad2-7f34-43b0-ae38-935e0758e82b	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:23:26.876
d5b44e59-ecac-4c02-8d13-2660d7e23871	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	78e57057-c212-4537-96d4-9d2394da5df4	\N	{"name": "Telegram", "iconUrl": "https://svgl.app/library/telegram.svg"}	\N	\N	\N	2026-06-06 15:23:53.422
97b2ac13-2c79-4fcd-9c2f-873fbb61f25f	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	2ea180f3-e393-46f7-b0cf-3586c758e1c7	\N	{"name": "Tool Telegram", "iconUrl": "https://svgl.app/library/wordpress.svg"}	\N	\N	\N	2026-06-06 15:24:04.9
91623365-988f-453f-b2fa-32825513ba61	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_TUT_TRICK_CATEGORY	TutTrickCategory	39588a82-d0c1-491a-ba88-652868b25fef	\N	{"name": "TikTok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:24:21.587
65dc10d4-c061-46dc-adb6-0311e39afdd0	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	52a61ea7-7047-48c5-ba8c-6ea1e893e0c1	\N	{"name": "Game", "iconUrl": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/resource-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780759657943.png"}	\N	\N	\N	2026-06-06 15:27:40.782
79c198e2-c3dd-4336-8ad8-26883ee618ca	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SERVICE_CATEGORY	ServiceCategory	314a50b6-1fcd-45da-88ea-80fb6e31274c	{"name": "Goole", "iconUrl": "https://svgl.app/library/google.svg"}	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:41:53.687
7b87be7e-8e87-4cf8-b819-e3df5344f44a	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_SERVICE_CATEGORY	ServiceCategory	75261ce4-87c0-4447-8ee8-1f362ef473b5	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:42:00.332
e5d7c609-9950-41ae-b413-24b112e1b3c3	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	314a50b6-1fcd-45da-88ea-80fb6e31274c	{"name": "Google"}	\N	\N	\N	\N	2026-06-06 15:42:04.872
93d3e129-ce86-43d3-95d5-2ca3d3b5ae6d	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_SERVICE_CATEGORY	ServiceCategory	47ac02aa-34d0-4557-9e24-3333a89ee8fe	{"name": "Youtube"}	\N	\N	\N	\N	2026-06-06 15:42:12.793
89104aac-1efd-46aa-9946-eae164c2ec18	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	836babc6-6e6a-456e-9dca-091c49c2ed62	\N	{"name": "Tiktok", "iconUrl": "https://svgl.app/library/tiktok-icon-light.svg"}	\N	\N	\N	2026-06-06 15:42:18.22
d16d2fce-1b64-4106-9d1c-11ca7ebb2140	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	ed072890-2b5e-440b-a248-19de9dd310c4	\N	{"name": "Instagram", "iconUrl": "https://svgl.app/library/instagram-icon.svg"}	\N	\N	\N	2026-06-06 15:42:28.781
b67fdffa-e8c0-4ad2-9aa6-244b5dde8399	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	d9fc7056-0e96-4184-8f52-10e494d01bff	\N	{"name": "Google", "iconUrl": "https://svgl.app/library/google.svg"}	\N	\N	\N	2026-06-06 15:42:36.55
4c626f33-6162-40ea-96d0-5ada83e9a14b	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_SERVICE_CATEGORY	ServiceCategory	bd783349-7a97-4dba-b969-d346a8fd0a3f	\N	{"name": "Icloud", "iconUrl": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780760568205.png"}	\N	\N	\N	2026-06-06 15:42:51.43
f1e8931f-5dd7-4793-b03b-257bfe89e5ba	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	b3d4bf87-fe9d-4dd6-bc29-fe9c49a50bd5	{"name": "Xóa Đánh Gía GG MAP", "slug": "xoa-danh-gia-gg-map", "price": "1500000"}	{"name": "Xóa Đánh Gía GG MAP", "slug": "xoa-danh-gia-gg-map", "price": 1500000, "rating": 5, "category": "Google", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780047000131.png", "isFeatured": true, "totalViews": 21422, "productList": [], "reviewCount": 124, "successRate": 100, "totalOrders": 240, "displayOrder": 1, "requiresCccd": true, "customerCount": 423, "processingTime": "1 NGÀY", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-06 15:43:18.829
c77166e3-05eb-46a9-9a50-17d1ebe2ec48	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	f2251457-dd7e-464f-8942-85447bf0fe95	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": "600000"}	{"name": "Đánh giá GG MAP VIP", "slug": "danh-gia-gg-map-vip", "price": 600000, "rating": 5, "category": "Google", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428783583.png", "isFeatured": false, "totalViews": 241, "description": "30 đánh giá gg map 5 sao ngay lập tực cho gg map khi thanh toán chỉ cần link gg map cho chúng tôi. ", "productList": [], "reviewCount": 86, "successRate": 100, "totalOrders": 45, "displayOrder": 2, "requiresCccd": false, "customerCount": 132, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": false}	\N	\N	\N	2026-06-06 15:43:25.501
f03abcac-42e3-4994-8cff-6706e9245eee	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	c8f14b74-fff9-46ee-b36b-93fa0e33287f	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": "2500000"}	{"name": "Mở khóa tài khoản instagram chính chủ 180 ngày", "slug": "mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay", "price": 2500000, "rating": 5, "category": "Instagram", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428759528.png", "isFeatured": false, "totalViews": 32123, "description": "Mở khóa những tài khoản instagram chính chủ", "productList": [], "reviewCount": 3242, "successRate": 100, "totalOrders": 2134, "displayOrder": 0, "requiresCccd": false, "customerCount": 4124, "processingTime": "1 ngày", "warrantyOptions": [], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-06 15:43:48.339
1b09be8a-3131-4242-923e-b2d159cec0eb	e580851a-de0a-48bc-b0a0-922784cbbd2c	CREATE_RESOURCE_CATEGORY	ResourceCategory	d58b451d-8402-4f2d-987d-9f007ef03fa8	\N	{"name": "Intagram", "iconUrl": null}	\N	\N	\N	2026-06-06 15:46:09.245
524fded0-8b2d-402e-ad34-93511e24bef8	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	7a270438-cff5-4f5c-93a7-30d1e771bf9b	{"name": "Tài khoản intagram cổ trust 2021", "slug": "tai-khoan-intagram-co-trust-2021"}	{"name": "Tài khoản intagram cổ trust 2021", "slug": "tai-khoan-intagram-co-trust-2021", "price": 259000, "category": "intagram", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780244746727.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Instagram", "requiresAccountType": false}	\N	\N	\N	2026-06-06 15:46:25.464
eab7b866-b59c-4ddd-9365-4577eee1e6ef	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	7418205f-3c53-4823-ab68-d5c9a1b17f6a	{"name": "TOOL JOIN BOX TELEGRAM", "slug": "tool-join-box-telegram"}	{"name": "TOOL JOIN BOX TELEGRAM", "slug": "tool-join-box-telegram", "price": 500000, "category": "tool telegram", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780684116099.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Tool Telegram", "requiresAccountType": false}	\N	\N	\N	2026-06-06 15:46:40.167
bb0e6cb8-53a6-475f-81a3-adcc3dd6f43c	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 16:13:44.675
25628046-eb88-4667-b525-081c891f4da6	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PAGE_PERMISSIONS	PagePermission	USER	\N	{"permissions": {"don-hang": true, "nap-tien": true, "tro-chuyen": true, "lich-su-giao-dich": true, "thong-tin-ca-nhan": true}}	\N	\N	\N	2026-06-06 16:13:55.989
a69f5dc4-5560-4e20-9fb5-188c4ebfb7e6	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT_UPDATE	MmoProduct	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	{"name": "VIA", "slug": "via"}	{"name": "VIA Trust Us", "slug": "via", "price": 99000, "category": "Via 1m1", "isActive": true, "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779642138078.png", "isFeatured": false, "displayOrder": 1, "requiresCccd": false, "categoryGroup": "Facebook", "requiresAccountType": false}	\N	\N	\N	2026-06-06 16:16:02.441
f53174b8-92f5-4ffa-a60d-b1abe16e68fc	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_UPDATE	TutTrick	2729244b-ae96-4a23-9703-180bb075df0a	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq"}	{"name": "TUT Mở khóa tài khoản Faq", "slug": "tut-mo-khoa-tai-khoan-faq", "tier": "Miễn phí", "price": 1000, "rating": 5, "category": "Facebook", "isActive": true, "platform": "OTHER", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780762576912.png", "isFeatured": false, "successRate": 100, "totalOrders": 234, "displayOrder": 3, "requiresCccd": false, "contentUrlUpdated": true, "requiresAccountType": false}	\N	\N	\N	2026-06-06 16:16:22.592
0840be45-8346-4638-b097-b6ab8016e9f1	e580851a-de0a-48bc-b0a0-922784cbbd2c	DELETE_RESOURCE_CATEGORY	ResourceCategory	d58b451d-8402-4f2d-987d-9f007ef03fa8	{"name": "Intagram"}	\N	\N	\N	\N	2026-06-06 16:16:42.524
09e6fb8f-23b3-43a0-b95d-ea684d2f1641	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_ADJUST_BALANCE	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"balance": 0}	{"amount": 500000, "balance": 500000}	\N	\N	\N	2026-06-06 16:22:46.601
4256285b-4c2b-4d1e-96a0-c43d34bc6333	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	b02bd798-3e00-4b18-b2ec-5c6f2b99272a	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:33.81
668a1d3b-87c0-47b3-be00-064db7533568	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	fb17d681-5f52-4792-9c2e-c5f8c77f12d9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:44.955
539b259a-e8cd-4dc5-b9c2-4934ad15953b	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	0413bfac-9275-4f8b-a143-2e30066e9bc9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:54.023
513839e6-4f61-4c81-b881-02230bb4357a	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	fa22247f-ec6f-435b-b070-57419639397d	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:23:55.584
a0f97c0b-25a3-45f3-8400-7affa67a1595	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	b34e9db7-b2de-41a5-8ecb-a0301ead185f	{"status": "FROZEN"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:24:51.625
dd847648-1f77-441d-ab0c-252c8e086e50	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	{"status": "FROZEN"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 16:25:00.797
f2e78f25-4cc5-4bc1-8bce-d81f9489b3f4	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 17:55:30.408
41d8d02f-ee10-4c39-a25d-892d0fa7f157	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "DONE"}	{"status": "PROCESSING"}	\N	\N	\N	2026-06-06 17:57:13.148
314ea32b-e360-4e47-adec-f66369e4eda1	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN_UPDATE_ORDER_STATUS	Order	9dcf0cbf-ea8f-4e80-8349-95da399773a9	{"status": "PROCESSING"}	{"status": "DONE"}	\N	\N	\N	2026-06-06 18:05:33.514
0d03eaaa-4369-4fb4-a8c4-33aa7ddd3b05	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-06 18:37:27.357
08bae780-eb9c-460f-9263-e04b88df6e7b	e580851a-de0a-48bc-b0a0-922784cbbd2c	UPDATE_PUBLIC_PAGE_CONFIGS	PublicPageConfig	\N	\N	{"count": 10}	\N	\N	\N	2026-06-08 03:04:35.137
1d716d5a-4288-40ba-a797-d456f76ac5aa	e580851a-de0a-48bc-b0a0-922784cbbd2c	SERVICE_UPDATE	Service	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": "100000"}	{"name": "Mở Khóa Icloud", "slug": "unlock", "price": 100000, "rating": 5, "category": "Icloud", "isActive": true, "platform": "ICLOUD", "thumbnail": "https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png", "isFeatured": true, "totalViews": 13213, "description": "DỊCH VỤ CHẤT LƯỢNG", "productList": [{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}], "reviewCount": 124, "successRate": 100, "totalOrders": 12, "displayOrder": 1, "requiresCccd": false, "customerCount": 32, "processingTime": "1-3 ngày", "warrantyOptions": [{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}], "platformVariants": [], "requiresAccountType": true}	\N	\N	\N	2026-06-08 08:55:01.625
100eb505-7fdb-4de8-af71-d969b491b1f2	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	55d1694a-443e-4f08-8875-8dadff9cbf62	{"permissions": ["products:read"]}	{"permissions": []}	\N	\N	\N	2026-06-20 11:01:13.438
a20a5258-64f2-40fc-9718-7a22246e1aaf	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_STAFF_PERMISSIONS	User	e580851a-de0a-48bc-b0a0-922784cbbd2c	{"permissions": ["dashboard:read", "products:read", "products:create"]}	{"permissions": ["dashboard:read", "products:read", "products:create", "chat:read", "chat:reply", "sellers:read", "sellers:approve", "sellers:update", "sellers:delete"]}	\N	\N	\N	2026-06-20 11:01:42.136
485436b4-0d2e-420c-b1a2-4494d74d3271	e580851a-de0a-48bc-b0a0-922784cbbd2c	TUT_TRICK_CREATE	TutTrick	a0db9bb3-dc95-443f-acd6-2160c90576de	\N	{"id": "a0db9bb3-dc95-443f-acd6-2160c90576de", "name": "TUT 1", "slug": "tut-1", "hasContentUrl": false}	\N	\N	\N	2026-06-20 18:06:02.209
06a27cf3-217c-4be7-8f63-30d916744694	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_RESOURCE_CATEGORY	ResourceCategory	6ca6cdb1-0183-4dd6-a348-f264e2a33512	{"showInKhoTaiNguyen": false, "showInTaiNguyenMmo": true}	{"showInKhoTaiNguyen": true, "showInTaiNguyenMmo": true}	\N	\N	\N	2026-06-21 11:52:46.179
64bb43b0-a03e-4aaf-81a3-e19fe27ad218	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	b68b9b6d-58d5-44fa-aa71-c8aa05611d52	\N	{"status": "RESOLVED", "orderId": "a953723d-d10d-4601-9536-08f2cfad4cf4", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 17:25:21.3
a1b294cc-1ea6-4b8a-84fa-917e61a0c0c0	15bbcf73-c01d-4730-85d7-a1cca3730c83	CONFIRM_ORDER_COMPLAINT	Complaint	bef57476-e8bb-4a38-a409-31d93b9f2984	\N	{"status": "RESOLVED", "orderId": "0594a66c-6226-49e4-a615-c57f5c11b93f", "outcome": "seller_wins"}	\N	\N	\N	2026-06-21 19:03:33.199
de79bfbf-710a-4300-adce-4adc8a6eb64c	15bbcf73-c01d-4730-85d7-a1cca3730c83	MMO_PRODUCT_CREATE	MmoProduct	d57c5055-e229-4d0c-a4fa-27bbbaa60a74	\N	{"id": "d57c5055-e229-4d0c-a4fa-27bbbaa60a74", "name": "aaa", "slug": "aaa"}	\N	\N	\N	2026-06-22 06:22:27.08
d7942dd8-7dc4-470e-b950-08258d828cea	15bbcf73-c01d-4730-85d7-a1cca3730c83	UPDATE_DEPOSIT_BANK_CONFIG	SystemConfig	deposit_bank_config	\N	{"bank_bin": "970422", "bank_name": "MB Bank", "account_holder": "CHU QUANG DOANH", "account_number": "1536238386"}	\N	\N	\N	2026-06-22 15:31:10.767
\.


--
-- Data for Name: bank_change_requests; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."bank_change_requests" ("id", "seller_id", "bank_name_enc", "bank_account_number_enc", "bank_account_holder_enc", "status", "reject_reason", "reviewed_by_user_id", "reviewed_at", "created_at") FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."chat_messages" ("id", "room_id", "sender_id", "sender_name", "sender_label", "content", "created_at") FROM stdin;
c55b524a-7459-4816-9d58-3b4310c2b8f3	43a125a9-fa00-4d9e-aa46-0a56f038acd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Xin chào	2026-05-26 15:52:55.232
528fe7bc-840c-43df-ae3c-890b993876c0	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	Mình cần xử lý đơn hàng	2026-05-26 16:01:14.341
9fc1b925-3c44-484d-a725-c54826923b39	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	ama	2026-05-26 16:02:00.672
fea386d1-da86-4a86-8a3b-e300288133a4	43a125a9-fa00-4d9e-aa46-0a56f038acd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Hỗ trợ xử lý đơn hàng	2026-05-26 16:33:28.119
a8ba9cbd-3c42-4eb6-8577-4eab4aa03b59	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	đấ	2026-05-26 16:34:10.353
92ca08d2-73a5-40fa-a656-cd1b8d2dc164	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Hỗ trợ  xử lý  đơn hàng khách hàng công khai !	2026-05-26 16:34:54.473
8adbe392-5ad7-47b3-9d90-13c755b7165c	3fec273c-4e76-43fe-9160-375ea69bad9d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	Xử  lý ngay	2026-05-26 16:35:59.888
16fa778f-8411-4be1-88c6-3d4b3a601967	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	a	2026-05-26 16:42:20.494
52022327-2505-4ea8-a928-cd7385bf514d	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	a	2026-05-26 16:42:32.059
70c009bd-cb3f-4bf4-80db-7c4e73a7061c	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	a	2026-05-26 16:42:40.662
e9584a07-daf6-42dc-9186-8dde4d408fad	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Của bạn gặp vaansd dề gì	2026-05-26 16:46:32.588
0b0e212e-fe14-4599-a1bf-c10d9513116f	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	chúng tôi sẽ hỗ trợ xử lý ngay cho bạn	2026-05-26 16:46:40.816
db829c24-dc42-4021-91f5-6048656015fb	137076b5-d499-4115-b753-1699ba023dc9	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	addad	2026-05-26 17:41:16.203
dc24101f-7454-4b0b-be7c-aa5e719d27e7	f1700988-9793-4b43-b824-f1edc99a108a	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	aa	2026-05-26 18:14:53.647
13402385-6572-4541-b5f9-ab0a4ee04422	f1700988-9793-4b43-b824-f1edc99a108a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	hello	2026-05-26 18:15:39.215
c45449e0-190a-4b49-8d2e-77e72dd67145	55f9caf9-090f-4d97-b026-4d23f75ad69d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	Đơn hàng của  bạn đã được xác nhận thành công không thể hoàn  tiền	2026-05-26 20:22:20.822
c6481b0a-90fa-410c-bbbb-6e6d91cb1476	406c1105-43bd-4e65-a0b2-82940747ce7f	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	XỬ LÝ  NGAY	2026-05-27 07:35:24.185
8b658916-c9dd-4b01-9c2c-debeb2db5665	406c1105-43bd-4e65-a0b2-82940747ce7f	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Chuquangdoanh	Nhà bán hàng	1	2026-05-27 07:35:34.599
d7f5aa30-8159-49eb-bcfd-afd1d6bfff39	406c1105-43bd-4e65-a0b2-82940747ce7f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Chuquangdoanh	Người mua	2	2026-05-27 07:35:45.759
10374377-402a-4f58-9c3e-2328b46f3db5	fea640ee-c62c-4ffd-baba-c06874046a7d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	aaaa	2026-06-20 10:42:00.989
216dde54-a24e-470b-99ec-153083206a9f	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	aaa	2026-06-20 10:42:18.024
582f2344-e2f5-4f1e-8406-3be60ff0f9a2	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	xác nhận nhé	2026-06-20 11:20:57.51
0c17446d-e0d2-4f42-a6f3-842691d0e2f4	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	aa	2026-06-20 13:37:10.025
0a1406af-18b4-4e07-a1d0-5285de43be2e	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	aaa	2026-06-20 13:37:18.656
955d6bff-161d-4ba5-bbc7-7ed357a40472	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	aa	2026-06-20 13:37:20.803
22187be6-2792-4722-b023-5a72baee1267	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ADD	2026-06-20 17:47:46.365
7cebad74-6fda-4c30-9d10-b9a437db013f	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ĐÂ	2026-06-20 17:47:47.898
05821927-1019-4583-8736-2ebc11d3dd45	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AD	2026-06-20 17:47:49.157
14f5a326-23a4-4031-b7f5-a50e3345edaa	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AD	2026-06-20 17:47:50.49
aab5aa7b-da5c-4c97-a2ab-2ee2314b7498	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AAAA	2026-06-20 17:47:52.002
c2228f3b-9dc5-4a60-8c90-0c5df8f33055	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AAA	2026-06-20 17:47:53.354
e2b31d81-ee61-4773-9968-7c9102e20f44	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AAA	2026-06-20 17:47:54.904
787089b5-a1ee-47ad-b793-f42308d55cc1	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AA	2026-06-20 17:47:56.318
1322dbb6-8ac9-445b-a912-fbade5bed620	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AAA	2026-06-20 17:47:57.348
cbd07630-e09e-488b-ad71-7d47870ccfcd	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AAA	2026-06-20 17:47:58.715
bd725242-5aa0-4ea9-8e6e-3354bff5be2d	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AAA	2026-06-20 17:47:59.961
acc9c291-151e-4346-b22e-02b68ad99077	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AA	2026-06-20 17:48:01.687
11a89096-0c00-4034-ab57-e7efd6bb1798	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AAA	2026-06-20 17:48:03.294
0c0e4200-60d7-4651-8039-7b1cbfc4439d	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AA	2026-06-20 17:48:05.332
940cfd9c-90f0-4b8e-8b9e-206f27fa8423	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	aaaa	2026-06-21 14:01:13.134
d2e27910-4b58-4101-9501-4d8ccf83c97f	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	da	2026-06-21 14:01:25.815
dc9872ed-83c6-4d9c-82d8-f57f933eab33	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	addad	2026-06-21 14:01:30.182
97394e79-ea28-426f-b897-180bc058562a	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	adada	2026-06-21 14:01:31.874
3cacc164-4512-4d19-8cc6-539738af701e	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	dâd	2026-06-21 14:01:33.303
8526b928-66a5-4e07-a551-5915ab940fa6	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	adadad	2026-06-21 14:01:34.676
961d1478-e439-4ced-af53-7ae26f3cf4a6	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	adadad	2026-06-21 14:01:36.133
3ab0da25-6c4a-4a29-98d7-c2954d738656	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	ad	2026-06-21 14:02:31.387
f5356f3e-681a-4e66-8063-835674ffef94	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ad	2026-06-21 14:02:36.648
8cffc37a-b777-4924-9882-751f7beac571	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	â	2026-06-21 14:09:23.672
f700a47e-4ea8-4bc3-87f4-3b15d246785f	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	tôi đã xử lý rồi ?	2026-06-21 14:09:28.322
fe3d7f81-3613-4dfb-9483-ff04497b71b3	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	addadad	2026-06-21 14:09:33.601
3f2b7d72-61b9-4070-b25f-be4464507ffe	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	dâd	2026-06-21 14:09:34.695
92c7fcba-32cc-44a6-8e03-d6d8c09a104c	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adada	2026-06-21 14:09:36.131
0f9c5ba0-4e79-4a10-b87a-3af1bad23bca	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adadad	2026-06-21 14:09:37.334
4e6f26f1-9c8c-447f-a1c7-e2c1be05afee	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adadad	2026-06-21 14:09:38.585
91c3e75a-adad-47de-88e8-01b726a84673	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adadad	2026-06-21 14:09:39.902
4e9f456a-de69-4ce2-b961-d9fc6256860c	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adadad	2026-06-21 14:09:41.136
47339546-1461-4e2a-8c21-098029cd55cb	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	dádasd	2026-06-21 14:09:42.732
617e855e-301b-4f37-b070-baf82e0662ab	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	dấdasda	2026-06-21 14:09:44.195
de2f9e30-12a9-442a-a9b7-5a678bd2eca6	bacc989b-50c2-49c4-992e-f00834b22279	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	dddd	2026-06-21 16:53:07.899
6faffe2f-0526-40ac-a868-47d15a1dee34	bacc989b-50c2-49c4-992e-f00834b22279	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adad	2026-06-21 16:53:11.524
a65b0cc7-9175-41d8-bd95-d0e447e31608	bacc989b-50c2-49c4-992e-f00834b22279	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adad	2026-06-21 16:53:14.033
12028445-ee0a-49d5-93ec-0344be9b0f17	bacc989b-50c2-49c4-992e-f00834b22279	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	ad	2026-06-21 16:53:24.934
c77a8dd0-0c6a-4058-8833-715e54a28a37	bacc989b-50c2-49c4-992e-f00834b22279	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	đa	2026-06-21 16:53:49.492
2d0b8964-6408-475f-aae9-9f3576c74311	bacc989b-50c2-49c4-992e-f00834b22279	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adad	2026-06-21 16:53:54.344
4b2630a6-ba40-4da1-a7d5-1de3e083fa73	02ac8a5f-5b41-42cb-a847-8295342f2ba1	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	ad	2026-06-21 16:57:42.815
37e7b3b6-8b9f-461a-b7ce-0b989f089ea8	02ac8a5f-5b41-42cb-a847-8295342f2ba1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	add	2026-06-21 16:57:49.039
9bb02638-bbce-4f5f-91f0-465b6a989c59	02ac8a5f-5b41-42cb-a847-8295342f2ba1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	add	2026-06-21 16:57:51.508
6ad0ab66-a51d-48d6-92a1-7c5e9197b540	02ac8a5f-5b41-42cb-a847-8295342f2ba1	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	ad	2026-06-21 16:58:04.022
8a6a794b-5d02-4e97-905c-35b5e8e2170e	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	add	2026-06-21 17:13:55.206
58695ce3-1b2d-422f-9d92-2e03c197a80d	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	addad	2026-06-21 17:13:57.33
add8a5f3-4a4b-48ce-8326-e1396c5693cb	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	adadad	2026-06-21 17:13:58.913
285cef71-6873-44bb-96ee-e9ecaed117a7	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	adada	2026-06-21 17:14:00.733
972561d9-2a8d-4960-b773-4f2c507c63eb	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	addd	2026-06-21 17:14:31.007
5ba3f8a5-aa1b-44a0-9750-e471eedff1ab	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Admin	add	2026-06-21 17:14:48.669
f67ea364-c6b7-4c3e-adc7-fe566d1875cf	497c6343-a2c2-4ea8-9ab4-5e04483ccf08	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	dâda	2026-06-21 17:24:18.038
74a32c44-77a8-4f78-aa02-30c9c408feb3	497c6343-a2c2-4ea8-9ab4-5e04483ccf08	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adadad	2026-06-21 17:24:26.483
00d0f9a7-029d-476b-a1e8-7679cb7749ea	40b905f9-02fc-4e56-81d5-c829a3fb744a	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	dâ	2026-06-21 17:28:06.853
0813f63e-e84e-4cbc-881c-5610e17dd45a	40b905f9-02fc-4e56-81d5-c829a3fb744a	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	đ	2026-06-21 17:28:09.004
167db0b5-3b6c-4c45-8b51-fb56445e1721	40b905f9-02fc-4e56-81d5-c829a3fb744a	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ad	2026-06-21 17:28:10.131
e375a120-f571-4fd5-bbfd-ea91ff52e7ed	40b905f9-02fc-4e56-81d5-c829a3fb744a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	aaaa	2026-06-21 17:28:21.512
154f485c-928b-415d-a7c3-8637861c9162	40b905f9-02fc-4e56-81d5-c829a3fb744a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ddd	2026-06-21 17:28:23.214
e8d8a24e-beea-49f5-97ac-acc4d52c9e53	74b510c5-3795-4a2e-b99f-15f3f78fcc2c	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	d	2026-06-21 17:29:27.71
c954ea77-d088-468a-ac27-f7424081e78f	74b510c5-3795-4a2e-b99f-15f3f78fcc2c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	addd	2026-06-21 17:30:47.73
c6ee62c8-a14c-4167-9f0f-27386d55ccb7	ad6d7edf-a497-4c1b-ab0d-3e992eea4b95	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	a	2026-06-21 17:32:15.468
78b50544-6131-4831-ac3e-6c7e2ab74fd3	74b510c5-3795-4a2e-b99f-15f3f78fcc2c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	a	2026-06-21 17:32:36.514
cfe1d5e3-67dd-4f67-9fca-4ac2d09da0cd	ad6d7edf-a497-4c1b-ab0d-3e992eea4b95	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	addd	2026-06-21 17:35:04.202
14d05e57-ef63-4216-b6bd-61e5575073a7	a01d3797-414b-4c34-b29c-99bb2caeaa09	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	addad	2026-06-21 17:40:36.333
7f48cc05-3eab-4e38-82f4-b5f3fe91b919	a9e03d21-cb5d-4886-aa47-90d13c8dc7ce	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	add	2026-06-21 17:52:29.157
307c35c9-3945-4ed7-ad17-c53fb2753520	a9e03d21-cb5d-4886-aa47-90d13c8dc7ce	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adad	2026-06-21 17:52:37.626
656d6859-42d6-4f1e-b4e2-eb9d0609af8a	701b9b4a-1cf1-4390-a04a-6af42a59f209	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	adad	2026-06-21 17:58:21.153
02d6e0f1-9864-4af2-bfbf-3f9f52f3fb06	701b9b4a-1cf1-4390-a04a-6af42a59f209	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	d	2026-06-21 17:58:31.402
b7ba14f4-e6df-4d11-ba51-50b153e655d1	afef669d-4efe-4937-a7f1-baf6943591b2	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ada	2026-06-21 18:00:27.515
d5f64a55-7d22-4cec-8323-0a40329dcb87	afef669d-4efe-4937-a7f1-baf6943591b2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	a	2026-06-21 18:00:36.226
5fd4294c-f833-4978-9aa2-12ee2b4b1cd2	23ca94a5-0bd4-4002-9828-896847e9c60a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ada	2026-06-21 18:04:04.307
29b57c44-503f-42ae-beb5-7401ecae8b09	b640a972-9268-48fe-be06-b6feedbdfb5e	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ada	2026-06-21 18:05:07.237
864a5300-8050-43dd-a55c-4c6f161d7b38	b640a972-9268-48fe-be06-b6feedbdfb5e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ad	2026-06-21 18:05:13.955
e19a7cbf-f552-44cf-9005-6d82e64eca4c	f37cbb26-cfff-4689-9912-5b3f79b15d48	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ada	2026-06-21 18:13:15.731
20f0d933-4e65-40f7-851c-1223085f01e5	f37cbb26-cfff-4689-9912-5b3f79b15d48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ad	2026-06-21 18:13:24.305
df0d8473-a125-44e7-aa00-55bda5e1dd72	f37cbb26-cfff-4689-9912-5b3f79b15d48	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	tiếp tục	2026-06-21 18:14:07.096
bce49c42-2a12-4634-ab9d-4ccb4d3dddc0	f37cbb26-cfff-4689-9912-5b3f79b15d48	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	addd	2026-06-21 18:14:15.988
1bed0d6e-b1c2-4cdd-8b57-2f2f28433031	f37cbb26-cfff-4689-9912-5b3f79b15d48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	đâ	2026-06-21 18:14:19.967
1bf4cfc2-6ff2-4c4c-8a97-0dbb994eeb7a	f37cbb26-cfff-4689-9912-5b3f79b15d48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ad	2026-06-21 18:14:25.276
1d7a0e72-4e68-4490-a540-7f1dda630f77	f37cbb26-cfff-4689-9912-5b3f79b15d48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ad	2026-06-21 18:24:03.444
be7798b7-988b-4662-8b80-31a109068d80	f37cbb26-cfff-4689-9912-5b3f79b15d48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	add	2026-06-21 18:24:07.464
48ee18be-e1d0-4bde-936e-83ee7a56680e	7ded4c1c-4be6-403d-986e-0d6d4899155d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	adada	2026-06-21 18:25:42.627
5eac0b95-8112-4da9-800f-d36f346974ad	7ded4c1c-4be6-403d-986e-0d6d4899155d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ADD	2026-06-21 18:26:55.875
ccb7feb0-aed4-43d6-ad9f-21127b73f5a8	7ded4c1c-4be6-403d-986e-0d6d4899155d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ADDD	2026-06-21 18:27:17.862
e38154af-c081-4749-a1a9-cd9353c49ab0	7ded4c1c-4be6-403d-986e-0d6d4899155d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ADAD	2026-06-21 18:28:05.082
703bb410-bf09-4e17-9191-e022fe3d1243	7ded4c1c-4be6-403d-986e-0d6d4899155d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	AD	2026-06-21 18:28:10.071
2be3bf98-4632-4987-beb3-aa09c0577514	7ded4c1c-4be6-403d-986e-0d6d4899155d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	add	2026-06-21 18:34:59.059
873c55f4-8346-4ead-8813-a52ef1ccbb72	7ded4c1c-4be6-403d-986e-0d6d4899155d	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	add	2026-06-21 18:35:19.489
8cdca74b-4eac-46e5-b818-4efb13063d55	7ded4c1c-4be6-403d-986e-0d6d4899155d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adad	2026-06-21 18:35:45.821
4beeff0f-4a04-402d-b9a6-ace5b9960b14	9fec916e-7db2-46ae-9bd8-1d4663196f32	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ada	2026-06-21 18:38:16.231
d84b5202-5c34-436d-8eb5-3646f0378a70	9fec916e-7db2-46ae-9bd8-1d4663196f32	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ad	2026-06-21 18:39:04.589
330afcc2-6e05-44b0-8c72-be8ae939f471	bb215514-20c0-4fb2-b694-7d738fe6a846	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	add	2026-06-21 19:12:09.298
9e2d2e65-9f35-4386-94e4-022fb76ab05a	bb215514-20c0-4fb2-b694-7d738fe6a846	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adad	2026-06-21 19:12:12.414
a7f75e76-f2b7-4c61-9b73-96e2068e2dfe	58844a52-0ff1-4762-aaf7-77c016baadf6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ADDD	2026-06-21 19:20:34.639
e5007098-aae8-453a-9999-021a413d69ec	58844a52-0ff1-4762-aaf7-77c016baadf6	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ADA	2026-06-21 19:20:44.321
b53117d2-dea6-4124-bdd3-27addf654f6f	58844a52-0ff1-4762-aaf7-77c016baadf6	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ADAD	2026-06-21 19:20:45.539
bec9fc5a-f1f3-4f86-b121-39e19434455b	58844a52-0ff1-4762-aaf7-77c016baadf6	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	ADAD	2026-06-21 19:20:46.527
e860941e-690f-472c-bb9d-f677903598d3	bb215514-20c0-4fb2-b694-7d738fe6a846	15bbcf73-c01d-4730-85d7-a1cca3730c83	Chu Quang Doanh	Admin	ADAD	2026-06-21 19:26:48.257
3d163026-634e-4927-8110-29685b71a0f7	bb215514-20c0-4fb2-b694-7d738fe6a846	e580851a-de0a-48bc-b0a0-922784cbbd2c	ADMIN CHU QUANG DOANH	Người mua	adad	2026-06-21 19:34:39.391
72d6b613-9112-4787-a381-37db726a95c2	bb215514-20c0-4fb2-b694-7d738fe6a846	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	adad	2026-06-21 19:34:47.527
deee55a0-60c0-4269-811f-251c93d869b3	54909e8c-4427-4e4e-8cdb-09ebca5e1c48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Seller #3AD147CC	Nhà bán hàng	ad	2026-06-21 19:37:21.194
\.


--
-- Data for Name: chat_participants; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."chat_participants" ("id", "room_id", "user_id", "label", "joined_at") FROM stdin;
0af5a9dc-2949-4557-b2f8-e5fb66e84655	43a125a9-fa00-4d9e-aa46-0a56f038acd8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 15:52:51.067
a155d0e8-6693-4206-9663-be16a94ef4b9	43a125a9-fa00-4d9e-aa46-0a56f038acd8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 15:52:51.067
2c20d0c4-d9bc-4db4-92a6-ea72bbaea1d2	3fec273c-4e76-43fe-9160-375ea69bad9d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 16:34:43.855
4a06bb0f-b9f6-4c99-80f9-4d48c95d6ae8	3fec273c-4e76-43fe-9160-375ea69bad9d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 16:34:43.855
17621fc5-c541-4a61-8e48-112d8af5d3bd	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 16:42:16.156
ea428b82-6bbd-4b31-b4d4-8b2d5b58478e	b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 16:42:16.156
42b4bc99-f820-435d-94bc-07b8a45dc80e	137076b5-d499-4115-b753-1699ba023dc9	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 17:41:06.387
d1186846-50eb-46a8-9874-6195b776253f	137076b5-d499-4115-b753-1699ba023dc9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 17:41:06.387
67a63d7d-eac2-41d2-9a21-f2986e394cd0	f1700988-9793-4b43-b824-f1edc99a108a	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 18:14:18.128
30fa5c0c-d551-4686-9148-68a4a01bb35b	f1700988-9793-4b43-b824-f1edc99a108a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 18:14:18.128
b6d2dbbe-55f7-44c3-b960-8896fe20db57	dad82d96-9d0f-4742-a384-b070659416ad	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 20:14:21.278
d4692abe-7bc1-4447-83a5-5e90176fe7dd	dad82d96-9d0f-4742-a384-b070659416ad	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 20:14:21.278
6b3d419b-9de8-4a29-a87b-c24c545c735b	55f9caf9-090f-4d97-b026-4d23f75ad69d	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 20:21:50.027
01f7d461-c930-4f9f-b946-e661f8fb2dae	55f9caf9-090f-4d97-b026-4d23f75ad69d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 20:21:50.027
fe413b31-f2fe-4046-8e27-293bb8172c4b	2b6ee792-3409-4c34-b675-5c4ea1dfd94c	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-26 20:24:40.094
92c3ae04-d465-428f-bf71-752b21ea6be5	2b6ee792-3409-4c34-b675-5c4ea1dfd94c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-26 20:24:40.094
005dc447-aaa4-40f1-9515-5a826dd29886	406c1105-43bd-4e65-a0b2-82940747ce7f	15bbcf73-c01d-4730-85d7-a1cca3730c83	Admin	2026-05-27 07:35:06.528
b1adbe48-5f44-4aa0-a8fc-bbc18731f204	406c1105-43bd-4e65-a0b2-82940747ce7f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Người mua	2026-05-27 07:35:06.528
aabfb05e-f36d-4b7a-acdc-2d5c75a0944c	406c1105-43bd-4e65-a0b2-82940747ce7f	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Nhà bán hàng	2026-05-27 07:35:06.528
0d707da8-aef2-459a-9c38-ba335bfeaef9	fea640ee-c62c-4ffd-baba-c06874046a7d	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-20 10:41:45.624
0eb56d3d-9c36-4e1b-b7e9-964a6e7e9c08	fea640ee-c62c-4ffd-baba-c06874046a7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-20 10:41:45.624
4d683094-a69a-41b9-b1c9-48858216b56e	b47ab722-785f-42a5-9b49-e3de1c516e47	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 13:59:17.883
6643bfd7-5e6d-469c-a7a8-d25378e01430	b47ab722-785f-42a5-9b49-e3de1c516e47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 13:59:17.883
bbb23d16-6c80-45ed-8deb-552256d46224	bacc989b-50c2-49c4-992e-f00834b22279	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 16:52:52.872
6fe7172c-8968-4ba3-9c92-004400a81fc1	bacc989b-50c2-49c4-992e-f00834b22279	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 16:52:52.872
4922173c-a74f-40b7-949d-083dd72491ca	02ac8a5f-5b41-42cb-a847-8295342f2ba1	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 16:57:22.137
b1965fd8-cb04-4aa4-8444-ed888b68f646	02ac8a5f-5b41-42cb-a847-8295342f2ba1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 16:57:22.137
b96ba1a3-2614-4072-9ff5-080e962eec69	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:13:43.136
fc881feb-4936-4f4d-b3d0-2aff36d043c5	bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:13:43.136
8d25b970-5090-4cfb-b9a7-bfd2216239ee	497c6343-a2c2-4ea8-9ab4-5e04483ccf08	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:24:09.69
abd2e3cf-e93c-4dde-aa3b-0d938c725b1a	497c6343-a2c2-4ea8-9ab4-5e04483ccf08	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:24:09.69
2e20ff34-5cb5-4e3e-9b47-45ea9e95e680	40b905f9-02fc-4e56-81d5-c829a3fb744a	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:28:02.217
36babe17-9b4a-4b51-a146-771dee58fe46	40b905f9-02fc-4e56-81d5-c829a3fb744a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:28:02.217
75f87dcc-4d39-4ae5-a2c1-cf6d98d1b889	74b510c5-3795-4a2e-b99f-15f3f78fcc2c	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:29:06.17
d889e4de-97d1-470a-bc9d-ad08cf156b93	74b510c5-3795-4a2e-b99f-15f3f78fcc2c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:29:06.17
b2fdf5fd-74fe-4de2-b3ed-816f0844887f	ad6d7edf-a497-4c1b-ab0d-3e992eea4b95	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:30:19.277
aa9cf750-f394-4a50-a084-0e58596ec103	ad6d7edf-a497-4c1b-ab0d-3e992eea4b95	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:30:19.277
6cb3fbb5-bbda-48c1-aea9-7481718d3dfa	a01d3797-414b-4c34-b29c-99bb2caeaa09	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:40:20.177
80f0c76c-d916-40ed-aca4-030928c4d79d	a01d3797-414b-4c34-b29c-99bb2caeaa09	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:40:20.177
8c1611e6-31fb-493b-9dd0-32ada515f8b4	a9e03d21-cb5d-4886-aa47-90d13c8dc7ce	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:52:19.735
e79198d0-e27d-4afd-97d7-d206cd63d289	a9e03d21-cb5d-4886-aa47-90d13c8dc7ce	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:52:19.735
67ef848e-817f-4b3b-bfba-eb2fcec34767	701b9b4a-1cf1-4390-a04a-6af42a59f209	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 17:58:15.853
eb3c6460-323d-4dfb-b267-30a85df4fbd8	701b9b4a-1cf1-4390-a04a-6af42a59f209	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 17:58:15.853
ec0eb21b-4cac-4f70-ae55-e2e7eebb13ae	afef669d-4efe-4937-a7f1-baf6943591b2	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 18:00:20.87
946b8fed-d9b1-46ce-8b88-4f899b954368	afef669d-4efe-4937-a7f1-baf6943591b2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 18:00:20.87
aab05a17-0674-4150-a2cd-4fece9894804	23ca94a5-0bd4-4002-9828-896847e9c60a	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 18:03:52.864
342c24c9-fb99-4ffd-867a-3db5da59a7cc	23ca94a5-0bd4-4002-9828-896847e9c60a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 18:03:52.864
da424ab3-4935-4930-b17c-626c64dc7bcb	b640a972-9268-48fe-be06-b6feedbdfb5e	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 18:05:02.488
8e31aaae-9c47-4b6f-a13e-e68e02bde8af	b640a972-9268-48fe-be06-b6feedbdfb5e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 18:05:02.488
5e923552-756b-425a-a882-10f202631663	f37cbb26-cfff-4689-9912-5b3f79b15d48	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 18:13:10.313
737341a2-7d92-47eb-92da-c49baf679607	f37cbb26-cfff-4689-9912-5b3f79b15d48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 18:13:10.313
66bfbb45-8e1a-494a-9466-ddc714c5fad2	7ded4c1c-4be6-403d-986e-0d6d4899155d	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 18:25:20.23
0d280cd6-fcfb-42bb-8b17-fa18f9547578	7ded4c1c-4be6-403d-986e-0d6d4899155d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 18:25:20.23
474a41af-0fb2-46bc-ac12-8b3706a7865d	9fec916e-7db2-46ae-9bd8-1d4663196f32	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 18:38:05.51
e16551d8-9c3f-4586-aae7-3bf922698992	9fec916e-7db2-46ae-9bd8-1d4663196f32	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 18:38:05.51
cbb2158c-1abd-45bc-ad7e-2ba8642f31cc	bb215514-20c0-4fb2-b694-7d738fe6a846	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 19:04:32.267
f6aa4286-78b3-4aaa-8a05-64f481706f49	bb215514-20c0-4fb2-b694-7d738fe6a846	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 19:04:32.267
9f46a943-bc53-4d02-8db7-2675e29cd143	58844a52-0ff1-4762-aaf7-77c016baadf6	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 19:20:21.399
9e74030c-35cf-4652-a9fc-6dfb63c5c94c	58844a52-0ff1-4762-aaf7-77c016baadf6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 19:20:21.399
6f044fe8-ebf3-4ba9-9079-dedcb20cf553	54909e8c-4427-4e4e-8cdb-09ebca5e1c48	e580851a-de0a-48bc-b0a0-922784cbbd2c	Người mua	2026-06-21 19:36:48.257
bea8027c-22b5-4c54-b27e-d754205ab415	54909e8c-4427-4e4e-8cdb-09ebca5e1c48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Nhà bán hàng	2026-06-21 19:36:48.257
\.


--
-- Data for Name: chat_rooms; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."chat_rooms" ("id", "complaint_id", "created_at", "total_messages", "user_turn_count", "first_seller_msg_at", "seller_confirmed", "seller_confirmed_at", "user_done", "round_two_opened") FROM stdin;
43a125a9-fa00-4d9e-aa46-0a56f038acd8	5d6ad5ab-7fcd-452f-8546-2fd338dc9128	2026-05-26 15:52:51.067	0	0	\N	f	\N	\N	f
3fec273c-4e76-43fe-9160-375ea69bad9d	2cb7f08b-8193-4319-b249-946a92ff29b2	2026-05-26 16:34:43.855	0	0	\N	f	\N	\N	f
b3d29bc5-3a2c-40c0-9c62-d34f76d31c16	81444c36-4596-4aff-9797-3bd13051fc07	2026-05-26 16:42:16.156	0	0	\N	f	\N	\N	f
137076b5-d499-4115-b753-1699ba023dc9	577b1d94-2ec5-4b2a-8f40-ee1013d3491b	2026-05-26 17:41:06.387	0	0	\N	f	\N	\N	f
f1700988-9793-4b43-b824-f1edc99a108a	dc87e547-2db2-44b1-a85d-4f7766d77352	2026-05-26 18:14:18.128	0	0	\N	f	\N	\N	f
dad82d96-9d0f-4742-a384-b070659416ad	77359dd4-9b9c-4ca0-8ec2-ff589ecb8358	2026-05-26 20:14:21.278	0	0	\N	f	\N	\N	f
55f9caf9-090f-4d97-b026-4d23f75ad69d	fd9addea-3163-415e-820d-e4e16970da61	2026-05-26 20:21:50.027	0	0	\N	f	\N	\N	f
2b6ee792-3409-4c34-b675-5c4ea1dfd94c	4959b6d7-24ad-4f97-ad3f-643dc3a6b422	2026-05-26 20:24:40.094	0	0	\N	f	\N	\N	f
406c1105-43bd-4e65-a0b2-82940747ce7f	bb3a017f-1e5c-44d0-b032-ffd8645d8e1b	2026-05-27 07:35:06.528	0	0	\N	f	\N	\N	f
54909e8c-4427-4e4e-8cdb-09ebca5e1c48	7c6a7a01-8d29-418b-b1a3-f00ff0e6eaa3	2026-06-21 19:36:48.257	1	0	2026-06-21 19:37:21.19	t	2026-06-21 19:37:22.639	f	f
f37cbb26-cfff-4689-9912-5b3f79b15d48	ac3a5767-602c-4bcb-872f-adf41c58abad	2026-06-21 18:13:10.313	8	0	2026-06-21 18:13:24.302	t	2026-06-21 18:13:26.158	f	f
497c6343-a2c2-4ea8-9ab4-5e04483ccf08	b68b9b6d-58d5-44fa-aa71-c8aa05611d52	2026-06-21 17:24:09.69	2	0	2026-06-21 17:24:26.479	t	2026-06-21 17:24:27.537	f	f
fea640ee-c62c-4ffd-baba-c06874046a7d	f30977b4-4e23-4122-9d56-c52a3fa65f6e	2026-06-20 10:41:45.624	20	0	2026-06-20 10:42:18.019	t	2026-06-20 17:48:16.932	\N	f
40b905f9-02fc-4e56-81d5-c829a3fb744a	49bf7e0e-b551-4031-83ac-8f60595af0b6	2026-06-21 17:28:02.217	5	0	2026-06-21 17:28:21.508	t	2026-06-21 17:28:24.604	t	f
74b510c5-3795-4a2e-b99f-15f3f78fcc2c	56dc4a32-7a5d-43bf-9965-01111b84c9ef	2026-06-21 17:29:06.17	3	0	2026-06-21 17:30:47.727	t	2026-06-21 17:32:37.929	f	f
7ded4c1c-4be6-403d-986e-0d6d4899155d	a1d62628-abbe-4bc6-b5e7-0b4ffedc5b09	2026-06-21 18:25:20.23	3	0	2026-06-21 18:34:59.055	t	2026-06-21 18:35:00.436	f	f
ad6d7edf-a497-4c1b-ab0d-3e992eea4b95	7e3e716a-83c2-4390-86b3-68dfce733df6	2026-06-21 17:30:19.277	2	0	2026-06-21 17:35:04.197	t	2026-06-21 17:35:05.061	f	f
a01d3797-414b-4c34-b29c-99bb2caeaa09	5d20df0a-182e-4ae9-8868-f6867800ac72	2026-06-21 17:40:20.177	1	0	2026-06-21 17:40:36.329	t	2026-06-21 17:51:20.557	f	f
b47ab722-785f-42a5-9b49-e3de1c516e47	2dae67ba-3aa3-4b36-b421-787ed068ce4c	2026-06-21 13:59:17.883	20	0	2026-06-21 14:01:13.128	t	2026-06-21 14:02:16.195	\N	f
a9e03d21-cb5d-4886-aa47-90d13c8dc7ce	3a648e89-6813-4c56-99e7-f3dffef80520	2026-06-21 17:52:19.735	2	0	2026-06-21 17:52:37.62	t	2026-06-21 17:52:38.597	f	f
9fec916e-7db2-46ae-9bd8-1d4663196f32	bef57476-e8bb-4a38-a409-31d93b9f2984	2026-06-21 18:38:05.51	1	0	2026-06-21 18:39:04.587	t	2026-06-21 18:39:05.214	f	f
701b9b4a-1cf1-4390-a04a-6af42a59f209	e2415682-2d5d-4355-8e24-6ee5bb223444	2026-06-21 17:58:15.853	2	0	2026-06-21 17:58:31.399	t	2026-06-21 17:58:32.147	f	f
bacc989b-50c2-49c4-992e-f00834b22279	fe85aec8-39da-40c1-a14f-32d446326807	2026-06-21 16:52:52.872	6	0	2026-06-21 16:53:07.896	t	2026-06-21 16:53:16.433	\N	f
02ac8a5f-5b41-42cb-a847-8295342f2ba1	15769eba-d5ad-4820-8ed1-7821d8afb038	2026-06-21 16:57:22.137	4	1	2026-06-21 16:57:49.035	t	2026-06-21 16:57:52.68	\N	f
afef669d-4efe-4937-a7f1-baf6943591b2	5996990d-2c2c-4960-b554-2f66e4c0515d	2026-06-21 18:00:20.87	2	0	2026-06-21 18:00:36.223	t	2026-06-21 18:00:36.768	t	f
bcd5ed6a-8fef-4e63-bc95-6e07abeeaa39	cf172c93-c876-41f8-82be-d6f4e913c4ce	2026-06-21 17:13:43.136	6	1	2026-06-21 17:14:31.004	t	2026-06-21 17:14:40.174	t	f
23ca94a5-0bd4-4002-9828-896847e9c60a	e34a9d82-a789-4a26-9642-fea4f684eb15	2026-06-21 18:03:52.864	1	0	2026-06-21 18:04:04.304	t	2026-06-21 18:04:05.198	f	f
b640a972-9268-48fe-be06-b6feedbdfb5e	bbc55809-641a-40bb-8012-736fe9d895e4	2026-06-21 18:05:02.488	2	0	2026-06-21 18:05:13.952	t	2026-06-21 18:05:14.926	f	f
58844a52-0ff1-4762-aaf7-77c016baadf6	17615619-f682-407a-a5c1-9312261c47e6	2026-06-21 19:20:21.399	4	3	2026-06-21 19:20:34.637	t	2026-06-21 19:22:45.166	f	f
bb215514-20c0-4fb2-b694-7d738fe6a846	d4251f69-bb14-4282-9159-d22ee9cf169a	2026-06-21 19:04:32.267	3	0	2026-06-21 19:34:47.522	t	2026-06-21 19:34:51.129	f	t
\.


--
-- Data for Name: complaints; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."complaints" ("id", "user_id", "order_id", "subject", "content", "status", "resolution", "resolved_by_user_id", "resolved_at", "created_at", "updated_at") FROM stdin;
5d6ad5ab-7fcd-452f-8546-2fd338dc9128	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fc287ba1-28b3-4daa-b4eb-f159632298b5	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 16:33:48.855	2026-05-26 14:37:07.064	2026-05-26 16:33:48.855
81444c36-4596-4aff-9797-3bd13051fc07	3ad147cc-59c4-4623-ba0d-59011dcb6b93	f5986697-1fe9-4778-9f32-540d877b9813	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 16:43:30.285	2026-05-26 16:42:06.538	2026-05-26 16:43:30.288
2cb7f08b-8193-4319-b249-946a92ff29b2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	90604f49-f398-4a4e-8660-e7225e19d6cc	Không nhận được hàng	addd	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 16:48:54.722	2026-05-26 14:30:43.148	2026-05-26 16:48:54.723
577b1d94-2ec5-4b2a-8f40-ee1013d3491b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b34e9db7-b2de-41a5-8ecb-a0301ead185f	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 17:41:28.813	2026-05-26 17:40:55.498	2026-05-26 17:41:28.814
dc87e547-2db2-44b1-a85d-4f7766d77352	3ad147cc-59c4-4623-ba0d-59011dcb6b93	287872ad-aaba-4d2c-941c-dc2b8806d4ce	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 18:16:55.102	2026-05-26 18:14:01.647	2026-05-26 18:16:55.102
77359dd4-9b9c-4ca0-8ec2-ff589ecb8358	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 20:14:25.972	2026-05-26 20:14:09.065	2026-05-26 20:14:25.974
fd9addea-3163-415e-820d-e4e16970da61	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4f2127c4-9914-4e8e-8d09-d312f2286323	Khác	Tôi    muốn hoàn  tiền	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 20:22:24.1	2026-05-26 20:21:32.328	2026-05-26 20:22:24.1
4959b6d7-24ad-4f97-ad3f-643dc3a6b422	3ad147cc-59c4-4623-ba0d-59011dcb6b93	373ca467-4600-4dfa-a72e-76b20d5abb52	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 20:28:34.817	2026-05-26 20:24:29.129	2026-05-26 20:28:34.818
bb3a017f-1e5c-44d0-b032-ffd8645d8e1b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	47951cf1-b33a-407e-8853-705086363659	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-27 07:36:42.11	2026-05-27 07:33:57.315	2026-05-27 07:36:42.111
53f04ea0-9b5e-4f15-8a3a-76572bb81859	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 03:10:58.354	2026-06-02 09:36:47.287	2026-06-04 03:10:58.357
80270900-1509-4867-96a3-c1402df7412d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2ec9ccff-7621-4925-a6df-6a6dc48a961a	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:36:11.913	2026-06-02 12:35:08.234	2026-06-04 08:36:11.914
89b3932c-59f2-4d51-abfa-c40ced675fc8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0334e4cd-2a86-4638-b18b-2665b94c0143	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 12:13:31.488	2026-06-04 11:39:13.429	2026-06-04 12:13:31.49
57acac26-5f8e-4822-b755-d3db1017d7de	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e075b268-818d-41dc-9a2a-4f89177f1acf	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Nhà bán hàng có thể rút tiền.	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 14:21:56.167	2026-06-06 14:21:41.81	2026-06-06 14:21:56.173
f30977b4-4e23-4122-9d56-c52a3fa65f6e	e580851a-de0a-48bc-b0a0-922784cbbd2c	d02e9b91-0db8-4f4a-9194-61a745e3f301	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Người mua không xác nhận trong 60 phút. Hệ thống tự động xác nhận đơn hàng.	\N	2026-06-21 14:00:43.427	2026-06-20 10:41:45.598	2026-06-21 14:00:43.43
2dae67ba-3aa3-4b36-b421-787ed068ce4c	e580851a-de0a-48bc-b0a0-922784cbbd2c	179f3897-e9ad-4d55-a5c5-629b70c5e387	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Người mua không xác nhận trong 60 phút. Hệ thống tự động xác nhận đơn hàng.	\N	2026-06-21 15:40:01.681	2026-06-21 13:59:17.85	2026-06-21 15:40:01.683
fe85aec8-39da-40c1-a14f-32d446326807	e580851a-de0a-48bc-b0a0-922784cbbd2c	08b1bed9-237f-4864-bc01-03975b26b5a4	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 17:02:01.729	2026-06-21 16:52:52.868	2026-06-21 17:02:01.73
b68b9b6d-58d5-44fa-aa71-c8aa05611d52	e580851a-de0a-48bc-b0a0-922784cbbd2c	a953723d-d10d-4601-9536-08f2cfad4cf4	Không nhận được hàng	adad	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 17:25:21.268	2026-06-21 17:24:09.685	2026-06-21 17:25:21.268
49bf7e0e-b551-4031-83ac-8f60595af0b6	e580851a-de0a-48bc-b0a0-922784cbbd2c	51183fd6-d7fa-4bf4-b451-13e03c4415a0	Bị trừ tiền nhưng không có đơn hàng	ad	RESOLVED	Người mua xác nhận đã nhận hàng.	\N	2026-06-21 17:28:36.825	2026-06-21 17:28:02.214	2026-06-21 17:28:36.826
56dc4a32-7a5d-43bf-9965-01111b84c9ef	e580851a-de0a-48bc-b0a0-922784cbbd2c	27773527-36ef-4544-9c57-643149bb66ff	Không nhận được hàng	Không nhận được hàng	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 17:33:54.99	2026-06-21 17:29:06.167	2026-06-21 17:33:55.018
7e3e716a-83c2-4390-86b3-68dfce733df6	e580851a-de0a-48bc-b0a0-922784cbbd2c	8b52fa9a-a367-49dc-b5ae-a219a48ffc1a	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	REJECTED	Đơn hàng bị đóng băng do khiếu nại được giải quyết.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 17:35:30.694	2026-06-21 17:30:19.274	2026-06-21 17:35:30.695
5d20df0a-182e-4ae9-8868-f6867800ac72	e580851a-de0a-48bc-b0a0-922784cbbd2c	9218d70d-bfcf-4a3b-8e76-cbf1596fd87a	Không nhận được hàng	a	REJECTED	Người mua xác nhận chưa nhận được hàng. Hệ thống hoàn tiền.	\N	2026-06-21 17:51:26.853	2026-06-21 17:40:20.173	2026-06-21 17:51:26.856
3a648e89-6813-4c56-99e7-f3dffef80520	e580851a-de0a-48bc-b0a0-922784cbbd2c	00e2ffad-5f6e-4412-8887-795bf68af323	Không nhận được hàng	Không nhận được hàng	REJECTED	Người mua xác nhận chưa nhận được hàng. Hệ thống hoàn tiền.	\N	2026-06-21 17:53:12.862	2026-06-21 17:52:19.718	2026-06-21 17:53:12.862
e2415682-2d5d-4355-8e24-6ee5bb223444	e580851a-de0a-48bc-b0a0-922784cbbd2c	6ab4b9ce-c56b-447f-a4aa-47febc746300	Không nhận được hàng	Không nhận được hàng	REJECTED	Admin phán quyết: người mua thắng khiếu nại. Tiền hoàn về ví người mua.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 17:59:21.977	2026-06-21 17:58:15.849	2026-06-21 17:59:21.978
5996990d-2c2c-4960-b554-2f66e4c0515d	e580851a-de0a-48bc-b0a0-922784cbbd2c	d6143418-315b-4598-9e82-79c3fca96e9c	Không nhận được hàng	adad	RESOLVED	Người mua xác nhận đã nhận hàng.	\N	2026-06-21 18:00:41.241	2026-06-21 18:00:20.866	2026-06-21 18:00:41.243
cf172c93-c876-41f8-82be-d6f4e913c4ce	e580851a-de0a-48bc-b0a0-922784cbbd2c	f43c66f5-1251-4939-a2cf-b8eb64b881e9	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Người mua xác nhận đã nhận hàng.	\N	2026-06-21 18:01:16.67	2026-06-21 17:13:43.133	2026-06-21 18:01:16.671
e34a9d82-a789-4a26-9642-fea4f684eb15	e580851a-de0a-48bc-b0a0-922784cbbd2c	dd2dc810-a1da-4121-b4a9-26febee581d7	Không nhận được hàng	Không nhận được hàng	REJECTED	Admin phán quyết: người mua thắng khiếu nại. Tiền hoàn về ví người mua.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 18:04:18.485	2026-06-21 18:03:52.86	2026-06-21 18:04:18.486
bbc55809-641a-40bb-8012-736fe9d895e4	e580851a-de0a-48bc-b0a0-922784cbbd2c	122f5101-4b1b-4980-8e34-147581f29ab9	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 18:05:28.599	2026-06-21 18:05:02.484	2026-06-21 18:05:28.6
ac3a5767-602c-4bcb-872f-adf41c58abad	e580851a-de0a-48bc-b0a0-922784cbbd2c	9b97b3a3-e7af-44e0-a574-8a02cfa712dd	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 18:24:33.581	2026-06-21 18:13:10.307	2026-06-21 18:24:33.582
15769eba-d5ad-4820-8ed1-7821d8afb038	e580851a-de0a-48bc-b0a0-922784cbbd2c	75af354a-776c-4d81-95d0-17a76a609b93	Không nhận được hàng	Không nhận được hàng	RESOLVED	Người mua không xác nhận trong 60 phút. Hệ thống tự động xác nhận đơn hàng.	\N	2026-06-22 11:45:51.683	2026-06-21 16:57:22.133	2026-06-22 11:45:51.7
a1d62628-abbe-4bc6-b5e7-0b4ffedc5b09	e580851a-de0a-48bc-b0a0-922784cbbd2c	7450f2da-0d9e-4a98-9e84-63811095c148	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 18:37:43.449	2026-06-21 18:25:20.226	2026-06-21 18:37:43.449
bef57476-e8bb-4a38-a409-31d93b9f2984	e580851a-de0a-48bc-b0a0-922784cbbd2c	0594a66c-6226-49e4-a615-c57f5c11b93f	Bị trừ tiền nhưng không có đơn hàng	Bị trừ tiền nhưng không có đơn hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 19:03:33.132	2026-06-21 18:38:05.507	2026-06-21 19:03:33.132
17615619-f682-407a-a5c1-9312261c47e6	e580851a-de0a-48bc-b0a0-922784cbbd2c	c7793e2e-97d8-43b1-b731-2896dce51db1	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 19:23:22.953	2026-06-21 19:20:21.395	2026-06-21 19:23:22.954
d4251f69-bb14-4282-9159-d22ee9cf169a	e580851a-de0a-48bc-b0a0-922784cbbd2c	f446c556-1e25-44c6-9a80-08a7790c678e	Không nhận được hàng	Không nhận được hàng	RESOLVED	Đơn hàng được xác nhận hợp lệ. Admin đã thanh toán cho nhà bán hàng.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 19:35:41.077	2026-06-21 19:04:32.264	2026-06-21 19:35:41.078
7c6a7a01-8d29-418b-b1a3-f00ff0e6eaa3	e580851a-de0a-48bc-b0a0-922784cbbd2c	ec601ff4-98cc-4b1d-b912-4d09377741fd	Không nhận được hàng	Không nhận được hàng	REJECTED	Admin phán quyết: người mua thắng khiếu nại. Tiền hoàn về ví người mua.	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-21 19:37:49.92	2026-06-21 19:36:48.242	2026-06-21 19:37:49.921
\.


--
-- Data for Name: course_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_categories" ("id", "name", "icon", "display_order", "created_at", "updated_at") FROM stdin;
77dc5824-4df0-47a8-9d39-df6f15d5ee03	Facebook	https://svgl.app/library/facebook-icon.svg	1	2026-05-29 08:43:30.948	2026-05-29 08:43:30.948
1b1b5275-03bf-432a-a8db-c271ac35832c	Tiktok	https://svgl.app/library/tiktok-icon-light.svg	2	2026-05-29 08:43:37.191	2026-05-29 08:43:37.191
6d6941df-146b-4d74-92c2-80c2b6f0229c	Google	https://svgl.app/library/google.svg	3	2026-05-29 08:43:48.524	2026-05-29 08:43:48.524
17e7f260-7123-4117-aaaa-84a0ff9ce385	Intagram	https://svgl.app/library/instagram-icon.svg	4	2026-06-06 14:58:23.685	2026-06-06 14:58:23.685
\.


--
-- Data for Name: course_faq_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_faq_categories" ("id", "course_id", "name", "display_order", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: course_faqs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_faqs" ("id", "course_id", "category_id", "question", "answer", "display_order", "is_active", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: course_support_items; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."course_support_items" ("id", "course_id", "icon", "title", "description", "display_order", "is_active", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."courses" ("id", "slug", "name", "thumbnail", "description", "category", "learning_format", "original_price", "sale_price", "duration", "student_count", "instructor_name", "rating", "content_list", "platform_variants", "badge", "sale_deadline", "youtube_url", "seo_title", "seo_description", "total_orders", "total_views", "is_active", "display_order", "created_at", "updated_at", "deleted_at", "requires_account_type", "requires_cccd", "commitments", "registration_procedure") FROM stdin;
4447b4b5-91b3-4226-8089-638faa948030	khoa-hoc-mmo	KHÓA HỌC MMO	https://cdn.hethongmmo.vn/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779680328773.png	Khóa học mới của chúng tôi	Facebook	ONLINE	1999000.00	1599000.00	5 buổi	54	\N	5	["ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New", "ĐÀO TẠO DỊCH VỤ FACEBOOK\\n SETDING Tăng Tương Tác Tất Cả Nền Tảng Mạng Xa Hội\\nLấy Lại Tài Khoản Facebook Bị Hack (Ép From)\\n Mở Khóa Tài Khoản Facebook Bị Vô Hiệu Hóa Tất Cả Các Dạng 956 - 282 - FAQ ( 583 - 811 - 429)\\n Kháng Nghị Fanpage Bị Đình Chỉ HỦY ĐĂNG\\n Bảo Mật và Bảo Kê Tài Khoản Facebook + Fanpage An Toàn\\n TUT TRICK Facebook | Khai Thác Tricker Update New"]	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}, {"icon": "https://svgl.app/library/tiktok-icon-light.svg", "name": "TikTok"}]	NEW	2026-05-31	https://youtu.be/pfatajwTL4I	Khóa học online	Khóa học 2	4	231	t	2	2026-05-25 03:39:33.624	2026-06-02 19:38:18.083	\N	f	f	["Hỗ trợ nhanh 1:1", "Đào tạo chuyên sâu"]	Sử lý toàn bộ các thông tin và đăng kí học trực tiếp
6e646372-6751-49d3-9ccd-1fc78e96c2bd	fba	Khóa Học Kiếm Tiền Online Chuyên Sâu 1:1	https://cdn.hethongmmo.vn/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780222154228.png	kHÓA HỌC THỰC CHIẾN MMO \nDÀNH CHO TOÀN BỘ NGƯỜI MỚI-CŨ\nHọc Chuyên Sâu Các Kỹ  Năng Làm Việc Với Facebook	Facebook	OFFLINE	100000000.00	99000000.00	12 NGÀY	123	\N	5	["Mở Khóa  Tài Khoản Facebook", "Chạy Quảng Cáo Facebook", "Học Dịch vụ Tut Trick", "Cung Cấp Tài  khoản quảng cáo", "Update  các  tính năng  trong  khóa học", "Học Kiếm tiền từ nội dung  Facebook"]	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	VIP	2026-06-09	https://youtu.be/pfatajwTL4I	Khóa học trực tiếp	Cam kết  hiểu  cv	5412	1323	t	2	2026-05-23 16:18:31.239	2026-06-08 04:31:41.259	\N	f	f	[]	\N
cbf81219-3e12-4060-9303-dca020c2e798	khoa-hoc-chay-quang-cao-tiktok	Khóa Học Chạy Quảng Cáo Tiktok	https://cdn.hethongmmo.vn/course-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780284674383.png	Khóa Đào Tạo Chuyên Sâu	Tiktok	ONLINE	15000000.00	12999000.00	7 Buổi Online chuyên sâu	431	Chu Quang Doanh	5	["Chạy Quảng Cáo Chuyên Sâu", "Tối ưu hóa chiến dịch quảng cáo", "setup gian hàng quảng cáo chuyên sâu", "hỗ trợ thực chiến trong quá trình học", "Đào tạo trong 7 ngày được hỗ trợ đặc biệt"]	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	HOT	2026-06-09	\N	Khóa học quảng cáo tiktok	\N	2131	1214	f	1	2026-06-01 03:31:35.134	2026-06-20 18:39:11.959	2026-06-20 18:39:11.937	f	f	["Hoàn Tiền", "Dạy có cộng động học viên"]	Nộp tiền là done
\.


--
-- Data for Name: fanpage_registrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."fanpage_registrations" ("id", "name", "phone", "service_type", "service_name", "description", "created_at", "status", "note") FROM stdin;
48a93408-8bff-4bb7-b758-294b61ad6f8a	Chuquangdoanh	0929990999	MUA_PAGE	Cài Đặt Payout Chuyên Nghiệp	Dịch vụ Cài Đặt Payout hỗ trợ bạn kết nối tài khoản nhận tiền từ Facebook Creator Studio một cách an toàn và đúng quy trình. Bao gồm: xác minh danh tính, cài đặt ngưỡng thanh toán, kết nối ví/ngân hàng và theo dõi lịch sử chi trả. DNET Media đảm bảo toàn bộ dữ liệu cá nhân được bảo mật theo tiêu chuẩn cao nhất.	2026-06-06 08:22:45.309	DONE	\N
8faf4ca8-0b8e-448e-a8a3-e494f7373a1d	Chu Quang Doanh	0929990999	MUA_PAGE	Cài Đặt Payout Chuyên Nghiệp	Dịch vụ Cài Đặt Payout hỗ trợ bạn kết nối tài khoản nhận tiền từ Facebook Creator Studio một cách an toàn và đúng quy trình. Bao gồm: xác minh danh tính, cài đặt ngưỡng thanh toán, kết nối ví/ngân hàng và theo dõi lịch sử chi trả. DNET Media đảm bảo toàn bộ dữ liệu cá nhân được bảo mật theo tiêu chuẩn cao nhất.	2026-06-08 08:53:21.418	PENDING	\N
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."login_attempts" ("id", "user_id", "email", "ip_address", "user_agent", "success", "fail_reason", "created_at") FROM stdin;
c27d97e4-9436-4e37-a29e-c7c1fee51b75	\N	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-05-23 16:10:00.188
7499d92a-16df-43ce-8d9d-0e88ed7dfbeb	\N	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-05-23 16:10:09.006
2f538334-fd58-4899-9088-07cdb06ae6fe	\N	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-05-23 16:10:26.489
75baaab2-d438-4d3e-b778-63c71cc7c488	15bbcf73-c01d-4730-85d7-a1cca3730c83	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-23 16:16:51.47
76b62a1e-0e1d-4aa5-8b74-cddc4b35ceae	3ad147cc-59c4-4623-ba0d-59011dcb6b93	chudoanh107@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-25 08:13:28.583
42c13cfd-edca-4726-b3fe-d4127291f35c	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-25 11:20:33.619
6ba25af5-0ceb-4077-964b-cc9c1bb014e5	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:30.032
f9029236-d5d2-43a5-a743-a72fb8594c07	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:36.511
e499d57c-baa6-4c42-97f0-b36c4586f21a	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:53.997
19029948-3fe9-40bd-a025-aff9308b3ffc	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:55.784
ec4d03ca-5b25-45cb-8cf2-9014cdee4c96	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-05-27 07:22:56.334
83454012-0397-4e17-bb53-ddefe044de7c	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_LOCKED	2026-05-27 07:22:56.771
4819607b-9808-4e92-baee-b0fe3dff5dde	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_LOCKED	2026-05-27 07:22:56.947
33c5c282-707f-47a7-b7a2-831eeba24caf	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_LOCKED	2026-05-27 07:22:57.096
e62b9662-988d-44dc-82e3-391f18312b13	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	doanh123@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-27 07:24:31.449
7e8475da-faa1-4c37-99c2-cb1231de90dd	f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-28 02:22:23.34
9a8e4cc8-0fbe-4072-b280-65de2e30f5e1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	chudoanh107@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-05-29 19:03:40.713
af08ff97-551e-4431-b4c0-641a3e561e03	\N	ad@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-06-02 18:54:36.453
258f2207-d6eb-4899-8151-cf06bc051bc0	\N	chuquangdoanh@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	USER_NOT_FOUND	2026-06-02 19:24:38.871
4a9fce4c-7b4a-4d25-bcf3-4acdbb35227c	e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-06-02 19:24:54.628
e8cc2eaf-6b67-443d-bcae-0e9758c34cb5	55d1694a-443e-4f08-8875-8dadff9cbf62	nhanvien@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	t	\N	2026-06-02 19:27:19.264
2da0b8bf-1111-4471-82e5-0aa0a81ca03f	\N	lasvergasblackmeta@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_BANNED	2026-05-25 11:23:30.132
64ca07e8-324a-432f-9c02-1e699950a716	\N	lasvergasblackmeta@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	f	ACCOUNT_BANNED	2026-06-02 19:23:07.017
d101baf7-91a9-4c53-b468-31b6c66ac601	15bbcf73-c01d-4730-85d7-a1cca3730c83	chudoanhofficial@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	t	\N	2026-06-20 10:23:39.459
3fd3ba52-4357-4533-a632-d0c7daa3742a	55d1694a-443e-4f08-8875-8dadff9cbf62	nhanvien@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-06-20 10:48:15.357
1a29012a-1e9c-49fc-8517-60e645b00675	55d1694a-443e-4f08-8875-8dadff9cbf62	nhanvien@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-06-20 10:48:20.589
ae4ccd81-2cdf-4cb0-b304-659df5b63292	e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-06-20 10:49:48.555
486d4d9e-4ad7-43eb-8089-7e233a69ad69	e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-06-20 10:49:55.227
43f39e37-a8e9-4ace-bc4b-a8c9ee348254	e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	f	INVALID_PASSWORD	2026-06-20 10:49:57.374
edca7cff-3230-4502-948a-fb7a6ea460a0	e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	t	\N	2026-06-20 10:50:04.648
890730f8-c30e-4ab2-b76a-226d007492f8	9c652e2d-15d7-42d8-9b96-1179145dd096	khachhangtrungtamfb@gmail.com	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	t	\N	2026-06-22 07:50:23.416
\.


--
-- Data for Name: mmo_product_items; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."mmo_product_items" ("id", "product_id", "value_enc", "status", "sold_to_user_id", "order_id", "sold_at", "created_at", "updated_at", "value_hash") FROM stdin;
e5b6563f-af22-4325-920c-2cb477347ae1	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x21aed8bae84ce28df394aff2b66697eecd2a1cbda7e1e6765248f4091e7c3d2080	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2fafd37b-5d19-4e88-b3b0-76402374e4e1	2026-05-25 18:30:36.603	2026-05-24 14:44:09.22	2026-05-25 18:30:36.603	\N
af6d05a8-c83d-4ba7-82c7-885e3a409426	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\x8fd71ea4079f0880b713839b8710d88f3b0e2ce4ffa2b7a621aa596a0337e6	AVAILABLE	\N	\N	\N	2026-05-25 18:49:16.893	2026-05-25 18:49:16.893	\N
a18da2c4-9d5f-4946-b4fe-9b130d8eb83e	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\xc8d7eea90dc535b4d6c0d449373eda36a73d79ae7d915ed46a4f5bd834a082a150	AVAILABLE	\N	\N	\N	2026-05-25 18:49:16.893	2026-05-25 18:49:16.893	\N
4d4885a3-8917-4ca8-beba-fb4e1a3638ce	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\x5a7abe142ace9ee785ab3890dd5ee544601b8a8567ae90607fc2fa92855a435a85dcae	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	ac56e421-5f6b-4277-93eb-a9e1cfc831b7	2026-05-26 08:31:10.699	2026-05-25 18:49:16.893	2026-05-26 08:31:10.699	\N
f9e8f5cf-68d3-4e54-8d1c-5a1a45544a21	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\xf074f0644094f1b0ddcce82fdb5eca6f3c30ab384de075bd6114ee398e855f9a2f	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	55cd38b0-cd40-4d86-b883-9893f7c4f9c6	2026-05-26 13:47:37.46	2026-05-24 14:44:09.22	2026-05-26 13:47:37.46	\N
ccbaa773-bf85-48f1-bb22-25562302965c	9446f730-205a-42f2-ad8c-7d7b035e638f	\\xbdb747d25ee30475d8f785d65ab14b4459fcebad4e1a48943830357d5c	AVAILABLE	\N	\N	\N	2026-05-29 08:36:19.396	2026-05-29 08:36:19.396	\N
5f04a7df-52b1-41b7-8d44-49d92489bbd3	ee1eeca5-490a-462b-8be7-e4b14f61513f	\\x78d859af7b101c491035489604f4927328871cf41f92d2eaaf01c3a12b	AVAILABLE	\N	\N	\N	2026-05-31 15:56:03.52	2026-05-31 15:56:03.52	\N
4692de6f-f920-4a8b-b202-a158220e0df3	ee1eeca5-490a-462b-8be7-e4b14f61513f	\\xca1746a279e0ae7606d533679b910b92f80387225997b6b22deee43a3a	AVAILABLE	\N	\N	\N	2026-05-31 15:56:03.52	2026-05-31 15:56:03.52	\N
149cb505-ba90-4cea-ad19-f6aaa584cac5	ee1eeca5-490a-462b-8be7-e4b14f61513f	\\x22bc19dce29e3849488d5705ec4c91659648cbf31ba1baf847b06222bb	AVAILABLE	\N	\N	\N	2026-05-31 15:56:03.52	2026-05-31 15:56:03.52	\N
15b3795e-0c2b-4447-b611-774f0316e61d	c0828411-0c17-4fdb-a37c-67c101879466	\\x4dabeda2f9d295c7a5288e2aac93bf632c0a3658ba98c5a74d99b2d2e1	AVAILABLE	\N	\N	\N	2026-05-31 15:56:53.824	2026-05-31 15:56:53.824	\N
4031ad9d-1b06-4e37-971f-0dad912ef32b	c0828411-0c17-4fdb-a37c-67c101879466	\\x62c1831d5250e161eb51262a24aa298792bc9df816d1dfc72b6a48da39	AVAILABLE	\N	\N	\N	2026-05-31 15:56:53.824	2026-05-31 15:56:53.824	\N
43ab65c5-2fb9-4e44-af06-c217aada91c1	c0828411-0c17-4fdb-a37c-67c101879466	\\xc05e008f8d28620276729b9ec1f146b8f87a31beea13265972cabd9d4c	AVAILABLE	\N	\N	\N	2026-05-31 15:56:53.824	2026-05-31 15:56:53.824	\N
1cc5a876-7232-44ef-bfef-82046eb6b048	44e26368-8fad-47ec-bafc-5ce03123a5b0	\\x166b94f269eb74679a0baf3cce88aecf27352e511425bd3af3a893efac	AVAILABLE	\N	\N	\N	2026-05-31 15:57:39.988	2026-05-31 15:57:39.988	\N
392df6c5-f780-4d15-86b1-dae04dce4ff6	44e26368-8fad-47ec-bafc-5ce03123a5b0	\\x7d6f1207fecbea30fc393aeef27a681c41b39513dc6d93570d47d1270e	AVAILABLE	\N	\N	\N	2026-05-31 15:57:39.988	2026-05-31 15:57:39.988	\N
878e9626-0810-46b0-83a3-efc18b3a4b54	4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	\\x872db9fe7934330c227554c404b59674380b29095047f7a88af07f6023	AVAILABLE	\N	\N	\N	2026-05-31 15:58:51.279	2026-05-31 15:58:51.279	\N
24893b3a-16c9-4f80-8fe1-6b91a7cb22be	4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	\\x7c6c6130a7406c2a1070f1e2958d39bdc5e5362feec899a6cbbee21fbe	AVAILABLE	\N	\N	\N	2026-05-31 15:58:51.279	2026-05-31 15:58:51.279	\N
7915c972-3ba1-4f64-af80-b594c22e964b	4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	\\x2be94a85a26215d985bcfa56d52b0949650d186f99cbe03b6dce4625ee	AVAILABLE	\N	\N	\N	2026-05-31 15:58:51.279	2026-05-31 15:58:51.279	\N
0a9c1255-7cfc-4e8d-9348-187f3126dc3f	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\\xdd63ff05a863b6bc8b89284fb9a96595dc4c48ceda1e525a60b5a3637e	AVAILABLE	\N	\N	\N	2026-05-31 16:25:54.582	2026-05-31 16:25:54.582	\N
6d8badd8-caf8-420b-a4f0-2e5ef368aa2f	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\\x4dae94954c077a03fbf11ff397f05689133b3fd07588c21c21dfb67dda	AVAILABLE	\N	\N	\N	2026-05-31 16:25:54.582	2026-05-31 16:25:54.582	\N
141b6996-caf8-496e-a9bf-a75dacfa9afe	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x36fb381efe3b5bb237d738f5c00f542b723df5e3b01ec654a9ee7c3527abb88a98	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b2e08071-f6dd-4e59-bb9b-5e7108897372	2026-06-01 08:01:02.958	2026-05-24 14:44:09.22	2026-06-01 08:01:02.958	\N
8edb52a0-ba37-4bf0-9dde-e7a6d2706db7	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x71c4f56de0bcb68962d6ae511904d85d64ba1604086d35cb0638ad07b52f413f12abe5a672e0d827b8ab33fe375dcfd9576db55638bd998dc46c11265a1618768794ab6e572a9d36be0a9e9d0dd98d65e6016dd7930f2e73bbbd6ad07789f1d44aa8f590007dc79374a4f36638daf6572e6040f4b4565180099a4fa46e0229a96d04739bcc7f60096b42658f0cb52f7fc9f0fba0fbf86ee7722f866eab4707452af667a0c70ae1bd648b45c941a1f464a7fac263c3bd57579be3e913266dd92d50c97b690e78dcb740e5d0d556c60bcfb212d2fe6a2613f674a8ef4ca02b9d3a2aac729e51bd787278c7674504f4bc17354584614a2a198f5e2f9a3fb28c7262dd4569862b169d0c8772f2291be31940d90cc2937bd430745b36f6a729076676981039e730fe22b00988b6fa2107f90df20e4cffec1ac43a15ce2bf0b35effdf73d5217fe38e3c29ab691ffa2eb38e36c1626cb05728c34d74dbda6102c667076a85a4a3b8680c4798c39a6027d23e0ff459c108059149fac4d72d48a74e2fd6f2248e38699160dfb4b5f604d96bacfa856ba9e785876d80abf7d60a931facc67c156b883b2f8f281dca62a43b6bfe5c09923ad7a820aaf9db0a6941cd367ffbac26900247afed1ccbd3ad6019db4cacdb41509be577691397f7f99527b87cf7bd28d0988de679f4269bdc4f4abfb6280619140d2347b7dc262a17a23d1a226d7c934ec18df3fb300aaec516cffb1e2e44237bff6f8c9727dc3068870a715d79a4c6d32f9cc85d999316f3388b42bc9630da64acf6798c446e48de5090857dac6bc0816fc787abf8d7238186b5a688754da0da461511684b79c31200e1d03b672e3eba25d5836b3d638a5b21aedd2e56092ed30de160872740afc5dcb9045354b092f91cd9f48167fb33f6b52eac1c95032c35c5e0a38c2fbac60fa2e48ecfd4465e3c2b6a6507644400daadc0facddafd2392a07fd6a86fb0f973119f0cd51064539e54a2a70c046ce92f1d30fec48464121d9d2aa6fa470b2d3326c45a8bf5faa2735d2248f3994f2af2fb15dc35e7596ad0500ab424bf431818570ccc0a82a9871112d3521d7a065219be23fe7663f4f39b3461745b5ae2a514f3b6a2f2634c80651306629497ecb04d1db846d8dfba6c837e9725555af41a4348c5e32f7200840c18ad53989a46d5acd7c82d908c6b0b6d5b150c3a117b7919894e0571d1684b505c9b026110680268da9cfe43eaf9dd83eb77c7a9d32cd7bec9ec204edf0afe314c75b41328ba2d4159fe8ed1464e0f896bab36ae94fa98d33b046ef1a757cdfb0104dd74cd3f53b1d16aadbc59f3a4ca275da54e2fd2fbb1776cae9ea6c77e8f89dabb00b15ba9902a575a2d7e9e44140f8c9de737a933903c6095ea023e37b039fcf798b485ddb088c7978083c0304a556e9b035701230d88ad63cd26d9930458be2de479967d1ccc5a8e6548ce69629c2f9cbde145dd5bce00362c06fbb19131d43f9b88403f	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	de7c53c8-069b-410a-83d3-fbbfe131cf95	2026-06-01 08:01:06.526	2026-06-01 07:59:52.356	2026-06-01 08:01:06.526	\N
e76c41b2-0fca-4797-89bd-ad6182b2c44a	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x59e68c7f8485fc50cf8c1d84a206673a9f6d8aa4e1b2513c24d25eeaa364375915e3cb4f3c50b5679814ab6dc6c45c3ae921bb6806635e694fd4478da5adfe209e4cf468aacdbe24f257d2708960e03e733a9efc2056ce8c002e85970e1c5db7f67547c75cc74314c09e388b994b2ae309c88955429f2e2b783d721a9f53b3c7653962a1ce3e43c2595cf280c9449c4b7e8b89f5dd6dff2f7935bd7c41997238b60d4e50fa1ff5af624ab59ff2cf0f422167921646412044d94e43666675e98fa474af63bbdaf5ddf1c5fe9de477a6ba55472682cefe92907bffc2e4c37e83d28ea593b5a8ca9fdd075b935579420e03124ea1ae89c446d6378b559144e7519151f78bca387e252a6650312a19d7fe73b0ae9bcee14c999b3d60ba9573fb6f4ad11f02c19228f767f46544236670bf07aa0c687fea464d41b3a69e2c2aef9a9715f86c665d0d2815b2d1fdd221b901df35a8c1b8514ba151f6412f158677f934d313d8619cd2e4f165d43b963199f3196ff9f13eefe38158fcd6b815b24912cb295176cb6aac3a532c781f9f5c916e9e6c67de32baf27af787cbbbe0c0d3f4347792da2da49c9a561b365f37507377dc9cc2c3b9032dc254113cfbbf28fac06b2e2ed1474b12fe6d4f86a443c699e1fb2390bb0966cb9d2ac1473be172b79cdba22571b1c5b290ebe8735ff79bf78d3a56a61dd1edd2941a9fe47a4ec75c54a01734e6e6701b49a73704a951b714b0288ebbb0ee186df0af7df3f3223c2a484dcabd6fe0e036837da818155fa61acf042826ba4e1fbdb4337ffe6c99682d74aacd1d2bed04dd698639822efa89d678014086c521ff20023f059f8c09835d5aed8f55cb764ce253696d5a67eb062ab5e7cf95767af023167b959170543cec3d7132493a463ff51fcdcacfcbffd2987f16cdbab259e8d6d0aa5989e25f7735de6291d999b90bf3c9572fd05bd13c5e3a450db9d5cdb8cdc5a8120de5522124790cf3d9d2115bfd91f51fbea1f867b26cdf5eaedf071c3b8cdff7c44f2c1ba95b083c523c54f13840c5629b2436e8e8efa57f5b09b6865ec8345687ed125d53bbdd06049b42ab2759d1ab11fcdcee540bfd73e692862cb13f996f0fcb334ec09271e68845a125e5f143dac3afddcc56c8fa2a005be6afb5cc3a9d42a9a40cc0d4f5177c325c5d0b57df980d2d12d5e47c9341e3b8648b2cec5ed13cb57afccfc8aafc515f5cf9bd85cae14b014ebea3d03c336cbf368b376d21a7a77e3b131a2bf32c85752980a85489b0edae0ddefe14e668c8536b310c59e2802ee6844d1590c22e75059e22596a669f246c1140203090596bf3005889ede8001a30263792ccac87dc4d976e8603ed4c0d5affbfa20dfeb9654571971dfa3a9cc620dd744d072eee3b6281825b79c18ed2433e7412c17d35dfa987b09ffe16b1551cb20395593fccf9c284252a3ff1d5290ab49577cf620ca5edf0369ec84078da0b4ab41cbd59af0908f9cbc5d79b271a	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	48c5a877-2769-4dfb-8f15-226b75bbe391	2026-06-01 08:05:00.41	2026-06-01 08:04:39.524	2026-06-01 08:05:00.41	\N
07c1e75d-c61e-44a6-8483-58deed22e179	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\xfc859b667594a2aa6d8417b9069dd1f0e23432979dc5220fffccbabe4fe28b26c6e6815c66ae9ff777694ab2398bfb9461ae7be9aaa55ef8f979e9e35b9dacbd0bef558be0aeb59681c8cfd5f9947a06ae9551c556e85f04b47cc122cfcc294b717c55773d23edc308ca1257ae954733141599a6271b3dc9e763cadd1a725a849705ee82a749a39fc1497d966c35936d77e617ec671f7ab8a51a453a954acbe31d16be5cf1a7306c3f411f90268648b07597e5e83caada6279dac8858be23dd36f3a8318a62d6f7bfc0bf521ec2650c12175b4c181838a9450892ad0a1de4d21a1fce8a1c762b4b4ff3a2daabc405ac48f756e0f502e302b151def398a90655f4cfd4aef8f4d23c342e1be9b5fa4a71d6964799c05dcb254274ec36a7bfb3e8d513b1efab0550a8e009993b847ab415d17fce818c987a9647003e125e4aaae21564fbbfd3986e7cc354c07be16f55e6a8245e27e61b53ac5785653f3572cde9b71a617f7fd4899e33a8ca31fb8345bef9cc9ec17b0fb40daf2349791c7ea9c38323b5742746e42225085855e1629727ac479c0948a2061cd1e1b096d3f0067146542a592985d8596072b384a2e9e12ae2f73848f7fc4e9cf5e9b17e940054b03ad1f1da46a0100d5e38c0a5bdeefdf420d448b59ffda1c6b254fb477f8a583e9ca9766eb222764b448546ea3791738c83998a5192e7d61778e5ce3a8d4fcb9ec426a30ac6c47920b31d3799403f9cd2c52712c3f2ff71f55a27e33bd3e7c5510c2038cd7544681ef1d1791afd9c7d793275258bed76a06d7da1d5147be0d1c5d65008af09670e15e4f9d53159f0faa2d9abb7a979615b52febb9d32aa2bda41abc483883d168967416b383928f5f2b777c669d34198f99d5512d00e6f561b3280352412b69a4c0338be1f346a736286de05773e7b854cf833a85e2ba0ad10fdace3b12b3034d1c7da2346eaab50d54503f6bd3364fe18d68ea3f908e76e37601d6656e020c3736d43cb02a2678ab00e7e5c1ccfaa502f0ff03c2b212289d028c00bd14ee0c4081f0452bad25ad42d4b4589f47d0b252ca371ecdf7c6abb7a8b76df7afd316554aa66b326c0519a9ca9337f3a276b55aa3a724bb1f32d0426a7b97d5bee0be1caecc2bc722e111657acdd345a021d1a1ae30a3045742acbe5a8f018f2c82ecdfaccff5d1a72ebdad49b4c88eb6a6d56992010f965ce16e8cf050b86d8e5c615249ab3ea223f783e269a8b7456a20a31da113f4ebc7effd826d8fdaebca4b6227fc0590c352d492088c2ddda2e6d267b5d3f82c4d3e7c85fd09759d3e2a49f6f2955918b9c53584c4e9ecc93ff6c4f38ab7380e98d4f5f11c63baac0f3300d5f299afe26f9c1983e6b59d2b9eedfffac88d76a19a3ffc5c7d760df9c283c57bfcdc7ca596499a631944e2d33b53aed83b085e6c64ae7fde61973cc267c5636967774c6eceea386299a54cf02648726d942ede35dcf4054341167fd3d1f84bcd95a9bc5468	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d680918e-f4bd-4608-9f6e-8516126cc5a0	2026-06-02 09:58:27.322	2026-06-01 08:04:44.981	2026-06-02 09:58:27.322	\N
8338df82-f2c0-4060-b075-712fd9772714	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\\x5aeff841243a8d3772a2f1a4b581d84e57f80b7cc4803d852a6b60b2ee	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	36a1261a-339c-4226-98d6-cd3ec9867bdf	2026-06-05 16:43:55.473	2026-06-04 12:28:03.997	2026-06-05 16:43:55.473	\N
4783f567-a617-46e4-9a59-853c48b304dc	44e26368-8fad-47ec-bafc-5ce03123a5b0	\\x075a27b07c397d213f0cf06d1f4db2e0fbf1ca14b232a482d996866337	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e37704de-5da0-4c00-98f4-6a62aaec35bc	2026-06-05 18:09:09.946	2026-05-31 15:57:39.988	2026-06-05 18:09:09.946	\N
10ebce0f-898a-4679-ada1-4fef82d84cd8	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\x5d0b53d9295d75f922f602ca9a939904615c4ecad09c3f830466f04470	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	542b5e5d-ad27-4eb1-93e0-92b53bab03ec	2026-06-06 03:59:24.678	2026-06-05 18:29:08.377	2026-06-06 03:59:24.678	\N
6924aaf5-d660-4f4d-9a57-4294d3f15b54	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\xdfe2e2ef98ba1d2dfad86cdca9f45df9fad8bdc144f7da24dadfef2f1b	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0d50ba32-07c2-42c8-bb2e-5d40f148cd20	2026-06-06 03:59:43.098	2026-06-05 18:29:08.377	2026-06-06 03:59:43.098	\N
2352678b-6afd-4154-90cf-8cfe3056f281	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\xcbda65c1af49c7f895d420f2286ebec8e2d933c123e0d9e278dbd11052	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	df1e2b85-e049-4c78-a468-2af9db41391c	2026-06-06 03:59:45.475	2026-06-05 18:29:08.377	2026-06-06 03:59:45.475	\N
bea50305-c46d-49e8-b545-f7fc28e26a87	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\\x16dbd7f855602e61f68ca3d21e14fbe5f132688b42561ca6159d73d07e	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fc918566-99d5-494d-8e4f-4281ecc30df6	2026-06-06 04:04:07.211	2026-05-31 16:25:54.582	2026-06-06 04:04:07.211	\N
724a986a-379d-41d4-bd39-46fcf1bd3407	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\x6941110d4bbadf072975ebd6a2ef8cd2fd93bfd624b68336d1443792d4	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	59668832-2a45-418f-869f-6e1bef691fce	2026-06-06 04:04:20.41	2026-06-05 18:29:08.377	2026-06-06 04:04:20.41	\N
b9ad1692-804c-4bae-9c64-baafc7444550	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\x3d9d3a1720c4b50e4faf22b6b70cf9b35245a503d3b5b0b1b9a082a43a	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4417f9ed-16e4-4213-968a-92e61b80e4e5	2026-06-06 04:04:28.476	2026-06-05 18:29:08.377	2026-06-06 04:04:28.476	\N
ca28272d-cb32-46f3-84a3-8de7ee734921	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\\xe14e1e79ef94898b54038d990ee40bc4a3919b60d8bcdee175b024ed7dc61468acfd	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b107e371-602b-441d-9e28-a1b434c15b38	2026-06-07 17:50:10.079	2026-05-25 18:49:16.893	2026-06-07 17:50:10.079	\N
31e1ddc0-885c-4a9d-a0c0-eabe988191bb	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\\xf8cf6a74ae00c552d1eca55de25b1a9365c9f67fc238c80ff8b1cb7103	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	12c769df-87b3-47f6-9b36-dca0750a1889	2026-06-07 17:50:22.882	2026-06-05 18:29:08.377	2026-06-07 17:50:22.882	\N
6d6257a5-ef59-46a8-97d2-5a3171703bd2	f7e18809-6daa-4cc4-8522-2b1b94f4f03b	\\xc76e69d14ad8235e0f7f7df9a0b55c1048b9c46566bc0369a570fcb0176feb	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	9cc59f88-9b0d-416f-82e5-866fa2644173	2026-06-21 13:58:55.255	2026-06-21 10:26:44.106	2026-06-21 13:58:55.255	\N
8084e5c5-fc17-48ce-b4f0-9e19e66ff353	9267c748-0bd9-4837-865e-6284602dce02	\\xeca1cd82e3608a88f951597396510e858b57678dd47884b4154594282a2ee2148c	AVAILABLE	\N	\N	\N	2026-06-21 19:19:20.645	2026-06-21 19:19:20.645	\N
ecd8fc43-b02a-4d2d-ad5e-8d52e159b011	9267c748-0bd9-4837-865e-6284602dce02	\\xc92d81c6bb4d2a612cd0049e0c6df801958d7703271624f389a52c0d1a00d6aba170	AVAILABLE	\N	\N	\N	2026-06-21 19:19:20.645	2026-06-21 19:19:20.645	\N
\.


--
-- Data for Name: mmo_products; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."mmo_products" ("id", "slug", "name", "thumbnail", "category", "category_group", "price", "description", "is_active", "is_featured", "display_order", "created_at", "updated_at", "deleted_at", "rating", "total_orders", "total_views", "requires_account_type", "requires_cccd", "section") FROM stdin;
9446f730-205a-42f2-ad8c-7d7b035e638f	tai-khoan-game	Tài Khoản Game	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780043767935.png	Game Liên Quân	Game	900000.00	\N	t	f	2	2026-05-29 08:36:14.095	2026-05-29 08:36:14.095	\N	0	0	0	f	f	TAI_NGUYEN_MMO
ee1eeca5-490a-462b-8be7-e4b14f61513f	tai-khoan-tiktok-1	Tài khoản tiktok 1	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780242940045.png	Tk tiktok	Tiktok	300000.00	Tài khoản reg mail trust hỗ trợ truy câp	t	f	3	2026-05-31 15:55:55.408	2026-05-31 15:55:55.408	\N	0	0	0	f	f	TAI_NGUYEN_MMO
c0828411-0c17-4fdb-a37c-67c101879466	tai-khoan-tiktok-2	Tài khoản tiktok 2	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780243007643.png	Tài khoản tiktok 2	Tiktok	200000.00	Tài khoản tiktok 2	t	f	3	2026-05-31 15:56:49.593	2026-05-31 15:56:49.593	\N	0	0	0	f	f	TAI_NGUYEN_MMO
44e26368-8fad-47ec-bafc-5ce03123a5b0	game-lien-quan	Game Liên quân	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780243053682.png	Liên quân	Game	200000.00	Game liên quân	t	f	2	2026-05-31 15:57:35.85	2026-05-31 15:57:35.85	\N	0	0	0	f	f	TAI_NGUYEN_MMO
4f5cf909-2e4b-493e-805f-c3fd6ffc6a83	game-lol	Game LOL	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780243099202.png	lol mobile	Game	1500000.00	Full skin hỗ trợ login	t	f	4	2026-05-31 15:58:47.536	2026-05-31 15:58:47.536	\N	0	0	0	f	f	TAI_NGUYEN_MMO
7a270438-cff5-4f5c-93a7-30d1e771bf9b	tai-khoan-intagram-co-trust-2021	Tài khoản intagram cổ trust 2021	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780244746727.png	intagram	Instagram	259000.00	Tài khoản intagram cổ trust 2021	t	f	1	2026-05-31 16:25:49.14	2026-06-06 15:46:25.445	\N	0	1	0	f	f	TAI_NGUYEN_MMO
f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	via	VIA Trust Us	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779642138078.png	Via 1m1	Facebook	99000.00	Via mới	t	f	1	2026-05-24 14:43:38.883	2026-06-06 16:16:02.434	\N	0	0	0	f	f	TAI_NGUYEN_MMO
3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	tai-khoan-tiktok	Tài khoản tiktok	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779734932645.png	Tài khoản tiktok 	Tiktok	360000.00	Tài khoản tiktok ...	t	f	1	2026-05-25 18:48:59.12	2026-06-07 17:50:10.079	\N	0	1	0	f	f	TAI_NGUYEN_MMO
7418205f-3c53-4823-ab68-d5c9a1b17f6a	tool-join-box-telegram	TOOL JOIN BOX TELEGRAM	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/mmo-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780684116099.png	tool telegram	Tool Telegram	500000.00	TOOL join box telegram trỏ thông tin nhóm đẩy data quản lý 	t	f	1	2026-06-05 18:28:49.913	2026-06-07 17:50:22.882	\N	0	3	0	f	f	TAI_NGUYEN_MMO
f7e18809-6daa-4cc4-8522-2b1b94f4f03b	aaaa	aaaa	\N	aaa	Facebook	1111.00	\N	t	f	0	2026-06-21 10:26:37.815	2026-06-21 13:58:55.255	\N	0	1	0	f	f	KHO_TAI_NGUYEN
9267c748-0bd9-4837-865e-6284602dce02	fanpage-20k-user	FANPAGE 20K USER	\N	Tài khoản fb cổ	Facebook	11111.00	\N	t	f	0	2026-06-21 19:19:12.095	2026-06-21 19:19:12.095	\N	0	0	0	f	f	KHO_TAI_NGUYEN
d57c5055-e229-4d0c-a4fa-27bbbaa60a74	aaa	aaa	\N	group 20k	Instagram	11111.00	\N	t	f	0	2026-06-22 06:22:27.063	2026-06-22 06:22:27.063	\N	0	0	0	f	f	TAI_NGUYEN_MMO
b9384472-6f75-4161-a94a-c6230c026dc9	adada	adada	\N	Group 10k	Instagram	1111.00	\N	t	f	0	2026-06-22 06:33:49.49	2026-06-22 06:33:49.49	\N	0	0	0	f	f	TAI_NGUYEN_MMO
\.


--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."modules" ("id", "code", "label", "icon", "description", "sort_order", "is_active", "created_at", "updated_at") FROM stdin;
1e1f1469-2421-4585-94a2-18b17c1a0391	dashboard	Dashboard	layout-dashboard	\N	0	t	2026-06-20 10:10:00.14	2026-06-20 17:56:17.612
b620d2ab-91b2-487e-bb1d-2a40b50d52cb	users	Quản lý User	users	\N	1	t	2026-06-20 10:10:00.172	2026-06-20 17:56:17.656
b72b03c8-bea1-46dc-a649-874bac3f9767	orders	Đơn hàng	shopping-cart	\N	2	t	2026-06-20 10:10:00.177	2026-06-20 17:56:17.662
4ad5b9c6-4c20-400e-b849-2af59216afa7	products	Sản phẩm / Dịch vụ	package	\N	3	t	2026-06-20 10:10:00.182	2026-06-20 17:56:17.666
6aae1572-a61e-4714-a06e-b366f2c82457	services	Dịch vụ	briefcase	\N	4	t	2026-06-20 17:56:17.67	2026-06-20 17:56:17.67
d801ef20-c21a-4bf4-8c46-8fb5b476c5a3	courses	Khóa học	graduation-cap	\N	5	t	2026-06-20 17:56:17.676	2026-06-20 17:56:17.676
326a4ee4-ae74-4983-8095-e2a2cd625421	tut_tricks	Tut Trick	lightbulb	\N	6	t	2026-06-20 17:56:17.68	2026-06-20 17:56:17.68
c046a18f-75a0-4e1c-a609-7076c07a2054	resources	Tài nguyên MMO	database	\N	7	t	2026-06-20 17:56:17.684	2026-06-20 17:56:17.684
1bd39221-ce50-4665-b856-01be5947503d	categories	Danh mục	folder	\N	8	t	2026-06-20 10:10:00.186	2026-06-20 17:56:17.689
d762db8c-9029-48a4-b2bf-2b6f48df65a4	finance	Tài chính	banknote	\N	9	t	2026-06-20 10:10:00.19	2026-06-20 17:56:17.693
951bef9c-2d30-48ea-97be-481781089083	complaints	Khiếu nại	alert-triangle	\N	10	t	2026-06-20 10:10:00.194	2026-06-20 17:56:17.697
6f614a18-2521-4b5d-b504-6a739059c1e2	chat	Trò chuyện	message-square	\N	11	t	2026-06-20 10:10:00.198	2026-06-20 17:56:17.701
9e1c6ed7-4019-4465-9971-d79b009aa23d	content	Nội dung & Thông báo	file-text	\N	12	t	2026-06-20 10:10:00.202	2026-06-20 17:56:17.706
239ff57d-f9bb-4a7b-923c-f56fced2a356	sellers	Quản lý Seller	store	\N	13	t	2026-06-20 10:10:00.206	2026-06-20 17:56:17.71
d32e6785-7751-4319-b86b-021dffdae3a6	seller_products	Sản phẩm Seller	tag	\N	14	t	2026-06-20 10:10:00.211	2026-06-20 17:56:17.714
14603784-cd6d-408b-8230-5ccb8915f0ee	transactions	Giao dịch & Logs	activity	\N	15	t	2026-06-20 10:10:00.215	2026-06-20 17:56:17.717
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."notifications" ("id", "user_id", "title", "body", "type", "is_read", "meta", "created_at") FROM stdin;
7cdfaed3-5376-4e0b-bbe3-d5f29d5bd111	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Facebook đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-05-25 08:59:46.604
24aeb9c2-7ce9-426b-a4fc-e898529aa7ed	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL0OIT1-96CB - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL0OIT1-96CB", "orderType": "SELLER_PRODUCT"}	2026-05-25 09:41:42.354
36b62fd1-62c8-4920-b2f9-7452411a623e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL0OWX2-4F48 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL0OWX2-4F48", "orderType": "SELLER_PRODUCT"}	2026-05-25 09:42:00.625
2de16ff5-ea27-4887-8857-7979746e35fc	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL0W1I1-89E1 - adđ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPL0W1I1-89E1", "orderType": "SELLER_PRODUCT"}	2026-05-25 09:47:33.16
6fc302ca-f6c4-49df-9043-c834f46d1a11	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL3W9S1-3A8F - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL3W9S1-3A8F", "orderType": "SELLER_PRODUCT"}	2026-05-25 11:11:42.747
08da2c7b-0763-47d0-bbce-ef00046b2e7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL3WE9E-1846 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL3WE9E-1846", "orderType": "SELLER_PRODUCT"}	2026-05-25 11:11:48.542
b415729b-b848-435e-b060-bc2e5fea30d7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPL3WHTW-D670 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPL3WHTW-D670", "orderType": "SELLER_PRODUCT"}	2026-05-25 11:11:53.165
44b26f53-096c-48a8-b8a7-4351c5ff01a0	f15fef1f-7843-44b0-b983-72068d1647c6	Tài khoản bị khóa	Tài khoản của bạn đã bị khóa bởi quản trị viên. Vui lòng liên hệ hỗ trợ để biết thêm chi tiết.	SYSTEM	f	\N	2026-05-25 11:21:08.9
de6deb8d-c421-4092-a2ec-9dbe6fbac1aa	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-25 18:19:07.582
5c6057a3-23ee-4a81-b8f4-eba0409df0d6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-25 18:19:15.375
14e0fc85-ef19-4e64-aaed-d42a70f25155	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-25 18:19:17.386
cccf8343-782e-4c7b-8160-32e79d04ca1f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-25 18:19:47.612
dc27bfc2-2e18-4d83-bf42-af5f150a988b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJKP5E-BCC5 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPLJKP5E-BCC5", "orderType": "MMO_PRODUCT"}	2026-05-25 18:30:36.651
6a10e3e9-c692-4841-9de8-d94dbe5181c9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJQHSA-4DA4 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPLJQHSA-4DA4", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:35:07.032
b18d7a6d-559f-4ce1-8b3b-77442eb2d150	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJQNSG-D1EF - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPLJQNSG-D1EF", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:35:14.811
d3f32a80-8502-4eae-8bac-627ff3d7339b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLJR013-E5AA - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPLJR013-E5AA", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:35:30.676
56f299a4-210f-4b2a-9326-106d2b6450d4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLK63X9-0789 - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPLK63X9-0789", "orderType": "SELLER_PRODUCT"}	2026-05-25 18:47:15.565
206478e1-72a8-4b97-a18a-95fcc74aec5d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPLX1VSQ-A7B6 - addad đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPLX1VSQ-A7B6", "orderType": "TUTTRICK"}	2026-05-26 00:47:53.416
6090e1d3-2a0e-45a2-b584-75fb1c5f64f4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM39U3T-D7D3 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM39U3T-D7D3", "orderType": "COURSE"}	2026-05-26 03:42:02.186
5f8060e8-e01a-4d27-8759-9c65bbd54682	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM39ZGY-D66B - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM39ZGY-D66B", "orderType": "COURSE"}	2026-05-26 03:42:09.122
81b111a4-3786-475b-8f69-a36ee48fd0c4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3A2JB-8ED7 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3A2JB-8ED7", "orderType": "COURSE"}	2026-05-26 03:42:13.093
9d7f5811-75a5-4ef0-b528-54585a2f9663	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3IYUY-54B2 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3IYUY-54B2", "orderType": "COURSE"}	2026-05-26 03:49:08.238
bfd7d243-5bcc-4af3-b3fc-b5e220063f92	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3JSTG-9C76 - Mở Khóa 282 đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3JSTG-9C76", "orderType": "SERVICE"}	2026-05-26 03:49:47.065
44ea059c-0e2f-47d8-b081-05e0663b4c83	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3PGY9-8FE4 - Mở Khóa 282 đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPM3PGY9-8FE4", "orderType": "SERVICE"}	2026-05-26 03:54:11.621
5a58c5a7-e26d-4a7b-b42b-e6173a052cee	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3Q7Y5-ECA1 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3Q7Y5-ECA1", "orderType": "SERVICE"}	2026-05-26 03:54:46.61
412dfa49-b10b-4212-844c-d187141f6c18	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3QSLD-FF3A - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3QSLD-FF3A", "orderType": "SERVICE"}	2026-05-26 03:55:13.361
f241eb75-0642-40d8-9299-b72dd8096f5f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3VR0N-2D53 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3VR0N-2D53", "orderType": "SERVICE"}	2026-05-26 03:59:04.603
1e13bd2d-c373-45c2-bb06-6a3b70fd7c9d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3XWWO-FC8B - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM3XWWO-FC8B", "orderType": "SERVICE"}	2026-05-26 04:00:45.539
bbdbe939-4413-4f7b-9b00-8b22a234c9ef	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3YN6L-EEAF - Mở Khóa Icloud (IPHONE 11) đã được xử lý.	PURCHASE	f	{"amount": "3500000.00", "orderCode": "ORD-MPM3YN6L-EEAF", "orderType": "SERVICE"}	2026-05-26 04:01:19.594
ed370ec5-746f-405d-b4e4-fab5da0a5425	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM3YPQR-0620 - Mở Khóa Icloud (IPHONE 11) đã được xử lý.	PURCHASE	f	{"amount": "3500000.00", "orderCode": "ORD-MPM3YPQR-0620", "orderType": "SERVICE"}	2026-05-26 04:01:22.908
4805cdef-e7a5-45dd-9052-da0698a667e0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM461QM-C459 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM461QM-C459", "orderType": "SERVICE"}	2026-05-26 04:07:05.053
83f14783-7ac0-4c50-95d2-8e19852c45ca	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPM4C203-D695 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPM4C203-D695", "orderType": "SERVICE"}	2026-05-26 04:11:45.334
8e6b88ee-4df0-440e-89db-8984b7ebd96c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMCIPU1-CD72 - ADADAD đã được xử lý.	PURCHASE	f	{"amount": "123213.00", "orderCode": "ORD-MPMCIPU1-CD72", "orderType": "SERVICE"}	2026-05-26 08:00:53.12
b64a8d3a-5507-4cdd-85fb-f003b30c65f0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMDLOCH-B175 - Tài khoản tiktok đã được xử lý.	PURCHASE	f	{"amount": "360000.00", "orderCode": "ORD-MPMDLOCH-B175", "orderType": "MMO_PRODUCT"}	2026-05-26 08:31:10.742
78f472c4-4b48-4be5-b543-59591b7a7e75	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản bị khóa	Tài khoản của bạn đã bị khóa bởi quản trị viên. Vui lòng liên hệ hỗ trợ để biết thêm chi tiết.	SYSTEM	f	\N	2026-05-26 08:44:34.695
14bb58b9-9c12-463f-9053-dd7c8a0581ac	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMLI8NH-90FE - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPMLI8NH-90FE", "orderType": "SELLER_PRODUCT"}	2026-05-26 12:12:27.364
136f3306-caa7-429c-b3fc-f382c0e4dc1c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMM60OP-0B88 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPMM60OP-0B88", "orderType": "TUTTRICK"}	2026-05-26 12:30:56.776
ab47d936-cea1-4da2-84d3-f67c9a00cef6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPMOWMMF-B02B - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPMOWMMF-B02B", "orderType": "MMO_PRODUCT"}	2026-05-26 13:47:37.495
ff433a65-ff7a-48bb-a65f-60297330a92e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPMOWMMF-B02B (VIA) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 14:36:24.665
7547b8fc-9b0f-482b-98c7-933b8affc084	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPMLI8NH-90FE (Tài khoản 250$) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 15:52:43.787
273a7af8-e8b7-4338-938e-3a5b067a48ea	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPLK63X9-0789 (BM FACEBOOK) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 17:40:05.03
8cac5d2e-ea72-40c2-aead-71b1b585e222	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Yêu cầu rút tiền bị từ chối	Yêu cầu rút tiền bị từ chối. Bạn có thể gửi yêu cầu mới. Lý do: Chưa xác  nhận thông tin	WITHDRAWAL_STATUS	f	\N	2026-05-26 20:01:06.256
63b5211f-73c5-4e77-8145-5340bb60402f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPMDLOCH-B175 (Tài khoản tiktok) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-26 20:23:02.781
0c9fa7fc-26bd-4c66-9979-68889fbd791a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPN3EO7U-AD0A - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPN3EO7U-AD0A", "orderType": "TUTTRICK"}	2026-05-26 20:33:33.996
850439f8-b950-4e97-b1f4-6cde7be99afa	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Game đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-05-27 07:31:01.867
ee7c331c-470a-46fe-93f7-cfd43c5ee297	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPNQYA6M-0093 - GAME LQMB đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPNQYA6M-0093", "orderType": "SELLER_PRODUCT"}	2026-05-27 07:32:40.095
c41f3e1e-ddf0-44f2-a93c-a7213ce92e88	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-27 07:37:39.869
ebf72fc9-cfbd-4d40-8bd9-f97ae34b212f	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-27 07:38:08.041
578d7365-94e8-4f72-90e5-c41ee5d35cb8	15bbcf73-c01d-4730-85d7-a1cca3730c83	Yêu cầu bán hàng bị từ chối	Lý do: a	SYSTEM	f	\N	2026-05-29 10:00:33.219
ed946dc9-5bce-4b36-b223-7a23e7811704	f15fef1f-7843-44b0-b983-72068d1647c6	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Facebook: a đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-05-29 10:02:37.815
aaf8691b-f620-4de2-ab5e-f12e872e1c2f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Yêu cầu rút tiền được duyệt	Yêu cầu rút 187.000đ đã được chấp thuận. Admin sẽ chuyển khoản cho bạn.	WITHDRAWAL_STATUS	f	\N	2026-05-29 19:04:47.167
4643ad6b-55d4-4a15-8f9d-e6fd0e955637	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Rút tiền hoàn thành	Đã chuyển khoản 187.000đ thành công.	WITHDRAWAL_STATUS	f	\N	2026-05-29 19:04:53.987
ba0586b6-ae62-4708-b7ba-dec3625d3e84	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPRANUOS-C863 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPRANUOS-C863", "orderType": "SELLER_PRODUCT"}	2026-05-29 19:07:44.321
894b1d1b-a68b-4b48-928a-eab2e3cb2c4a	f15fef1f-7843-44b0-b983-72068d1647c6	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-05-30 04:16:22.73
ccd011ac-dfb3-4a18-9092-e7ab0e3d6e0e	f15fef1f-7843-44b0-b983-72068d1647c6	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-05-30 04:16:25.764
a6c7c52d-76b0-4ca2-a562-e736b21f16cd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPT963BS-BA1A - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPT963BS-BA1A", "orderType": "COURSE"}	2026-05-31 04:01:28.46
e0e6ddf0-7347-445c-8162-3b9d596568fa	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPTAN5R2-3F44 - Khóa mmo đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MPTAN5R2-3F44", "orderType": "COURSE"}	2026-05-31 04:42:44.345
065e2c7c-e06e-4bec-b184-643e285c8134	15bbcf73-c01d-4730-85d7-a1cca3730c83	Đơn hàng hoàn thành	Đơn hàng ORD-MPTAN5R2-3F44 (Khóa mmo) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-31 06:53:39.571
fbfad40e-a376-4838-9d78-e0ba055435c6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPT963BS-BA1A (Khóa mmo) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-05-31 06:53:51.605
4769a5e9-6b9e-4172-876d-901faeaf31d8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPTFGZ6F-8A3E - Via Facebook Clone 2019 đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPTFGZ6F-8A3E", "orderType": "SELLER_PRODUCT"}	2026-05-31 06:57:53.958
8138d419-d727-40f0-8583-173db961651d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUMX1FC-DB2D - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MPUMX1FC-DB2D", "orderType": "SELLER_PRODUCT"}	2026-06-01 03:14:06.871
d840cf30-75a0-4702-be8d-e55edd152d4e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUMXD13-5470 - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPUMXD13-5470", "orderType": "SELLER_PRODUCT"}	2026-06-01 03:14:21.892
720de727-34b0-443e-bcc7-407ab077527b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX61HR-7845 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUX61HR-7845", "orderType": "MMO_PRODUCT"}	2026-06-01 08:01:03.017
a180e71f-d36d-462f-99a2-188efd8f1af8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX648F-D916 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUX648F-D916", "orderType": "MMO_PRODUCT"}	2026-06-01 08:01:06.556
f5b1b1c6-dccc-4a57-a147-1f3dd5b753bd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX7A14-253D - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPUX7A14-253D", "orderType": "TUTTRICK"}	2026-06-01 08:02:00.728
71950e69-69f5-4505-8509-75eef6eaf48d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUX89MH-B3A6 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUX89MH-B3A6", "orderType": "TUTTRICK"}	2026-06-01 08:02:46.862
cd67d357-53a5-4547-abd5-8b0e7430c363	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXB4P5-C1D1 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXB4P5-C1D1", "orderType": "MMO_PRODUCT"}	2026-06-01 08:05:00.444
867ccf35-a7d1-40fd-9b44-ab0841186f85	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXE1C5-19AD - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXE1C5-19AD", "orderType": "TUTTRICK"}	2026-06-01 08:07:16.055
92f97643-0b63-490d-9926-19b926f3366f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXE6OB-E73A - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXE6OB-E73A", "orderType": "TUTTRICK"}	2026-06-01 08:07:22.971
c3c3032a-5acb-477e-8ebf-847a14236b1c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXEX0Q-5AF7 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPUXEX0Q-5AF7", "orderType": "TUTTRICK"}	2026-06-01 08:07:57.12
9b57939c-0ca7-4a48-82f9-a8127aeb40ba	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXJL8I-59AB - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPUXJL8I-59AB", "orderType": "TUTTRICK"}	2026-06-01 08:11:35.123
19116d20-a8fb-4bbd-bb3c-eb3a056def47	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPUXJQRT-0AC3 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPUXJQRT-0AC3", "orderType": "TUTTRICK"}	2026-06-01 08:11:42.293
49de450d-3cfd-4b81-9df4-4a0066ceac85	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPV71IR1-20B9 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPV71IR1-20B9", "orderType": "TUTTRICK"}	2026-06-01 12:37:28.259
8622b17c-0792-4550-8900-4696003ee7f7	15bbcf73-c01d-4730-85d7-a1cca3730c83	Mua hàng thành công	Đơn hàng ORD-MPV71PPA-F2DD - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPV71PPA-F2DD", "orderType": "TUTTRICK"}	2026-06-01 12:37:37.259
7b98700f-5f41-4e4d-b177-9aad113bbffe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWFPP28-E993 - Tài khoản 250$ đã được xử lý.	PURCHASE	f	{"amount": "50000.00", "orderCode": "ORD-MPWFPP28-E993", "orderType": "SELLER_PRODUCT"}	2026-06-02 09:27:59.299
27c9ea0c-29d6-44a7-b5d6-2fbf01d78e96	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWFZ86P-BA58 - Via Facebook Clone 2019 đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPWFZ86P-BA58", "orderType": "SELLER_PRODUCT"}	2026-06-02 09:35:24.019
b5514670-3b4b-45a7-85b4-3bb0fb478bdb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWGSVM5-BB6C - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPWGSVM5-BB6C", "orderType": "MMO_PRODUCT"}	2026-06-02 09:58:27.36
162fb144-912e-4416-b4d8-58fdb98f7784	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWMD2BA-DD81 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MPWMD2BA-DD81", "orderType": "TUTTRICK"}	2026-06-02 12:34:07.245
986676fd-6c10-4c79-bc5a-5acf135db16c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWMDBKR-95C7 - GAME LQMB đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MPWMDBKR-95C7", "orderType": "SELLER_PRODUCT"}	2026-06-02 12:34:19.238
4ebee96d-a3d6-407a-be05-6afaf8aae86e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPWMDI04-90DA - KHÓA HỌC MMO đã được xử lý.	PURCHASE	f	{"amount": "1599000.00", "orderCode": "ORD-MPWMDI04-90DA", "orderType": "COURSE"}	2026-06-02 12:34:27.568
f5f6cf05-41da-4cc3-8c47-cc58454f464b	15bbcf73-c01d-4730-85d7-a1cca3730c83	Yêu cầu bán hàng bị từ chối	Lý do: ad	SYSTEM	f	\N	2026-06-02 19:19:27.024
3080a5ea-411a-4dc7-a26b-8f095afc5e7e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPX17R5I-CBA2 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPX17R5I-CBA2", "orderType": "TUTTRICK"}	2026-06-02 19:29:53.746
fa3bfc56-1ad8-4d1b-bbe2-ee39ec48db5e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZ75MTQ-E24D - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MPZ75MTQ-E24D", "orderType": "TUTTRICK"}	2026-06-04 07:51:44.871
3fa6b70f-a64d-4c2c-a6c0-f9ec80447d2e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZ773EE-3590 - Mở Khóa Icloud (IPHONE 12) đã được xử lý.	PURCHASE	f	{"amount": "3800000.00", "orderCode": "ORD-MPZ773EE-3590", "orderType": "SERVICE"}	2026-06-04 07:52:52.996
b5691817-52b8-47c6-a89a-4b613ce3e4c0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã bị khóa	Admin đã khóa gian hàng. Sản phẩm sẽ ẩn và bạn không thể rút tiền cho đến khi được mở khóa.	SYSTEM	f	\N	2026-06-04 11:28:30.131
e8940f35-e3a3-4a04-abe2-fa4b9293b4d5	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Gian hàng của bạn đã được mở khóa	Admin đã mở khóa gian hàng. Bạn có thể tiếp tục bán hàng bình thường.	SYSTEM	f	\N	2026-06-04 11:36:05.927
e8b6af3e-059f-4702-9f4a-e89a427b6a13	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZF6L8O-9ACC - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MPZF6L8O-9ACC", "orderType": "SELLER_PRODUCT"}	2026-06-04 11:36:26.395
1a1992c0-a3bf-42db-a794-f1237bde68ea	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MPZGYUMW-90E2 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MPZGYUMW-90E2", "orderType": "TUTTRICK"}	2026-06-04 12:26:24.55
610b3cd9-14af-404d-94f2-0d89e95e4f33	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPZ773EE-3590 (Mở Khóa Icloud (IPHONE 12)) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:00:59.631
5427af95-2b71-4c21-8829-20294345782a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPZ773EE-3590 (Mở Khóa Icloud (IPHONE 12)) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:02:08.522
fa0d1915-15d2-4ce9-ae21-fbf18edd4f31	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPWMDI04-90DA (KHÓA HỌC MMO) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:03:14.447
d428d30d-93f1-4452-897a-8689a6ba4ef8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPWMDI04-90DA (KHÓA HỌC MMO) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-04 13:03:29.451
bbed9e15-2012-4938-bd4c-6daf061e1745	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14L0VC-C244 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ14L0VC-C244", "orderType": "TUTTRICK"}	2026-06-05 16:15:16.411
9ce2b7ed-7c3a-4544-9f1a-b6059c957414	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14M885-60D8 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ14M885-60D8", "orderType": "TUTTRICK"}	2026-06-05 16:16:12.593
f030ef62-7f4b-40ad-8c34-e3430a7288a6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14RY9L-29D2 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ14RY9L-29D2", "orderType": "TUTTRICK"}	2026-06-05 16:20:39.631
b01f5b53-d481-4296-9ed2-6f744005b6d8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14S3XN-6367 - TUT Mở khóa tài khoản Faq đã được xử lý.	PURCHASE	f	{"amount": "950.00", "orderCode": "ORD-MQ14S3XN-6367", "orderType": "TUTTRICK"}	2026-06-05 16:20:46.967
4541ac24-228f-4988-941f-363edea2392b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ14SORE-139D - TUT Mở khóa tài khoản Faq đã được xử lý.	PURCHASE	f	{"amount": "950.00", "orderCode": "ORD-MQ14SORE-139D", "orderType": "TUTTRICK"}	2026-06-05 16:21:13.96
5e78f325-64e8-4a17-a513-56f2f3cadd1b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ150QYR-3056 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ150QYR-3056", "orderType": "TUTTRICK"}	2026-06-05 16:27:30.075
12ccd949-3cee-473e-bd5e-bf5c2752771a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ153DAQ-7E07 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "95000.00", "orderCode": "ORD-MQ153DAQ-7E07", "orderType": "TUTTRICK"}	2026-06-05 16:29:32.33
13d5cdac-29fd-48a8-8bdb-53f31a4df6a3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ157SRS-212D - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ157SRS-212D", "orderType": "TUTTRICK"}	2026-06-05 16:32:58.997
161f548d-8336-46ac-b4b6-cfdb0d96d080	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ158E6W-DD42 - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "95000.00", "orderCode": "ORD-MQ158E6W-DD42", "orderType": "TUTTRICK"}	2026-06-05 16:33:26.766
ee21f6bb-9161-4c58-88db-1ed9bf9a0c4e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ158IDK-7E3C - TUT MỞ  KHÓA TIKTOK HẠN CHẾ đã được xử lý.	PURCHASE	f	{"amount": "95000.00", "orderCode": "ORD-MQ158IDK-7E3C", "orderType": "TUTTRICK"}	2026-06-05 16:33:32.178
79b27d5d-0ea9-4ce4-a6dd-26672ef8ee7d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15APIE-7D78 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15APIE-7D78", "orderType": "TUTTRICK"}	2026-06-05 16:35:14.736
5e113462-fc6f-4181-9cab-4cbefb81b3bb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15DQ08-2B1B - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15DQ08-2B1B", "orderType": "TUTTRICK"}	2026-06-05 16:37:35.359
f17f63a2-12c2-47dd-87d0-65394ec373e4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15E5C1-7536 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15E5C1-7536", "orderType": "TUTTRICK"}	2026-06-05 16:37:55.211
84262be7-6798-4b7f-a809-709963e377fe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15G40X-E560 - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15G40X-E560", "orderType": "TUTTRICK"}	2026-06-05 16:39:26.838
70ba364a-bc37-4d02-b7fb-f0c33ec14b19	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15GH4S-63FA - TUT UNLOCK 282 đã được xử lý.	PURCHASE	f	{"amount": "94050.00", "orderCode": "ORD-MQ15GH4S-63FA", "orderType": "TUTTRICK"}	2026-06-05 16:39:43.814
66bb4d09-f7af-48fd-8f33-55f789063746	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ15LVC4-C082 - VIA đã được xử lý.	PURCHASE	f	{"amount": "99000.00", "orderCode": "ORD-MQ15LVC4-C082", "orderType": "MMO_PRODUCT"}	2026-06-05 16:43:55.517
dca86d13-3c3f-47cf-8242-c4267d046e09	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ18NHPR-B453 - Game Liên quân đã được xử lý.	PURCHASE	f	{"amount": "200000.00", "orderCode": "ORD-MQ18NHPR-B453", "orderType": "MMO_PRODUCT"}	2026-06-05 18:09:10.08
70d8d0ab-7564-40e1-b394-224d97b99443	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TQJVF-241A - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TQJVF-241A", "orderType": "MMO_PRODUCT"}	2026-06-06 03:59:24.727
cb8f8575-4fd6-4b09-a989-4d4ca3901c32	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TQY2R-7433 - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TQY2R-7433", "orderType": "MMO_PRODUCT"}	2026-06-06 03:59:43.118
b0ff9fbb-4df8-454d-bcc0-4c24b4776f86	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TQZWL-06F0 - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TQZWL-06F0", "orderType": "MMO_PRODUCT"}	2026-06-06 03:59:45.486
a98e5adf-87bf-463b-b970-ec1f58375dcb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TWLVU-E312 - Tài khoản intagram cổ trust 2021 đã được xử lý.	PURCHASE	f	{"amount": "259000.00", "orderCode": "ORD-MQ1TWLVU-E312", "orderType": "MMO_PRODUCT"}	2026-06-06 04:04:07.256
af782809-4c01-4221-ae64-5f41c7031d27	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TWW20-C01C - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TWW20-C01C", "orderType": "MMO_PRODUCT"}	2026-06-06 04:04:20.435
8f744aec-199c-42c1-80ad-bb068f896dfe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ1TX2A2-617D - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ1TX2A2-617D", "orderType": "MMO_PRODUCT"}	2026-06-06 04:04:28.501
6ecf555c-ae34-4ea2-a20d-a5ef0b6ebf39	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ24NLH2-BC97 - Đánh giá GG MAP VIP đã được xử lý.	PURCHASE	f	{"amount": "570000.00", "orderCode": "ORD-MQ24NLH2-BC97", "orderType": "SERVICE"}	2026-06-06 09:05:02.61
7aabf0f0-2501-41f3-b9d3-c1db79b670cd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ24OPTI-87C7 - KHÓA HỌC MMO đã được xử lý.	PURCHASE	f	{"amount": "1519050.00", "orderCode": "ORD-MQ24OPTI-87C7", "orderType": "COURSE"}	2026-06-06 09:05:54.884
bd0ef247-f45c-43ff-a80e-b041f83f02be	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2FYIH0-35D0 - GAME LQMB đã được xử lý.	PURCHASE	f	{"amount": "79000.00", "orderCode": "ORD-MQ2FYIH0-35D0", "orderType": "SELLER_PRODUCT"}	2026-06-06 14:21:27.726
789b7360-aae2-41fd-b849-57e2ccd53625	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2H1ZS6-EE65 - Mở Khóa Icloud (IPHONE 15 PLUS) đã được xử lý.	PURCHASE	f	{"amount": "11875000.00", "orderCode": "ORD-MQ2H1ZS6-EE65", "orderType": "SERVICE"}	2026-06-06 14:52:09.715
2364fdb7-f9a9-43f1-8b8f-ef2cc12bdbf0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2H2LWE-5F51 - Khóa Học Chạy Quảng Cáo Tiktok đã được xử lý.	PURCHASE	f	{"amount": "12349050.00", "orderCode": "ORD-MQ2H2LWE-5F51", "orderType": "COURSE"}	2026-06-06 14:52:38.38
8adff912-5730-4951-b8fc-b44d1de0b4fd	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ2H2VO4-2430 - TUT MỞ KHÓA CHAT META đã được xử lý.	PURCHASE	f	{"amount": "190000.00", "orderCode": "ORD-MQ2H2VO4-2430", "orderType": "TUTTRICK"}	2026-06-06 14:52:51.04
08bf9dc5-9a16-490c-ab8b-b08fc84af542	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H1ZS6-EE65 (Mở Khóa Icloud (IPHONE 15 PLUS)) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:33.804
15cffe80-5cd6-4ca6-8df5-e46c55087972	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ24NLH2-BC97 (Đánh giá GG MAP VIP) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:44.95
311ed61c-42b7-41ff-a480-678c64972016	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2LWE-5F51 (Khóa Học Chạy Quảng Cáo Tiktok) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:54.017
54e91cf1-e979-4839-8f21-6efe8fdb7462	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ24OPTI-87C7 (KHÓA HỌC MMO) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:23:55.58
240b99d1-7f66-4241-80ab-e94225d8159d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPLJR013-E5AA (Tài khoản 250$) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:24:51.62
8ae1d3d0-fd2c-4950-b735-34c0008899f8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MPL0W1I1-89E1 (adđ) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 16:25:00.791
1051a367-08fe-4e38-9f30-848bd6e12dea	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2VO4-2430 (TUT MỞ KHÓA CHAT META) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 18:05:33.508
1a04856d-dbe5-43ac-bd7e-828d7c6a82f8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2VO4-2430 (TUT MỞ KHÓA CHAT META) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 18:45:48.414
d1ff6ac5-4520-4013-b860-efb6c6c9827f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Đơn hàng hoàn thành	Đơn hàng ORD-MQ2H2VO4-2430 (TUT MỞ KHÓA CHAT META) đã được xác nhận hoàn thành.	ORDER_STATUS	f	\N	2026-06-06 18:48:02.567
d276fd0f-d639-402f-ac3a-b59e9f4be058	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ42URI7-1630 - Tài khoản tiktok đã được xử lý.	PURCHASE	f	{"amount": "360000.00", "orderCode": "ORD-MQ42URI7-1630", "orderType": "MMO_PRODUCT"}	2026-06-07 17:50:10.144
4164c3db-cb3f-47e2-becc-e607beee9d71	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQ42V1DG-3B3E - TOOL JOIN BOX TELEGRAM đã được xử lý.	PURCHASE	f	{"amount": "500000.00", "orderCode": "ORD-MQ42V1DG-3B3E", "orderType": "MMO_PRODUCT"}	2026-06-07 17:50:22.913
127dd1be-8eb2-45df-97dc-d971b367de36	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQM89MB5-9476 - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQM89MB5-9476", "orderType": "SELLER_PRODUCT"}	2026-06-20 10:41:32.491
2d2187f6-a486-41c9-8102-b4aae8608b27	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQNUQUTT-3EDC - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQNUQUTT-3EDC", "orderType": "SELLER_PRODUCT"}	2026-06-21 13:58:34.403
d5a0c815-4c27-4984-9d58-bd6d0a5f251e	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQNURAXZ-72B3 - aaaa đã được xử lý.	PURCHASE	f	{"amount": "1111.00", "orderCode": "ORD-MQNURAXZ-72B3", "orderType": "MMO_PRODUCT"}	2026-06-21 13:58:55.285
79ce8f39-eaa7-47e2-b3bb-22e17b5a4af7	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO0YK3A-CE8D - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO0YK3A-CE8D", "orderType": "SELLER_PRODUCT"}	2026-06-21 16:52:31.431
aecf50bd-c95a-4808-a985-d365b1326b34	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO14EHL-A7F0 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO14EHL-A7F0", "orderType": "SELLER_PRODUCT"}	2026-06-21 16:57:04.1
7ff945ba-25cc-4de2-ac4c-19b91e32ecf5	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQO1P5CN-B932 - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQO1P5CN-B932", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:13:12.044
318759a5-0fb5-4cb8-9a77-bc5130788e03	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO1PJP2-E3FC - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQO1PJP2-E3FC", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:13:30.624
9b6111ba-d69a-4c0d-964a-a6e0a397da24	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO22XBK-1E40 - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQO22XBK-1E40", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:23:54.819
9c20d5d1-f019-4d3b-b92b-2210009c1eca	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO281A5-0935 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO281A5-0935", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:27:53.224
4ed4e08f-898f-4095-adff-71775cbf0238	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO29FHT-FCD7 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO29FHT-FCD7", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:28:58.302
7af22194-fb34-4a4b-aa5a-86e1fb838fc6	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO2AYBW-6ED4 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO2AYBW-6ED4", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:30:09.368
cc39cf2f-67ef-4288-ae79-60cbcc7b83b6	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO2NULE-DA0F - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO2NULE-DA0F", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:40:11.08
da2dc2c6-ee66-48c3-9ed5-5b8d10bea055	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO335N6-B80B - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO335N6-B80B", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:52:05.22
b1f95239-6e78-4b6e-80cf-0e6dd3b3d73c	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO3AW9K-D347 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO3AW9K-D347", "orderType": "SELLER_PRODUCT"}	2026-06-21 17:58:06.308
417a589f-e3e9-4228-8d33-229034893325	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO3DJJX-4E67 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO3DJJX-4E67", "orderType": "SELLER_PRODUCT"}	2026-06-21 18:00:09.802
abcaa5da-de28-43a3-99c4-19b9c24dff4e	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO3I5FZ-059D - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO3I5FZ-059D", "orderType": "SELLER_PRODUCT"}	2026-06-21 18:03:44.796
53613fee-1b8b-4289-b4f7-e48a23642203	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO3J94S-615E - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO3J94S-615E", "orderType": "SELLER_PRODUCT"}	2026-06-21 18:04:36.23
27d02e78-3466-46de-a36d-8a1591f2a931	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO3U0YM-A2E6 - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQO3U0YM-A2E6", "orderType": "SELLER_PRODUCT"}	2026-06-21 18:12:58.858
a55422e8-4e25-43f9-8130-93e7afb5d5d3	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO49NT6-295F - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQO49NT6-295F", "orderType": "SELLER_PRODUCT"}	2026-06-21 18:25:08.307
d52c11b5-64e1-4cef-98f3-61336d9fe48f	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO4Q4YK-2ECD - BM FACEBOOK đã được xử lý.	PURCHASE	f	{"amount": "100000.00", "orderCode": "ORD-MQO4Q4YK-2ECD", "orderType": "SELLER_PRODUCT"}	2026-06-21 18:37:57.032
86fea6df-20c1-4c0a-bdc5-445dad330d14	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO5O5IB-028D - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO5O5IB-028D", "orderType": "SELLER_PRODUCT"}	2026-06-21 19:04:24.046
dd952233-3c53-4183-9255-e8d05417c30f	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO68FW3-94C2 - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO68FW3-94C2", "orderType": "SELLER_PRODUCT"}	2026-06-21 19:20:10.625
c07121f3-784b-4364-88be-05cb169eaaa7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Mua hàng thành công	Đơn hàng ORD-MQO6T9SW-E2CF - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO6T9SW-E2CF", "orderType": "SELLER_PRODUCT"}	2026-06-21 19:36:22.518
4296e498-1f8a-4598-bdd8-326520d1a9d4	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQO6TLFQ-97FE - Tài khoản quảng cáo đã được xử lý.	PURCHASE	f	{"amount": "10000.00", "orderCode": "ORD-MQO6TLFQ-97FE", "orderType": "SELLER_PRODUCT"}	2026-06-21 19:36:37.585
bbb9a31b-6a0f-49c1-a2b8-0c7a2c984aa6	e580851a-de0a-48bc-b0a0-922784cbbd2c	Mua hàng thành công	Đơn hàng ORD-MQOSRERP-B657 - Vip đã được xử lý.	PURCHASE	f	{"amount": "5000.00", "orderCode": "ORD-MQOSRERP-B657", "orderType": "SELLER_PRODUCT"}	2026-06-22 05:50:47.203
b97c2773-b9ca-454a-a38c-bd556688269a	e580851a-de0a-48bc-b0a0-922784cbbd2c	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Instagram đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-06-22 07:22:03.552
3002ac63-cd67-4139-a094-0edfd7d4b85c	9c652e2d-15d7-42d8-9b96-1179145dd096	Tài khoản bán hàng được duyệt	Tài khoản seller danh mục Facebook đã được phê duyệt.	SELLER_APPROVED	f	\N	2026-06-22 07:51:57.733
d8491d30-33a9-4b2b-8031-0c1e3d85dd2b	e580851a-de0a-48bc-b0a0-922784cbbd2c	Nạp tiền thành công	Admin nạp thủ công: Cộng. Số dư mới: 19693889đ	DEPOSIT	f	{"amount": "10000000.00", "referenceCode": "MANUAL-15BBCF-1782153021824"}	2026-06-22 18:30:21.875
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."orders" ("id", "order_code", "user_id", "order_type", "service_id", "course_id", "tut_trick_id", "mmo_product_id", "seller_product_id", "seller_id", "item_name", "original_price", "final_price", "warranty_variant", "payment_method", "status", "delivered_item_id", "idempotency_key", "created_at", "updated_at", "completed_at", "customer_note", "withdrawn", "tut_trick_content_url_enc", "tut_trick_docs") FROM stdin;
f446c556-1e25-44c6-9a80-08a7790c678e	ORD-MQO5O5IB-028D	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	ac690ba9-fe91-4be0-ac03-c09a38e085bb	2fcff910-7c5d-4218-97d5-ffffa50d8069	2026-06-21 19:04:24.036	2026-06-21 19:35:41.115	2026-06-21 19:04:24.035	\N	t	\N	\N
70855275-0c52-41a1-98b8-9f1364f119c5	ORD-MPLX1VSQ-A7B6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	addad	100000.00	100000.00	\N	BALANCE	DONE	\N	afdfc054-eb93-4e4d-965b-db838c025208	2026-05-26 00:47:53.404	2026-05-26 00:47:53.404	2026-05-26 00:47:53.402	\N	f	\N	\N
6da836ad-b3b7-45d6-8825-fc6fa2621f3e	ORD-MPM39U3T-D7D3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	622a0e6b-aa57-4bd0-8902-9c6ffce62f3e	2026-05-26 03:42:02.158	2026-05-26 03:42:02.158	2026-05-26 03:42:02.154	{"name":"Chuquangdoanh"}	f	\N	\N
82e4ba46-1263-4f62-96cb-8462ea8f5ae7	ORD-MPM39ZGY-D66B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	1ab85dbb-6049-490b-91fb-5f9a5b07be39	2026-05-26 03:42:09.107	2026-05-26 03:42:09.107	2026-05-26 03:42:09.106	{"phone":"0929990999","name":"Chuquangdoanh"}	f	\N	\N
6d45fd7c-1ffe-4f1e-9de0-7db36147c12a	ORD-MPM3A2JB-8ED7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	9a2e4453-6513-4d3f-af0a-409b9bab835a	2026-05-26 03:42:13.08	2026-05-26 03:42:13.08	2026-05-26 03:42:13.079	{"phone":"0939990999","name":"Chuquangdoanh"}	f	\N	\N
a182c6df-0a9e-4418-998c-60862168023b	ORD-MPM3IYUY-54B2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	ae17d81d-7d1a-4994-a474-8b220cf364ee	2026-05-26 03:49:08.22	2026-05-26 03:49:08.22	2026-05-26 03:49:08.219	{"phone":"0992999000","name":"Chuquangdoanh"}	f	\N	\N
963438b7-fb49-4e25-a2bf-c1894bd1a00d	ORD-MPM3JSTG-9C76	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	1700c5db-6a48-48bf-9c5c-57037050267d	\N	\N	\N	\N	\N	Mở Khóa 282	200000.00	200000.00	\N	BALANCE	DONE	\N	1d80036a-7108-4d26-8beb-8d447ed10d1d	2026-05-26 03:49:47.047	2026-05-26 03:49:47.047	2026-05-26 03:49:47.045	{"link":"a","accountPass":"a","gmailPass":"a","zaloPhone":"098765422345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767380916.jpg"}	f	\N	\N
91387efa-602f-4240-b366-7d26464b3eb9	ORD-MPM3PGY9-8FE4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	1700c5db-6a48-48bf-9c5c-57037050267d	\N	\N	\N	\N	\N	Mở Khóa 282	200000.00	200000.00	\N	BALANCE	DONE	\N	069d76e6-9dc7-42b3-872b-de309c14b976	2026-05-26 03:54:11.602	2026-05-26 03:54:11.602	2026-05-26 03:54:11.601	{"link":"a","accountPass":"a","gmailPass":"a","zaloPhone":"098765422345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767380916.jpg"}	f	\N	\N
a4b0ce0c-67b8-43df-8998-42e8634fb403	ORD-MPM3Q7Y5-ECA1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	de90cdb1-275b-4438-85f9-347846ff3f33	2026-05-26 03:54:46.592	2026-05-26 03:54:46.592	2026-05-26 03:54:46.59	{"link":"á","accountPass":"q","gmailPass":"q","zaloPhone":"0987654345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767682906.jpg"}	f	\N	\N
1d3d9688-8042-4381-ad04-ffa209c312ec	ORD-MPM3QSLD-FF3A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	f96167e4-2dea-4297-a0df-88d8d092070b	2026-05-26 03:55:13.346	2026-05-26 03:55:13.346	2026-05-26 03:55:13.345	{"link":"http://localhost:3000/dich-vu","accountPass":"àdsds","gmailPass":"ad@gmail.com","zaloPhone":"0987654345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767682906.jpg"}	f	\N	\N
63c430ef-bd77-4eb2-ae85-bdc782c9f5d7	ORD-MPM3VR0N-2D53	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	a86933d9-2176-4a15-953a-bb75da73d22f	2026-05-26 03:59:04.584	2026-05-26 03:59:04.584	2026-05-26 03:59:04.583	{"link":"http://localhost:3000/dich-vu","accountPass":"àdsds","gmailPass":"ad@gmail.com","zaloPhone":"0987654345","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767682906.jpg"}	f	\N	\N
821c5caf-09f4-4071-b258-aecc86aa7701	ORD-MPM3XWWO-FC8B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	b761888c-5715-48db-bf8f-27dd1595bdb5	2026-05-26 04:00:45.529	2026-05-26 04:00:45.529	2026-05-26 04:00:45.529	{"link":"424234","accountPass":"adsd","gmailPass":"ad","zaloPhone":"09876544567","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779767962668.jpg"}	f	\N	\N
e9662536-42f5-4b78-86a5-2207088c8a0d	ORD-MPM3YN6L-EEAF	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 11)	3500000.00	3500000.00	24 GIỜ	BALANCE	DONE	\N	6ae6e18a-bb82-4c1c-a6a7-8ecba1ff0391	2026-05-26 04:01:19.583	2026-05-26 04:01:19.583	2026-05-26 04:01:19.582	{"imei":"3453345323424321","zaloPhone":"0393118789"}	f	\N	\N
1aaff007-ccf1-453c-93f7-a0e8114e876a	ORD-MPM3YPQR-0620	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 11)	3500000.00	3500000.00	24 GIỜ	BALANCE	DONE	\N	595b34de-16b4-4ede-be4d-6beaff7f3b4c	2026-05-26 04:01:22.9	2026-05-26 04:01:22.9	2026-05-26 04:01:22.899	{"imei":"3453345323424321","zaloPhone":"0393118789","note":"312"}	f	\N	\N
1816facb-ba21-4fd9-a765-b62ed9c6e934	ORD-MPM461QM-C459	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	287ef7e7-6ff6-4b2b-84f8-08845451f16a	2026-05-26 04:07:05.04	2026-05-26 04:07:05.04	2026-05-26 04:07:05.039	{"link":"dádadasda","accountPass":"dfsgsdgsg","gmailPass":"fsg@gmail.com","zaloPhone":"09874567654","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779768421599.jpg"}	f	\N	\N
373ca467-4600-4dfa-a72e-76b20d5abb52	ORD-MPLJKP5E-BCC5	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	e5b6563f-af22-4325-920c-2cb477347ae1	c2810faa-7301-4d6f-af35-87a8d880ec0b	2026-05-25 18:30:36.629	2026-05-26 20:28:34.823	2026-05-25 18:30:36.627	\N	f	\N	\N
7c9cddea-a5d2-4c01-9ad9-74f88917b4c4	ORD-MPL0OIT1-96CB	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	98634793-a566-4c0d-b09f-5595edda622d	e512afaa-5243-486c-8b0d-010fc129c4fc	2026-05-25 09:41:42.332	2026-05-29 19:04:47.09	2026-05-25 09:41:42.326	\N	t	\N	\N
33ba99d2-4f44-4cf5-a5e5-fbe849a5991d	ORD-MPWGSVM5-BB6C	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	07c1e75d-c61e-44a6-8483-58deed22e179	08ec90c0-e0fe-4056-8a3a-9432ee6812ae	2026-06-02 09:58:27.347	2026-06-02 09:58:27.347	2026-06-02 09:58:27.342	\N	f	\N	\N
3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05	ORD-MPWFZ86P-BA58	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	a4a52a6a-5914-4f9d-9c07-606b73a5e842	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Via Facebook Clone 2019	79000.00	79000.00	\N	BALANCE	DONE	1750c1f0-5345-45ff-9ddd-79fa723c458a	8c1debbc-85f6-43ee-87b2-7acee0d1f431	2026-06-02 09:35:23.956	2026-06-04 03:10:58.376	2026-06-02 09:35:23.954	\N	f	\N	\N
b34e9db7-b2de-41a5-8ecb-a0301ead185f	ORD-MPLJR013-E5AA	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	3b4e4d9d-e186-4649-a234-947e02fd0589	42b4a39f-488a-4f03-aa40-e9024d82df62	2026-05-25 18:35:30.666	2026-06-06 16:24:51.616	2026-06-06 16:24:51.615	\N	f	\N	\N
d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	ORD-MPL0W1I1-89E1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	adđ	50000.00	50000.00	\N	BALANCE	DONE	f940b9bc-f26e-40e8-936b-5ae39ac8062c	e4dd425f-b725-4517-a06c-3eb9fdbd06ac	2026-05-25 09:47:33.148	2026-06-06 16:25:00.787	2026-06-06 16:25:00.787	\N	f	\N	\N
9218d70d-bfcf-4a3b-8e76-cbf1596fd87a	ORD-MQO2NULE-DA0F	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	REFUNDED	2cf35fb0-71aa-4ea4-9966-45261117c99b	f49b4893-5ace-404c-a696-24d595e5112a	2026-06-21 17:40:11.044	2026-06-21 17:51:26.863	2026-06-21 17:40:11.043	\N	f	\N	\N
00e2ffad-5f6e-4412-8887-795bf68af323	ORD-MQO335N6-B80B	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	REFUNDED	a7b7a38d-cf68-4c02-8f50-78c31b9d3298	5dcb95da-48e2-4517-b099-f6c92ea506e1	2026-06-21 17:52:05.205	2026-06-21 17:53:12.868	2026-06-21 17:52:05.203	\N	f	\N	\N
6ab4b9ce-c56b-447f-a4aa-47febc746300	ORD-MQO3AW9K-D347	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	REFUNDED	fd2f217e-0621-450c-8a92-7b6fd784e3a4	01568745-72df-4104-90f1-91ac7b7e8267	2026-06-21 17:58:06.299	2026-06-21 17:59:21.985	2026-06-21 17:58:06.297	\N	f	\N	\N
d6143418-315b-4598-9e82-79c3fca96e9c	ORD-MQO3DJJX-4E67	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	6ceaf383-d11a-4589-93f9-669b769e5cef	75ea6d1f-28dd-4fe6-a585-47e2f85cdb11	2026-06-21 18:00:09.79	2026-06-21 18:00:41.261	2026-06-21 18:00:09.789	\N	t	\N	\N
f43c66f5-1251-4939-a2cf-b8eb64b881e9	ORD-MQO1PJP2-E3FC	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	c2757b53-0b71-42e3-b016-4da343f64a74	cb68fac3-aec5-46b4-8f22-6a324217c771	2026-06-21 17:13:30.615	2026-06-21 18:01:16.7	2026-06-21 17:13:30.615	\N	t	\N	\N
18af19f0-0422-4858-b7a4-6a6f7a7cc21e	ORD-MPM4C203-D695	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	c839da86-3edf-4610-9e21-148648b0201c	2026-05-26 04:11:45.316	2026-05-26 04:11:45.316	2026-05-26 04:11:45.315	{"link":"ghỳgbn","accountPass":"dgshmg","gmailPass":"fgd@gmail.com","zaloPhone":"0987654567","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779768702519.jpg"}	f	\N	\N
238fe35c-1d5d-427f-b77e-cbb7cac2f379	ORD-MPMCIPU1-CD72	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	d11fa0ca-9935-441c-9f62-d46cf4d45999	\N	\N	\N	\N	\N	ADADAD	123213.00	123213.00	\N	BALANCE	DONE	\N	27444133-8f0f-4b9b-871c-1d4936dcd238	2026-05-26 08:00:53.072	2026-05-26 08:00:53.072	2026-05-26 08:00:53.066	{"link":"fhfhf","accountPass":"adsf","gmailPass":"sfdg@gmail.com","zaloPhone":"0987654567","accountType":"chinh_chu","cccdUrl":"https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779782448522.jpg"}	f	\N	\N
5f16e9e8-ff23-46cc-918b-cdb591870c6b	ORD-MPMM60OP-0B88	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	37e22ff4-153b-4737-921c-657a6ec183db	2026-05-26 12:30:56.763	2026-05-26 12:30:56.763	2026-05-26 12:30:56.761	\N	f	\N	\N
90604f49-f398-4a4e-8660-e7225e19d6cc	ORD-MPMOWMMF-B02B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	f9e8f5cf-68d3-4e54-8d1c-5a1a45544a21	694be0b2-e1c0-4264-84dd-ac9313c2f481	2026-05-26 13:47:37.482	2026-05-26 16:48:54.728	2026-05-26 14:36:24.653	\N	f	\N	\N
4f2127c4-9914-4e8e-8d09-d312f2286323	ORD-MPMDLOCH-B175	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\N	\N	Tài khoản tiktok	360000.00	360000.00	\N	BALANCE	DONE	4d4885a3-8917-4ca8-beba-fb4e1a3638ce	c7c3caf6-459f-4b28-86a1-8c30818bf86a	2026-05-26 08:31:10.726	2026-05-26 20:23:02.775	2026-05-26 20:23:02.774	\N	f	\N	\N
4e8f2cc9-e39e-4f21-8042-9919b38cdaff	ORD-MPN3EO7U-AD0A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	dfea36d0-042e-46ee-bcf2-e6d4eb9ad132	2026-05-26 20:33:33.98	2026-05-26 20:33:33.98	2026-05-26 20:33:33.978	\N	f	\N	\N
47951cf1-b33a-407e-8853-705086363659	ORD-MPNQYA6M-0093	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	GAME LQMB	79000.00	79000.00	\N	BALANCE	DONE	7f6ee20c-0252-43a8-85ba-e0c9081a8820	18fb3da6-1dfb-40bc-84cf-7bafbd3d0a16	2026-05-27 07:32:40.08	2026-05-27 07:36:42.116	2026-05-27 07:32:40.078	\N	f	\N	\N
0751a761-71b9-448e-84df-841b9cd772e2	ORD-MPL0OWX2-4F48	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	f5a2b518-2cd6-4df8-960a-7a857f75c661	5eb55a7e-f9ca-42ea-911f-d7e7b6d3d07b	2026-05-25 09:42:00.615	2026-05-29 19:04:47.09	2026-05-25 09:42:00.614	\N	t	\N	\N
26622a2c-2286-44ea-b60d-99a8655c86c2	ORD-MPL3W9S1-3A8F	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	2255dcef-a060-4b4d-a817-696879154bb6	d1dc8812-0a46-4faa-9c99-266c81701672	2026-05-25 11:11:42.73	2026-05-29 19:04:47.09	2026-05-25 11:11:42.722	\N	t	\N	\N
b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf	ORD-MPL3WE9E-1846	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	d50c2a98-8488-491d-a30b-cf5d6580a231	e05a4d84-3542-426b-8112-b1888aa0d325	2026-05-25 11:11:48.531	2026-05-29 19:04:47.09	2026-05-25 11:11:48.531	\N	t	\N	\N
479458ec-e829-4b69-983a-2880dc884ef5	ORD-MPL3WHTW-D670	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	2d1dc460-f5d4-43ba-bf00-06d96d7dae71	1593a02d-5d0f-401d-9a4d-6a25966ef77b	2026-05-25 11:11:53.157	2026-05-29 19:04:47.09	2026-05-25 11:11:53.156	\N	t	\N	\N
a4293674-897d-4645-8e0a-ca3b6cb5988b	ORD-MPLJQHSA-4DA4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	aa8f512c-5808-4caf-a8b3-8e20e467cd8a	11edb467-be45-478f-bf99-9872e4d43f78	2026-05-25 18:35:07.02	2026-05-29 19:04:47.09	2026-05-25 18:35:07.019	\N	t	\N	\N
f5986697-1fe9-4778-9f32-540d877b9813	ORD-MPLK63X9-0789	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	f1194ced-7572-4ea7-80da-8886cad60ee5	cca58176-5cf2-4f1b-9ea5-5ae783b0a56b	2026-05-25 18:47:15.551	2026-05-29 19:04:47.09	2026-05-26 17:40:05.024	\N	t	\N	\N
287872ad-aaba-4d2c-941c-dc2b8806d4ce	ORD-MPLJQNSG-D1EF	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	1a2258ce-3ab6-4ab1-8fbb-ed09f2f4a837	8c39e379-ee05-43c7-a789-16597319ba5e	2026-05-25 18:35:14.801	2026-05-29 19:04:47.09	2026-05-25 18:35:14.801	\N	t	\N	\N
fc287ba1-28b3-4daa-b4eb-f159632298b5	ORD-MPMLI8NH-90FE	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	b78bff62-948d-4261-b043-953886e2dc2a	fabe060d-a2bc-4627-8aba-497669dfd755	2026-05-26 12:12:27.348	2026-05-29 19:04:47.09	2026-05-26 15:52:43.755	\N	t	\N	\N
46c1d333-5e35-4297-867c-a0d04c61bd7b	ORD-MPRANUOS-C863	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	4b259378-4811-4a07-8ce2-52b777f23427	1912ab44-d9ef-480c-b6a5-f16c35a71d22	2026-05-29 19:07:44.29	2026-05-29 19:07:44.29	2026-05-29 19:07:44.285	\N	f	\N	\N
da31c0f9-d65e-4f7b-b01e-e2c65ca10d5a	ORD-MPTAN5R2-3F44	15bbcf73-c01d-4730-85d7-a1cca3730c83	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	e2e64bca-a62e-4fa0-aa12-8157f9f185c3	2026-05-31 04:42:44.32	2026-05-31 06:53:39.562	2026-05-31 06:53:39.56	{"name":"Chu Quang Doanh"}	f	\N	\N
605a39a1-7e5c-42b8-9aa2-637b96a29b63	ORD-MPT963BS-BA1A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	6e646372-6751-49d3-9ccd-1fc78e96c2bd	\N	\N	\N	\N	Khóa mmo	200000.00	200000.00	\N	BALANCE	DONE	\N	90f749bd-e604-4bf7-b0fd-d413d14f5715	2026-05-31 04:01:28.43	2026-05-31 06:53:51.6	2026-05-31 06:53:51.6	{"name":"Chuquangdoanh"}	f	\N	\N
0bc64cf9-58a5-48a5-9275-92d81dd83200	ORD-MPTFGZ6F-8A3E	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	a4a52a6a-5914-4f9d-9c07-606b73a5e842	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Via Facebook Clone 2019	79000.00	79000.00	\N	BALANCE	DONE	f2c680fc-f10b-4642-bd1b-a772c1c626ca	297d4a03-1d40-41a2-b092-19a4fd3032cf	2026-05-31 06:57:53.946	2026-05-31 06:57:53.946	2026-05-31 06:57:53.944	\N	f	\N	\N
bce1fd9f-46f6-43f8-afc6-ac7e1828b47c	ORD-MPUMX1FC-DB2D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	258e1849-79f8-4217-bfe9-0ed185e56ba5	c69da14f-e291-4ebd-8adc-ddd0efc19d8c	2026-06-01 03:14:06.851	2026-06-01 03:14:06.851	2026-06-01 03:14:06.84	\N	f	\N	\N
df4dd4cb-0be4-4eda-b7d8-930f1cfc3c44	ORD-MPUMXD13-5470	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	ee6968f0-9de8-4e94-9637-3c91b62c73d9	629edd42-9cb3-4f83-99b8-4d0d10333efc	2026-06-01 03:14:21.881	2026-06-01 03:14:21.881	2026-06-01 03:14:21.879	\N	f	\N	\N
dbc4681f-fab6-40d7-b33d-68fbaf8e0ff6	ORD-MPUX61HR-7845	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	141b6996-caf8-496e-a9bf-a75dacfa9afe	fd69cb72-ffd4-4b51-be2c-431cfa8a54ee	2026-06-01 08:01:02.996	2026-06-01 08:01:02.996	2026-06-01 08:01:02.991	\N	f	\N	\N
3d06aecb-2b49-47f9-8d5f-94720e48cc5e	ORD-MPUX648F-D916	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	8edb52a0-ba37-4bf0-9dde-e7a6d2706db7	7e3ba48d-785f-406b-836f-6ebef5838846	2026-06-01 08:01:06.544	2026-06-01 08:01:06.544	2026-06-01 08:01:06.543	\N	f	\N	\N
0ff04e93-84f1-4ef1-bcab-476e9a5fdbfc	ORD-MPUX7A14-253D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	5c66cf4f-6c9b-4271-b22f-8a10d125c339	2026-06-01 08:02:00.714	2026-06-01 08:02:00.714	2026-06-01 08:02:00.712	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
d277e481-1f37-44a0-bc9b-32ea59491e30	ORD-MPV71PPA-F2DD	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	86032c08-6516-48f1-9294-18ffa1414360	2026-06-01 12:37:37.247	2026-06-01 12:37:37.247	2026-06-01 12:37:37.246	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
1928e3fb-0e2c-46e5-b5b6-01e180c2f569	ORD-MPUX89MH-B3A6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	0c8362c7-2a48-4f54-9d75-18fbeb23e9da	2026-06-01 08:02:46.845	2026-06-01 08:02:46.845	2026-06-01 08:02:46.841	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
690a9668-7a57-4275-9207-516b4b9faf50	ORD-MPUXB4P5-C1D1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	e76c41b2-0fca-4797-89bd-ad6182b2c44a	17466b9e-5731-4463-83f5-7677c847930b	2026-06-01 08:05:00.426	2026-06-01 08:05:00.426	2026-06-01 08:05:00.425	\N	f	\N	\N
e20c58c8-08f9-4c46-8032-bc1e9180b357	ORD-MPUXE1C5-19AD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	c5a8281d-9ea4-4601-9d30-e15a4352e962	2026-06-01 08:07:16.038	2026-06-01 08:07:16.038	2026-06-01 08:07:16.038	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
1313ab6a-de81-467d-9c1a-ad655e207fac	ORD-MPUXE6OB-E73A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	0f2e0a95-e7ab-4195-baf1-a5a525e86e71	2026-06-01 08:07:22.957	2026-06-01 08:07:22.957	2026-06-01 08:07:22.956	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
d5cbf671-ed55-4752-a74c-1fcd095a305f	ORD-MPUXEX0Q-5AF7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	b4de7577-3c70-4838-8293-2c4d75f57ba6	2026-06-01 08:07:57.099	2026-06-01 08:07:57.099	2026-06-01 08:07:57.099	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
c8253d47-289c-4ac6-b905-0eeb1167ccd6	ORD-MPUXJL8I-59AB	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	11f0ff3c-3a79-4bc8-995e-a6f5ec7510eb	2026-06-01 08:11:35.108	2026-06-01 08:11:35.108	2026-06-01 08:11:35.106	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
94eabca6-5e5d-43aa-bf36-9a5a773fd29f	ORD-MPUXJQRT-0AC3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	7612c1ef-3039-4131-ab02-986f16cb0d4b	2026-06-01 08:11:42.282	2026-06-01 08:11:42.282	2026-06-01 08:11:42.281	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
7c9f520c-80d0-4bdb-9995-87287d80af1d	ORD-MPV71IR1-20B9	15bbcf73-c01d-4730-85d7-a1cca3730c83	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	e059c577-6ee8-4299-bc91-79762c9fb300	2026-06-01 12:37:28.24	2026-06-01 12:37:28.24	2026-06-01 12:37:28.238	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
61ed19d4-72cb-40d3-a018-9e963b80952a	ORD-MPWFPP28-E993	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản 250$	50000.00	50000.00	\N	BALANCE	DONE	965fd401-a209-4b43-a17b-7bbcbd42c716	91d0c4f1-6d3b-428d-a7de-72aef129e201	2026-06-02 09:27:59.279	2026-06-02 09:27:59.279	2026-06-02 09:27:59.264	\N	f	\N	\N
84643e15-e06f-4f5d-a029-62058737dde8	ORD-MPWMD2BA-DD81	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	99000.00	\N	BALANCE	DONE	\N	f6c9f573-4a6b-49a8-9315-12ee69dd3de1	2026-06-02 12:34:07.227	2026-06-02 12:34:07.227	2026-06-02 12:34:07.224	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
0c24f7af-f8ab-4da7-a05c-549dd7335f2b	ORD-MPX17R5I-CBA2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	100000.00	\N	BALANCE	DONE	\N	09df96a8-3048-4321-9c84-1f3f45d3f9d3	2026-06-02 19:29:53.722	2026-06-02 19:29:53.722	2026-06-02 19:29:53.719	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
c4b8ea04-b1a9-4fbb-be7c-fdd66640f3d7	ORD-MPZ75MTQ-E24D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	e62c5bed-8859-44ab-b398-f26f846355f7	2026-06-04 07:51:44.849	2026-06-04 07:51:44.849	2026-06-04 07:51:44.846	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
2ec9ccff-7621-4925-a6df-6a6dc48a961a	ORD-MPWMDBKR-95C7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	GAME LQMB	79000.00	79000.00	\N	BALANCE	DONE	86a47279-1c0b-45c1-83c9-d0f932ea5ce2	c28bdb51-fa19-4f31-85c1-c49e3bdf9a67	2026-06-02 12:34:19.229	2026-06-04 08:36:11.931	2026-06-02 12:34:19.227	\N	f	\N	\N
0334e4cd-2a86-4638-b18b-2665b94c0143	ORD-MPZF6L8O-9ACC	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	d467a4b2-c65d-4bbd-92e9-74a0be9387b0	640eaae4-32d0-4742-86fe-14744674835a	2026-06-04 11:36:26.378	2026-06-04 12:13:31.503	2026-06-04 11:36:26.377	\N	f	\N	\N
5fe5505f-e4bb-4c2f-88f6-b647051a3ec7	ORD-MPZGYUMW-90E2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	f370438f-aa51-4720-b2a0-0e23d3cbae15	2026-06-04 12:26:24.537	2026-06-04 12:26:24.537	2026-06-04 12:26:24.537	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	ORD-MPZ773EE-3590	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 12)	4000000.00	3800000.00	24 GIỜ	BALANCE	DONE	\N	fe3d6b81-daf1-45cd-9793-01965096d07b	2026-06-04 07:52:52.984	2026-06-04 13:02:08.518	2026-06-04 13:02:08.518	{"imei":"12222222222222","zaloPhone":"0976454523"}	f	\N	\N
5470e985-5cf3-4179-bfea-2bc3ea6065c8	ORD-MPWMDI04-90DA	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	4447b4b5-91b3-4226-8089-638faa948030	\N	\N	\N	\N	KHÓA HỌC MMO	1599000.00	1599000.00	\N	BALANCE	DONE	\N	5a2feeb0-4c13-4c40-af44-529671be5106	2026-06-02 12:34:27.559	2026-06-04 13:03:29.447	2026-06-04 13:03:29.446	{"name":"Chuquangdoanh"}	f	\N	\N
e890d75e-2f4b-4e55-9f85-02ab7fc9a152	ORD-MQ14L0VC-C244	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	13a22904-adf4-4f91-8068-76b37e2e20ef	2026-06-05 16:15:16.395	2026-06-05 16:15:16.395	2026-06-05 16:15:16.393	\N	f	\N	TUT VIP
621bcefe-6099-43a5-be50-4f1b123f01ad	ORD-MQ14M885-60D8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	65443bbf-5e24-4641-9549-2db9cbf6e9a8	2026-06-05 16:16:12.583	2026-06-05 16:16:12.583	2026-06-05 16:16:12.582	\N	f	\N	TUT VIP
bd3f526c-1d84-4585-a680-d049ae7f2a58	ORD-MQ14RY9L-29D2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	3450e78e-e3ef-4d5e-8d96-738073e6cda6	2026-06-05 16:20:39.61	2026-06-05 16:20:39.61	2026-06-05 16:20:39.609	\N	f	\N	TUT VIP
dcba1098-37fc-4c91-8615-abb46720d953	ORD-MQ14S3XN-6367	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	2729244b-ae96-4a23-9703-180bb075df0a	\N	\N	\N	TUT Mở khóa tài khoản Faq	1000.00	950.00	\N	BALANCE	DONE	\N	67ce3a51-95b0-49c6-8475-e65d86b8bc14	2026-06-05 16:20:46.957	2026-06-05 16:20:46.957	2026-06-05 16:20:46.956	\N	f	\N	TUT ĐÂY
7f2ea2ba-ac75-492f-ad9b-ae5869be3230	ORD-MQ14SORE-139D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	2729244b-ae96-4a23-9703-180bb075df0a	\N	\N	\N	TUT Mở khóa tài khoản Faq	1000.00	950.00	\N	BALANCE	DONE	\N	2c6bc3e9-a19c-4ae0-9c12-1804f89cab8f	2026-06-05 16:21:13.949	2026-06-05 16:21:13.949	2026-06-05 16:21:13.947	\N	f	\\xdd5bc81180d6911e08220ce51da2cf34d5911222c886ad522bbb9e11feb624d9fe49e83d9e8679d1ab02b473de707d6f46ba1e20137162b4eba6f5ef649208e43c2a19d1cecc199e086d8c64fe91674ea50040377b4e844d1b0207aa7c4865f1ae8700bd6aa0b7996784ae	TUT ĐÂY
d6375185-eef8-49c5-af68-e6e755dd68c9	ORD-MQ150QYR-3056	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	72b59e72-ab81-4698-902f-6969b1a2eff8	2026-06-05 16:27:30.053	2026-06-05 16:27:30.053	2026-06-05 16:27:30.051	\N	f	\\x5a6aafa1529e429da2f6c8619e95530ae11e42ad6c0cc4affd9887ba84828e32fd2825885886ba44fd660695d60a14105a9a755ac25b5cbb7b64ad2bb5f17a545fa999c811d4670205f584225ed27d71ccdcae5ee7f2fab6d82ccd6a184115a8fd1d3fb276c36ee757784bdd73a599c5fed1f3c86d74d5cfac738f01b202e1d4	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
7fabd2c4-3744-4ea6-a692-80889dc10401	ORD-MQ153DAQ-7E07	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	95000.00	\N	BALANCE	DONE	\N	4379117c-3895-4746-b2dc-9c684646b460	2026-06-05 16:29:32.309	2026-06-05 16:29:32.309	2026-06-05 16:29:32.307	\N	f	\\x676139be6e09db1e141ae2e77c53943883a42e35cf8baa41f43e4382c332cc59e26d60feb55a5c38291aca7c06ee20c7c301c73e0d49ac9575ba16bc24e8e5089351d17368f4b09c6b40f3e45c	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
4631775d-d81f-4a2f-b904-72c228aef56b	ORD-MQ157SRS-212D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	f1f2338e-3fd9-4fe2-83a1-ed41c4e3cd0c	2026-06-05 16:32:58.986	2026-06-05 16:32:58.986	2026-06-05 16:32:58.985	\N	f	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
4967f83b-6fa3-48cb-a5f8-b87467e4c6d2	ORD-MQ158E6W-DD42	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	95000.00	\N	BALANCE	DONE	\N	5472c2b5-1cac-436e-b28e-3a7f66dc7eb8	2026-06-05 16:33:26.744	2026-06-05 16:33:26.744	2026-06-05 16:33:26.744	\N	f	\\x69bcd44587bad931f3fc6838771f92035e50fc1921741ef9918e5fd464	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
9aaac224-b238-4fd6-94fd-d80f3ecb7f4b	ORD-MQ158IDK-7E3C	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	f978b336-1afc-4d93-ae65-0417bce2040d	\N	\N	\N	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	100000.00	95000.00	\N	BALANCE	DONE	\N	aabd840d-6c09-4708-9923-24f953f2250d	2026-06-05 16:33:32.169	2026-06-05 16:33:32.169	2026-06-05 16:33:32.168	\N	f	\\x69bcd44587bad931f3fc6838771f92035e50fc1921741ef9918e5fd464	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n
5133bc8c-63b3-4271-93a0-f3e5d0f36ac7	ORD-MQ15APIE-7D78	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	f92d3987-0428-4566-b726-9d41607d0914	2026-06-05 16:35:14.726	2026-06-05 16:35:14.726	2026-06-05 16:35:14.726	\N	f	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
4e3ed6dc-ae65-4915-9a07-1de00512b25a	ORD-MQ15DQ08-2B1B	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	e0a1817d-30c8-4c19-9cbb-dc8b44c91a15	2026-06-05 16:37:35.337	2026-06-05 16:37:35.337	2026-06-05 16:37:35.336	\N	f	\\x50b09ada569ee27c2c3371efc813c7e0bb6b4e92b7308c1098fb5a71651c21	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
83b3f010-bbfd-437a-be1a-8237a6f2c578	ORD-MQ15E5C1-7536	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	03414679-8cd3-4804-a567-a7a2d72e964c	2026-06-05 16:37:55.202	2026-06-05 16:37:55.202	2026-06-05 16:37:55.201	\N	f	\\x50b09ada569ee27c2c3371efc813c7e0bb6b4e92b7308c1098fb5a71651c21	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
cf95309a-dc00-4dd6-87f5-96b86d133752	ORD-MQ15G40X-E560	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	490e4b3e-3603-4e80-965e-5fb54f17d273	2026-06-05 16:39:26.818	2026-06-05 16:39:26.818	2026-06-05 16:39:26.818	\N	f	\\x83df1d7cf4c9054191dffae6973075783765cc154b6afbf88a2fa43106bb53	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
7a945572-0ae0-4a5d-a252-0d713ea49e76	ORD-MQO6T9SW-E2CF	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	91b419ae-c0a8-4c61-8e20-bd83f9cf364f	f48ae19d-87d1-4d50-a0b5-27b824124be7	2026-06-21 19:36:22.499	2026-06-21 19:36:22.499	2026-06-21 19:36:22.497	\N	f	\N	\N
cdb6d997-7957-4011-a5b0-582bf512902e	ORD-MQ15GH4S-63FA	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	a5e5093b-abdc-4ec6-b888-72085054523a	\N	\N	\N	TUT UNLOCK 282	99000.00	94050.00	\N	BALANCE	DONE	\N	d856ad56-50cb-4126-923e-171705cc8795	2026-06-05 16:39:43.805	2026-06-05 16:39:43.805	2026-06-05 16:39:43.804	\N	f	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 
4f10d6f9-4b1f-40da-b12a-09667907560c	ORD-MQ15LVC4-C082	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	\N	\N	VIA	99000.00	99000.00	\N	BALANCE	DONE	8338df82-f2c0-4060-b075-712fd9772714	a1be558c-5bb7-4088-b82e-b934f8ef3cee	2026-06-05 16:43:55.495	2026-06-05 16:43:55.495	2026-06-05 16:43:55.493	\N	f	\N	\N
d48f9bf8-ee42-4b79-8740-431b3bb96552	ORD-MQ18NHPR-B453	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	44e26368-8fad-47ec-bafc-5ce03123a5b0	\N	\N	Game Liên quân	200000.00	200000.00	\N	BALANCE	DONE	4783f567-a617-46e4-9a59-853c48b304dc	40052d03-3786-4967-bfca-9225a240ca39	2026-06-05 18:09:10.02	2026-06-05 18:09:10.02	2026-06-05 18:09:10	\N	f	\N	\N
44e47a6e-f082-4ce7-adb6-aace5b5b8777	ORD-MQ1TQJVF-241A	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	10ebce0f-898a-4679-ada1-4fef82d84cd8	4ab5d15f-4c17-4c4e-9ca1-aa0bac302816	2026-06-06 03:59:24.71	2026-06-06 03:59:24.71	2026-06-06 03:59:24.7	\N	f	\N	\N
df05a069-48b7-4762-8680-4e9090095065	ORD-MQ1TQY2R-7433	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	6924aaf5-d660-4f4d-9a57-4294d3f15b54	5a2fa2c5-7ea6-46e1-bc9f-1149af9af179	2026-06-06 03:59:43.108	2026-06-06 03:59:43.108	2026-06-06 03:59:43.107	\N	f	\N	\N
cae36b9b-3dff-4d84-9bec-20a648d37366	ORD-MQ1TQZWL-06F0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	2352678b-6afd-4154-90cf-8cfe3056f281	a687c3de-b361-4505-894b-f47aa5c9a1ba	2026-06-06 03:59:45.478	2026-06-06 03:59:45.478	2026-06-06 03:59:45.478	\N	f	\N	\N
2db67bdc-13e9-490e-9666-0482129daf4b	ORD-MQ1TWLVU-E312	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7a270438-cff5-4f5c-93a7-30d1e771bf9b	\N	\N	Tài khoản intagram cổ trust 2021	259000.00	259000.00	\N	BALANCE	DONE	bea50305-c46d-49e8-b545-f7fc28e26a87	20087702-71dc-4c47-a203-42bcd8ed8a46	2026-06-06 04:04:07.245	2026-06-06 04:04:07.245	2026-06-06 04:04:07.243	\N	f	\N	\N
e83a2e30-a9cd-4226-bea3-ee6fb26e70db	ORD-MQ1TWW20-C01C	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	724a986a-379d-41d4-bd39-46fcf1bd3407	c59e8a28-2f3a-4d9e-bf3f-afd265094c7d	2026-06-06 04:04:20.425	2026-06-06 04:04:20.425	2026-06-06 04:04:20.424	\N	f	\N	\N
7333b0d0-9fb1-4de6-a162-6d1b883aa1bc	ORD-MQ1TX2A2-617D	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	b9ad1692-804c-4bae-9c64-baafc7444550	253b609d-760b-433d-b51b-37a1c9a12eb9	2026-06-06 04:04:28.491	2026-06-06 04:04:28.491	2026-06-06 04:04:28.49	\N	f	\N	\N
e075b268-818d-41dc-9a2a-4f89177f1acf	ORD-MQ2FYIH0-35D0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	GAME LQMB	79000.00	79000.00	\N	BALANCE	DONE	2ccc37d2-00c3-4bfc-abd6-4dcf738d653a	2d57f29e-9d1e-4202-a321-636e763877fd	2026-06-06 14:21:27.7	2026-06-06 14:21:56.181	2026-06-06 14:21:27.685	\N	f	\N	\N
b02bd798-3e00-4b18-b2ec-5c6f2b99272a	ORD-MQ2H1ZS6-EE65	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	a71bbf5c-913d-4232-b1e9-cd37f54b3a05	\N	\N	\N	\N	\N	Mở Khóa Icloud (IPHONE 15 PLUS)	12500000.00	11875000.00	1 THÁNG	BALANCE	DONE	\N	980c3a21-3926-444e-b54c-51e0b2f79f2b	2026-06-06 14:52:09.704	2026-06-06 16:23:33.798	2026-06-06 16:23:33.797	{"imei":"12332213421424","zaloPhone":"0987654334"}	f	\N	\N
fb17d681-5f52-4792-9c2e-c5f8c77f12d9	ORD-MQ24NLH2-BC97	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SERVICE	f2251457-dd7e-464f-8942-85447bf0fe95	\N	\N	\N	\N	\N	Đánh giá GG MAP VIP	600000.00	570000.00	\N	BALANCE	DONE	\N	bb09cd48-a342-43c3-ad51-7d2498d3bb4e	2026-06-06 09:05:02.588	2026-06-06 16:23:44.946	2026-06-06 16:23:44.945	{"link":"http://localhost:3000/dich-vu","zaloPhone":"0989787856"}	f	\N	\N
0413bfac-9275-4f8b-a143-2e30066e9bc9	ORD-MQ2H2LWE-5F51	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	cbf81219-3e12-4060-9303-dca020c2e798	\N	\N	\N	\N	Khóa Học Chạy Quảng Cáo Tiktok	12999000.00	12349050.00	\N	BALANCE	DONE	\N	9cd63914-919f-4eb0-9fd4-261b6b42fb8c	2026-06-06 14:52:38.368	2026-06-06 16:23:54.012	2026-06-06 16:23:54.012	{"phone":"09876556754","name":"Chuquangdoanh"}	f	\N	\N
fa22247f-ec6f-435b-b070-57419639397d	ORD-MQ24OPTI-87C7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	COURSE	\N	4447b4b5-91b3-4226-8089-638faa948030	\N	\N	\N	\N	KHÓA HỌC MMO	1599000.00	1519050.00	\N	BALANCE	DONE	\N	658cb499-b58a-4c6a-af2b-8eb456004e30	2026-06-06 09:05:54.872	2026-06-06 16:23:55.577	2026-06-06 16:23:55.577	{"phone":"0989999888","name":"Chuquangdoanh"}	f	\N	\N
9dcf0cbf-ea8f-4e80-8349-95da399773a9	ORD-MQ2H2VO4-2430	3ad147cc-59c4-4623-ba0d-59011dcb6b93	TUTTRICK	\N	\N	165f87a9-d530-48aa-beb9-c94995d60aae	\N	\N	\N	TUT MỞ KHÓA CHAT META	200000.00	190000.00	\N	BALANCE	DONE	\N	023a4573-81ef-46ae-914d-27cb7258c3f6	2026-06-06 14:52:51.03	2026-06-06 18:48:02.564	2026-06-06 18:48:02.563	\N	f	\N	TUT VIP
a8255c9d-4ba5-44c1-81c4-3389c541eef6	ORD-MQ42URI7-1630	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	\N	\N	Tài khoản tiktok	360000.00	360000.00	\N	BALANCE	DONE	ca28272d-cb32-46f3-84a3-8de7ee734921	843005df-3f17-467e-a131-bc5f0297c56d	2026-06-07 17:50:10.123	2026-06-07 17:50:10.123	2026-06-07 17:50:10.112	\N	f	\N	\N
ef41ab50-c8b8-4c41-8887-3f911434987d	ORD-MQ42V1DG-3B3E	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	\N	\N	\N	7418205f-3c53-4823-ab68-d5c9a1b17f6a	\N	\N	TOOL JOIN BOX TELEGRAM	500000.00	500000.00	\N	BALANCE	DONE	31e1ddc0-885c-4a9d-a0c0-eabe988191bb	846f6a69-4487-4b63-ab4c-bc655db6f632	2026-06-07 17:50:22.902	2026-06-07 17:50:22.902	2026-06-07 17:50:22.9	\N	f	\N	\N
3981505e-ca0b-44b5-b532-5619a863882f	ORD-MQNURAXZ-72B3	e580851a-de0a-48bc-b0a0-922784cbbd2c	MMO_PRODUCT	\N	\N	\N	f7e18809-6daa-4cc4-8522-2b1b94f4f03b	\N	\N	aaaa	1111.00	1111.00	\N	BALANCE	DONE	6d6257a5-ef59-46a8-97d2-5a3171703bd2	d046c0d4-da48-4269-a33d-db2717d4d742	2026-06-21 13:58:55.274	2026-06-21 13:58:55.274	2026-06-21 13:58:55.272	\N	f	\N	\N
d02e9b91-0db8-4f4a-9194-61a745e3f301	ORD-MQM89MB5-9476	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	2b8608e8-77b8-4d81-bd24-710d51e97482	39300a46-2bb4-45cc-befc-71ac875d9454	2026-06-20 10:41:32.474	2026-06-21 14:00:43.459	2026-06-20 10:41:32.466	\N	t	\N	\N
179f3897-e9ad-4d55-a5c5-629b70c5e387	ORD-MQNUQUTT-3EDC	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	2f9f5e02-52b9-4da2-a486-5fba690ba4b3	3ccf99c2-87e0-4043-bd91-80156ecf8e8e	2026-06-21 13:58:34.39	2026-06-21 15:40:01.769	2026-06-21 13:58:34.386	\N	t	\N	\N
08b1bed9-237f-4864-bc01-03975b26b5a4	ORD-MQO0YK3A-CE8D	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	9323fb11-f1f4-47be-bacf-485490c93070	ad8d2f72-1700-4355-95f3-fccb33900a30	2026-06-21 16:52:31.42	2026-06-21 17:02:01.751	2026-06-21 16:52:31.414	\N	t	\N	\N
4402137d-9582-41ad-856d-390d9aeaab70	ORD-MQO1P5CN-B932	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	fd33ce3c-352b-4dee-a806-dec2bb25d77d	5b3a5026-c3a8-43e4-bf53-48232d336653	2026-06-21 17:13:12.03	2026-06-21 17:13:12.03	2026-06-21 17:13:12.024	\N	f	\N	\N
a953723d-d10d-4601-9536-08f2cfad4cf4	ORD-MQO22XBK-1E40	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	35b772ee-a051-4462-a475-d4d118a055c7	7767fd02-232c-4cd9-b4af-8bb0ef119c59	2026-06-21 17:23:54.802	2026-06-21 17:25:21.289	2026-06-21 17:23:54.801	\N	t	\N	\N
51183fd6-d7fa-4bf4-b451-13e03c4415a0	ORD-MQO281A5-0935	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	e4884549-6f0a-464a-939a-e81e93b5226f	fdd6223b-6f5f-47b1-a6dd-498e62dcad2c	2026-06-21 17:27:53.214	2026-06-21 17:28:36.843	2026-06-21 17:27:53.214	\N	t	\N	\N
27773527-36ef-4544-9c57-643149bb66ff	ORD-MQO29FHT-FCD7	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	FROZEN	d844a8a8-415e-4b79-ab01-e7a1d3aff698	e3521614-7fc9-410c-a06e-6ef947926c89	2026-06-21 17:28:58.29	2026-06-21 17:33:55.025	2026-06-21 17:28:58.289	\N	f	\N	\N
8b52fa9a-a367-49dc-b5ae-a219a48ffc1a	ORD-MQO2AYBW-6ED4	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	FROZEN	b39eb9d9-88cd-46bc-83b7-c615481b959e	fbd17ef2-9cd0-4107-84e1-6633b86fc463	2026-06-21 17:30:09.357	2026-06-21 17:35:30.701	2026-06-21 17:30:09.357	\N	f	\N	\N
dd2dc810-a1da-4121-b4a9-26febee581d7	ORD-MQO3I5FZ-059D	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	REFUNDED	08f55e9a-8a63-4c5e-aee6-6bf99845f6c6	34ce6d08-db8f-40f7-9d0d-b03ecc69ca4a	2026-06-21 18:03:44.784	2026-06-21 18:04:18.493	2026-06-21 18:03:44.784	\N	f	\N	\N
7450f2da-0d9e-4a98-9e84-63811095c148	ORD-MQO49NT6-295F	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	fbd4a16b-92c4-489c-bac1-fcc4298cd54b	0d1c5a0c-83df-413a-9147-11f2b43d1632	2026-06-21 18:25:08.299	2026-06-21 18:37:43.477	2026-06-21 18:25:08.298	\N	t	\N	\N
122f5101-4b1b-4980-8e34-147581f29ab9	ORD-MQO3J94S-615E	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	a12d2821-fbcd-4632-97c2-b8ffad39b0f9	970cec09-64ea-4ef7-96c1-f8dffbe928d6	2026-06-21 18:04:36.221	2026-06-21 18:05:28.616	2026-06-21 18:04:36.22	\N	t	\N	\N
0594a66c-6226-49e4-a615-c57f5c11b93f	ORD-MQO4Q4YK-2ECD	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	79f4ce84-b134-4b9b-a7b5-ac815efd53ef	2698508f-55d8-46d4-bd5f-88bbc2f26c08	2026-06-21 18:37:57.021	2026-06-21 19:03:33.184	2026-06-21 18:37:57.02	\N	t	\N	\N
9b97b3a3-e7af-44e0-a574-8a02cfa712dd	ORD-MQO3U0YM-A2E6	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	BM FACEBOOK	100000.00	100000.00	\N	BALANCE	DONE	1470ce3e-9a12-4cda-bfd9-f8721f7b1a38	3aa5b891-7212-4817-b10b-7a8ce6e9dfcc	2026-06-21 18:12:58.848	2026-06-21 18:24:33.6	2026-06-21 18:12:58.846	\N	t	\N	\N
c7793e2e-97d8-43b1-b731-2896dce51db1	ORD-MQO68FW3-94C2	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	34a3fdf2-8acb-4ae5-baa7-46d7ce2d9b99	f540d620-cc39-481b-a90c-6c4cbdcba0e0	2026-06-21 19:20:10.612	2026-06-21 19:23:23.166	2026-06-21 19:20:10.611	\N	t	\N	\N
ec601ff4-98cc-4b1d-b912-4d09377741fd	ORD-MQO6TLFQ-97FE	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	REFUNDED	bc3cf691-3cca-4c2d-a99d-b24389f7696a	bb981ae9-f18f-4d60-b82b-dfccdafe6125	2026-06-21 19:36:37.576	2026-06-21 19:37:49.929	2026-06-21 19:36:37.574	\N	f	\N	\N
3992667d-d309-4755-9211-38f5242db551	ORD-MQOSRERP-B657	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Vip	5000.00	5000.00	\N	BALANCE	DONE	45cac83d-a70e-49d4-a034-a7e53b42c57d	efc0b39b-7d7d-45f8-921d-b10af6d20787	2026-06-22 05:50:47.175	2026-06-22 05:50:47.175	2026-06-22 05:50:47.173	\N	f	\N	\N
75af354a-776c-4d81-95d0-17a76a609b93	ORD-MQO14EHL-A7F0	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	\N	\N	\N	\N	8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Tài khoản quảng cáo	10000.00	10000.00	\N	BALANCE	DONE	9b776f04-9337-40b2-ac25-6888f9914365	f1c84d66-eda5-4f71-9f57-4c865398f819	2026-06-21 16:57:04.09	2026-06-22 11:45:51.746	2026-06-21 16:57:04.089	\N	t	\N	\N
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."otp_codes" ("id", "email", "user_id", "purpose", "code_hash", "attempts", "max_attempts", "ip_address", "expires_at", "used_at", "created_at") FROM stdin;
3e2fc9d8-4c7e-40c8-ad5f-4024dffe6fda	test_923627132@example.com	\N	REGISTER	$2b$12$D9AaJ0XvNcnnA6oetotj9OLnyQV/B2QPl3TEuLMVAOdIH65TVANSO	0	5	::1	2026-05-25 08:12:40.11	\N	2026-05-25 08:02:40.126
ecd03727-a895-44e7-82f7-9c0fea0a0920	testfull_996932857@example.com	\N	REGISTER	$2b$12$1xHFZVDPO4cS29sflA8JHu5HtXH3H2tgtADB7ye8fOsLpaPE5wMa2	0	5	::1	2026-05-25 08:13:01.074	\N	2026-05-25 08:03:01.08
3cd04309-0b34-40c3-8898-8e07a13dc6e9	test@example.com	\N	REGISTER	$2b$12$0KCJ.3sCIccEUin4/DOCfOtQkMS9dYH6byqWc0wjUIWG5m9B43SeK	0	5	::1	2026-05-25 08:21:16.715	\N	2026-05-25 08:11:16.722
f0973410-6d61-4496-833d-37d3e7f5afa3	khachhangtrungtamfb@gmail.com	\N	REGISTER	$2b$12$OhobRbXzp9K2MASPRPCyO.feZlQOzSTFT3qp9PNvN6mDIF9DM06bG	0	5	::1	2026-06-22 07:59:47.904	2026-06-22 07:50:14.151	2026-06-22 07:49:47.928
\.


--
-- Data for Name: page_permissions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."page_permissions" ("id", "role", "page_key", "is_enabled", "updated_by_user_id", "updated_at") FROM stdin;
384565e6-c9ba-4d0c-a510-c79b2e6ed73a	STAFF	admin/dashboard	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.43
f5571e11-a189-4289-b1e0-75c5f9932681	STAFF	admin/orders	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.439
1ba2fcc2-2a58-47a7-aecb-4e0d6b497658	STAFF	admin/deposits	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.442
0678f28c-0226-46dc-8070-13fdfc427e9c	STAFF	admin/withdrawals	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.444
e0f78cad-898a-4005-abaf-b30b5ea870fb	STAFF	admin/complaints	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.446
33a1512c-7423-4585-98ba-1b736b4c7f39	STAFF	admin/chats	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.448
285b69cc-19cf-4787-917e-5771a82b7e97	STAFF	admin/reviews	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.45
e06f3126-da90-4ebc-97e7-875a5aabec93	STAFF	admin/danh-gia	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.452
98786e96-e6ab-4b40-b363-175749e853f3	STAFF	admin/tickers	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.454
f9440d12-1c4b-45e7-9000-0b43aa204f7a	STAFF	admin/services	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.455
4ef8b59b-5ce9-4820-9a29-d561a0ec217e	STAFF	admin/courses	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.457
4b278f4d-402d-4b78-849c-b00ff2b8d87c	STAFF	admin/tut-tricks	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.46
f019f579-b3a0-4202-8f5d-b312817cbb25	STAFF	admin/mmo-products	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.462
46df95b2-db38-4f0c-a5d8-98ea1ef1b987	STAFF	admin/service-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.464
cba1f6bb-ccef-44bf-877b-28436a1c4b2d	STAFF	admin/course-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.467
71651a6a-f4de-4082-a776-99857b8dc945	STAFF	admin/resource-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.469
04173518-ee0e-433b-9fe7-e8cfe348323f	STAFF	admin/tut-trick-categories	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.472
106f3800-c0fd-422d-9a24-d257022c69fe	STAFF	admin/sellers	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.475
19546361-3604-49b3-a36e-4806ac3d67d9	STAFF	admin/san-pham-ban	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.477
08cb7a55-5e7f-4d5a-9382-e825d16e564d	STAFF	admin/cai-dat-ban-hang	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.48
8b7d3c4b-273d-4f5b-bcd5-f655251a17fd	STAFF	admin/users	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.483
a4cdbe26-5953-4ac5-9dfb-2453ab629d5b	STAFF	admin/audit-log	f	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-04 08:03:44.485
fe0f0925-cb5f-4d9b-8595-0db7e05fc8a3	USER	thong-tin-ca-nhan	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.667
d8707c3b-4489-4371-b82b-d2b92df4a0e9	USER	nap-tien	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.673
52ab11c1-1b21-4881-b853-b06778ffcab4	USER	lich-su-giao-dich	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.675
1c9c0f67-6620-42e4-8b1d-37742b67e7a3	USER	don-hang	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.677
ba0f3ccd-bbe9-4b10-bee8-96fee25772ae	USER	tro-chuyen	t	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-06 16:13:55.679
\.


--
-- Data for Name: pending_registrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."pending_registrations" ("id", "email", "full_name", "phone", "otp_code_hash", "attempts", "ip_address", "expires_at", "created_at") FROM stdin;
afc73c88-396e-4ce9-adcc-aa1f1e38ff65	test_923627132@example.com	Test User	0912345678	\N	0	::1	2026-05-25 08:12:39.799	2026-05-25 08:02:39.819
ed5ac539-2464-4d42-af7e-9701b5e3dfa3	testfull_996932857@example.com	Test Full	0912345678	\N	0	::1	2026-05-25 08:13:00.808	2026-05-25 08:03:00.808
0f7436e6-fd75-47c4-a7e3-3e5b29e6416c	test@example.com	Nguyen Van A	0912345678	\N	0	::1	2026-05-25 08:21:16.444	2026-05-25 08:11:16.444
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."permissions" ("id", "module_id", "code", "action", "label", "description", "sort_order", "is_active", "created_at", "updated_at") FROM stdin;
f48d52bb-ea9b-44f6-b5fd-e173099c60bc	1e1f1469-2421-4585-94a2-18b17c1a0391	dashboard:read	read	Xem dashboard	\N	0	t	2026-06-20 10:10:00.229	2026-06-20 17:56:17.731
70e2e247-fc54-43d7-a63c-b3b211f6c963	b620d2ab-91b2-487e-bb1d-2a40b50d52cb	users:read	read	Xem danh sách user	\N	0	t	2026-06-20 10:10:00.238	2026-06-20 17:56:17.739
3727c546-2ee8-4d98-b839-1e7140a75e5c	b620d2ab-91b2-487e-bb1d-2a40b50d52cb	users:create	create	Tạo tài khoản	\N	1	t	2026-06-20 10:10:00.245	2026-06-20 17:56:17.745
671e02aa-43e1-4877-9188-c0fb609bc18e	b620d2ab-91b2-487e-bb1d-2a40b50d52cb	users:update	update	Sửa thông tin user	\N	2	t	2026-06-20 10:10:00.252	2026-06-20 17:56:17.751
0c77a8f1-cefb-421f-8afb-178d29dbd0c6	b620d2ab-91b2-487e-bb1d-2a40b50d52cb	users:delete	delete	Xóa / khóa user	\N	3	t	2026-06-20 10:10:00.258	2026-06-20 17:56:17.757
ca425329-9bd5-44bd-afe0-69883c47742e	b72b03c8-bea1-46dc-a649-874bac3f9767	orders:read	read	Xem đơn hàng	\N	0	t	2026-06-20 10:10:00.264	2026-06-20 17:56:17.763
f20d6d0a-7943-431f-b17c-3716bba1f023	b72b03c8-bea1-46dc-a649-874bac3f9767	orders:update	update	Cập nhật trạng thái đơn	\N	1	t	2026-06-20 10:10:00.271	2026-06-20 17:56:17.769
8f771bf6-7604-4549-9307-0397eeb68766	b72b03c8-bea1-46dc-a649-874bac3f9767	orders:delete	delete	Hủy / xóa đơn hàng	\N	2	t	2026-06-20 10:10:00.276	2026-06-20 17:56:17.775
933a1b44-90ac-4c8b-a805-28738a939930	4ad5b9c6-4c20-400e-b849-2af59216afa7	products:read	read	Xem sản phẩm / dịch vụ	\N	0	t	2026-06-20 10:10:00.283	2026-06-20 17:56:17.78
49ea4613-2722-463b-ac74-1788ae576543	4ad5b9c6-4c20-400e-b849-2af59216afa7	products:create	create	Thêm sản phẩm mới	\N	1	t	2026-06-20 10:10:00.289	2026-06-20 17:56:17.787
ca380347-865f-4903-bf0d-603e3da388f0	4ad5b9c6-4c20-400e-b849-2af59216afa7	products:update	update	Sửa thông tin sản phẩm	\N	2	t	2026-06-20 10:10:00.296	2026-06-20 17:56:17.793
9ff7a03f-e00d-4742-acaa-67a20774a11b	4ad5b9c6-4c20-400e-b849-2af59216afa7	products:delete	delete	Xóa sản phẩm	\N	3	t	2026-06-20 10:10:00.302	2026-06-20 17:56:17.799
123edd4a-e249-4ba1-a833-d968071deb63	6aae1572-a61e-4714-a06e-b366f2c82457	services:read	read	Xem dịch vụ	\N	0	t	2026-06-20 17:56:17.805	2026-06-20 17:56:17.805
a0ba093d-00cd-4730-b7f0-94759169b376	6aae1572-a61e-4714-a06e-b366f2c82457	services:create	create	Thêm dịch vụ mới	\N	1	t	2026-06-20 17:56:17.813	2026-06-20 17:56:17.813
2e16862a-2af3-4f9a-ab40-e4b47310b3b8	6aae1572-a61e-4714-a06e-b366f2c82457	services:update	update	Sửa thông tin dịch vụ	\N	2	t	2026-06-20 17:56:17.82	2026-06-20 17:56:17.82
cfc942d2-6a86-4a43-8a86-f2773d997f1a	6aae1572-a61e-4714-a06e-b366f2c82457	services:delete	delete	Xóa dịch vụ	\N	3	t	2026-06-20 17:56:17.826	2026-06-20 17:56:17.826
9c3ce2b0-17d2-440a-9ba1-81a61fa12eac	d801ef20-c21a-4bf4-8c46-8fb5b476c5a3	courses:read	read	Xem khóa học	\N	0	t	2026-06-20 17:56:17.831	2026-06-20 17:56:17.831
e6535077-3e5e-4797-a5e7-a2f46381fdfd	d801ef20-c21a-4bf4-8c46-8fb5b476c5a3	courses:create	create	Thêm khóa học mới	\N	1	t	2026-06-20 17:56:17.836	2026-06-20 17:56:17.836
e5cfb747-d4d1-4b70-9d24-b0253ef1ea1e	d801ef20-c21a-4bf4-8c46-8fb5b476c5a3	courses:update	update	Sửa thông tin khóa học	\N	2	t	2026-06-20 17:56:17.842	2026-06-20 17:56:17.842
4f49c18a-2e39-425e-8106-2ef12a24f307	d801ef20-c21a-4bf4-8c46-8fb5b476c5a3	courses:delete	delete	Xóa khóa học	\N	3	t	2026-06-20 17:56:17.848	2026-06-20 17:56:17.848
a33036ca-9f47-4c20-93e0-ead8ec6fd278	1bd39221-ce50-4665-b856-01be5947503d	categories:read	read	Xem danh mục	\N	0	t	2026-06-20 10:10:00.308	2026-06-20 17:56:17.903
bb4e6829-ad2d-432d-9bb2-426585c5c7d9	1bd39221-ce50-4665-b856-01be5947503d	categories:create	create	Thêm danh mục	\N	1	t	2026-06-20 10:10:00.315	2026-06-20 17:56:17.91
f43f4ccd-10a5-4f6d-9603-02f112b7575e	1bd39221-ce50-4665-b856-01be5947503d	categories:update	update	Sửa danh mục	\N	2	t	2026-06-20 10:10:00.321	2026-06-20 17:56:17.915
123a0afc-2ca3-406a-9253-04cb3d7c22a2	1bd39221-ce50-4665-b856-01be5947503d	categories:delete	delete	Xóa danh mục	\N	3	t	2026-06-20 10:10:00.327	2026-06-20 17:56:17.92
5a0d1371-fcc7-41a4-b56a-ce102e6da606	d762db8c-9029-48a4-b2bf-2b6f48df65a4	finance:read	read	Xem nạp / rút tiền	\N	0	t	2026-06-20 10:10:00.333	2026-06-20 17:56:17.925
ec8dc824-d3a4-4561-be3e-419bc2967015	d762db8c-9029-48a4-b2bf-2b6f48df65a4	finance:approve	approve	Duyệt giao dịch	\N	1	t	2026-06-20 10:10:00.339	2026-06-20 17:56:17.93
f594440b-4460-40ca-abf7-e8e62f28fb1b	d762db8c-9029-48a4-b2bf-2b6f48df65a4	finance:reject	reject	Từ chối giao dịch	\N	2	t	2026-06-20 10:10:00.344	2026-06-20 17:56:17.936
aa498141-e9c4-4010-87fa-03a4bcb133bc	951bef9c-2d30-48ea-97be-481781089083	complaints:read	read	Xem khiếu nại	\N	0	t	2026-06-20 10:10:00.349	2026-06-20 17:56:17.941
c9f36abc-2e20-4553-a35d-fabce73bc9db	951bef9c-2d30-48ea-97be-481781089083	complaints:reply	reply	Phản hồi khiếu nại	\N	1	t	2026-06-20 10:10:00.355	2026-06-20 17:56:17.946
26b4ecf7-0bb8-405a-b15c-585443d990fa	951bef9c-2d30-48ea-97be-481781089083	complaints:update	update	Cập nhật trạng thái	\N	2	t	2026-06-20 10:10:00.361	2026-06-20 17:56:17.952
246db549-bc73-4ecc-96a5-628124c9135f	951bef9c-2d30-48ea-97be-481781089083	complaints:close	close	Đóng khiếu nại	\N	3	t	2026-06-20 10:10:00.368	2026-06-20 17:56:17.957
23823130-6af7-4610-af65-d370c42805ac	6f614a18-2521-4b5d-b504-6a739059c1e2	chat:read	read	Xem hội thoại	\N	0	t	2026-06-20 10:10:00.374	2026-06-20 17:56:17.962
776acaad-4d10-4479-b2c1-75e40c850733	6f614a18-2521-4b5d-b504-6a739059c1e2	chat:reply	reply	Trả lời hội thoại	\N	1	t	2026-06-20 10:10:00.379	2026-06-20 17:56:17.967
b739e784-e342-4a5a-8cc3-14b1aa21e52b	9e1c6ed7-4019-4465-9971-d79b009aa23d	content:read	read	Xem nội dung / thông báo	\N	0	t	2026-06-20 10:10:00.385	2026-06-20 17:56:17.972
a2c908ef-f050-4868-b796-accb01b4d9f0	9e1c6ed7-4019-4465-9971-d79b009aa23d	content:create	create	Đăng bài / tạo thông báo	\N	1	t	2026-06-20 10:10:00.391	2026-06-20 17:56:17.978
81b1506a-9278-4fd4-ac86-b9916a74ee7f	9e1c6ed7-4019-4465-9971-d79b009aa23d	content:update	update	Sửa nội dung	\N	2	t	2026-06-20 10:10:00.396	2026-06-20 17:56:17.983
b36e5084-c44f-4d78-8ca0-94b5a7a9a83e	9e1c6ed7-4019-4465-9971-d79b009aa23d	content:delete	delete	Xóa nội dung	\N	3	t	2026-06-20 10:10:00.402	2026-06-20 17:56:17.988
23b880d8-c30a-4bdc-88bd-d5d9e9cf25d2	239ff57d-f9bb-4a7b-923c-f56fced2a356	sellers:read	read	Xem danh sách seller	\N	0	t	2026-06-20 10:10:00.407	2026-06-20 17:56:17.993
dd901081-1237-479f-a090-52e30476c926	239ff57d-f9bb-4a7b-923c-f56fced2a356	sellers:approve	approve	Duyệt seller	\N	1	t	2026-06-20 10:10:00.412	2026-06-20 17:56:17.998
0d22f57b-9cb1-4419-a760-79f883dfa654	239ff57d-f9bb-4a7b-923c-f56fced2a356	sellers:update	update	Sửa thông tin seller	\N	2	t	2026-06-20 10:10:00.417	2026-06-20 17:56:18.004
8904eea1-800b-484d-bca9-d42929d1d9bc	239ff57d-f9bb-4a7b-923c-f56fced2a356	sellers:delete	delete	Khóa / xóa seller	\N	3	t	2026-06-20 10:10:00.423	2026-06-20 17:56:18.009
2e16ac3d-1e8a-4e23-9609-fc3f411ae3f8	d32e6785-7751-4319-b86b-021dffdae3a6	seller_products:read	read	Xem sản phẩm seller	\N	0	t	2026-06-20 10:10:00.428	2026-06-20 17:56:18.014
8240822c-f0d4-4dce-9230-6e1a1b70daaa	d32e6785-7751-4319-b86b-021dffdae3a6	seller_products:update	update	Duyệt / sửa sản phẩm	\N	1	t	2026-06-20 10:10:00.434	2026-06-20 17:56:18.02
8bb5514f-5ff8-484a-9147-42b3a60f6bdb	d32e6785-7751-4319-b86b-021dffdae3a6	seller_products:delete	delete	Xóa sản phẩm seller	\N	2	t	2026-06-20 10:10:00.439	2026-06-20 17:56:18.026
9cd0eae1-8d54-4eb7-a9c5-44297dcff085	14603784-cd6d-408b-8230-5ccb8915f0ee	transactions:read	read	Xem lịch sử giao dịch	\N	0	t	2026-06-20 10:10:00.445	2026-06-20 17:56:18.031
6a5888a7-b321-4417-8881-617be04afafe	14603784-cd6d-408b-8230-5ccb8915f0ee	audit_logs:read	read	Xem audit log	\N	1	t	2026-06-20 10:10:00.451	2026-06-20 17:56:18.038
a4dbd7e8-d242-4170-9def-e5aec13214ac	326a4ee4-ae74-4983-8095-e2a2cd625421	tut_tricks:read	read	Xem tut trick	\N	0	t	2026-06-20 17:56:17.855	2026-06-20 17:56:17.855
3e60c108-e46a-4da2-a0ca-1677ccb2a39c	326a4ee4-ae74-4983-8095-e2a2cd625421	tut_tricks:create	create	Thêm tut trick mới	\N	1	t	2026-06-20 17:56:17.863	2026-06-20 17:56:17.863
e5aafd65-010a-4fc2-a499-c0df06c7b02b	326a4ee4-ae74-4983-8095-e2a2cd625421	tut_tricks:update	update	Sửa tut trick	\N	2	t	2026-06-20 17:56:17.868	2026-06-20 17:56:17.868
2c348795-2e5b-491e-ab1d-a38f9ba30b7b	326a4ee4-ae74-4983-8095-e2a2cd625421	tut_tricks:delete	delete	Xóa tut trick	\N	3	t	2026-06-20 17:56:17.874	2026-06-20 17:56:17.874
dbe4f3e9-fc67-49df-8044-f4aed96e1619	c046a18f-75a0-4e1c-a609-7076c07a2054	resources:read	read	Xem tài nguyên MMO	\N	0	t	2026-06-20 17:56:17.879	2026-06-20 17:56:17.879
5726f239-68a4-4c3b-87f5-70f05023945b	c046a18f-75a0-4e1c-a609-7076c07a2054	resources:create	create	Thêm tài nguyên mới	\N	1	t	2026-06-20 17:56:17.886	2026-06-20 17:56:17.886
8f750add-8640-4190-943a-cef6c67fee06	c046a18f-75a0-4e1c-a609-7076c07a2054	resources:update	update	Sửa / Quản lý kho tài nguyên	\N	2	t	2026-06-20 17:56:17.892	2026-06-20 17:56:17.892
deec7fee-32d7-4fad-a409-c485b317c95f	c046a18f-75a0-4e1c-a609-7076c07a2054	resources:delete	delete	Xóa tài nguyên	\N	3	t	2026-06-20 17:56:17.897	2026-06-20 17:56:17.897
\.


--
-- Data for Name: public_page_configs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."public_page_configs" ("id", "page_key", "is_visible", "is_featured", "custom_label", "updated_at") FROM stdin;
65313a2e-19d4-4759-b8a9-9c96bf37641b		t	f	\N	2026-06-08 04:15:59.696
c5c67dd2-7b12-4f8c-ac52-27c6e5bb6068	dich-vu	t	t	\N	2026-06-08 04:15:59.706
fa557d60-be0d-417b-8c57-074793e36b72	khoa-hoc	t	t	\N	2026-06-08 04:15:59.709
9604fd90-16ff-4fbc-af02-88975eaa83d6	tut-tricks	t	t	\N	2026-06-08 04:15:59.711
fc6f0187-6acb-46c9-bbf9-41460393c2b4	tai-nguyen-mmo	t	t	\N	2026-06-08 04:15:59.713
1de31c54-90c0-43d1-96c9-93973aebe890	NetWorks	t	f	\N	2026-06-08 04:15:59.715
65e95397-26c4-4396-93f3-03732e7cb920	quang-cao	t	f	\N	2026-06-08 04:15:59.717
36dbf340-330c-4f75-8de7-0b31c8d2c9b5	chinh-sach	t	f	\N	2026-06-08 04:15:59.718
5f3057f3-df37-43b1-927d-5c9b093e05c0	dieu-khoan	t	f	\N	2026-06-08 04:15:59.72
8ea75765-036b-4a74-b02a-0c607eb7f709	chinh-sach-nha-ban-hang	t	f	\N	2026-06-08 04:15:59.722
91174e4a-2a44-4fe6-bf06-abb09547912e	fanpage-ads	t	f	\N	2026-06-06 18:37:46.654
decf83e3-56fa-497f-81c1-40dde9c61bfa	gioi-thieu	t	f	\N	2026-06-06 03:34:30.981
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."refresh_tokens" ("id", "user_id", "token_hash", "family", "revoked", "expires_at", "created_at") FROM stdin;
\.


--
-- Data for Name: resource_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."resource_categories" ("id", "name", "icon_url", "created_at", "updated_at", "display_order", "show_in_kho_tai_nguyen", "show_in_tai_nguyen_mmo") FROM stdin;
6ca6cdb1-0183-4dd6-a348-f264e2a33512	Instagram	https://svgl.app/library/instagram-icon.svg	2026-06-06 15:23:18.571	2026-06-21 11:53:06.061	1	f	t
78e57057-c212-4537-96d4-9d2394da5df4	Telegram	https://svgl.app/library/telegram.svg	2026-06-06 15:23:53.401	2026-06-21 11:53:08.47	3	f	t
7d8d51be-7709-4b46-9f0a-037f70281103	Facebook	https://svgl.app/library/facebook-icon.svg	2026-06-21 13:55:29.138	2026-06-21 13:55:33.885	1	t	f
8f4f7ad2-7f34-43b0-ae38-935e0758e82b	Google	https://svgl.app/library/google.svg	2026-06-06 15:23:26.858	2026-06-21 13:55:33.889	2	t	t
2ea180f3-e393-46f7-b0cf-3586c758e1c7	Tool Telegram	https://svgl.app/library/wordpress.svg	2026-06-06 15:24:04.894	2026-06-21 13:55:33.891	3	t	t
52a61ea7-7047-48c5-ba8c-6ea1e893e0c1	Game	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/resource-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780759657943.png	2026-06-06 15:27:40.773	2026-06-21 13:55:33.893	4	t	t
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."reviews" ("id", "user_id", "product_type", "product_id", "rating", "comment", "created_at", "updated_at", "order_id") FROM stdin;
b093435a-6c96-4df8-a369-914ec271bd9b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	5	addd	2026-05-26 12:57:07.095	2026-05-26 12:57:07.095	373ca467-4600-4dfa-a72e-76b20d5abb52
d459d559-2761-4156-8e72-1b7441649ab5	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	45a65117-624f-4e87-b2cc-add4714bc25e	5	addadad	2026-05-26 12:57:17.952	2026-05-26 12:57:17.952	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51
d8912e2e-2ab4-497b-b727-efda12f33a91	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	46d8319b-f7a2-488d-9c21-08a6891c7e67	4	adadasd	2026-05-26 12:57:25.244	2026-05-26 12:57:25.244	f5986697-1fe9-4778-9f32-540d877b9813
bc4418e0-033d-4e5d-bf5a-6f56c584f56d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	3e677c06-d4b5-4bcc-9a7d-ab2d13bdfe13	5	\N	2026-05-26 12:57:38.517	2026-05-26 12:57:38.517	4f2127c4-9914-4e8e-8d09-d312f2286323
3c952c55-4a80-4361-b8df-f604f7348124	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	f7a0a8ca-4b96-41d8-b10c-6a365f6f4788	5	\N	2026-05-26 20:29:22.399	2026-05-26 20:29:22.399	90604f49-f398-4a4e-8660-e7225e19d6cc
10ca681f-3bfc-4d82-baed-8e8fb3d56e04	15bbcf73-c01d-4730-85d7-a1cca3730c83	SELLER_PRODUCT	8000aac0-41a3-49f4-801e-1a12191721c7	5	OK ngay	2026-05-29 19:07:55.492	2026-05-29 19:07:55.492	46c1d333-5e35-4297-867c-a0d04c61bd7b
425f5f54-c044-4fa2-9b76-6894e5fd6c91	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	8000aac0-41a3-49f4-801e-1a12191721c7	5	\N	2026-05-29 19:08:32.071	2026-05-29 19:08:32.071	7c9cddea-a5d2-4c01-9ad9-74f88917b4c4
4ff8f41a-580e-4a06-ada8-257492ee1b00	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	a4a52a6a-5914-4f9d-9c07-606b73a5e842	5	giao hàng nhanh	2026-05-31 06:58:25.088	2026-05-31 06:58:25.088	0bc64cf9-58a5-48a5-9275-92d81dd83200
33212fce-536f-4b54-ad55-955a881dacee	3ad147cc-59c4-4623-ba0d-59011dcb6b93	SELLER_PRODUCT	0fbf8797-e5c2-493a-b175-61f2b6b412ef	5	\N	2026-05-27 07:32:56.815	2026-06-04 12:21:36.239	47951cf1-b33a-407e-8853-705086363659
23c34290-62da-4a7c-9c85-4bd75c6cf779	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	44e26368-8fad-47ec-bafc-5ce03123a5b0	5	Quyas ok	2026-06-05 18:19:47.105	2026-06-05 18:19:47.105	d48f9bf8-ee42-4b79-8740-431b3bb96552
76330d0b-6f15-4b77-9592-693974ad539e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	MMO_PRODUCT	7418205f-3c53-4823-ab68-d5c9a1b17f6a	5	\N	2026-06-06 04:00:43.941	2026-06-06 04:00:43.941	44e47a6e-f082-4ce7-adb6-aace5b5b8777
3cbf2ae4-5f35-4765-b79c-58c75510e949	e580851a-de0a-48bc-b0a0-922784cbbd2c	SELLER_PRODUCT	8000aac0-41a3-49f4-801e-1a12191721c7	5	được	2026-06-22 08:39:47.003	2026-06-22 08:39:47.003	08b1bed9-237f-4864-bc01-03975b26b5a4
\.


--
-- Data for Name: seller_product_stock; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_product_stock" ("id", "product_id", "content_enc", "status", "sold_to_user_id", "order_id", "sold_at", "created_at") FROM stdin;
98634793-a566-4c0d-b09f-5595edda622d	8000aac0-41a3-49f4-801e-1a12191721c7	\\x9883675b2f451a494bff2df112780ac1711651765347b49bec5950af23	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	984b82dd-1f99-4de6-a4f8-9b0946d61829	2026-05-25 09:41:42.293	2026-05-25 09:21:32.274
f5a2b518-2cd6-4df8-960a-7a857f75c661	8000aac0-41a3-49f4-801e-1a12191721c7	\\xa946516f547f7ca6213a716fd5ceac6c1f820c48fc8cde3267005e1a55	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	db4a6df0-e805-4fd8-9a66-7f5309a671a0	2026-05-25 09:42:00.592	2026-05-25 09:21:32.274
f940b9bc-f26e-40e8-936b-5ae39ac8062c	45a65117-624f-4e87-b2cc-add4714bc25e	\\x70af146b51d0d11833d451c5367cb72b0aa9e893563c1c32c1f1c0e302	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b64a3d2e-bd2d-4b14-b963-75afb970c4e4	2026-05-25 09:47:33.123	2026-05-25 09:46:03.471
2255dcef-a060-4b4d-a817-696879154bb6	8000aac0-41a3-49f4-801e-1a12191721c7	\\xcad08f9a0719ee163ef99046a6335507be16244c0b09634ac7223a8aa4	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	00fea6b5-485e-4fed-8cf5-1904f1343963	2026-05-25 11:11:42.692	2026-05-25 09:46:23.733
d50c2a98-8488-491d-a30b-cf5d6580a231	8000aac0-41a3-49f4-801e-1a12191721c7	\\x6aa7025d51406bb40fcb68487b61b88c05ab87568e0c49f6659fe2df0b	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3b19b2bd-4d8c-4015-ab1a-5170d48ab0a6	2026-05-25 11:11:48.511	2026-05-25 09:46:23.733
2d1dc460-f5d4-43ba-bf00-06d96d7dae71	8000aac0-41a3-49f4-801e-1a12191721c7	\\xd1ff3165dba088a9b4be4c76966b06a8f49ca445cac28299553252b4e4	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b9dc0c73-5e69-4536-b885-abdd81496f66	2026-05-25 11:11:53.142	2026-05-25 09:46:23.733
aa8f512c-5808-4caf-a8b3-8e20e467cd8a	8000aac0-41a3-49f4-801e-1a12191721c7	\\x481eb4fd379aa727bb1b2279ee93aba0b0a45daa0efcfd6ffadc3c3a43	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5d2b161e-c073-4518-9687-d0280099ca90	2026-05-25 18:35:06.994	2026-05-25 09:46:23.733
1a2258ce-3ab6-4ab1-8fbb-ed09f2f4a837	8000aac0-41a3-49f4-801e-1a12191721c7	\\x14d4c9407bf87434e2f23215937a23ce85218b4b5431fd6249bbf91f28	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	6a8db83c-f71c-4d5a-929a-50a4d7838b60	2026-05-25 18:35:14.785	2026-05-25 09:46:23.733
3b4e4d9d-e186-4649-a234-947e02fd0589	45a65117-624f-4e87-b2cc-add4714bc25e	\\x328fcbfb79e7e773315cfa954d5d75f74dd99fd7c46d11cd1f1519b644	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fd7ece0b-a926-48cd-b475-67572d1f1dfb	2026-05-25 18:35:30.642	2026-05-25 09:46:03.471
f1194ced-7572-4ea7-80da-8886cad60ee5	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x03433c4cd1767beb8fdcc305aa31a1d5fd51a737c47b70fa62a1b681530ddce6215e908ef5d5cc561cc5a8	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b3c9f1b2-9cb9-4ce5-9e16-d3cb8264be64	2026-05-25 18:47:15.525	2026-05-25 17:45:04.69
b78bff62-948d-4261-b043-953886e2dc2a	45a65117-624f-4e87-b2cc-add4714bc25e	\\xc524e53f9ec8cc10a23db482500186d61903d5b5bbdcaa9839b58612d3	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b0310ece-0018-4a24-809c-aa3c234f276b	2026-05-26 12:12:27.319	2026-05-25 09:46:03.471
60ec1dab-b307-40de-aaf7-9b228f23bd43	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x5f9f995395d4ff51b679aa4589e949fd24b4f7cd8a31929de5f391992d	AVAILABLE	\N	\N	\N	2026-05-27 07:32:05.41
c243318a-5fde-4b3f-9ba8-28a6fe3bb97a	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x13c025f1acba42dac925a6b19fdf93b4fe6115a4a0280809e65d94454f	AVAILABLE	\N	\N	\N	2026-05-27 07:32:05.41
7f6ee20c-0252-43a8-85ba-e0c9081a8820	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\xe26f02e1797f7d8df7e064b2457479d86ecdd5ab2e3af2d354c64c85ae	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	708d0b40-804e-4cb4-b6b1-4345b7379492	2026-05-27 07:32:40.06	2026-05-27 07:32:05.41
4b259378-4811-4a07-8ce2-52b777f23427	8000aac0-41a3-49f4-801e-1a12191721c7	\\xfc5ab383cf0ac034f15eae48e3b02d3b612878729099cacc33b0daf207dd	SOLD	15bbcf73-c01d-4730-85d7-a1cca3730c83	1cd13ad6-fed8-4e00-9044-978a569caec7	2026-05-29 19:07:44.218	2026-05-27 07:20:29.939
f2c680fc-f10b-4642-bd1b-a772c1c626ca	a4a52a6a-5914-4f9d-9c07-606b73a5e842	\\x246d02643805d6624c8ef83658db452d07fe67ac3a41603e8dfaf457363bf8973518431682a13f38d660cd93a910de148ad6b61be06bf6465e71d638724edbd55440f2d93c24f0cbbb8ca5d3131660f48d7dcd8ecb57bcd2a4c795614c60de823607f028af962914cadafa2dc174147c3e5527b9f067d889e022534992c3214689de3cbc935acb3083adb6387edf2a4ad1940a00e6a6e9927784128d387a5c06659bf8dd14287346d6b2a43e797d942998c0c1b9a2af93f13b15ad525f377fbf87f5f3e7531f01070bfcdf8fe566ff7bfc76e15750d5ca1d9a8dbe83b6fd35f2863af4c3d72d18cbb03c3c67e58a52646d34f86c565f384f5accc47fb7f6ce43aa39a8ff7997062c0404a9f6b0166e7f1667f1058b54fcb99836d98964f6622cd983ec3616f617460b4f5c673bd103c78547cf10d69ca8db6a6f302347531b454e83501d6e9fc01186a053885926f45ae11b9b681202a3a5447bbbcbef5174011b81e49c93ca38d520308299bd7f212525e766f727a964edcda5513a7d4bcd48d561c769a04b61ad77c7909566eaaf1ee474dc78816ded0ccdb8d7ec2cb6cc8d7387845214732145047e2a3891d37b362d027547c7f87d5f239577318bb17471b3bd99703e56b86a951f990f70695a40ad6bc9791dae4c0a2bc08ef8d4c5bd2392b6157787673538d0eee1f2f9aa94ed247959e40330a51978e1403ba4b236d8b10baab889af40ffb2f9031340be0f7c3961b8b8169048a0d924a3fc9a9d24a704ff41776f3b5563064b911bc9f3f0606162208fb7c1f3850ccffe6e05b404a14b9256add49c7c04cc6048ad20e1cc18f8ed4406b26b5dbe789be8c0a0fd44ad907b03e9c020cc89a5640245bd9e87d41d503abcf55dce3c9bbb7599e029579ad929c574ed8c2c51448bf4cceec603b8e56d85a2cebef9d760ef1860d338a19bdef74d85838caa0750b3394193e4ee40c7118b0c34d35646d10b836ed6a4e5862d4d4f0602e0d91ea40f2d655d0e7d4c9843f2fc77e8ce454dcf283c65ca5e9a27bf3320b4da714472e9da8d01ea6e86e8f83b053a834551dfee1ddad5bc7bb8cda782f9f5310bfc1de3ef794c809e03e865b68dd55219154f833e6a0c8be6c7d32ff7783802697f367cca668796104d94a2eda64103a9308b2826b0cd4ee80c880f208c159f67351ee2d28f289f4c88719fb35fc54d657edb4ccf2db24666ebac117858f05d3e8bc582ef4c6653cf174aa90eb1d17fe21470e3bdce63ed7e2cfc17847e6bf0a5b4fd8a95773155c38eb13f0d368d7f465e1f2839b9eac7332666cc478a13bc0e35549b75d0bc9750cad37dfb692d399012cb1a9be44316603eb970ef4cb54652e9c2e9cd9585acc52930b7429e3ad39f6bd2cb90356787637dfc0d02af4d2c2f053d56ea0f899ce9bfe3b9dbdb77e3eb2af5a2a82faf0e6c79550153f28e1111f7f71b1bde8b332354dcf84256d08b11bac0d6be366c728fee10cd73cb09ed760fb24b	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	09e77744-92ce-4e23-881e-6882c6b1a0d2	2026-05-31 06:57:53.915	2026-05-29 19:59:52.488
258e1849-79f8-4217-bfe9-0ed185e56ba5	8000aac0-41a3-49f4-801e-1a12191721c7	\\xe79d8019e9a1abf4357bf73f9dd1a9f59d18cd76fcd6fe2187ccc1dea7fb	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	bdd35353-ff3d-43f6-af05-47f2b9926d32	2026-06-01 03:14:06.81	2026-05-27 07:20:29.939
ee6968f0-9de8-4e94-9637-3c91b62c73d9	45a65117-624f-4e87-b2cc-add4714bc25e	\\x0f126f46f91dd0c4a04345b175e0ee8535224ced789e54ab15714c610f	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7cc98edb-7f14-4ed8-896d-29efe2e67340	2026-06-01 03:14:21.858	2026-05-25 09:46:03.471
965fd401-a209-4b43-a17b-7bbcbd42c716	45a65117-624f-4e87-b2cc-add4714bc25e	\\x5c61478e4d2b30ead5246f7f4fa9b8f6ee242ec02062ce1805ac9126ea	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	13a92213-3eb5-43b1-80e3-c4720e105a21	2026-06-02 09:27:59.22	2026-05-25 09:46:03.471
1750c1f0-5345-45ff-9ddd-79fa723c458a	a4a52a6a-5914-4f9d-9c07-606b73a5e842	\\xb55f23c02abd387d32ca0789377b8a5c7eb5e2484e196b0f8c88a55837c619c9b25f0642dd97dcd208d2f0588e0e3f1c37de7fd9a2dec8de4d128975eb5b3b7d92ce55558d5acbcac58f1e47f9aa38c23bb218b00d3ddda48c7348a1908ea77a73f3d3484d68e43a0d79273c02121ff028f317f144b61b63ee4de5297fa603fd5914a00d9266f1cfb3ee856a5eaf09890bfa019635fa1d45204c94d0425333bae5fc95727181ce8fa22692ef7f01a190f7b4999df7f58fb03454330eaa8c29cfaf2fd1f8470a817d4dcbf52434e7a784d2102caecee763a969975cab0451ce8661abd1811b5ee25d3a087bafa55d6cff4cd40ff052c09b71fbc178912a443428de83d12299aa7d3f81486faf5bfba4cb7551ba6ca1404a1f4d065590b6dbbc25ea437841aea4d84f3002e023d9d91e83c23cc7eb84efb4257932a31cfda665f7718a13049b7a5b3ab700a6b775cbb0764241db6d036d7b4e0ecffee70264db574326b7624fc122c174a20c8c86288e7805d4a8f8b560d3c84ddb3daaa9008cdfe3277e9f1aa899abeaec8578dd3eb5b68e91a27b176300357cc6596006db13a90d8ebaa869ef123a11a13291330532ac11cef9d585cac29e828286e71ff1581c051a0fa78d9c6757cd9026d7c5c6f5abcdc94de19a83d505b8861ba9c0cd9a1d14e6e00f8efaa73493c7c700ec95aac4f99ae71cd79c771e72ad9eb88ca8d9fa14847ad320ca70a9a431f848b2d8159d1d32ee7e098cf1d0ab3555f5533b6a6b96e085bbf6344cc4e4f2164bba0e8efa655acb8bf69d9d4c762aec11550a2fb935ce031765441ce12f91b53deb32c48e442b1f8243025d58a085a2d3d02221402245662344ac0553e9035ae0edb120ed6388a8b2872bc5e157e31262c153ec8996deaa9365e5b0aa739c3b538e0794c7f46490e380d0a8121bd9c35de916164eea944bc17f740d0fc975e91d509e93da425e51073147b45a9e75cf4e1ecbf5b0a2855e4f71028340963ed6429c08d1c264f2d4ed9431dbe624b619c7beb19581a4336548544134016141f28047361be34c593aafc9d80686914f294392ada282b04718d5019277c9e506653f3ab9243cf6b93252edb7f7d213ee860c7c985f06b585436b36f58a5a2082e643b8bef1fa0a831a5cba697ae22f3f31c6ec01efc6a507d4245dd0d420ffffd2ae874156bfdc2aa14a06d2231f257f9129a7acdbcea518fec5b9728cbf2632b9eeb2106de38bee0ad1ca2b8adcdfbf05e320512bd97f36d72c701c47620f3a98ef5e442f3cd3444c85f75346fc7eb4778566c3955af97a7c9808421bb876554e601546de285d2dcfd957f8076961427c8ec28b42351cf27d1ac6d1a1cf0bec15e68c1662fd89ccd9fa3833b963d8dab39952a0935e74367120a32b49d53e0db2b23034f5c5b39db51704bf80794c7db4499e24a09e0ad6aede4734bb6d494285ad6839a772f5bcfd968dbd28f001dbfa615b7c4125b110746a8a75f483f0e1ec067d0143	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	93697e0d-f53f-4ee8-8d48-a06aa37d57c0	2026-06-02 09:35:23.715	2026-05-29 19:59:52.488
86a47279-1c0b-45c1-83c9-d0f932ea5ce2	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x1ec48c140875db49ec92cbe4ef6ca8780b91a500a789dcd3c9ff3db138	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	c6ceca88-b3e2-4f54-8095-0850838658f6	2026-06-02 12:34:19.204	2026-05-27 07:32:05.41
d467a4b2-c65d-4bbd-92e9-74a0be9387b0	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x99c7b8ddf4a5a3a59c2aa8ab243b4bd2adf074b41ed84e4b9e8a4682b3b1b0780a716e0185ab41e6	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cfb64bca-11b9-4773-8443-bdfc730a319e	2026-06-04 11:36:26.345	2026-05-25 17:45:04.69
2ccc37d2-00c3-4bfc-abd6-4dcf738d653a	0fbf8797-e5c2-493a-b175-61f2b6b412ef	\\x86e95c85b01b8464fae3ee7fecf8b65455f6457d5fb849788a115aa3f9	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	35075bb1-40c9-432a-900b-9e1a9e7635ca	2026-06-06 14:21:27.603	2026-05-27 07:32:05.41
2b8608e8-77b8-4d81-bd24-710d51e97482	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x0abd79441197045e87f094ea1a54de41b70de1fcaec5eaf98731cdf1f9	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	6c7138b6-cded-4ac9-882d-c8ba5fcee8c3	2026-06-20 10:41:32.435	2026-06-05 18:18:46.937
2f9f5e02-52b9-4da2-a486-5fba690ba4b3	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x1f81ed4e5d9ee79282bb0207323f75cff1ac4d29281381603228dca1269cbb13b025df2fd4977af21a659c77b5a2ca44b52778b1d292fbfc8f476d2bcec1b95a76e182b8f021a241a98f548274e454a9679cc6131505e2314bad3add96d922bb2811cfe0266da3a2de1108	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	9bacaeea-f3e1-46be-b73e-36eb486c8a2a	2026-06-21 13:58:34.359	2026-06-06 14:26:24.85
9323fb11-f1f4-47be-bacf-485490c93070	8000aac0-41a3-49f4-801e-1a12191721c7	\\x26847384c573e500784de5c0154e2e3cf55d88e02e1c310ee5db355e7c5bd298	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	e47a4c15-46eb-40a7-9de0-a159c6d67ef9	2026-06-21 16:52:31.393	2026-06-21 16:52:11.195
9b776f04-9337-40b2-ac25-6888f9914365	8000aac0-41a3-49f4-801e-1a12191721c7	\\x6fc05feba88f13e53f1e4523be5f23da3df709406187483010c628d36eb2ab	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	6c19e223-b752-440b-a5f4-bc5b62ca1cb2	2026-06-21 16:57:04.071	2026-06-21 16:52:11.195
fd33ce3c-352b-4dee-a806-dec2bb25d77d	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x752b4e96dee37456b24297411cd4787d336a21c3d9e88c6212b260135ad0b5	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	ddeac787-7415-4a32-833f-ef6991bc0bb3	2026-06-21 17:13:12.001	2026-06-21 16:51:58.568
c2757b53-0b71-42e3-b016-4da343f64a74	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x626f43a891d0fa7201356761f4e190108d7e59a8a924f73dfa951993ae526655	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	f1babcff-2b7f-4c2a-bacf-7a60e080d0d3	2026-06-21 17:13:30.599	2026-06-21 16:52:06.073
35b772ee-a051-4462-a475-d4d118a055c7	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\xa7c10ff3daa9931382df38a7866f30529f8b3ed4e951f4369d1ef5fbadab2850	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	8bd91e5e-b8a3-4bf2-8b23-8808461b4bc7	2026-06-21 17:23:54.78	2026-06-21 16:52:06.073
e4884549-6f0a-464a-939a-e81e93b5226f	8000aac0-41a3-49f4-801e-1a12191721c7	\\x6d5a23d40bd56eec28fd049d15bef7dd9c740089e11deaee6b2268521fb7e702ae6ce5	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	a1d164c9-86d2-421d-9599-86f636e26038	2026-06-21 17:27:53.194	2026-06-21 17:27:37.727
d844a8a8-415e-4b79-ab01-e7a1d3aff698	8000aac0-41a3-49f4-801e-1a12191721c7	\\x9acf6a4a7cde261da2a137632c26723ded8d557625702c61a4ce746e2c1505	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	658abfc9-b55f-4157-acf8-cb0b3b534178	2026-06-21 17:28:58.272	2026-06-21 17:27:37.727
2cf35fb0-71aa-4ea4-9966-45261117c99b	8000aac0-41a3-49f4-801e-1a12191721c7	\\x2febb1e785edaa95dcdff7f49e891305af76deb97ae23c7d9623b3dfd25d41	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	273d9442-ff4c-4ea0-8057-0235305d2a40	2026-06-21 17:40:11.015	2026-06-21 17:27:37.727
a7b7a38d-cf68-4c02-8f50-78c31b9d3298	8000aac0-41a3-49f4-801e-1a12191721c7	\\x1d8d0758f2e132910517b55ee5032ab7deca85ff50d7d24ccf82d0f281c2	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	3833a29b-4ee0-4b3e-9c74-d7240f8e144d	2026-06-21 17:52:05.181	2026-06-21 17:27:37.727
fd2f217e-0621-450c-8a92-7b6fd784e3a4	8000aac0-41a3-49f4-801e-1a12191721c7	\\xeeca2699c94edabb887a93dc46813280eb6e11669462dc4021cc9c797100	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	efb84754-72e3-492a-bfbb-30467fa46189	2026-06-21 17:58:06.277	2026-06-21 17:27:37.727
08f55e9a-8a63-4c5e-aee6-6bf99845f6c6	8000aac0-41a3-49f4-801e-1a12191721c7	\\x2c56214e256f51864f44bf454f3222b80b43c75a0ef4a206db46e31065e8	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	5789e22d-68d1-4d11-b835-c8a6b530a04a	2026-06-21 18:03:44.766	2026-06-21 17:27:37.727
a12d2821-fbcd-4632-97c2-b8ffad39b0f9	8000aac0-41a3-49f4-801e-1a12191721c7	\\x111106be6e72934bff763a6fb09eaf28c977a49f57ff03dacdb712d4b4	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	f24b4e1c-eb46-4fc9-87ec-a8883fcf4683	2026-06-21 18:04:36.201	2026-06-21 17:27:37.727
fbd4a16b-92c4-489c-bac1-fcc4298cd54b	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\xc2991602509996fd841f74c95af118569c4595f2b1b6ffc80fbc8c3bab5584fc4c58	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	7d57b985-032f-4463-b286-29cec672e248	2026-06-21 18:25:08.28	2026-06-21 17:26:54.341
79f4ce84-b134-4b9b-a7b5-ac815efd53ef	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x4069c50816065e24dea843f8e367cea8803225ecd92fda7035974c4a8472a89fa40e	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	33da7412-cde0-4118-b670-9db66bbab10b	2026-06-21 18:37:57.002	2026-06-21 17:27:29.153
b39eb9d9-88cd-46bc-83b7-c615481b959e	8000aac0-41a3-49f4-801e-1a12191721c7	\\x2795c56aebe0b77cb93b4f5d4fdf5891458a97de21e1d540e484c0c31776a16f	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	fee7a9c0-9f91-4c99-a85f-48814f4c787f	2026-06-21 17:30:09.339	2026-06-21 17:27:37.727
6ceaf383-d11a-4589-93f9-669b769e5cef	8000aac0-41a3-49f4-801e-1a12191721c7	\\xaf3ff3ffb331c57b2a5637a6e14fbabcfffde2180a04a1bf7558876c9245	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	edd11f1d-f5d8-4736-aef3-23bdb32b4e4c	2026-06-21 18:00:09.772	2026-06-21 17:27:37.727
1470ce3e-9a12-4cda-bfd9-f8721f7b1a38	46d8319b-f7a2-488d-9c21-08a6891c7e67	\\x6ae7d3e858c36a39feeff9b72de2ea3e9b802efd12c4b5463758fd1a1ef271ffd4ca	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	3c7eceaf-fcb0-4682-8e64-96976bce9f05	2026-06-21 18:12:58.827	2026-06-21 17:26:52.864
41c979db-fc89-455b-8c5b-a83001f13b6b	8000aac0-41a3-49f4-801e-1a12191721c7	\\x35ece2ed55be71901a961a7d1b80f63a19b22b1f8c8623a449df902857	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
da4d0c8e-b28c-4f35-bfd7-ea7843a9807d	8000aac0-41a3-49f4-801e-1a12191721c7	\\xa69fef4cd9e8bc1d52fae3098ec9f6a5a4f0f587667bf006f36dbf7281	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
7730ea46-4be0-46e3-9056-e8bdcce787d8	8000aac0-41a3-49f4-801e-1a12191721c7	\\x44642450ca9ffdebb53db23f57b399b77e929a13240246831c4ce61d8d	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
6d52cb9f-1956-49d1-b762-9cff21e09624	8000aac0-41a3-49f4-801e-1a12191721c7	\\x77f43548905d46b5d676c026b5092987521bc1589d0e917841e9d5d866	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
9a4684d0-5b12-45f1-b9c9-b7d5e09d5c64	8000aac0-41a3-49f4-801e-1a12191721c7	\\x42812b11e6cca0568c500186eadf21c345193b93d46febcbae3e824047	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
b43af124-750a-492f-a62b-ffe80d18415c	8000aac0-41a3-49f4-801e-1a12191721c7	\\x0c12fd0d234277b94e9e3a59036188f16a3675b60470d3fd25e1cabf3817039f	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
92b7081e-7894-485a-ad44-6932a2521425	8000aac0-41a3-49f4-801e-1a12191721c7	\\x2af6b002569334d7d2ce56f5cbfcfd6c002114f7731ae0205e4b7d7c9f	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
4338d4d8-30a7-4fcb-85c0-ffb78ae86482	8000aac0-41a3-49f4-801e-1a12191721c7	\\xc6f5505e74c6fa384850129892a71c91c74aebe7fc1526131bdc7d3be959	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
c90da048-c0d4-43af-8a1c-7da6df124226	8000aac0-41a3-49f4-801e-1a12191721c7	\\x37999a72ba1f7f24fc500d92fa6231771e9b9e64b9ed4e65411232febd	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
45432c39-b26c-4dee-8b1c-67d86924d0e7	8000aac0-41a3-49f4-801e-1a12191721c7	\\x83dc0c810b7a598f95ab580efee6f6d5244ac68fc01a298460cc44011da2	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
0f3b01b7-9728-4844-8a28-0971cc1dfe90	8000aac0-41a3-49f4-801e-1a12191721c7	\\xd213b9a1d184d63d6a35cb45bb7f330e32b053a9180068d506393fe4bd	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
c2efda6d-f1c5-4ecb-a82b-f2f20145f823	8000aac0-41a3-49f4-801e-1a12191721c7	\\x4ab7f3d401d8c233f9daa065df2c5905a3fd4730eafeb89ac0f8fa648e1133	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
ebc74547-27f5-4fa0-83fb-a99f986cbf21	8000aac0-41a3-49f4-801e-1a12191721c7	\\xe6ee24835883d02c43f04ef6e406e95658ebf62863fee1179e76c7b16d5aa5	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
b6f1da9e-f318-4d41-847d-d75679bea10d	8000aac0-41a3-49f4-801e-1a12191721c7	\\x5f1fa14dabcaff800c5f340b1e4d77b3c4718d0d4f88a04639e6cf71bfeb8c	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
511366c0-0432-461c-9063-424fd76aa468	8000aac0-41a3-49f4-801e-1a12191721c7	\\xbc6f7af160d682415829a66c0f495189ab775ccad6311ada90baae93f2d372	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
8e4ca660-b168-4a50-b28f-eab671842233	8000aac0-41a3-49f4-801e-1a12191721c7	\\xe896e50dc72dc9fd393d7fc01e7069db446b67eae68130865f4790c31c95f5	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
a10d40ba-9c1f-4d73-b55b-f88749e5fc8a	8000aac0-41a3-49f4-801e-1a12191721c7	\\xc53c30595b757307047b2dec27b502e1e379222c9ff1109e2d7e3929ce34b6	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
db460963-6cca-42d5-8159-8202b1526570	8000aac0-41a3-49f4-801e-1a12191721c7	\\x3291c95acf1dcc8b11a5878348db05596beda587da607080fb5e9e2bfc25	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
aa545143-1c8e-41d7-81e7-8de7ea568c9e	8000aac0-41a3-49f4-801e-1a12191721c7	\\x807c5e72cb6f4f21ec582bc4668c477603ab782404b356466804982e973ca1	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
771c08d7-08b2-4b40-bbfd-103900800e9a	8000aac0-41a3-49f4-801e-1a12191721c7	\\x951b470eaa07a5b81c9a658f8aa2e9735cf7351d6e729b3e073704c603c5	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
db944ec6-9476-422c-8ada-c0d1b722f00f	8000aac0-41a3-49f4-801e-1a12191721c7	\\x2e89b84f2056f5e7a0c35579a6f49783e21c8f417f0029d7a4d4693d9b0c13	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
3ab7b97a-84ca-44ca-a733-11a6b5266b64	8000aac0-41a3-49f4-801e-1a12191721c7	\\x57bc8522f05f7b35822115db3ecd19ec9ce0d67afc6216f4f56a6918fa07b7	AVAILABLE	\N	\N	\N	2026-06-21 19:04:12.729
ac690ba9-fe91-4be0-ac03-c09a38e085bb	8000aac0-41a3-49f4-801e-1a12191721c7	\\x0be3c6119a0b614853d4595aae1802f5cba1170e53079095357521aebb	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	c6add55e-bd77-425f-be52-c219e644b1e2	2026-06-21 19:04:24.015	2026-06-21 19:04:12.729
34a3fdf2-8acb-4ae5-baa7-46d7ce2d9b99	8000aac0-41a3-49f4-801e-1a12191721c7	\\x6982603415e22bef032fc5e8b5e92902937a5cc68a9229c096b3427239	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	6d0ca435-d927-44e6-8e90-be80c2372591	2026-06-21 19:20:10.588	2026-06-21 19:04:12.729
91b419ae-c0a8-4c61-8e20-bd83f9cf364f	8000aac0-41a3-49f4-801e-1a12191721c7	\\x98330ac6ff0b874b13220133db7c90ac005bcfe81dace19dea6590f9a0	SOLD	3ad147cc-59c4-4623-ba0d-59011dcb6b93	43f2b6b6-3e49-4ed7-8abd-f48a12746b61	2026-06-21 19:36:22.477	2026-06-21 19:04:12.729
bc3cf691-3cca-4c2d-a99d-b24389f7696a	8000aac0-41a3-49f4-801e-1a12191721c7	\\x1db976449c6c32e1f115fae9579e908b7fc86e798d2bb023c79fc74e4b	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	ec4f1313-8993-4173-ba8e-cf9f3e734d53	2026-06-21 19:36:37.56	2026-06-21 19:04:12.729
8e9510d7-cb8f-44ab-b377-b9ac1671de46	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x5a00e752a023abaf6da4158ac7bbd6cb5e3140315e405d01af75a5a817386d2d7e5cacd9639f60108daf6b58f4e3951049c221fa8ce987c138feb2692e3cd391dcab6194	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
c4b0d881-b00d-4e33-9ef7-d9c174265836	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x0b05c7d62d6340ec8c0d2f76cb17545ec9e4c9fbd7349ca313cee1e1260b6581c345376c591385bc2213bbec0502511eb6c48bd21eab6a0ba27b2be441c2e48e4719733e	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
a2937a01-d352-40d0-907a-0fbb5e30b6c9	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x58cd0b97ff87fac900c49eaddb997ed3da8faafcbad96ec4bc63802c25b1eaa3bb86ce0348520204b8a87af32dd3772c0f40b8360d5eaa2c995d68b5fe7247e9203735cf	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
660d2a8e-ec21-41a6-bd84-ec08465454b2	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x5dceeb52fd6db4b4b30e9ca80ae7ec5c608a4b1ae9e72daee394bf4df0340d70b88e3d3038f54f41f098e95bbf635d28834b5f247ee32bf083f566df396bc17aaa188089	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
f9b417dc-6bea-4c00-b80a-78e495ed8048	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x558fc96e64933a9e3e777b3883dd30b599c59c7c879783860faaf6dbda0fcfa45dfcd1aaa28fb5e079059eb397b27b2bf788c489b59b67204a58362163cb387e724dbe8e	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
530b3117-73cd-4a5b-99bf-fdb2cf96d179	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xac7758b4aebcb1dde3928fdb33cc1a7c44f366c8fe98802dc219aefc084bd9554aec572362bb1c02987f49dea00620b5a6d2a29d72220624170d282f6eab7cc52e1d6eb1	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
af1d3cd3-16df-40a2-aafd-13cdd701b46e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6b0f4ac9995d2f0197503bbebd68a700f955a50100cab8f96ae60fc44e8116b0e7a1c28296b4cd115e0d4b67e680ff433f16d9801c1dd402e23770f1c547eb2d23cb17e5	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
07603363-d101-4971-aa88-f341ab7c6c4e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6fb52ed50872b32cbf1a2a76f0046bd1c5f450405d84b8eea81531da2e36168658b1f9cb84fac905d11f549b372135997377ebae8e0f1e378d1de2a1e138f70a9d19ed20	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
ac3c5330-4b97-41d3-a15b-1e2636b8df95	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x69de0bfb2a1a7de144af75e79ac1c1039998c2f21ab9183e2ea42d502713eb1aec6722006cc14d28a064816223e6f771374f58554adab64e678bdb894811d7081f3442fd	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
5f7c5925-2e7f-4545-888b-d57279cc4b5d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa0cd5e4d3ef329b83e0a450552f522ddd3fbb5c621381abec9bd7be3f72ac529d4cfb581987a9a28ab24b0dfe8d81addccb5b704e3870a76cdec54fb9902881b87d55b4f	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
648fa3a1-e5e7-49ff-9fdc-b3ba0623f7bf	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6963a39f04e788cbb16c2af651670c4374006c57518fe23febed71236be9305f7846d0845757c686ee62884dbf7973d26ad8682884d0dad91e348583d9f1ecd90d2f4ccc	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
2853fa92-845a-4bfe-85ff-a1a1b4c60521	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xb4a3fcf5367f1c5b12cb3d39d44c91952a9beb5ad5cca79e9212c4b74e6742d9c20848444dd22a0674d3c36b40158b07588b99cca51b9444512911f45cb45cd9a3d8c16a	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
7e9d11a0-acd5-44e9-83cd-bf298ed77b96	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x4d4bb607da3ac7b06b47c009789502ab1081a4c853cc8b8227699b025f64823b201fe3455a546fed31450746a381603c3f782b759688d6e7965ceca6f9ed359101542487	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
29e6c6c4-2078-4d63-9129-59e38b7a79d7	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x706850f1d0233c23d8bab95fde4485b76477a72e2b9c0c2ed03e765ae4bab4331a8b870d78bef1e6e96994258ebb15fdcc7d6f64fe4a23a4cbb468ff56b30ebebf58b011	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
8556288d-152f-4463-b9dd-36fc234c96ab	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x074acecc86b32140bed2d56ecb89d69ae5b68fee33a5aba743d25f8ab897e2479f9beb744974a55dcd06814522826cf940f8f07aedde2d6f97a008d63dedd60d0003373a	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
992671a2-0a85-48f6-9aaa-5ec68c7cb3b4	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xca030b176c962ee1966f6fcb170c9fa855eff6648f5e2bb2433fe8aaa06df0e7e9546f83439f62d6a765ecc66e925e962d4fc664e85e8c5602e97ddcc1354f97b8d428d2	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
fe944936-4a17-4fd3-9ac1-40b415300ceb	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x37cfd4283848aa179e80a40ad4e9cbae8d4e46132cab2816c6d5af2ef02fa92bcb8bad4ae3a09a842885c17079cad79e658f1a2482be4ffe0bc33cd26ccd4e5961702c09	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
79b1847c-eee0-45f0-ad81-8f12bda1e1b6	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf1f0b0e94cfd077def589ade2f21e681863e536166c2bfbd4b053f493ddf8c7c07019a1a13cda60b105f308166535fe170dae5c757de8c14741e9079659a36eb4a2a3841	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
27ae3522-5a3b-4bbf-b0ee-2aa8f9baa928	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x7c78a7a49d9eeb2262d33713082d17d736082bc17feafd94285750889f7a1b1e72105db19e6ba22a74dbb36cafc2837097bea2737400ca5f77588857eeb173f260d326ae	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
9ec1747e-9274-49e2-97b1-40bb28ade1e2	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x27c61085e5c3c63fb2766313498323b1c2af93cfec236e4a93e76e8c1ec6775177db2298bdd0fa52abc46bdf55da6209f2e004350655388b470e104514269aea81549b39	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
cb7311c9-5aeb-439c-92dd-0fb9f4779c76	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf7953f0d4bad2e8d0ae226d4d7a0220423f246ac65d7aa0adf1c3ff32a93334fdb6d046731fc119493cba18558cfe0447ae0b6456a37e0ab70cd55efeecb005b6d1a52ec	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
a02139ca-d185-4c70-be1c-7ca07287e793	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xe1040cc7279a3ff88b25ddec195709d2b5d3ccdbda5b6732a54e1f94134c54edb957ac6615d497cfa7ec24c75b9c898d4d774125fe660aa0376afdd86b5523d4951bb0ab	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
bdbcbe94-f17b-4e7e-b13b-c8386a0a248b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa1d865d4de6b770596b44f57409ec449fcc95a1c2ba42eb623aeeec0e375067bfe6c13839240670c421d2c9de0180ff07a4afdd060ab6edf1d4269d35d19571cea1301a1	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
26e61c97-0568-4bd7-86f4-6e83d33f1a52	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xafc7a8b89e7dfc1674ca4cc7122ca571c8b72a24874d26785a807579b47502ddd1a7d0d53658ccd7fb79355a45babf2f3ee804ebda4245db98702b15cfc1d088bec1c6f6	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
5c8cd63f-9e64-44a3-8e18-6bbebf042e4e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xba6c5b7a9d863e9a710c79cd3315c3aa9e037bd93a0cf8ccf7a5bbb7d78478681b64c1180a18c9366812533b8e2ca21471b720657ebcea5f72fe35f45a3353d17911fb17	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
df6bcfb3-1ffd-4ce3-8332-6e0e9613c146	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8d0207a7b69616f11740de2a3d4f60b28a3d148aeb5038d2ecbf13db472b42720ba253ca5d0cf2753d0330ba462b18b1bb03be9fbf67936bd9e8a4b71b576dd68ba177cb	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
70e9b514-c9d4-4259-a4db-ff05ae77ad27	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x43ee7fffc53139fcd56625969426c911e1b664306a6e93d083766462ec3597e68683bd95a1c7cbc25fdc4a7ae2e407eeedc7930f377ffd82ca9967d2e0684843e9632f12	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
e7859c0f-afdd-4aeb-98f9-5d91f5f697a9	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf4062c220ddbc592246192048350947925dedd0aa5f96bab721ff10b7172e309ea68c3fb8f7b21d5258b41aeae52dc5c153e8a7a6fdba5811b328c966a8cdb57bb53c2ef	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
59aa24e1-eb68-44e5-b743-7406b2f8de1a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x0057fe56053a5703055c081c1979abc18b2ce8e9b5f2ae4142432ddc96a58e470e588eed59290f17fa14e2d1f0b77ee655c651b95da4f3b08a21146c48b4a9e2bcead988	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
8db3e910-8584-4270-8690-a5cabaa7335d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xb00c6bfc0a985c137076b8380299dacb86332a16f56467ea880247714a681f61a708ecce53b2b19f577d228c497fdf74344de15da03afc1e411049483c752f34f5a7ed5a	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
5d819a8e-4742-4583-a708-0e3d05c6da35	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xe0d5fa0bcfb0db9b6417a20cac307ba77ca972f74a0d537b9c69704882eddadbb72c99a431e498685a276e5bdbd7e94c5efc3e348e5a8183dac42d0fb118157876badd12	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
07505b28-e165-4a07-9eef-4134459830be	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc4db7dada70e56d4fbae66ae366d0b66dd9c34a004a6b31c09d73937a07abd966690d2df0025fcf9c6501370201c7c290650bc63e53570091e5544e8b2e3103699ad4a59	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
b7826745-ee64-4b96-95b4-b59e85867460	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xac4c6e96ffb6b1e0282a2416b187149320733bfefa1c1dce84b79ed6fe28f017de4995f6d7fff2ae475caab1cf475cfe541333b479ad12692249fd24436102aa8d2b379a	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
ed64d046-c080-4939-898b-767bb7c8cd5a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8eedf67eca0ec7dbb6e2d4d76245ee17783a536eacad1dd0f8135bf53a726e7f54008ea889f22d5a60086824084a92461125d289fc4a9e5f2901a323242b1ae66ffd2ecb	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
f2ee3567-f9ac-4565-b0bf-b370e1c57e82	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x25c147db8f945f402e5c559be9f07888411b132826f9f423fff021208aea010c7e2b6152cbdf1ace2cce8cc18a9855f07f28a2283150c32ce6a10cfaed24b0d78717a111	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
6e579d9b-0b62-4fb2-a989-ba7b0d6b8829	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc87cb518cb30766936438f193ad3c80cb89a8218afa84e4567d19b3307600ad5416f9d7fa5d07b2ed599e67520bc9c225978284db6b69595b04735b8c5ea2c672a88009a	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
151725bf-916d-439d-834f-7b9e7abb093c	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc81efb7f3351e3c710659ede3e7c61a9e3391e6e2e9731ea92cb810f7a1e7f5a4b519ddf0dfcb5d359510014e20be4a73aaa3d02e584f965c254cfc5f4be808cfdd71692	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
1089a717-119a-4aac-823d-d40b43260372	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xb7f350f321464871ffc9ef838be5715f6d7613ddd7cbcb5ae600b7b92e6a96acf68f7e7c2dcf85fd27ce05de6cb8005cbd5f6c57664d38a21783c78022bc1b119fe8cef1	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
a5be87fb-8e22-401f-a624-e7c528e83653	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x77b88b524f3cae172ab20ca437a4703b70240987a63ad17e3a3084462e0a59226dbff1a79416ec63014f4c9ed13dfabcacee744f7feddf74ca3a7764e65b5ee5540f1db8	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
32455e07-3202-4376-989e-9d1a25df0244	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa6f4be148d6272b60ddfd2bb013c7371df53ec3232ae26ff095190ddf616b6770e556c5feb54407831309a04547984fc8a6d9e6a31d929aa0bf0fee710f9b7ce3efbcb0d	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
7982fce9-c64c-4984-ba22-c5a981575a0e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x12562c5ed521844917def60c42700d3f6d34b688ff71456b804909006a79d5a99ed44cdf664453b7de7e34af2450356585f74b8374a34e103e19d801d07a9f38fe375546	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
71bcdd1a-4bb2-432c-bd1e-0f6d8de5b3c0	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x7476566267c825887dd2bd18f0eb5e69a11bc152739aff190aa580ad0465834daeab5880132bc00418394c2da3073859df67c9032e49d41453def219ebaf960abd25865c	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
05c58f6a-4e5f-40a1-8ff2-e81cb439c94b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x03158a5398a3b6c6eeb8aa181130a12e48f43771a8c36f777ef7dc8a96f868b6a382829ea3568dce63810a039348cfda327208361f0626fa33fa474cc85d5191a965a776	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
ce634b4a-8f75-4205-895d-ef4ce7ef2c07	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x72193f2f4d43db6b5d295d63b62a64bbb57178ccb27ed4833c08c1019733d2733741e0289b3d2702b77079b32dc6f1dc4c4e835abafd8008403b5a11d2f59a28599e412b	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
06f411d1-b712-4e64-a3b0-084f86358d86	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2b7968123d2f50333aac66bba78345c2a6ad18ab781c6ab4e4c676705f4ef4a79d177f0fb8640ed9515700000e337bca590615576123ff67b9a3546b599487a99949db14	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
b7c8fd6c-f9e9-47fe-8c76-f7b3bfa2c983	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6ea66e73c26f4d876dca70e88c01ddb671b88b3dc6495140d566a09a649b56af9fbc4c152ba6d66088302e3221794edb77879223bcd7e018e784d2fe3f2711ddd466e68d	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
f2ef5a81-1579-46ac-8a50-0784922d2b48	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x78e9ae47f94503b44586dd5686a2de07a746d5c492e7aef8fb4350ffb78a1f2bfbeb26ce9776552140b846bbddd44732099a6551999b1bdcc30d33d3dc250b68dd77fa92	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
3f5669e8-4d83-4d56-bb2a-38ad97ff4866	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x047835bbb7abc8a6f1909f431d3fa27f873846efa06e34357e6ffaad2551e9369cc8bd5a6ef9c913f32d0280efb1a01f8b2a886c4fcd6e6f08daa04761bff41b9af05615	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
ae6e74ce-19f6-450e-aa8f-b9398e4b0e5b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6f7eb77ae441621feae886cbcfcc8bdf42ab87d9745c1df5b58542310eee4635f1b3433c04cf09e66a10f510fe52fc5e774191c3730eb2df283bff95c407829abc77be2e	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
e87fa499-b136-43f6-9136-1e12b667807b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x7a08ae7f34dfe7091157981790804f75b3b5f95d01f4b567d86bf7ea9f240b24aea820e37210d3eb28084fce2c4caf010d5e2da71a93c5ca9f833664ba6accc3d27013d7	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
b0d47440-9a79-49c9-8548-328cdb523828	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x4d33e4c0a99d50e44b8168fcb036262ad2fc15497dc6efc0700e6a53c11e1ce3e204e6e2d7ec52e4bf7928be250766cf44385edc3fbf909e0413d753cf3b30bd32dfe627	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
49329bd8-9fe4-4bd1-a568-b1aa216cd2b0	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc387b25e3259ab6ad5a7447e9317f0770437872fb01ce3f08c947bc0453e46e6ab65e89bea793a58870c11ee5c6626c423c831978299e7d64a8f030a76d792102fc1db46	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
ad011533-11d8-4ea0-af0a-122113c2929a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x3862edec30281a81850d7badb15420e0d92019badb5052b4ea66d175e8f5b2b31074a6d96439d6c495f120998c7eff16fadaa599e41106ea55f7c30bda720d48c6c896ec	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
7c4671a8-5641-4fbb-903e-030df967fc85	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa2f2d65e25ed8f381f96bcc822b4582ed6bcb9aa6a9d723f15f8cf2e6c241b2edc012655e0c4da885c88dedbadd569f4d9a7cab4ac2d01e34094874268c7d5ce72b0dd4e	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
e013a0ee-ef2f-49bd-88dd-3c8ddda682fa	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa4ed20820dc818d1ed4adb9e47b526195063dd4c6aaf702801eef6dfb7102df552f9512febeb24354f34264939dba4ada633505091867fac8ee6b9273d0ddedad2067cf4	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
06568f83-fdbf-41b7-b874-77be47436e5d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x419ac7a7fd3092de67bce00d045d6272b0e759a7778c3ea2321279a19d852855de3fed18a6d77e7b8384717248c125ff0894be007e7ea8f90d33fa8be92a9a61e95965bc	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
196b4da0-b5be-4e32-8426-700e645fa364	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x35c3efe0d68dc6378b9c250b52eec21075505ca8677bada9b225da16d00daad7f6205e7202bd4ea217f3c51e5be6e64d4d79df3d138d3fcb12d235f25f614b09c9c2179e	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
808b903d-9539-40fb-8f56-2a0e899279e1	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x1bb1bfc7ac64d251dd412ed6054d9539b637055b890851997a6468ac8ab3453146f23d1f488370d00b8a58a1426a9c82206699bc48a322b3b2dfb5c49902781ec7ffc660	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
813f0ce3-ce9f-4864-bafa-4d8b0fecdf6b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x768d74533119f2dba05c54b9b505b914ded99d53b020a1200e7292493ce35a3b18eea861b43ef8ac847b34c13f57534ce09c1125d5160cf99507f76ef10304934b170909	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
0ce29415-99f1-4f90-88ac-eb2571ce0029	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x135388d40fa06e96137dcee42972f0f0d3a78e8ed507b998a981f5855684432130e25fceeac3b56630cf0123dcfd4fdd527d76e0f474a135ee438ac358b69ede40662191	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
918549fd-804d-4b9c-8736-394430f37c83	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2788348a82a6387daaf25dc203390996ae6357c048ba8de742d4762e4b8fc3071ffd1f2eb62f423e110be0219293dfc8db78bc40af117c9270c451bc2b266f88ce6fcd92	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
dcc7ae42-90d4-4ace-a6ef-303dffedc83e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x3f62113a1f6e4f3a0a516edffc60e22767b285b054c3c7e4c3e3bba87b9dea1e81e3ab62da079ba82f1830b66f10275a8d5d51824de81218dc1b85f435f85e5a1a87dd18	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
e0b97039-7c6e-4aaf-8cf2-6238ebf32edd	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf0c9a4a77826b155b6b62ee0f1097ff7b414b7b8ea40c72c9a67cc3d279fe459cf97fbc1f668137a89cc54245fc74a069cc25f439c8944c425a0cca5e0cbe36c0a0792a3	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
09469d0f-8302-4b8b-98c9-489d722680f2	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x07faca661f8e54980cacbd1f58ce1a0a175b2f8cdbb8314e2114b93b16c21ecd90eb77809d60b0aba29e55fd0bb4daa80cb3f1f188e8302eefea9c7e74982f6cdd6f6459	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
f9ee7c28-3e06-4a1f-977e-177980926465	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xfdd09ad976402fbafc6bebf610036bf2023c0947698cc94011ba0f7ffe4424d54a91bbb38e59382a28b3e39545d6a224dd6c4ef480f7190588d56a3ed8496ebd7db713a9	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
b285c2b3-b66a-498b-818a-4442cb1ae644	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc77d3be7f01c871173aa4c555a1c8484e922e0177c434af801bae57945c1a64065b0e05c847b4b5aba9fd504bd43af129ec3136809fccaab2eb594631e86554c46bc83b6	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
3d93108a-ad85-4566-b2cc-4e835448119a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc1aea4d33886129eb51eb881afee9a27436516f420ff5e0765706b4068dca83b0a8a2c6faf04aee31f8d10b5629a0715ab78f031b4218de19e82ca3ece3a180d5d43eead	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
c80ed02c-f5e9-4363-801c-d9a35d843d85	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x636aafca4765334d116c73ec244dff8071606aea6862d3c3c23361dc2540c731406d07ea8015777a93431e5045ba48aa360c72819b20c336508d5043dba39eaf3d022cad	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
b2d7a56b-b6f6-4e66-9e71-23ac954914a9	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x7ad82b5bdc51b9d82277acb2402d6a46c96cbca3c42e061cee9430584ab8db96c54b7a32e34ad3e6b49785e370f3042d518d2149cac14e371dcb6c3c09cb239688bd61cb	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
f457bb2e-1527-47d2-ac36-7f756b1b668d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x41ddb2e33e4da02f56299a304ef94840f632214f5da6d801e2a26adf7d2c2711a374150a46a302f38a18044137fbc0e9e8a43b846a9440fa6e7fdc21abeaa7ca0ef7c8b8	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
94cde1da-e3a3-4e90-91a8-c03e017f3887	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x05a14d910b58ef6295af8a2d8f41ecc8ce02dc5a3544a6b96c078a43dbe426d9a923c20c7a6ff4810ff47a7c32fd9a872e00d7fa991ff2e02ee0a0b57e9d95cf0bbd4ad1	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
6088ec54-0481-47a0-9078-8473dc5903da	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x795f928a2115126e5574177e4fe7bbd91ab1283688d5357e8ee47c562e7968ecc5f5a0a3707e4cbcb62c715b85fb44e4e3cd0ae95810dda93ec33250757f85aab98a5b3c	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
719df2fd-f394-47bf-a322-9eedd5265d63	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xbb4f6e9282de8fa8238d04f012523b49a013f95b38baa0b58c314eaff7510028105e53ebbdceee7dc0de8ebd98b6835d761fae582184ee5241a6251e27164a6c3d535031	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
2eb5cb0b-8670-4a77-a1ef-46e6982b195d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xe12c197a465edca5684c794f30884fa7b6631e547d6d0fb0d0f7585003b008958faf9f141c50fa1580c85277b013eb27b3fbd251d1fd5534e42e9b1529129eab9066d691	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
cb71ae4b-ebd4-4a3d-a515-5f256543ed5b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2a29b1d95e95da373c0cf550655beae64e1b009260774349f82bf85458f9a918981bc46ee94f94ccc5a510af85333b5e7b2d03998a237916ab2543412eee575e34ba161b	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
962349ce-559a-490c-9fe9-70ffaf34e967	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xd78687b78d85441bdf3ac4cbf2242cd5853afca40810ffc263f8ebb6aebc1a6a8fead853191ebcd762b0394a91648fbfb20ba4acac4de141a61fa122fbb8c944a277c012	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
e0b9b5d9-5af6-4e6f-abc2-d05e29b068c6	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x7ac13a25eacf26414ae10035e9c506684e7639d5c7425223ee4f1e5bc60826da27a279c4ad404840d5ab9fb3d63c1ce1bbd32708b2d02e54a3ecca18b9ee4bae006d0a75	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
0e427256-d1ea-447b-a2e5-73f5b88b35e7	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xe10273634d7e993aa91b82cb14a3589ca2fb675239480c21b6a5c431b0b2965ec724d2c443614e949e5f1fb54054112e2e5fae3967fd3e2f82746a89ec6c067f3c6f7935	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
19631925-338a-4520-838c-4682d21be0e6	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2f0e011227289d8cac4dcafe6109b93d75d8deaad101174923ebb43eb7cb3211db7641af54396241955a5b38210498ac44671479c978561af8ddbca384e06cb0d083ea65	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
da452085-a5a8-427e-a29b-7e9ba6e21e32	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x1a74b00529ff6da3c0c9c4e72e4d3b01839022e4c4dd2de34641b7a2290b49568e68153216fde199b1c1cd0ae64e5e6722c84a086362c772f0c8d4ab88ae6e7a1719ea23	AVAILABLE	\N	\N	\N	2026-06-22 05:38:44.013
f37b2f81-e0f2-4bc5-b71a-50b38c80949e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8959d8e88ca7ffb1d74e5b9ec960ee6dde7b424bc6bec67dda80183eb427d8e39453abfd897cabf7a383979896582bbd903a2e25ff1efb726bcff17e478579ad05770df4	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
7c892a54-f5a5-4dba-b5c5-f4092ee6c8c0	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xb306f776e05ef86daa45fc21b7570d7d3e361eabb0e6d2d28f76535de9a4ddf777d3c881ed3911c85734a7c9a473f1370cb93ad351b3d6be0d59b4f6935067f65e7daa89	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
54133dc3-711b-4c76-a55f-423f2d5cb58c	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xd04553ccb3783d9ad8be88af5d6336c128a0ad3ece985a6d60aa405b82c1e12e7fb8d3710e569636b4ab91be964284f9e631b6cbea67a42fd8151ddf8a306a059d107c55	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
e1dcdb7b-1d99-4bbb-957e-82bbae2f2bbe	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2a1fa27640a2b7f625a4c076a08bade090b73a5a5da67aed5adc86b58c3b6afedbdb1716163c6226e28bd338ca09c6cb72b5998f30b23671e0a7b47873e8a51c1745d223	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
88f423b6-30db-4506-bcee-373858ce6585	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x034bb2246ab4717ff06d25af2b7d12f9f9d38e685e202eabefc57a0b44559a1ac410e37c12a7245fe153bf0e424d9aec0c0d55e136129c90feb5d5d80f20feb97b64ed8a	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
282ac7ef-b1f4-4663-8754-98e7fd8b524e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xee61b00498ea930e3158118722d6919a29bbf1c5b8892f1de31feb7e99cb2d2322e9918aff0a4d64c2064dafeebe3ef994e93f7cda2cdb0c063773a099443c2aa09499ad	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
fa7b6e2c-de71-4dcf-b67c-ff199e6ad7dd	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x9450a197458bdf1b46424642b7027067fedb676c050c499810e95010a48f6b39830165c3ca437fcac4f334316be13624a20aaad2b4b876196ff83dbc6a5c6bb5973c70d3	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
529a01b8-a4f6-4a58-8241-51ac921c1f55	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8045b1d07f1ee02b2cc29fe1eea87797e61c6bfd14183fe2724854371c1f55ede222f496a2d19310895a6dfe40242c9dcf58950010ee0ff85c9f844d4eaa50aba4eb0ec3	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
679762cd-931d-4cc6-8cb9-e8fc7d1fa9ca	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x22f8cbf1f1dc5fc32e3a8d5179548be3df434b6333d73db900a6ee2409e329158ff58ff84c68ecfa023bd1803e4a054acbc3e8f56abd678c5c64b03ba0787534621d6819	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
490e28b4-257d-4702-af3d-76c1e5539bbf	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xff1bf91362cf670717a9e72a667df4d396a7f4f519d5ab05d229d3ff322b0553474ec44ba3f001338bef9141815ea0cee3f8d49f3825add6786e1e26c15619a5a994fa93	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
67d36a69-9095-4833-9ef0-622b44b8b8b3	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xe1896cdad955ed99f018f5e9d1959ffdd20bfa87d878ae2572503487157abaa59d19afaba66f032b01b4d40b278714c75987847cf1eb59ffc9661b01df0dd2884b34fe1a	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
cc429f82-2546-4e3b-8391-f6b411650867	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x0a7a82275d09cb4939ed436b9d3e20476b5002f6b22cd948bc8800526dd2fc07089f1b155db8a1fa17449bfc18c283486b0d48021a7ddc942c481cca1b0319c39044dbe5	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
42f2e075-5115-4664-bdb4-27dee3f3f8a4	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x4d60720a09f33e8e6b978569d78758c2a0d153ba4a49e287437745e1e4f2f6854effd9280b6961ca0f8b131a6ce803a7632849fde9526ba7577e8572b673efafbe4851f6	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
dc6bfb4a-6463-4bcd-9cf3-a056e178c1b7	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x969de2ec1ab6a22b7775f88310ebd7924657d7b7fbe1927616cb0ae6e0c9ea5197f05dea31a5d819718dd1fd402912df6267e83663967fb8e9427dfa34cfd9429ba13584	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
b09edc9d-4ec4-4691-b11e-f2c6cb4bb5da	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa21828fd9ce8d2c95cfb89dfa65fc44051f32718372161126d83ff7d5c39f86df8f1cecd412b3b2476abc2f6e2b7f20253155c34fe1ef232ff004046955b13262fce2461	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
71d6d733-ad31-4862-9455-cf4cce882a25	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xff16abe2c91f4a49fb73d53331a1ed2f9d3b4570a0fcc13408379bd808062f5a1cb24fbecd8040ac05c455a2b31565cfe883a04ce48240bf821d71f6797895fbe1ac8067	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
b3bfac52-f055-4e58-91ae-87cf97ba2e15	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x5d6385fb1903d0572c779d46a225f3cabf7dd12e66f7c60a51c9028bb72dbf14d7b11f45ffc0e0fc5102fefe2d49f031e90c45a38048193eeafcab0905986b5ca74b66e6	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
4847cd30-24eb-4bc8-81f5-a536f57888f0	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x76ce366a6918f9ea71a5d23e1804cb6eead4b767f68e34b4b01631645ee336648bc20a4a9c657c2c72e77bdf9cad12b1295ee1483330a4c20392074aeca05df9e14ff79c	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
08ad9ce1-e375-49b7-bd53-1e0c60fad341	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x966f692568ed37de1683ac1f172e68ad4ea9b36349aa3a638f9441b9795d18c80280887bd1ffb6e3648a3f09fdfdd0d9a9b8a86a546b77dc9432c7db4c9c5337917f6106	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
dd239158-1c7a-4a91-88ec-b02a206b836d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x60bbeaa4c822d11177dd4867f7318ce973e73644ea2261ceb32fc7881551c6f48e6c3f13ab78d873282400811d61b638b324a80188cf4db05227b1208f168755b3444001	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
390a2096-ab0f-422d-8832-e44530ca9d48	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x76afef7a9ea79178957877192077ddd20ca3627a40bc16472aba7e1baf93e8ab5376d796779ce717c8a61ee95e9805c2dab5c155d74a32e6aa11ca9c4ed43be09e5f34c1	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
699ee64d-7145-48ee-9806-cf98fadbab36	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xbf8856422ece9791ee627cb3efbf5527898eed2a6d5d6b550f429c5917c08d7ea2aac1f007d4a3ca43d435a77e05d5bbc5fc3b2657e5b4ec8d8d142a6dd6988a1926020f	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
c937a578-e891-4982-afe4-033763b86fe9	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf5a62b285752c915f15dfab9964577ff1d1e0939ceeba474fbbe7c6a7073cd708cbc1a463d61129be3a0f78817316d37ebecacc51458a41c5db8ec2c2a6635ae2148f374	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
f2bfea13-712c-498c-892a-6ab923bbd320	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x45452f426449cc60b1d12247d955180f9c8183cf7547f10c1822ac301cb42d4f37fbcee6264d34e689de6023d92b701484af31fc1e04ec80bde09967dad4328bc003dbb1	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
4e13709e-8180-401e-b469-881ecaf9cd42	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xcb432b655d9d03d162ee9680b0295c52fb1d29f6838568417e08abd460a4905d1e141314b247d1342b7fb17321b1cf4de4db0e7704e5f926c1b27dc9425ca4b1bbc1fa81	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
06a59c9e-562d-4cc8-bcc6-cab73b030242	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xec288402d17e13ea29fab631c2bc588cbd4068a0d810b71b5ca6a8f50d2951de465313f8a3c3699376359e1f8cb6c327d97aa5d11e918a49c0de59f34f46a2eee8934434	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
a28811a0-0bc0-4534-b606-c64d377eb3df	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8dde7724842bcfe3d24dfc9ed6b4c019beb9a0ed03e594167bb9bd1e25de9217127d552c444f24dcd963398f39652607f90d487762f0131c8eb141ccb44e2f17bebf6915	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
d3001c92-0ab0-4be5-9c54-ae02cef33f6c	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x4ca69f8c1c0209d53f497c3e234700bd30105cc707e59aa93880d546dd054ed538fd3adbed3c4b4219cd5bc000283c5a252e36e0af19a0368796be8adb8f928a887afbfd	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
34cd6780-83ec-4234-b8f3-11dfbddcbe70	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8701ba94748eb8d004f065babbb57f9ae69624ce54f8b5cc8095283008313df51ff23b1348e26d8a90394f5a129f0d539f41e4039b621024d3bef753015d23fcc94b3886	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
b8ef8ed7-7996-47c1-ba3d-c45eb14a82fe	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xb4d83f9849051dd2a07e10e0474910c56277916464a7be9c63f5ded76c14646b228ae7648d9e47de5a5cc22c577d9770f2e6e7916cf73bde11584628a5a126a8c4f74e95	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
927a489a-225c-43a6-be1e-fb31b8121d06	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xec78c544a20d1413f0891a7dfdeec0510dba2e2f33f0f8b9659cc69de6420faaed60c8baf27d16a7d49c35533a4731068c6fa861f60b0c8e53f64a2f817c057e7545236a	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
53cc251a-e200-4cbb-9f68-f909921052b2	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf79f48b69689f2ac1c14a7ddae39fc9417ea99e515b2122eebb82191c19146258c4b4d5cfa5e60eaf44ff70fd60ad1d685ba1078b27d43f20b6b664cca119b9e6f266d3e	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
6d48321b-071f-44ba-885c-959d5b4fe49d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xe7f449fbe205b59cf0de871165eb6fa5d2ed8034fd7676957571e7beb93aa6d3931f792a73ed87a432ed5f3b7ac29caf7683772c8f06dc20605616a1aa74e08127767d51	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
1e1fb074-b984-48be-ad02-c895bafada2a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6dd2efd9107f0ddfe917c01b985465ddc21da7b5bb1124da24694fce3734dbafb6cc3dc1f60a86b115c6a62036320e20d019d01fa16ac2658960126de69268198a428f14	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
20c7c403-f73f-42ba-80bf-250c78d3f93c	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x694af725da27caa44507387b8433b911767a8e187b122bf076bdba41394267989871fa92dd896f75b1dae73725438674571bfe2e622498fb7cd6eb1a906e6ae0a2e8b892	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
b882b26f-2d25-4a0e-988a-cd1ab8a25fc3	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x1d097cb603f3a050324aca5f83d7b8a43861b387232d86a74b1905d4227638fb609aeada84474344d84c7853574c2b994da09b1a26a984b468ec0e1a4865a0e023a9fbf9	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
7f13aa8c-b7d1-4a47-b46c-40d176a9eafd	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x7c49c2c8d2202d43d59a1f0b4e9ac2ba52550d72e7908717236498458b1759dd43d6809382877c49c6d4ea3bbe656ac5e8cffccd92641952a092910b22cd6f009b635578	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
185607b0-f8a3-4901-9b45-8f9f407e2549	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x0e074c52e71a056b5bdfa59005bb0bf58517311b3a8b71fc0117fc725184e8b56f12c4879c489915551fb7d9d4787f558b7ae5c8b3001607a40d2825cf7b2f3c2e9a0d93	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
a91d4dac-7f87-474f-a583-06a9ab93746f	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xcac12ecefc391fa5f0f896ca237584bde48399d3c5f718e52704b9072a6970a003b0b57cdae7032d4eaa85040fc157e30ea51a9ee1e4089b17731159ea8f06d1a1fe30dc	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
b641f991-72e7-4aa4-9334-648a00b64aa8	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x3783f1f6b23a6404263cc7f3af741ed50f4a71e0f6af08b93766dc8d9ebf9bc5cebc6b6169a8f8fb1aec1acc368b8c2776c7ac1bb178b6c232a4bccf0841196bd3d4f643	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
cd443dbd-d9b0-4f22-b53e-983002c184c1	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x4570cedc8eeae482ecc22044249360aa743305812ea70244bfd4fbd2215a8e8512a6565ecaa66f879b4ae69f87fe843e07ca446d00ed6bc0d75487571fd3676dd79fb5a7	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
7c2c3a10-c316-46bd-b1b3-ff9749da447e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xda019dfb00ae00e15dc3001c3972a7cdf7927c89cde6640d4079bd4c527d264e62406d21768ccc209a9418052f6ce530442659b55d4f23b1b518a9b30fa1ff502836f882	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
f7f30807-6e4c-4fdb-8938-4044bdb1f54b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x82cd9d0c43ce758437cdd46729af3a50575de6848b94509838ae0d67e379463ac3d3be412455692d6f9c37c65f5953d762c4a95616780fe0b667d9274ff3d9cf1a911589	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
697c6e10-4e20-4df9-a7f9-4991b39a3500	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8eea7ead260923024bf61a9c0d72d0212c680bd635fd403f2db15aeddf493515309c36971f02b1a2fafc93833ebd6fcf9854a0856644837eec479fef33abcf4da61c170d	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
5e357d77-19ad-4f8e-a960-b312258eb20e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x422a2e01f170c1a4fb7b6b86276452fdeb0d0a12b1fbc95b5d18a5d09b417ce053611623e2d81943c9f5dd516dfb077b9d58518882e9e853dfb9371e6ceb76363031bbb7	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
a2d5a495-6281-49fd-8d07-22d879523670	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x7db61a0def61bfb6ad0f3c46c4a2cb81a25e47a9ed335b68cb445755133522196b191292fa39bcf6c5a5931c925c0f331dcee00a5bcf6b32dc171af0c2c07020f00c9c98	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
30ff0494-a774-4993-a533-eb5327dd4022	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xdcc045e72b984576876947c6aa4ac321a863b39135386821867a4fd7e143fee8ba869e25186c3b2e40ec2f8ec0cc5df46ee626572f54905d2a464c7422b2c8ff63a43b17	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
5cccb75d-335d-43c2-9fea-91500600b3fe	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x08f1610a71f730a5710e6d5cae28e51b711199fae41b51329567d7191b4ce4773b66ad799bd8d91d7f64b3c36e17e7c74c5f9b4c7245ce8e9811333218c68672f73d3d49	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
8e9e1aa3-3dec-4be5-bdf3-6af57d4f339e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xb11932e67e8ffcc0fa59d787f37267edb31276a988d829908c264fa441e34238a28989eea5140a6124908483513e40a3bb86f8ac7bebb0335385ad11fccc29359c939b18	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
31762a3a-a80c-4b20-a239-d10028245e05	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x0fff82c6d9ef9c3b28e8f40b24ae183c706a3122a2f80b483417bef2fe9e93e01e268486ed82c5de48a1a15a730c118c85f08d6a2ed95c50d5ece8ca4396aeef686dd46e	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
26672ee9-6597-4fdd-af9d-e1b8a52ab7b9	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6f7f7dddba0d95b9096a88553f51b5f2b9d8e4be665f68cb472a316d7a27c42cd729373b25f1021db23305a2bf4deba43d4b261fdd44e2a75ffa3a7cd2eb31f5f6795fe8	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
95abca9d-24a0-4760-bd71-2d9f70124c5f	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc8ad6a2e40d7632aa10eedbf3b9d7fa2702ed8095cd9f5e7d297ec8796bf8322ce21b64b09449e9ce4674989a9f0ecf47e376c740a1714611f89c8d4e71585ef59e5c3af	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
ef105c0b-94a5-45c3-887a-63763705f0b3	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x9c06c406969786d8a26b60c75cda1e007acffe28b597df6ac593ad9e715e2cb97d7679272d58c580b44514a9d2867e264a6d0b19225bce547b1b446ca3668a89c7bd51d7	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
24f6599f-804d-4e0e-b6a0-68f0dc4c23a6	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2c514d2e5d0b0a15b9a89159dba0ec1f6dfa3504d68ee85ac70c6770ebe5322383ab2903a1ad496cb57673013339dfd1d4dce7eef2980d6e945520a52c2aa2eb61bea143	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
4cb9f3f0-10bc-403e-9387-56a5899b6f0a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xe59e82600280aa633604cfc66f137ac0f221862e41d16811a15b17961fed61f9792bbf0e2174be73c508257067966556726398b8093bc55a1d1865faf6402ddd5a338281	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
6c65a6a5-51bc-4b91-b7c4-79b35cdbf243	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xad1fde6f2e7cb62869aed3d94e9579de08f5c7d6b9814d26f0b2613d661c149874197635162e426a81042da7f2c29b05e5702416cedfeb88fb004a428fb31dd11ab442b9	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
8388d000-85fc-47d5-893b-4692a3c81b5d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2afec6b0d14413f16ded94ddaddc2dc47af37ed45542c1091b49f375365e5edc92eb50ec17e598fbfff1526fa2a74b53d9ae2a1a8aecea712a17b88209969b8b99b9f263	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
be583365-022f-4b7e-9e37-e9a4438e2557	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xfcc82fd59f44a7a272591e193ca0bb063b0429e3f0aee6eddbfae2cfa2184606d7d9e40c08b5ffd23c3d5898f01275fa0c28e0529ab7ae2de1d6553568f4a93fe6a57818	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
e2e56982-df63-478c-bc43-b0d3909afbd8	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xef1268a3b59d0af332ad464f56393c6249b91d1f30da680d3aa3b6f164197706358b08fb4188866d50d9cd0d3ec9157308e724b35808c2ebecfded4fa4148046e7d2c2d8	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
c2c6ed64-7c93-4cbe-b459-8579f2148487	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x39f0928bf8742a52ab2f06f4ffa92c4a42bf2ca9e4179e30c7cd5693370f0e19297568a2d2523953e70b7504d584cdaf0cd3254d8ea13f26c64c5accacdb93c905b68022	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
512f51b8-0cf6-479e-8979-ca25dda6272a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc9a71041ce8bcb0418a5f142ad2e41a70dce6947c433ed383dd3eeca2766329e81e2c55f06a8141c3c697452b4325dc854225d918c62eb4aa2060ba887d4c447bc02e332	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
1e31e311-2f8d-478b-b2e8-83e0dc4c67ef	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf296daed8abdd74631303ada96ec2e0585581b8d601823506671c5170034d5f47721a6ed5087fbc43800f1cdbcd9c64451b8ca7b7f47efcef953d708d8f60808d19756fc	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
56b26c51-5a27-4f19-a2a7-c669b557757d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2d9523580164007abc8cb1a31e4d278d4a0de446f2bab4a245e0e8a1f1748911330a89ab214e1426ec901c2306311a8fcaf0903fc5e58dcc000555c6827bc5cdeacd8adb	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
7647b33f-edcb-4b2d-89f8-8ef39203de00	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa3b892c2831b0e174aa8cde4482a2d602461839d70bf0fa8df89fb4baf7774033ebb31536ccb0348b41808903bfc585bc2706a9371a73ad4a56f68bfe5a70ddaec7d1248	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
e6882a08-aec7-4d60-84a7-2dbff95e09b7	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6dc3e99768693e96cd5f502c171b083262ad13820d2be39564d33bd3e3f52eedf55d03ac45ef277ed7149d2ae8e2bac7ccbe168a2c6f2d6dce3620ad1dea1b4def07baa0	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
39e99bbb-3a98-48bf-9c4c-5facd06f5fb0	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x34c37da78a931deb35ee7730985a013716227c94ae95c9b96992c852def0b73e3a7fe8ff8380a729be4dd14d779dd4aa33f5883f7518247fe1d3599f98a60be35477a7f7	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
812bb802-47c5-455d-8e86-659543a39672	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x872986c8cb42d64c9a2614a48860f44b276d322cbfbbd5be57740b606530193e11cd9e5e718ba55521ec9d53ddc80561e59cde5294438b8f93afb4dd1822882538889c7d	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
47aaec16-d5cd-4d29-b7ad-643979546c9c	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6d0e77e0bcdff87fa44feb26e1117706a9516be42664b146091f5ea0a9bf79032e1fda8befcc4b2523c5ae5dc3336e1fbab6b79b77ec73cf73223fc1ce9cf2bda7dea2d6	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
490f060b-18ce-4e9d-b7fb-d35853cb352b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xfff8402ba25a39a2029952b48f44abb7f56ed11cd8093b11676581b9850500b0907a4c0e4068338fbcbf8e85a815fd46fd9a98adce2d954f871ce3a87e2831caff71d0bf	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
63e4c4ad-8afe-49ca-a300-9aacfa77a64f	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x820d3a4b08076306b8e17ab519c94b6a9a2f25d12f6a6f5e5e4c27e7a149cdb3c1bda60a551902127933f519db6aa245b31214020ff98c7c9a3eca8d2bb5381d1cb41434	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
0d643857-f0d2-4659-819b-92fd59e6a4f5	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa3e78ebded03522e499f0c5b2d48138c446d6965a4ac49dfa24bacb1769f698a318e0fbce28d43bf93663ef73a0344d0be3e48ba3a3a4c8045be61c382ee64104526856c	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
36d20ff5-dfcd-4d4e-a808-b2c7187992f0	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc68b8e2c6c89c940d6ea168f2b2ea377a29e95dc15332b2289ebcfe38f5ae832ab13242030c7451d0e35a7ac3826e6e743587e1182fff6348f591d1e3802110ce379d6dc	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
8bfdf52a-03d5-486d-bca6-d33038f2151a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xaf5c475e098496d5297ddde8e64dd66b96eae2265cddf475b2f12fa42ae9db06de7a5e131ca3281f0de8ceaf87428f1faab49823ea4dabd4f93ad3dccdb99ef1e6f50ce5	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
3ab34648-0ea5-4a44-85fb-65831326af06	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xdf3c2d0ce3b98b5a650c43f09cbf67078d8c454dab94477ae285419d4671daf11c87ab96a1cfc1aca12fcee3811fa32e2e100b655287e3e6345393d27f5d7bd00453cafc	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
5a6a6f8a-b787-48d0-b39b-c158d0cf621a	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf7ff68f871eb71290bdd917c05d733f079b3c4be41f56a9a649bcf0d82563898e4943226ba367b06fa1006dec6134c89e1664a140689b9407dd5b646d58e8d2806f58c10	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
b2019937-c73e-422c-ac86-0167236cf5aa	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc28cf598d7cf03c5ac1c847eab9d98b2c878b116cf866cd66fc6527966c0f9df0305a52ca5b5408a167963d97224d8575a332d1194b2c9eeff24c473226f746cf57d4df4	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
83143deb-2adc-4bd2-b7b4-2701746b6808	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x471ae90d94adf5766589ce13b85a5cd3b1ac7848ab4ab2ff60e48ad766a61ad71f6a8fa2ef23faaea27db70523a4cea049a24fa99b4b713605e309f2c41766630a38a970	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
06482114-6d3c-4b21-9c9e-fa1bb3b88bad	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x9aa91398f7b80fa7dfb4e57027c417e4b03687527786462b6af893923012e99565bf3370546ae39da67e497ce5dfd44b311e474d2952370a271f70feb18e820c705e1de0	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
975a8a94-c312-4312-975d-c903db191324	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x93a45ff7fb485242b58f7d2fc83ed28925ccfaa834f40467e0cab939278a2d6c5ffad0b9e2edbf0aed0c635e69d4b4fc64dfa3302329ba9f899f27e50d846109c8c6c379	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
01021345-2e51-47df-b1a0-b06b9ab62e38	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc5f2c1769d9b63681c14413505e436ec482c74a1afb1ae9a771c7c6c7ce9400958ac72e9e5c2f900586411789203f4370f5adf22905a9ab99622cb5a8f6c88a216c7b31f	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
4c018ad6-0828-4f40-9c25-8f74673a4df1	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x22f9c455a63051fd35cdc7e68d1ecf7b75b6c2c2f91115e3921fa47c60036c3ddd2fb64a9ce714a06b78946fdd398680537cfd1765c76b6ef6964b0a88d298ffeadc6a56	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
54f0009b-83b3-4c99-8b98-3955473fb103	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x95b2b4ccf09d157872601d5df1264d066486f69c75d18078a746b8f97c254171f138af7335df45422d1a924d1704e4d1c75623f3ba8c243e63f80a476b068269fbc3099f	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
aa3b0c55-b258-45d0-8334-1ae414396f2c	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc0315a03b720f7ffbaa0f1e20109e1e6548e120a8b6521b78779889a06f78d4f7bd539a890c4f6d7d72213b43cde1e118377e7c929468c1a5e9ecdfdd1a51d0b922e95fa	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
4c08e006-c022-48c3-9c9e-f08e3ac1e98f	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x6b3d55c40e6f94e68a621e29769115f51d14958b551238a928ac1fa957a862c1be8a7d744a27e4176167c49d594a5137f251f6f0b7b657821baf60fd2ecf5d09bc4cafe3	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
a3dbd11f-1cd6-48cf-b847-7aa07988823b	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x36a3803543c0378e479ee01a70b56001f0af882659b4069d8bdf9bfc054f2478b979b2819100a04ee3e23854e65f4989dcc71ce30af76c506402f1886ff207b615e58e5e	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
67e6701b-da0a-4884-87a1-ffc4d26ec346	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2f195a444241013e2f767677b5ceab13f6a585c0b84bc838fbf02f0fe505af53ee1a35ce42b17656a95c07b174c50dd678f81b06037f70eabef9588997adbdba58b8fed6	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
17d130c4-d480-4094-8e04-9775fd684966	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x41be318d92e28c414892d53958465bb6959296722b4735203382dd40514500005c5c2b21b5d6770c21e1473b534343ad5c76b275c3e074076376c5610c78cc920d9218fd	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
57659460-1a07-4b36-9237-fd6236089f23	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x9a5dda54b884e6c135836d6794794c2483b5cd2b1e07260ea639734f3ced25d2ec3640b664b62ea68455e77ce2bad98dd8c247ea19af54f5184c225d0d82c2c0140bf60a	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
387653d5-6421-48ae-9e63-e0ee92938c12	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x5359e59f0c3f5dc1ae997959129e912c0cd59c80caab9c4ad135f1bcbee7e641b57494cc6b8d00bbb64f9c90023c3d5ea35a0ce0d2389e2a2a3a5b15198ce45a448d1d7e	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
5553aa72-482a-41b8-b503-69b46b549364	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xa90bd82efa062181e39c7c88ca2c2e265d52348095cd67778ac5fef1c40c8206c54f3235c9ee1eb2f84dc038128441d061f791ac8a402c2357f3cfb0a5f09db4266ae02c	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
8dfb5f0b-14f3-429c-ac12-e5f40ee2872d	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc5b5ec96383fac3627e7d15692780e901ff14d4f37d23f24261fa109c7fee48c8668827946a12a31aca57afb246e149bc4544d20877e28ddbb81676de99021783b773cf2	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
0605c041-3de3-4437-8fa6-aba6a9367dd3	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x48396314e35e7accb1d66d0b3cc88f99fa18f350fa7f1814eceb2f0cf8c6d6adbed54f862a3b6c09dbe272cbaeeddecc1d86672965c37cee0c9a3c2846eb10539010b2db	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
a5d55d28-f147-4b05-9449-021fabb13cdf	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xd8e055df18f2e34c35346ab23681c4dd76e35e4496bf1784102139131d8f9dca875dba547432703409e2bdc7ba2922ea051e3bb404bc287f6eff023f5b5944e583cfd2b8	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
f5a8e508-01e3-480e-84f6-d4b587773c92	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xd8e14da087057b9f1a781787f13c62f02a17afc6b3abe54fe0ce706445b8fef6dc880e5a151bc163b99ea616b0c1080345bcb7c6e0722100c49be077d71bb9914f850a85	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
4406532d-542f-4055-96e7-6109993ee672	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x345beee5705977dce71c521114ceff24ba891010709b4e2931c66226ee7f077fcfb053bf48978a36ccde4da420bae076ef99398fd5550c4183edbfb1b4ff1c8a6b4a4ca2	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
226fda7b-7702-477a-8dc7-da644feb9836	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x2355ee604d5f80e710812bee9f243424a3aa432f2a0a8e0dcc27bca9fdfefe2226aa4277e964e58392c657757e3a2c6ce33c23b6db8794fb5c0ed7a5c82ced3439d70087	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
3ee45023-ec3e-4532-9c96-7ba97319686f	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\x8a17439e4d94f6cfa923ec4b117cde1813787663124813f49dcf8a602f926b07a39970f50732ae34f02c9906a8a75b9753e7fbced1d0edb98f79c313e6ac94da37da1859	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
567aa04b-c69c-426c-b13a-f819f14130d4	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xb39fb13026a21c3d04ebdc3dff59cb049e3e30c038def47d1bde2b38d9fc91f3bab7c1c00ffd09d7054c5767904d61eeed5ec7a496bd2f2b5b33a3cccf8d6c97ea981475	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
68f2a126-7bd6-4ccc-b6cd-3efd8821ca8e	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xf13618d1a3f063be62129d990c32650048ab4b285be3bcaebe3ace24e132de78e1c87b363de35c7571b2731b8d05ed5f9dd45f0be724b9d07222ac41e0c81d2e4047727b	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
48ed805d-76c5-4069-8c23-95f4c0403b59	d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	\\xc7352d38af1910e03d7c1ff806cd64a8752b12e31cf1932a49bbdd15ed4051fed958debcf5802d6e0e60f8396b588944157714c48690a0224dec2a03bcfb816163e03c39	AVAILABLE	\N	\N	\N	2026-06-22 05:40:27.667
7163213a-6287-47d1-85b1-2b89046a114b	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x5657a59f2caa8bec8fed6d4d42ac3dfba88c4eff8a5295c109026c3ea2d6367928d776912244fdb6f93567a13b886e605c974db27a84412426081941a15ece914b83cc2b	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
c710d2cb-f892-4010-a907-d97a55e97f40	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x8092acb14cc96946f79298581fea0bfca45a01c3e4784f28083d7dcb35ad5043287bb6229319dcbbf2401819163fe9cd71adf07de3ddbef1524f3e6ee5e9aee90e996ff0	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
4d9bd2ab-ed58-4dc7-911b-ad55cc9cbf40	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xc2d02d038e6baefadc8d06603354224a79751e251931abda9422c5871939e33de9e698e58d0466267a094865c91ec8ef99467c0088e53172423c9afaf229f7fa071d252a	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
c05bb03b-9f31-4e03-b3f9-69731efb279b	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x532f438bfdbf71cf1c5165930869314172d0427619cd7ef51b8b70c2ca0302f83310de0c2e9251ece5f882cebc7b1c0fbf1f110a802b197dc306850585fbf36bc9073a53	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
e61dbcb5-e1aa-41bf-824d-876cb2f826d5	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x082263b5e6ea5b92dffbb343647f3d367f243755e218824a3a06323169b3b5994bdcf2e0a8f907f754f882cc07475b4ccb6592cd54632ecc0262bf89c5a6d7d2487be619	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
63cbd07b-7728-4760-a6ce-6d9ada805124	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x266236333df74ec2b82848c335ea8d1c3fad3c3b8563ada2fffb01b04209c381529cd17a6178c3953ef30ff837971a49e334a93d876c2fc9af71f9b17fa501c3d0ea0449	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
3420d6e0-91b9-4a7a-a654-f60485bb46cc	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x351a01682e88ec73ad0f77c303f154d829aa8d589dc4c4e0e6a3de3e1a393d5e957bbec2695c7da663f849894bac4d7355dc3102a96d96ae1bfdb3335cd356e8b8716050	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
d5f85192-6306-42e2-95f4-08b47df60c6d	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x8c4c8332abe9b4acd1615b92858b231d5782e8b970bb550d234ce8aa40d77d6f13a857e4572a85c64b3ccdaa0c013fb8adeb5c695defb251c75245600bc88a7323c89aaf	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
c45d3fa1-e2ac-445f-9551-899f17530e8e	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x45a8ed37b4977109a54658c143e82de01f953f553ec1604fed65bc883d3e4c0370f9325a830769adaa1dee237c4403a04f93cba0bbb28bc73f1ef622e988511a2dd54ad9	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
eea23821-1cab-478e-8f9c-96288006da0a	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xfd75caba83697e82046d8a97ce3a6286131e4f33927b3fa8e3684bf3cd1886e4b59c3b4c276e2f94c744f0d24bbc495c402a0bb67bc53f2b11e369c6ae3e121a5ce819e8	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
81370d46-c07d-4d8c-b2cf-a2afa48463a8	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x9a1bbc58b1f39a21a912fdcfff1fa4bd4b5d0caf35ec8d4e88521b4280184f760275e612961e03e8c8dbe4766a781ac412aca56170bb1732c1a423b71a5879903b2049ef	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
93e53719-9d7f-4882-8153-21255c3226ee	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x4e4ac8b586ccffd0e2fbf239227e2dbccdee58ca6116be7d8b4bd1164b002d0d2ef139fe3cdb880ae6b2db395be3be27bb3c21d9bfb4061097774edb209acbe61495c0c1	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
6e74073a-5bc1-4c48-8fdc-c9b6221a9804	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x9051eedf4fdb72d35fc929488da8b524ec5e79ad5b91d3a485a7a674f6030c529ab7ff004f8c94ed76b081d1c3ca43cbb7480ff8b1acce518dc1264bd7c4757b313d1aa8	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
eee6057e-596e-43b2-b0f3-2202a3897216	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x1574fdd829f2fb028bbd239de5d3321235c27b6d22fbd19c8414b055a89bf6030224a2eceb949b8b4bd9f182f9e475dcbacb0fc0f65daf17bc91cdbafc5eadb403e6414a	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
abe7e843-dfee-4d8a-9c75-e0c52427e313	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xaf20510d99cb97d232993586fbad000cdfd492b9e6e193fb5f5def66b6303e5522d640c7bab26c4bfa39356a9b11f96cf28f06a3caeb7ec50f7440d85de113a733cea325	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
b4c79728-a7d0-4120-b11f-3e9ef3eb1235	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x78d5ada39e6017442b73c6b985ce490e0d4a88a4536abc45a94e5bba5dcb9d31a35a96b90ebd7b66f819307116a78d86e9ea3dfedb628d50cf37dbff97b97e53c6784655	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
a5a99705-10af-49f0-889e-17f4aeeb2e39	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xa72de6424ddecab589476651420fe4104c6bee55b7d9a236f20fe01d09cfea7a83c115ce792224b912921ab3727db32fc69f153962780faa92a37c22f2ea4f3e2c5a6506	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
3622da6a-0e6e-4691-84b4-d232bdbbed16	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x18d2b39e002888efb34fd7260aff1e200ea0213c3574f15b34b0489e976eb0fbef229198e19bd993ad9b78de3c0dc4cf5809b408ebaabb46351acde3f4fe5522e0efe072	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
eefd915e-c88a-41a3-9eb3-a96524c5655a	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x8f226c1a19724c3378b1dec0f2a724d9fb83331eb2d69a26321623bd592ac57a384cf3d16b7c337f9ff9ac59961176fd5214d38e873460cedb2053e2114c1178018d706c	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
46546a99-e53c-4063-ae88-b0b07a7045f9	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xcfc7ea883dfc57ddf88ed2849096c47034082fe99967c6bfde25488c14834a16c79a9ebd856e13cede5784ddb4e3fe13cdad02f2eb69b6ae617ad98808677b41f7bc8a22	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
0b33c7ad-8a59-4749-9e29-13f176eebb34	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x6aad316ee663f53381ff10b701f78437c71662105ebcf72d284cfd33d89a31a17a82f2fbaf1bd8909ac17f1f5fb23f7c784af6df3505576ed79b27f97fa8551385e9ab1c	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
00572420-c0fd-4a90-ac0b-58c4fa8736e3	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x11445f676e514dcd93abf5abc6e0d947f0ddd04951feb634f26f9511d25370d02349a9947c72fec96d7471dbfb509a98a134b2f88bbb887a49a22e6f6b6ccffb34eb46cf	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
87c0f467-5b7d-47ba-ba26-7162b544bf4b	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x2338a4950c96b948e40be58e8bf375eafceecae975240a3237d797823c7369351bd7aa6fbfc638717df8e949b055052d8b556d9075e45b84722f5b7fae249b9a699edf1c	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
3592619b-1e43-43c8-93d9-c9855c6b64ca	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x81ed7d86c8953266edcce0da931bbcb9f791740afec2ca56ccdb84ef8a26a8fe001d89fe1b52dc77b5d01c1fc60f49931290c14fd875ec6dc92e612423da4a995397cce0	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
8805ed44-80c1-4a8e-b155-ac4d43b133f4	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x318837d107a11df88ba2845ce5a4398eaf59d9ea08dd0aee9e7c70023e348a764551765b67795d7d406f7f01fc4894f8843e6ef8b0d5c8ee3ffdd17322a670d0d8ec76c0	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
22780b14-9d17-4273-911a-2c77300fb0bd	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x3f68fe04ee4777b16a0bbed9719fae28c61cc4cb8073786766b842feda3c0ebdd8548ab63dec76dc09c3b21b979bc5beccef6f843d2b77471e81480917867fc85a6733ff	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
f181c0bd-9a13-4118-a879-d46753dfd519	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xe60db82845572c67148480dd83c71037b627655047a5b01601bb89dc77db92b2b4f7d5726b342eab310e225a58131665e4a59344528a4b99bd3472475973d5dc973b9173	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
f62a5374-7f0d-4e21-b505-034f65d09fc7	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xca2ed6f27b10d2a25ae241db1e68479f0e700af13a5b6654831ad902febbe8536aa7d0b774ab9080abac330c96e8a985e9db07b99a30b16b3ae29c76e9fdb334273ee95d	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
ba966921-0570-4585-9592-a1fac2741f64	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x7753846517c23b3671e6b7f425bc85cc8837f7a47fc325afe76477b490764a718155000b8f5cd31ec7e6ac73b43c88cc962646a3e21c3a7046e59c19cbd15bb1c97ce808	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
50d2fec6-a0e1-4c92-9a6b-9a1f98d81264	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xd88cddeeb95626f438f3fffaba4cf64209c68c99ac885c02fe62120556d8fe624414ba9b09b377ca416ff619678232aca8126d12649d013207ac5178c555e2a060160792	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
69a165e5-0b1d-40ce-b110-5e87a687d3f0	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xe89dc7e3f85318e2d0a25836e2beac7c93bbca7c43226e998a49622cdd8d26ee73ce4b3ce1af8dfb3d6db64c7e2e2f681e0740f5ceb8b13e08e1ece181d181cfa11f1d4a	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
8e4a67f8-235c-4c8d-ab4e-78f2efdaf145	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x75097e8c9420a87a958baded4bebd6323a39a8adf7a88c08a418a7b0183819d9c700cc802dce4eda32106b6ebb426741627c005cb4d7e8efa4a3d5f3c4b95b96c2d8ceb1	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
bba97ff2-78f9-4531-8add-cebe487f14cb	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xe1eb3c9c55f2397a5ef8d2fcdda4fdecefb4fa3a67774722ad169501589dc71d576f501ec224e27842b72152afc0b6cf9a8760be603c1d2a5f58d942d2eb0e03868c1a16	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
ce74876e-79ba-4283-8498-70d43b44ffad	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x5ffb08b44169030f68b73feac3e734de56881058a1b69cb281201494791fbd006d48bc449436f7de50d328469c2f6921f6fd55c7f37cf3d0a422cce9404b2605dc1eb084	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
902fa74e-a493-47fa-ad38-9307461899aa	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xf3b7741b08b37d15d94fe936f45a8ff1e1b8fed94ed54ece75ccaf7e9a6f2bceb4add55cbace0a92ff558189e2bea971dea4db07c3c58162c14153043052d781f6e4a3bd	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
56193796-79ad-496d-a624-35ebbec232a7	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x9b59c6037b88259517b67c800c8175444c020c8e97dbd5de75bf2471632f52a24246115bee9f891ae9e2fbadc767429ee7ff163436a700b5900cd09d37c0987108b5a1f1	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
ed4d38d3-6b5a-4870-a2c4-9013779e2539	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x135b4e8a488bfaf1cdb60ee5cea4f3a36793b94067d25bc6437b940108b43780eeb7a145220c6fa9f75acf2fa7401da528641e92833d16d0819097826b52107ee4a7c35e	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
0e8e89db-bbf2-46c8-a0e1-9eaec9844464	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xfb4328c84756cd355ce7e031c3046cead4a6553901a32726010028e03cd33c5a89de621bed1cb34d1d1934ea1353032cf2121e423fb17e39ec450861be986caf44734911	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
1731d419-0b2c-42be-b6eb-03d020d514ec	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xea93af40ae1ac1c6e178f2de785e1b67c808c1ac04bf1eeb942a399ff0e731a63856be1f244554e8629faf7cd9cd605c6596a9d9ca059ad29764d539a43001f2d0f4c469	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
93e7ddfd-7017-404f-a461-4afe20fee9b5	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x9555bd5b867ebd7aea40aa5911b246b2e5c9aabe3715816e4ad3848138109fd5de7bf8fd990962c9d156c906dedeb0bd326e12f8ef4fd421150023e64d3eacf260cbac40	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
1956dc6e-8e09-4922-a064-1d21fe5fd526	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xbb8f9cedb8446195549528afed64195c8b8639f3a5b8a784947607cbfacf3bad4c90b6349293411426ce934b5cac0d0fa27a88355dce9dd6fde26f6b573fccdcfb006484	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
55165823-43f6-449d-a3ee-ed155a527ae5	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x0385ec782e73aeb2f845472efedac78b77b1899c6c99270988b51bbf7f67fafc0bdfb2e819300a7b3667c2e99be0071857ba545ce569478dfda4eb22f3a88490090fbaf4	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
4853cd82-decf-4469-b6f5-d49bb99528fa	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x99b7fadd1cdb5f6aea223a1a6b80e9e7c6df030d254b53ccaba1de63eff5c78b5596173576e1f936d88e21910a643f40546e86b9c72f15a72de0c13e1442e803083f142f	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
c3ea6aee-f67c-4a50-8876-8df93d17b9d5	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x396dfbf83d36b44d5b5a2ad3414ca0a090cc078c4a371c00360bd786917d83afda7d98e7ca2ac14f157134a87a988c4b8689efaba6278e8c63e431f8a0e498a09c256117	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
d577689a-1e07-4ac3-b036-acabb9a1a4ca	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xde23c2dd741c6893d24b164f39d023a56c814f07c9b5232a39a154d698cdee4a4ab1c69f03aefe0a9eb737af92e47c86fbc3fbb707ef73a5ad24fa4889f4639e96e7bd8e	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
5dbf5451-237a-4b3a-a9b7-f39b2cd1feac	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x353745fcd4cb6bebdec30b16f5ff851d20b664d5ca49da613e658bc86eaa8c3a78a1d9e6e78e83a40df6e9b4ab057ba8508202812ac5cf4bfe0e072f0585070dac83b038	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
f7ebde92-dfb7-407b-a28c-bb2ec3062f9b	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xbd646fde0d0000654cace95ffa35b605b3b0378ea558c6f41d0a691bd83fdd0b109c46e1befde50f69a48ddbb9a9d802260590b1e2ab177ac1d7bc1eaeba4c8dbbfd8a83	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
a7b14f2f-cc27-49e4-b49f-78dc9121c275	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x8cadaebe38c4b13148cd829d80eb67b0431796faf2579783c252ee87f34a1ff609581fd0f02e3d3dbdfcc16d4c39b893fefb75884d9f48912060fd218efe158718404c99	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
13dd3349-5c7b-4deb-9fe8-eaa54fb956ed	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x91b4124530658b74b780f1242ee87e30fa3faf0390112b4b0ad64a1665668ef9f73e0a4b12a1053122bd49211a321232754db773e0b709f73dbfe8b4b08e097156d66c2f	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
241c860a-980f-44fe-a673-67c131a0dcb3	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x427f2ff1d3bf648b26a5fa03848184a9367e9be057d8e411f34738f56f01d3af4d9592c43aef0aa9b18892f041caa5652e0a859d35e3e5c3d8d51de02b52474a11f4a39d	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
452bdc70-54f9-4fc9-ae1c-f5bb23f34fdc	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x975e4d90d6f6c8f69d2e4260ef2e031dbc818f503e5113b3e78b0086a64acb715c5e976f161949215f9a8344d29361fe9c86e5a99a320705a0c5395a843d11a335ee9df7	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
438df717-5c90-45d8-a66f-395987a22dfb	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x856a2280d9f4cf3f1dd4715f1232e44ea12de4bd60c63c1b987b38687cc80c98db741a0c059daa4d9ab70f5fb6d3eca845358f894dc5508e582ebf124f04049cee8884f1	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
98dd0078-8dd8-49d6-96b1-dae5be5cef06	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x61d00effde34602c5f85b2488f16e14d12a941d596ba6c0b53992dab0f4c1a6ef5ca55e96df02aec03b28a355217534b622e3db330baf5f36811389bd3ae24493053a9fc	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
e247d52d-a54d-42c0-94ed-9942f43bd079	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xedfcb71a0121556b706f59b3c579cc2022159b8592646238a03fe1f23e060e83558357287f39e092061c18765fecaa0bf87499ec1b38cf5833d38842b91b4ba8b966677f	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
577388a9-812d-43eb-92cb-7b9e486012e3	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x72deb7b32a4a8004ab30dee4769b9fe3bf534b853ba370b02ae2f32b25b6e89423ede8868cd35762d3c15e531daedb09fd3014a54f8a70f032719e7dfbd70454e6bc59f7	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
6951e1a3-1590-486d-9bb0-cc5381ad9a1c	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x508725b11700fab94e85ec04458c342416493b8c07993560b84066230aba1d6ca0e398beb8198a90b4a845b7433e04d435879c153310becb79d48cdea7ffc319113486b9	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
306aba1e-e506-4b2e-a9b3-63ab436b4905	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x34e535b6ac34990825deca77f8c72e4fd33f48b2163caeaef0a4362f9eea5b487b1a927764d8f32de381fdfc5c266aabed0e18f36276c032fc5e4959bd8b5bbb78dd1797	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
2d55914d-6033-4f91-8218-d4d4f7e4f751	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xa0cd38caecf7c13253a4089d47597d8b570ae91e99e97dab2696acf47cbd21411d4d3353b8ac57bccddff2b7b492cf99547b5dcf53882736934238f23b46648f69729a61	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
f0fa2ccd-6492-469c-a785-f0ddf35958c4	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xc4f224e39ff9145c9812fd8dc646015ebf81c83e2280e2e401f3277be3f27ed52c4dcf342837a4ff41c026392ad1b49eee02901a19a0961dd86e0ed51a021e12ddee2bd5	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
adebcce0-3480-4dbc-9e55-22bdcbd106f4	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xd4db1f8fb624cfee64a84d9e7583842e97e6892711dd04d563be203a76f9dd70294544aca80fc62e5e2f9c91dda6b7b540b264b31683cd2a85a92fcf8ad855baddf96e44	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
102943cd-a6bf-4a0a-b87d-4ab0a4f2c94f	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x092a4827765a9b17d17ad55ada8f4157f0e6c28351de9f1910f6e09fd59d2bd120b50b6c5cc2eca87859f16b81d63d10b9fb9cb942e125a09e4d5c76e432d24179565b82	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
9a23b0fe-da92-45c1-aff3-2654216a8dbd	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xc0746a314d522a5024b18e33e39176af8b823223275f5c1f030b31845c2039343f95aef5f5998bf9be34197ed0f3798dbd0ae02d255906e7c41f102c7ef63c628558f346	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
4e009a0b-c9b9-4d25-99fb-8bb2c3f47aa7	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x80ac278db02763c2f2eb53108779adb2cb22668c34dc7f2a4f8b561725393f444eda5a4feedb6d9b693478267542c1076dc346b89dfdc32bc4b62686282465ff1903e1b2	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
bf3cd66d-78c3-4af3-aa34-19bad1dbd832	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x3e9823864abe83317e1ce9d0f4588eb0a64bf40ff7ffb720c21209e64b92498c832e22e472a6a55e32107ed047354474b2bcdb6b45db9ca19d78eca97d7659398ea6e947	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
d515ec89-0d3a-444b-a5a8-b159073c5bda	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x698dafeeae6ef6258cb18cd7c3106bb46e2ac86c47a784cf8fbaf82a7e5b3dad11d594ec7f697eac5ad0c6b7b9c42d3d14fa99f569787c4c87c7e904b3be24b9759076e9	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
ef1e1283-4c3f-4a84-9277-71538bfdb899	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xb93a898b42a95603c999ef7ec0e0a04764cf60792a1c564859d757925878979d4d28c6b5b7e3589f2aafa3aed16664082d64146ed9c69ab1f5a99c2da0f3ff5b5b5c9e6c	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
ddfd58b7-4554-471c-a0ca-3220ea7a1575	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x78768b86977280c9e2c69d1823c6a47f70f528e1784d24196c2956dde64a073b6a1711962d2a6acb0f91a5722a0265d6e5d49cb59fe5758c11d881cba680cd9445aee7f1	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
0e697fa1-e801-42d5-b600-989287608c7d	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xa829b74492c8c2f6c6ffc5dd947529ee7066c6e19e5cd6f6e76bb78b04eeaec3afacd2a3fe083c6f4cd95b16d085b26f436b21ef947f6b497a03af3570a7660a1c4f6e8c	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
4e5c8324-d4ce-4057-af2e-9328bde78305	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x5edebfc07f5fd680434b4213d328a73e4107f822229a87bae7457a3e6304489a8bccf4ef19dbb72eebb72b3f32601a208a80e23c7d5f8ec45a49a36c7dc40b966ac09d6b	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
b1181e4e-a9ac-477f-9bba-9fe51a318421	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xa8c450ceddd7025720e486e0a084502aa9250eebfeea0e90f9adc706156ad1e5e10161ed91e93fe012f4f358c4f91a3a7d736825fd2eda1aa25e3fe3bf910f34a666f945	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
3ceb7040-4245-4dec-a50f-495618f01ffc	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xacfdda1a1bcacbb2a90d16c1a8f72423bd590931f46fe8d7ed8e90ee759771a6c44e96004977802d9baa1518872e3caea7a93ddaf2fd05a40aba3044058bece05c220a0b	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
df537943-7f7c-471c-bb13-9644274db767	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xfd5456ea5323e4b638b5752109a67d01d9897e14bea15c123d13ad9e07b30625a957ff82ca3e6d851f4abdfbd048ff5aed85a3f564c333d20c675436c54bb717715fb3ae	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
4d214f46-a29b-4ffa-b609-e2de518205e0	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xd7952f8ad061f2837b073b5064d131a81f3984d45eab78f7bcc5eef9f1fce9d1c767a2fe7ba3ae88f55a91972d8d63a44ff6c796ecc5f7655e614ca8d7bd49f14691f18b	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
03e7c089-6e4e-492e-8106-95480ae474f5	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x35559a493684b49142799dcffb33fc5044a4757ecaef19bbbd3620019ede962516281c49717e20f6c96104aeabcf6890ca22124b9669044e839a1117408f86d32266641c	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
bec0fb13-6768-4ec1-a87c-d8e86e6c0811	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x059429f158594aff09cc792323a766916ef58951d19eba1a7a1fad3a3f32e4f22d6f1405431dd39adde4ec3390814b06164544b549758115db8bdae1d4cec24e7b1354da	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
8e5f9eab-7156-4b67-a444-09bd8fd8d845	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x9a29b53c334661e1f919f1c91262b8c601e27a436d7e6c601ffddb882a93d3652c7da8cab07b43feefba7d6ae4d3dca5092a0d963fb81bf4c7d22ad16d4b33ef56585538	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
a064367b-c8bb-4358-ae35-2bd8141f2eee	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x57979510b051eae0289674b340bc4786f3f8e5407c3d93d27b8910bd88f390f47c6e90e1326af4e16174e558553c1dd86b641caae149112a0f1dd0054fd348986c2e6944	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
4ad4ef33-6087-46ac-9ea1-a1adc1d9e744	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x0aecc7fd10e9acf67daad8523c0f17189ed924f9b1066efae1913d51271a66a8cae630682fb3ef475f43f4447236a684757a57162f97d1a700ead130ca37b8d5c12cd0c7	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
ec979557-dd17-4030-b0b3-074bfcf50e17	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xee79e77307356c356860653c0129d4f9817256f8c6564f1397fa112770aaa9fbab494bf31d35cbf6b7ff8160ce03004f964de4179123688f6104fc2c5c06794eef05a087	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
dab6d039-3580-4ebb-b69f-59602af76f1b	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x936a25c52dd03bb6e7b0c96625deaebf0e841ecc068bdffcee93e9fb8d84637c526556db8b1b96a379de7a1f12ae7e2019ad3cf58a7c18ef1238b9765a8c9b26f91ffae2	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
99590d89-a0e1-4d7d-a303-0773cbf3d985	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x858f12be14f00723275d59829dc949ba3315c9f5a38e6685cc0b1cc9d9dd93eac3f1b83849cd7090cc691c65fed544afd6a60eb1b0308258b3b706107381dece2e19fe44	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
1751fa9f-cf17-4805-b328-d38cc1d6e51f	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x5bcdf73b803d4d5cad2b6c4a3a00aefec9a92c217c232a31cfe3b7ab608dc2bfe0b59c5ef46eb0ecbc90ee00fc2f492e6eb40d2a1881187c4436dbe34b67aace76c2deb0	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
4e4a57b8-d32b-4209-942f-a221a78c28fe	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x73f1821ead39e91209acdd28c22504564541bbc0dfee8cfddb7dacdc3b296e0a360669f5a49c9669ba90d5bf7a344fc15c62793542f579896be71257b7b1245143bf577d	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
3e65e480-5174-46e5-9a9f-6e22a21462ab	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x7c4656d62a54791e9b7bbb725cdca6a370cbce94835cce3ee5ebb1826eb442810f59d447e390dbbce15afeea2ab3b31ec09ba835bbae1766279431b290fb8a03976ae6f8	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
7a324431-f8f2-4860-95e5-4666c78b065c	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x45f46c7dad82c2425644ff212437882c315de6c3c8391cd0db216ee46443d7390f6b7a6a4005a1bd43e20f10d4e485f56d6476161742ddeff2257d9a428a663413038370	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
72c3afbf-72ee-4f3d-a193-660d6fa696ee	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x4cf1c0d430c3503e85e8c079013341506045cddc6a7820f529ff0b820bcf6948df105f2ba7ae0fb5da9afdb14867ffdea827e54ff1e3422e4d1ce5b1b1407e7b858bbd70	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
8bd26de1-ca8d-420c-8296-63577412ef26	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xb9b84839729471512286be494768f6fc6e11375bce56aa9d1aaf87b5b95f407f44e319527379087a2f0d56af804fa2bb8e72968ba441c9d8b2701acdad210ace2447257d	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
3353d995-5b4f-4644-b853-d8a80d9de862	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x4aa17dbb856b1df3698d6000cbfd561a1b65e28de4b6d8873ce65ec512a0a7083e71a2a846bb6cccd583afc5960e349c2257c546d4d9d4c9279e885a1339360b3c8dcce7	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
a106e5f2-7adb-4a57-bb03-291966a36717	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x65794b4e46782060baa9707bb38fc41cebef45f8a3827fae64cc92e99c8237e8678e52832136ba064e81257c756119e9019b042bf6879e4bbe934842c5094b1e5f65f578	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
c9c3da90-dd45-4e80-88e5-ab71d02cbf84	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xa3acf3a3bafe150b4510bf02be7faf26f7d8dad3b3fa49718793402fef652dc3c29c5d3390e748ed155c0dfe250a4742216b839dba4737faf09c117b8e66a00693e255fb	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
32918bf8-a676-4e4a-85f3-47fd38242fe9	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x301e5aa68d2e7f3bd1b8cadefacb2e88c61af0a0792293e7857124f59c5a03591f7f50110612c3c638f58d8088e3e0182c1d00b6b09869c107ed4bdd48486f8dc8e6b59c	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
47dfe8d2-f423-4ee7-9f46-8bed675129b6	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x08004e1ce0a858967c20e01c1e16523cf4ff2217dd4f20d2d4c858c1ba1b905b311d2d38c91fa41ff784639cea9fa4e9922a832e9fbb8d1fccf5b0f442f8a0807a4f2339	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
6d360704-cb54-4f66-9e02-7aa5e6497cbd	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x6b0b3f75e4ac557732568c0c3bf0537defb84d73a79113925f3f1d5c8ac11679f4add77e6b7ed179fc7c878589b54c6d7f0102d31fa4870d27c68c8e64f64cfd0b1d9c44	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
22723a9c-7014-4b3b-894f-3eb9926ba8e0	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x55524f7ab0f1342f22c29b3a4dd84850f85d37f3d67205a873286f318ddbed358c0cd9a6454b95ac5b9e04916a5e533ddaadbf7c77c2c8c6a860e66a028d814802091c87	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
1e8af1d4-1d96-4d36-a320-515ca5e8a81d	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xd6a04448b20f784a2ffb887d979ace97531a5e1ad62b14479dcc0a114ec9146c8b66f64eeac26668019bc6fae96b679e1b120f0a50af545c3a0da7125c16843c6ad05266	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
32cdd321-6a2d-4853-9e14-7160e89adabe	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x7dfe627abeba79daa5275b549dfe3d83ad4af2c297f0e7463362c7892ae15a58922ac8c52381c8540e0f9d6dbe302c817b0326fc95c7a10f8856557ac21898021082b845	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
7aed5558-5236-415f-bca5-f3d64b5f1aa3	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xaf920e679afad69ee8171f78bfe87f62a8ea567825d0951c5ea9c0ba2a239cc8ccc4efceee3870edb7b1e0d82e3e555b1c7cb743a40a66d5f988bd4c8214f277a82e2856	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
1385f094-aca5-4ecc-90a9-fb912d9179fc	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x60e65dc939c1e50bb511787f049eba7d2c34a0ad5d6c6365ecab8c055373a64ad882343ca67a10dfdfee32263981a3d0773472fad3ad77bba8f1afc8b6cf60e64e297b99	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
de6d7d68-4cb9-4dcf-b310-ff9fc61ace3c	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\xf143294df88537772d3553a6aee27904d7c6aa2ddf7f3ea81c2b7ecfc44167df91ec66f6376747b830333721fbcfbebbd1662a8ef94784176aebece2cff9fa0118ad97b6	AVAILABLE	\N	\N	\N	2026-06-22 05:41:34.18
45cac83d-a70e-49d4-a034-a7e53b42c57d	9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	\\x7d7e2addfe476dac4400248ebd08ee3382b7f7584d49b1e317f1f622571f44d8ebb05741ab1e20c19ce4a716c7c49f783b31b35473ae99d52b32dc101d5fccee586e2d60	SOLD	e580851a-de0a-48bc-b0a0-922784cbbd2c	30950969-a4d0-4ace-83c6-8f2acf321cb6	2026-06-22 05:50:47.146	2026-06-22 05:41:34.18
35536d2d-04b5-4ad0-98d9-89b891a2b9d2	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x3ed32230850f3504dcc2b14a5a11c858e60f01e0f4298e087a0423180e73f63764b40787d739b0e1f2139b915dbfbd9987220e169e89c107b3cb7184555e000a6f301c19	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
20452161-1699-4655-a27c-7e3a9b3f9f99	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xc1e8ed6274fc31b8e2bb81b37572f05d4d03042d7fffcfd4e7c2553c8d256a7a3ed2ee6c029e26a447396dfbedb6c3edead2abf12acb205a975d7c63e8bb41df4204d575	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
6975f81e-a925-4d62-ab02-bc4518ff7261	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x829c9a0733efda41ff04eed2f79e30de154577b1fb6ead33d7fade8fb8b7ad558ba3f98193ee7c74272872ddf53b6a9241f5e4e18d7d9ec81b9bf9cd49b5eeca3be4c545	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
da9f65a8-264b-4dac-8b60-276efed9a1a5	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xf8cd08a4d8e9648d3f95eed422ca58de64df0dc1be29db5be509311afded1bf7637d3de36982a3580fad24dc68d80255d86f27b2a1d39a2fc6bdc4dd7b2b34a6d01386bb	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
e14541ac-4e98-4240-a87c-3128aee27d95	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x0419a059e67ff37953ec2d222f2d291a33a0391813f34ecf24d184400561671e931e6ffc7d3b2058dd69a98752cf2fdc3729bd4889b958493be6ea2c1082db1849d23bd6	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
a0f68c6f-050c-4def-a0f6-1c6445f3b12f	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xf1064edf9ff09106389f241501acb74b25db9d1eca281e24439e6c27c1c2110d9bedd92c55d2e2c4e0f89244581e60823cdb680f49cc6afecd186e63d43292979f8f51e4	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
8f34123e-64c7-4f05-ae44-9aada806de2a	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x1755012874aeae40d681f5ef2a324a5fade117d79841100ed64e54558c1167cc5ddf7518efb4f3289e798712e93bd1027e41a8b59b077fdd72947afa477dee4525a845ed	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
c04f3517-6b25-4086-b84d-41d5b5a39247	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x124eb1ab23adbad644736e42cdd97852fc7c3612528283b990f93cc7c10aa9bcfd2e554ad748376d9468efbcc06a00f698d21f74ed1bbd3ae207acef76862feee0522cc1	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
51174dd0-e44d-49cb-bef0-4ca7d7995748	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x99338202d6eda26fa9e3b96a7f3647e06a8aaa6c51b1753199a8ea89bb493dae79b96fd48bb1dcb2fa8503db68d0dfea71783c001eb061379ad2cdd6c8499a51ddc9e298	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
1108aba8-b7fc-497e-a9d3-7713839895cf	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x92ea6c6f2358eaaf637007564691c70d66dfd00d2786a64f82d680473010b836c3443dbc5932b4b654db65ecef37c48075577288afdf172a4f912d47e4f61dbb3de6c9b2	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
64423f8d-2074-4a93-aa07-43c25998777c	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x71c7ff91d26f020d936dcd286664aaeb517e5dd545915eba070f6666977dadb7d3ffa6ea86f1aed97b9d70c26ea754f4f9b7f83d751dcbc606624e682a049a3db6786027	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
e6fa0739-84d6-4b5f-b07b-80034bf58607	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x21c7e4da0daaa28009bbec050d293b61c1e7a2a56329ed458766062182a5c555e7bb14bee7aa940ad3a216bff6f6ba68f1e5b0eca9ef9f5516132f8ab117de0d69e39606	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
8d527651-874b-49ac-ac3a-62120cac846f	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x260fdcb6d7fa3d1c19da4ae5aeed925d5a5f7230523f99d0c3a73dec06cb3212fa8f2ac7e96f5dbd97184d060fc0824f3e44588b03458c5dbe125d134d309ed70e6fcaa6	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
8b559b1a-1d08-4dbe-b32d-3c2b29a1e1c4	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x764801e95ad5a44c8aa194dcd7781c905b5e99192ba292ee16ac1678f40192e5df9ee5e104d531fb3f2cb7bcd22f6e4f3123ebaa5e1af46adf66ab30d3710099fc2206f2	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
4db97ed5-852f-4367-8959-d0bb1515d7ca	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x63c980eda4e438e6d180e6d2767e155b149c06179fabc67b1b91f26ee54062a2eed60602ab93730a82ccd9ab9a0eebfab030e26798782798531be932585d62d176f50703	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
66a0ee33-6b0e-4a9b-aac3-52cfc23c7896	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xf241c00557a242324fb2fe3e16fce01d8a80ca0eb563bcaf29775c71a3f1524f42a9285d1528790d88502954fb330f6957345cfe0523a88249958a252d7fafb88b9f4cd2	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
d5af6bfd-792f-4151-b90e-c4afb826a9ab	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x4fa861872ab241001c81659bb819d068888441407d01e44d0c8ab78b5a6bf2413d8f182d967fb05ac32bce853097376625808be177323201dd2fb2e9d553ce18d638abc6	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
1af9862a-1c0a-4b87-ba8c-9b552b57b8c5	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x5199e5dafc1497a3f15b85354cf08925d374a92645f04d49ce1fa6a8d4487f25428fc9f869a6c8c93c9eec2c6956b7163930b3c13e6d2212a53706debe52937b0c49c14a	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
c71b8896-57dc-459f-a354-c3e2ed41b1de	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xcb003e10c32831b330ae343502cd2fe266844f4c9126341eb5385b15da5db764afaea71af5075177beab1fdd63173e03d283a4ea3882d816ae08a3900ff408ab47cf39b4	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
d11e76fd-460a-40de-b7a2-23fbcf3e6001	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xb72e377eedc01b984b930ec5409c5f3d00919591dcd48963cf5eb8623cd08fe32f7b5ac40f516b3571097a805b00e9ec1706ed621a0555306a35eb368aa0c79c90b24738	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
0f9240c2-dc69-4767-bae1-1d76212f7654	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x274be9a2ec34d7364b232e87a37dcd63e9618a52afbe0a2e34f485993108232c7cb7609a898ce11448c50feb49b89e97af3d36d1d0689c9108333302d8b0615cc89c19bc	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
9d4e6c24-d9c3-45a3-99d4-a59d08563503	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x8bee54f1cee03bb98273f7fe9fa006257f53a87cb6e0d43c96c66e50ddfdcf8d5f1c72c463bea108a360ff0e0b627c773fe01f6fe320c1a82681a37ba2b051081b3ebf92	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
494fff5a-c1f1-416c-87de-5f8bc26e6b1c	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x6f558236a7da7417699d65b7e1bd5d62a01d90ecddc66c60b64686cd1ef6071b17eaaede20be15408aab622244bc1c558365eabed1e132d77e78a41f69312e63b63dd7d3	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
3d3a237f-f8a2-4ec4-8e26-fa95aaa6ef66	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xa56cf9e35bcd8a507d4b5c5f8452d30801e965880edc7a4ccece5ae78097754683be9b965e8cd4a4c60b87694a20d09ef69a46e98a87f96c71335212b577198c30b9d68a	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
489f31f6-5aef-4941-9fd4-46545f57d5e2	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xaf809fbb3172039022e3ab6147a75df8f14a152bd473f2230ccd19ea6cda11d066b4e68d4340421b7cda2b0dde04f15c1b0c1ebb6451e6a44c5d0820fbf344d4ba95e4b9	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
19677978-097e-4ab5-9013-1295ee47a48d	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x8adcb4d81b43e744cedefe333151fe796e9e3540194fc8c2681c02ac874c527ccc6c74bd69201d693fa975a66c190e477daf0ce5f34fab404a108c71985b99e31ee79efe	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
b017ab5d-7153-4987-9516-ab93034eb8ab	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x24fd48952eb9f7b786fea294808019122a099619f6656755bde35b5524a545d226cde8f979706337c72cf42da30f6a9baf8ffba35507583699f6090087dc025e74932909	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
59811bd9-6313-45f8-b12c-a14620273743	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x39b82805ab7653c0c443cd33d669a7845b7b64d04d6bf357543396ae126ee9281ee85121b1412f65f016a1659fe24c3cfbd29df683ee15baf099600248c65fea238054ce	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
3989de42-b5f8-4552-b0dc-c6f6cf0879b8	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x107dda9cb645924ac6ceed5ca0dfe9c3a28045981a8872b12bba0ed47837324e82dcfef090ed7d8cd699033a3c6ad901e0b2b7b9055539570896cab8c29c5af7140167df	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
8b2ae71d-c27c-4d43-91ae-fc87560415fe	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xdfb6d768ca073a9c2ff671d01c95a7dab4a8049463bf324557e0e903860047a348d6b562b5d4000ab7df982213eb6ae86e983e860059be08958b5b226e585e72cf146889	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
e7b936b9-70a1-4dd8-9c3c-80cb9af5aa50	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xdb18b4f8b36fbfa334ac3e07c4a0a6c3d6c781ce011df9ba4fdc490bde97f30ec07d854850a8287d424e536a6a1a88addc76cb01683c632cfce3c71dc624770f2078c494	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
925d29c8-e887-4e36-8ebc-9fdcd64fcea7	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x73b328c472c4d26f99284994b62928a96590a3a0fec83e5d4cfec49b700b3462dbd672b594f1ed7a23c1b67da3c5b94ef937863b884729c5be4952d20f91e804563b4b9a	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
49d8716f-a6f8-47ed-99a4-e3d9fb6737d2	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x54d16fc44c50a839c1d080d6fdd64ff88d878ed4bd387934b187d5e50f746d7d44d12ffdb1b1d33a0ec592f97a1af4a82938dbb5d8cb46bdc0551a67bf45077dbafe2ac1	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
da909d7c-6aa9-482d-8963-347f9d24b44a	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xfac1686404433822c401fbca7f6d28ce13e6eb1d9cb6a0533547bf4ddd26ecda8ce6efd81d27d7804a9c3b46fec327086a07e9db27560756d72967bf63ec91339fdabe73	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
6a4e150f-ce9d-457d-b88d-ecdd39e08bdf	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x11ac19e8a8fafd4770d4e81180c46a3232c514c621b032264e08af74e177f48a9fe31a87e19513fbfef0fe84dcb2a78d20ab74b11c8a8c7225339e293f99d8669e4cf382	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
5b2dcf4f-de89-4e41-8e44-27446c06ab67	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x4097c3dcab0bc2b23d93a4be42463234b0664c858fd575cbdc9257f0e8104a0f354ba2f964ae25c1b5c6e260b9983fa6cfb7a5bb084d0e7d279c2b0413ac40463e26277a	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
e03b8f0f-1935-4cdb-874a-65d7b78a3a5f	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x4429a96dc8caca8518bea2680a8abe4dcb7c98f8f466e97c4dbd06c68e9b768df099979733017129ea89800661acfdc00eb3262ce5712eebeb9afe7bdc3b5531617b51d8	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
fa79eb8a-78bf-4d2c-8436-41ae47eee683	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x640d7447c6e5d9e89a8939436525d2b693ea9ba22edcd0e1705d7e239ba6b4ea0f6f654be2cd37534571a56cc437619d5ed66c7114d81e2f2a26d952be1c09c119a959a2	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
e0f31639-0254-4fd6-95b4-3d20afd2dcf8	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xeb90e59cfb3dc8ffe4d2922236c63a8691a0e08a16d15007265e374780d858447243fa4ab57eefba94860cb62d52153a7fe4fb06873e9114fe8d5f9c133cd0f7b467e1a5	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
bcfe4102-aed7-4ca3-a951-c2f2276b5c09	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x2acde086d25f474b33894f82adb1b041cba76adc141277c79c513a61890c03253b0f762e86f48a70361fbeb7aee7727b258e2b86831a516de87beb8c7fc1acdfcab5c83c	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
3ed60a91-c2dd-4611-b84f-593b7c5dd67c	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xf7c3840c9ffe507cd3f829d8d54f6dd3028f1338553334ee253026a835e9a15cf6265851c9a4c6b0b1ff3d2a817355e5f24079b69c6b8fe09746ac2380d7c5e8b7d0c3a4	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
df654d44-6bc9-47ee-a3b6-f576c250aee9	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x9117a1d1e4da6bd6a0d860530c2587c87a1fbdcb0bcbd6331b963dd51135bbdb27b43f49059b50eacbcd820054f4d6821c5dd6a005a257493543a9e76b034580e07d4a8c	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
3d3dba3f-02e9-4a84-86ac-89363654414f	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xfe0d856d75f3bfb3fae2078dd366996ada7e5589bdd62b166db9ac62d6bd5ed2f112ce47ac5fe50209f23e95a6818ef2cf02465ba555515bdb0761de6277d61419fac414	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
df5bb5dc-09f4-4120-8306-d438d686a49e	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xdce299b4bad3b2d0ed69515fa9a10ae1d928540f0a5b9e33821df5316dd814bf957b23336046c638c9bc5be9266761725f33e8de6780f4b0f30665c6464e7c30d5c5c6f2	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
e9ac2757-0ce2-4d7c-a515-afbcc331409a	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x77ed3f63e0092b6a9da52448db1b5264262ada07479d3097a1153656ec8c6450a14e3421f3bd85ca8bc2df889caa283f4062626e69af6ede0ec75441ea8753db949f3be3	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
09b1e830-e509-48d2-aa62-7346d53ca6b7	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xa0b73c692a0580c84a85051d242726ed65a5fd0409119c173f464cf31d5e5d2c83a809f35328b8cbf973f7de8d86757a8060f4fcd0d05338f5145dee3031f0643891e774	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
a527dee3-86f5-4c18-8e61-d4b61f3e218a	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x3185f28183bbe32899f7e1be713f9ce0781e1e4c3808bea489f52cbb4d3a35e369a7db375ce228c61b25225959df3b49899feeb1c3dd92007b649e5d3f85c10988a79b06	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
a4f7b1e9-0730-4eb8-b1a0-b4bc817bd45f	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xa48201f41387fc296fd02827479910f38d11ce3f989ea3beeaf38303342fba44ab13a4d35fc288614161b4efba8a0dd8552542995df7274712499aff285dae857ef8eba6	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
0dc2a9b3-ea8a-4655-9c2a-a8a81dbc476d	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x0f4e00785a827cbebbcd009a2e9c1ab30fa042872ca6057892cfd2a6f2458d8ec04f077f74a33503a71001d617a558a46d25d0a0e572ffd9e92fdb176779bb54c8bb479a	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
a626d99b-0fe0-419b-a8b4-39f8a35089dd	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xb51f9d1e2bf8d7a73adf2a08902eb0a6ceee3b8a3a0c5c27defff19471435cfb34aefcf9a4e2c38c51b47941612f49c67b1e28a58ec228becccf6fdf3d628f8ac27fb5c9	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
6e2b4bf9-eedb-4593-9bff-4ed7099227b5	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x34b9985d7974102a5f24ed6f0024fc24538fa4820e443b76f2c944108d2d3511851d8f36f598f90609c0d65a4a49376de01bb0ea78922eae0a8faee4e777f772c728b010	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
18142669-693c-4c5f-aa87-7685167dcb83	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x13bff94b127169304a9c5556e2ea53ba7a7b50ada9fba46c81b68b38e7b3350441af89965f7d55bade50dab2e1546a74233bb3b72fe121afb806c0fc212b3606ce5705ea	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
97f434d9-a13e-45ae-a8a7-0c18bbff419a	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x984f1cb2bff90b2d6b036fa1d8dae4abd2b7c130dd866122f399356d18c0cb33401513ff7fbc3035e650f59a26f83c8ffcd752717cd9146468da28f238ce8a622913f91c	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
012f4485-5e59-48b6-922d-9af00e83099d	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x61b7a1715ff26e66919db9c7efeb67a6a3154acfad788c532d9ac1526d98e5cecdecaaaa5d19b2a7e414fe9d58e5c03cb88fe8190b1e39af86c2d0b6a17ae079c251cce4	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
1341fcd9-d34b-4a23-8bf8-e7075d157f21	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xd303643ddfbf406c470f76d51299d322fab2de34afeb6a126534bb9eb4cbcaaa3cf847d962c6c084a4aad08678c8b3c4f29281b4b4b64e310dee3eb228b84df4d80975e7	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
68c0cde0-2a4e-4ff3-a9a8-823a339b5592	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xdae89e7bdb102ee78cd355682e4e6b6af4ac469148332c646a1aef6446e66ac168b852c5e8acfbf1f1628efd50ba60515917442456e50afa6d9d3c62b555ac0a2a43e54e	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
a421a1ba-1bc8-4a68-a7a0-9700b043f0d4	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xd6a85d29e965ce5895536617f986198789ded4690407be9f529d7aca9239dff4b5c9f0c9f252632ff5651e862d41cdb3553300d1bfda6064f9e7f154789bec2feb37809b	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
db675586-1e78-40d7-abfc-6eb1630fdce0	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xdfd9c0fd38cdcb3ee47613b604c9b1f8e3cf298ab1cf34b8aaeb02a44f30c011048a3c7a83f9e1da7c9a111ea64c091b01dcf583a5b089f11786176354459f8d5a73f98a	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
a466de84-5b03-46be-86a4-8feb150dda3f	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xb4042bb887703073d5973a1e3d51a1e68de2ab1392f634b98cb2b9078974f83a2ffc1a3af3351b9f0ea2ba3b803b27226747b43f2613a6f8fe162db400b44dc74b9b2b7e	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
20acc615-7019-4ef3-9710-99cbd7706d34	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xf1fae0e8534d9ded811d52f8c64e5ae0a052be75d5f268242379051899501766976aa5f04fc88262571a512dfdf02d05b5ce0c96f38cbe7e4fbf81a815d00f414bef2732	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
2073c7b7-2a76-43f5-8e68-10f6ae3d7ef5	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xb5e8f70660d8d44cccf6bd53eeeda6460ee105438e4c201323841d6d30975e4115efaa32bb9d4cd94edfb791719785ac68088a8f48c5ee35f164951796e581ec44f58a41	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
11fd2404-f2c8-4aec-aae0-e56b2759bd52	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xc9c2f8292041585cd1efcfbc7de749793223491b8d2a9bd8d339fbd15d9926779e3adc6d14d25c4014feadea7ac75dd56234810bc5978c3ca401d96aeb50076419006207	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
fdf91966-2aab-431c-bb4b-4dd5b6acb6e0	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x95465aeae113ecaa90136dbb2757c61770cec9c8a71ddcb7ad19d94d740ff5f44087eda33eaf0d96bea532867ecc6ecf849c2d21656179a94ed8b3767be9c0bfd34e2e47	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
6ced3737-2204-496b-b016-a747a77eecfc	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xe96c535ad24a42e2ad164c64b4ca53c0a1cc886c52a99c3a86ca620b0e89fd195616c5fccbbf100a3c84584662ad699eff2a951fde1cb2b6c3f716aa68124f3d9564b37f	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
8ea93fe6-6e2a-487e-9f93-ba92c87b8b8a	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x7e90d64145dccd10f412170a6474ea0f927b8cde8bcb4c0b5dfcd2587f6a118bc9a54cc3013b897da530392995ba35cf84f2bd0ce89cf3f8e32e1bfb4d91bfbfb3951b31	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
0e2eaf72-0898-45ff-b2bd-6428e510a146	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x376e670deb23bb83d0e9da925707019001e4a1b7bff6dc75be6e18bda51ff2c566d849c5c476ce68b0660d725909bf11e1ec269c43709a97b6bc8fa20740244672824f6b	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
49bb8136-2eda-4af2-b048-5a4016357a98	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xc8f750f84cd3732a19faf73eec1541895af7876198d068cd47b89a71abd7b0dab04095a694d7024673bdd63351340fb573d551065c3da665f76b0c48e50915287bc9e91c	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
0168be47-a784-4599-912d-b1da16f843eb	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xd5fb2f807a9b527f5445e8ccfb5456ed5d46dd09a9d6ec08dfe6cd2b60ae4cccc0530b392f13cf37942d281b609e8e575a1ab4eb8ee7464ae2ce6eab8086b1418501613e	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
8c4a4dec-9151-4e0a-9669-5d3c5f7062dd	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x86991c272cd1b780a8df8121283dd296d3ea7956b828365e7afd3198c03c8e4fc026825d09026760f0c80e7ae3302be60179155793ff0fa0697bf289c5a6448615c6a31c	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
6be661bc-66a1-4431-a10b-0f450e0b242d	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xa7e7746a091a513d54895973fad665dd1e1747ac19ea3d61940b1fc9cdd2b6b9582459d5e8ccb889ab5a8a0795c4894fdec8d8e188c2200537e394ad2375d3a67ab36dbd	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
fbf3737b-517e-4020-a706-8af8ad9bdff1	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xd83a5eaba2d7cabfc9d39d78ebb937a8a7e90e1b37206e197189986dbd527378cbab177a868e96d80256fd8cbf99151a740f89fb28031de485e41daaef4bc03dd522883c	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
ef99616d-09f0-4443-9ba2-113952a01c81	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x14cb87ea51b12168dfc982b9d4d96b57c19a6c38f50786339dce5f1ef70c03e9b390ad0e9d5512b964b20b02569b75fdc1c965b45c52fd5443e7856a924f2f2e38b855bc	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
0e5c20b0-b08d-4b03-ba3b-82e0cfab4ca8	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x93d26bc769b770c65af27aac32fc1416573976818c2e5622c807bbc9c32f68f5ee3669583e9fa75c6d84a1fbfea9159f1ed5d86d177c160bcc4ea0fcaf766fa00ed3f64c	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
27b18900-ac57-46a5-953e-2bfaca47dd19	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x79bbdb566de16323a92c5e9703e33522ae2cb16a25c4f9b6b54a7f4d0b5fa6b7e1ce6f0c3519ee84254874e45f929ac1f1daaeb81fb1fbccbd4ba00057a687319bc9b3b3	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
4feff4eb-af65-4efb-a21f-ecd251967c5b	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xb1a29f46fc3823c8fabf003481a15979eff900ced0010fc1dbe8eddc54578f0fc396551f0bdfbbb0cd9c6b76122174b1b42d63fea12ffd2de654ee96b1faa158af5d3832	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
c092170d-ef10-428a-9a70-1a6a52db1d2e	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x4007b0293627c2a4c275327910e3822cfd1af7121c5674485eb7fb438c169dcb1e8497359e296ede42b3c5bd3f5e03acf7080345873c43ab1a12dba3b9266e91ef2a9deb	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
70dcdb2d-36c5-435a-9069-64508e29a191	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x42be51097c77a900494b87d75dad18342707c639339084ed8b270165f148ff8779a4daf2b82dd871cf2cce5de0dec0a0cc99293b1c096413d3d25d357f4ecefa9b05751a	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
3aac5e28-3ce7-4e04-8456-b3ff1af295c4	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xff9f3f9faffe88df5e81a39c8bfde66304450d24972292e8ab6ba7273f90cc094499a6278f2cb8cc158a2d558dd655ecee2469881dd42b6544e6fbdafcbdabb935d9b7b9	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
62ff1008-acfe-421f-83be-69ad9413a3a4	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\x42de748515025ecb989225b422b2ec19f8f40cb88244e54a2daf86f370727d56d73d72faa0b1fbd869566e0431d01ea808765f8e7eafd4c11300be2e7ea77b14fe6acb17	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
a5420a17-3d98-4811-ae1e-e921c9f790aa	afe3f4e2-87e3-43c3-a851-3d7590e74231	\\xeea6031db8389c255647b5ae5943bcf1de22f8ab423470efa558fefc8eaa888aa0f65644bf61249c48f5638515c9950ecbe3bf986a5184f2662a6346a8356a2a96ab3b24	AVAILABLE	\N	\N	\N	2026-06-22 07:22:39.16
ab23200a-7d64-4730-9a5a-c6a8a50bc30d	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x265d572290fc5474f80fb3667e3368f439016473edae9f875610340d558a70bf3f45d53708cafdaffb1b6aeb8079218cb4332a9e8626b3762c817dc311429e1b0037e349	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
8517abf2-0eb8-4a03-b1be-12f545d3078a	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x77187f0a2f84c08e386cb663261767686f94a1c47b4ac44c1008a92e5a069826250f20ec1be947cb5b740de8ad159f43a5ec69c74ee861472c49ed62d32fd988f93b44da	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
89b4e49a-2d15-49df-a79e-0edcc3679806	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x3b56a598b7c332422eeeccf58eba7ae086d91551520a3fa9ecc65c09b9a57e4494fa664b470e4fb981b10726cfa1aa17b022c72cf67447bcb9cf394d78283d9e4ce6b6c7	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
4bc3e142-4f4e-43b4-979c-928134979ffe	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x6a2d0dfecf9c5a5d5671f32b99eda7ddd7ce9dfda9110842ce55fbf9f9f000cee81bbaf40c252d8254d0ac3b9d7a8195b0bec763bd51607ba61277cf5421c1e242e841b6	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
aca1c7ef-5b32-4040-bd54-b445d69b0847	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xba608fe78ec49f18d263bdde7b297cfc2b9cab304c086d896332b4c5e6b704b473ae81d5ecbd35d3da6fab3e068472d44bf29693232314ffeace8fbd2d3d458205ae6808	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
8924aa12-5737-4a0e-855d-e053af55f7e4	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x3ba56e9b3586d3c1aed4bd93bf75fcccbcb47483f529a075bfccc3638523708efeb051e2ea2b4736d9892bfbd34ae16f81838741bda605da44e33624b5a7b2bbab76f773	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
644b7376-9627-4f52-aebf-e9da44646ad1	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xca93a89845a8e5aa471078d89c30a068df36b8b456f789d86c1a9e94d618e81e639af852c400e6624a4dbf9228dcacead8334c6e8b2b0570d70f338981ebd684adbc5763	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
1eacc246-ed36-425c-9028-46b1f61e8ec0	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x8e29941a1c304b554474ff53e26eda2a355a9b1f879e74430227af958dd636ef3b39a5343326a0dd45ca80daad2c35cc0f26ae8185561c91a595cf4a6e6a06c2f5a7f506	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
3088f842-e3c8-4700-ad7d-657735d99841	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x837e7261288676d163a67687a620055f46468c88e99a3c430805ac176cbd82f97d862f3a300ad60fbceffd6d2ea16517d39455b64606e5c42ac91ed9883771ff86380b57	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
1dd8a9a3-6902-4cbe-9d4e-b28f91eb184a	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x85e4fd5cf020c53265afde57e1c47e329cbedba717f55119c05c6c89fa0dae3630276b9213fcf58666a936a760fa363705fc8d3ac8f8c25dc38dacbb78b5bcd25a9d4669	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
0dbbbeb5-fff8-4c3e-8046-02a1d200ee19	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x986cb6f0bfc0003bff214b3fd331114c582d053a6a8052e1c7759df349632ac707df706b25ef6ad27f144b8f24f57c4e30d68bb8873f0be464febdc2754041e8933b131d	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
4cfaa818-0c68-49f4-91d7-b3de630e517c	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x253bcfc19e7f9f4f81bb88f9fd23cd31789db7e6c523328c059cbbbe5c32d17ebe7fbab7f947cba6e6c1e5e9359c27792242feededde792b29c831277efea4ce5963e486	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
231cd126-932f-426e-b973-8910b3e71326	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x48a2278902199d63d15694f60920ddf8cc39cf9304360b3fd9cb23bc31a4203207043d370eaadee27e0d57ca76f22b28922667f7957d695ba904d560b40e89125fb9725e	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
5b953b97-94fe-4b50-80d3-574ba9c4379e	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x9d2dd178b4e0f51f8bf7c0c0295a1fe113e3abd0e3a10b83cb989605fff24bf7af478021ce578152a2dbad581a68e60c1ed23fb1c107a8b1460f79878c364e354a3562b2	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
13ab293c-4bfb-4fa6-ae1f-3432706b148f	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x169ef5ff419f22443d9175410388393c8ac6f33b315aa46ca130ddd54b2b00557e508a77b3d9f6526eafdeb0833746d31e8e30fb86e7595a59024b4089ce34c90de6ba9f	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
e0270663-cb88-4404-b14d-994cccec4496	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xe09f9b1758b879baed62cd9cdfedb4c35deba46880e57cbca95ef2927eb5a339270ecc70b23d373eed1e34d7e751d9d64053798f59945e50f52a4d1077c0427c580199e9	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
23d21695-9956-41f4-9818-e1d82f37abc0	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xf5f3a76abfa67dbcafdff02782a5b5fa5ab16a32f69d405583e9153efa7ea14aed024a56c512514f151201cbd20e99af15edf05323314442178b93d98e39805be50a3ed7	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
7594aa07-1710-44e9-9e77-1e06bcd83547	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x5053075440ee524cb9837a9f5a9130ad5e64bd8ead8ad7e716dc6a690dcebe87c1251d9cc3acc3532d3d46cc83c02c1654539b353894b5927e6912a50e094f9c002e28ee	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
caa59ada-a5db-40d4-a4fa-2fe4e748c2aa	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x4b12b7831ba911a56a90bce142cb2e891d1eda95a5204a8889582208874cfea970c0cd1edc65082b0a0f722e2178e65f74cee1dab9d0a67582da3e5ae54a1b8d4decfbaf	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
9498b7d4-9c95-472e-ab6f-55b69fac1fa2	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x69392fe94810a57825bd83355a2dc43d0a157959e192d9a187c53431769003e9ec61f9dc05d67426f3104b504732185d61afb4be598a5e66d35dfa6fe482fed729fdf4e4	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
cef753bf-5c0c-4baf-bf65-65011bbe6582	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xe75c94cd527a3a0bb33ca1897ec3152d88636257628b01f4260e6986a2264699b278c79fbf04065769c4b1956cf58c4fefa6bfad18f66c4f0645b4ad79c8d35613ac4b16	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
6923a7af-1406-4659-a0ab-2cd9601ac0d5	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xdad3055c6482e5b3b4e8c936b9b01c93aa9e76f318689f348a1079b8eb207104b3897c0b0574edf8bd7b60f3bb3c09a4d1c4ef06b2e539d351b9c5a11bf0300af18ea2e2	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
2ec86715-a1d2-4808-af58-b2c868699ea4	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x81d09782448d2ac7c524aeb70a9b5e315f974d2d523bc1fb27bdf72c6205d38abdcc7f6c07ccafec3b8ab5d82439a60f68b79f0ecfeba3c675783fc4f223e917b96beddc	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
9199c404-311d-4b1c-bfd5-571725daf183	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xe4f7955f7a14e8d0e14a6f3ce5bdc97352b7d8af839c27cdde72d088d9dc174bfbc92ca3080d9f29357df89feef0199a4d6dac54062c73cb0b290bc0b4f935e133a83e87	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
c49079d3-1916-4014-931c-d0b599028224	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xeb9d5fd0dadc5ca47242c863198697173bb0878adcaa87acffb48aeaa4575c2da6bfb534b254da60fcdac299344c48dee7b7f382aaa4018b491256493152e2de4c367ca0	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
f6ece07d-0477-4d73-94cd-b3952af362b2	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xf9a5021f8a003e04736442837dc50400b74c9a50353484e9a178af14ee7c87aec42728c9a41a3284293618af31010a84679e14b953fda904c2934ed1ad5651cabb33baa8	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
5ed9d0b4-707a-4707-a6a3-21f40a537a26	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x438d7aaac76394abf21c47cce6b330085daf10299b5c4805792e780c704f1d7984cee150c479e443d7dc695ca4cf74954400966e0e923a0c9a9ee4236eec3833463253fe	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
1bde7761-c2d3-44b7-abca-00d57fa7f9f0	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xa1296d607530c9080a61e799916a65ba58a6579757540bdc593daadbcb4afea7a677b7d73c54079af91ab712a6be50922f8c46cdb9e9719d21399c316257f297ee143c83	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
c16282c6-7911-4583-b31a-ba01c821e79b	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xcf2783af8e98edd16d0aa2e44c82978c90fc6cb51bc91283f6dd4bb84cefe60924b1fb49833cce6e1f051a1e2ef06e328a20d77037bba159056e0cdeff28e2b873ca83b5	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
683fc3d8-3dc5-4170-933d-765669a661ee	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x7aad330357aec6f3ca9b7314ca7d41998f7c1000fe23b86faa40d49b9bdd76aec5e5838d2daa3806c5579d33f2accca5d2172ccc2dc77315c24198ba80ee24d0fe8611f4	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
951bec0b-747c-43ca-b3cb-bfaf6c4fb3f0	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x49a40442e0d416b327071652cc39ad57106a09a835082f37063b6f600cbf884f5c7fce4220faa033924319c541ae7737a0d9579630292a8303225db72f127b3118593e2d	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
b5ff1177-2583-49ce-a44c-720b8cdcc45e	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xa42041c0d96184c63f73ed0fb4d63ed419f8a9db8a73d4f432a19fbcf390e737607ad87ecd09cc6e540295011fca746a40ac49540d24ab40007819486b6419a521a92a38	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
8bd56757-93e1-4969-afc4-0ee2066527b1	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x2959077d7c387b19a8129033872c26fad1a25418301af9ee222d571901cb4486e50658f0fc89f07b62dc38a2df1171d1fd5742a6655529a46c7ea727b6850b0beeeb9039	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
808bd6e7-6fd2-49b7-a8c4-3d80ffd208a3	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xfa201451535933b69fd74d3799d5c22131a41332d50f8a1174bb6cc7a69fff168434c3f3de59ed5919fc46d756b229339c40c46f7eec427b89ff7560acabfd045e294dce	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
410c8cb3-c61a-4205-b1e9-2cc302aed198	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xfa583cb9e4177bec9c6874fe219fe9d03847c246ca5873664eff83ade9d080a0e0795a8b9745771f9833e8667f1ebaa7334e2a4c02c86d56bb2a5ffad9ddad3dc98c49ee	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
2e6f2593-d950-4007-9151-01a810a3c6e3	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xb659aa71526dc1a043b7c6f43e9a1e44e48772d46f98d518fe1af344207e04d50eebad5469e1f61d8f5e83a7b021a01ca31dadd7e86d38d77e12254ae86dcf8668d7098b	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
f8ff7059-d67b-4105-8d64-b67f9d57d834	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x136d52f582d4e4f04819e94d2f2639ab5878608f2c7824d0b5e12129bb407160eb961b5943778ad24950c16dac7d2d2504b61d38e1c9a58e3a0bb8f06236289002a2490b	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
836e6aa3-e041-4295-8ba5-3f62daf5011f	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xa44644e26f32476cd0e994fb13dadf20bc981c2ff95fcb8f0fe11c3c02949cf598c88505741f58c946b9ef19bc85b360c057cb8881eb2811858ad4b6fbcbd96485d13a9a	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
55a63440-0e77-40af-91e2-065b054ae2a2	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xbada71efd03b4f887a3e1db931c3e3da67664bccad28690398d9096ba2750b43d01f38c91579ac8ab32bd2e65d0067d7d026ce0af93a09cddfd6608c7431dc009cbe9369	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
3f91b327-05a3-47a5-840d-c25eae14b241	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xf2cf31d0f7c9b3bb078e189c9f0ed87cfc5ed7c34c048ccedbfc8c8d4d48e15232a3177bfcd84a0c1ccb8268547123b883e265d1e6e103bef81c629c908b388780e53257	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
3aa90442-028f-4a2a-9662-6698f2a75695	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xf9802f0298d2fbffe30435f750ff8cc392609477dfe743e135bc5b9ebe1a668ddae98bc321b00cf9989c02a0f37712fa4475d6af5394de1cac3188d0c96dfb79df638848	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
70a8cb1e-52f7-4cd2-a2e0-89732804106c	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x655362a660aad316ec54b91d2c37d0021b608aca8a17d1021633da274a406fa02ee3667165a61e5fd6147ab3f8f08cab407a5e8a2147e4337d8b6423d689536f12e20e0e	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
0605f40b-3f6d-4e94-b4c5-4d46b28deac7	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x8f945a4abcaf523eb625e7d45fab873ccb52b3b037e63e7dbd48de73d47142fe60655ccb983d795f0fa316967e8aaf791ec24f7d446d2a9213bc4241d439b98843ceb304	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
564ce685-0991-4df1-b79c-295688d17d7f	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xcf8ec5905e07360db778f5b250f14a3773da978455459864a6c7b7d21d5dbb8cd95eba3ac3f369823e3de9550968696376b1bcc749d75b0cd0bd4d742d2d5d63091da47e	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
95e05688-ee66-43e7-9528-1c2d7f9a31d6	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x4b069d6aceceac647a6a058d4987a8d43e0abaf47ea4c524f09c7b038ad91aeaf5d5dfa6d1d03e8fa6a041f0e3a25c173b79309d8dd3f60d687186475a0ff375d91cf710	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
d73e0c86-9421-43bc-ab28-9a8c58d1a423	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x1590c69441e1a7dd62895bbb5941255f126d1a5d02e073168671f5d027345e711a7536030ea010778763e88e23ff8b53d69dee64663d69b1490f2e0b5d812e4ff1d983c9	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
6aec729c-a709-4a39-b46f-c637f6b60f88	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xaad0cb2a0cbec300dd0e1cb5580c32ea743289c256ae44457cd194df3e4a38ef58a4d82f123959659b5a7781e3ee5a4a20535dc236755dd32c554d0d12d0c1c3205e7ceb	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
629eb846-92ff-4b42-b214-febe5a45b928	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xe4f2b5d0a18ff6d1c96208a98f7b184a41a3e257b3484f1be10c49bf98402c651315c48ac99dca842a71e7ab56b35e7a478b9ed4f1668597dd5ac4399fa169bc97cff43e	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
80041254-bca7-4387-95c5-0e78fca07f06	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x39fd103e513233ec8aac9e6b43b2035c0e431d7b06f3b47ac46537eee593190a021f71c89f62be82b453ff80e011550884ea95d1a5db9e20f8319e4bb06cee8c1f991650	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
a4def74b-39d1-4857-b6bd-fbd23daa5db3	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xc565e278ded2f9f01c04a5579d8126eaace1ad11623f64a7a2325e67ae8c0bfff9fde2f78b50fce244d121523ecaefafa708b3b133add66d8c816982fc48ffdb5af306e8	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
61e9231b-44aa-47f0-a5c3-0511cf7fd6fb	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xef2cdeb312c4db6dc4333a5482e7beedd4c6e715654847face10486da2c280590f951e5464ded4a65fec5e3e75a135a2518b7897c8b613f23168b342156b5661870a85c7	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
be75d10c-a67a-426f-af9d-9edf5dddca95	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x082ae9c9e86d4d266b0a40da56e7ba930b0b6d573b6de5ec6df540970b6fa21e6e46b28e96a0f5b83fc885b0d8ff0722985b6348707cd55629f131f73e4e3917a51c199e	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
86228b92-26d6-4258-a406-ceb120e8ae33	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x0967242599d1d006a0209c12aab8746b48383152d6bf514023eed001969db9974e17fc93f8151db49a9abbf6a9e6b7df17f1c837d727369006731b2695969f121a48786b	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
cf10e859-aca2-4080-93a3-b86458c2b30e	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xba6df83c4fea08a96b763f0a1faf14a00a777d3642a53e397643f4334a23c365f852ad5185a533678e1bf8d65a8f31193b2ec42d9554c7b37989b1d3e30bc162563aeda5	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
c87bd913-a9da-4555-8628-f7e83af7eb3d	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x323ca20e846507b2e79de8ff4409425410f85c0d5b6383801e53494430c0029461754d2f41530c8d6f5a0455fedab02b1408fd1dccbd273ddc63f28368e9398aebc4beac	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
1b8fe780-2288-48c9-a6bc-265768591cf9	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x9f6553d6be9485a7d1c1d84e7408b90382b6e24ae47c9ff0c5a56967655c8366068870175bab6086d4be5d44f9f7fece7d3194c4f905931099e78e8a7e83fbbac17e66fc	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
a668dc44-74c9-4b02-ae57-a1ff7e378a17	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x62b762a9f13ac1c0ed0e7fb196d15419795cd406ae175b91f9ac2b42385a9c973eb4c440ccf11bd1d1fc0b7cf2750dbf384c19411ae49785c0a357e357257b6adc532bf2	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
e8a2799b-94bb-4ff0-84cf-45834a0b9325	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x870b32e24f8ac9031c0d2b36d3df57d105629f657842289a642770f1368e472e97c971a38537d56a07f107942b7aec649c1d994ce7af80cce180a76f6f08c3f35e86f061	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
e638de99-8216-4f7c-b9c3-f8326ab923fd	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x138afc7984e47c7929dd926cc7e4099c5c8c6abe7fdda5488a36d94ad85c52ae21df7cf21bd9f17029eb002537a1a76f47b35348ce4df11d0907a00d77ae0e7a273c7336	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
2fc49827-8b50-4b23-9c7f-a80f54833321	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x455f0ce78434c148398a6c6c66a25505b78eb3065ec4b62ced930f1dfeb664650e02b20668187892b4c470c970d6037ae37c36611544ce1e2b3a58a81de6faa27f98da9e	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
5a0376ea-107b-4229-b3af-4c2bd0b01abc	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x7f9e30a3ba6274cd99f1a45c9302181dad004d3bd2d19342a01d785cbb209412fd72416fcfa503960bb9772fbf99a1a4832f0fcf3b91713de9b20ce246c0915454a1a7d0	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
93826b05-f9df-4b4b-a511-a4672a62725e	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x1d3e79bea5ce994f9fb256e01d07e239bbd2c364b0b6243df71a34c95ff1c3064087d9ac087ac23c72891786a985837928ab339187f60dc41839b12ea71f96f25ae09e31	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
93c76256-4f93-4e7d-83ea-c2b59b01ccf8	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x1fac1dcd16be2043b29bec82cfb11010a61b221845b5e9d9fcb29da036373c9f10ff50eb6f6701ffead4e83276f18abe70645989b279ae002cf58b7c0b3f131d5fefe3e3	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
a228689f-07bf-41b6-bcc3-a9a2484e63c3	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x44e2daedf71f84c23d0358049d69f71d9ecc52de055ed6e93bc9a56349f5de350dc1d00c2a4aa75514820e0a5efef7840478f7e77317d55cebcf138dbbb7643672f920e7	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
bbf9dde1-ceb6-4c59-a06c-734fcf70628e	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x7b7436daae58c0f13e707041b437e73e6f639ea9e2a96740368946ea7db3c682d07f8a363243831c03f5adaff7fbf764919d0f522a8f9ec4561ad3c3fc38559332ab7c5b	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
f358e234-9e4e-44e0-bc4a-1f6786096222	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x0c63b54590650602d7c1f88f315e7b3836bde81c603e07813ba228e424e61c08f1518aaf6f27f8561974fecdaa2eac9360c6fe84f3dfe8c000f57540f741863f516f05a7	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
38650422-3573-454f-bbdf-0af41ded3120	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x6026ec6ca6a1385b52029b063c6ae539a4dfe653d192f3ea6b0f3a9e477411638213fec773a28ae9d0977cbe5979a5162a034d373fc329a11a49993ee84575975754a278	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
350d1e2a-7233-4295-90ed-d1142c3da4e6	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xfd3d0bd2f0e58e9f19809b89755c768ab5fa455de600424fd1a34f9cf46dcf79aa10fb7f31d5cabe220cf8fe94738dac8dce9e4d3edb19902801126617d1ef00aa16c087	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
976b847c-c52d-4c90-9070-ac4e2abaee79	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x01755c8f5cfda00892fc3cf51dd80aae74431742acfa5454ead7359b1d3255ba15b5af4dd715228efd094a23ee6dd0963d3ad579eb2aff964abd78121d199208bf60e7ae	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
95481398-2826-4691-a989-b40d758f0755	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xa317a63c9d6b392662b2bc75009483961b951fe852a630638d64ca206b909d4b0a9a4364129184439dc04afe9793b0b07d6fbb4b274ba94cf7516fb2a49c9def0a52459d	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
eaabac02-06b9-47fb-b33e-ec0dfdedfd17	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x3db19330c3af3ea7c298ec9d2a96b383eb673d82d677b1a8f667e44771957b68800edc49bc62edac52257f556c86fb2de56bc77683e1ae47b18856948a95fafa851acc1a	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
30a95128-b5c9-438a-a5ad-3600dbf40b26	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xac4b082b18a88feabb8c268526a3895dcbec01ba2889a12b0e160f73e8b904cf576ddacf2a81cb77e9c97436724da92938454bf2ca99baae50d652a2061f21d02f348b7a	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
3e16a81d-81fe-47f8-b3d9-4f757c34fa6f	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x1da064cbf8f4c8285eb08ffe6bab41abfb703b54a7b584a5d4346429d605f84ce6098396dab299a09cedcbbaba78a92eb72541ddc6d294e2baa8c9e0ba9129bf55f50d33	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
d77cfad7-e03b-4a89-aaf5-547f9fe80c4e	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x08f9d8b5ecc406a24b79eeae6f8af8d36cc53b7d2d2f7977f2fea97fa6bd16d33296e341b69780a8c4aeb947728164955105f54c1934c98739227b0d9b7e9354fb06890f	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
63b7b256-b6fe-4485-b02c-52e7e0c0f006	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xf025a723389b9b8d2ec738cdb6495c87d381a332376125dace5b6afca9719f705b3e2facacc09e32f41081e25f08e68e37fa7f992ec35f5ed5d8b0312c5d1d3bcc7e1fe1	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
5f4aa82e-1072-4643-907a-182cdd3f5940	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x43b572476fb994be350eccc68966c413d136b8d22ce7a2232dd0b2adb1d33bb8cdb0f914ca21512067b1a982189ee4f0d4cef56c44bfcb31e0ad7a5e0bbf1513277e80b2	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
7c4a7ba9-b61b-4814-9402-1b114a185b5c	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x86d3694a32b18e01e77aa2dcf6ffd1e67161cbab5d9cee4b0d2f4e026f8cc8daa36168ad16f5c6aa7fc96dddcba3b434f88ee39b67c4c56a241d15c7a2a19460c9ef2d02	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
00a2f9fb-4b13-4abe-b4ca-defd2fac5969	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\xfd22cd747f7f3b35a93b9558457cce84f1fe51bd1052e512a0997b0dc182c188ad0ebbd784727678ef196ea741a729e672a75df47f169bd3132aa6c5fafb36a518e733cf	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
5fe8bb20-009e-41d5-b1fe-c769be568993	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x4ac1e1e0fc050cbccbfac469e9034dff14671e00498f5e7df3fb60caee17f7c0fca636f58b18fc8624e793b537a28d2740a866cce7b4c086699111a552879c0034a13a04	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
a221cac6-6150-4b2e-9ff4-3eb210713c57	aead257b-5e76-4941-ad05-0fc9f7e4d71b	\\x56069f3c52a6f2c63833d9a52caeb6e94f4a6603728d12c242d1b35f6e25b8e100562ca4f164a978e06efde8bdc604498de7a0ed2b487aa03a22a8a4ddf43f94139c6efa	AVAILABLE	\N	\N	\N	2026-06-22 07:47:34.632
0edd85a8-faac-40f7-8623-e9c1c887a0e7	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x0203c38668d65b9ecd15e51c1125b826b12a38659df073d0fc8f5517aa017e9fcd10d4c9388ada11bee09b25a1b0ddfe92f7509af498de0ff418c7f1cf16756ef79134cd	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
a3494a54-0106-47af-8660-8ae6a0f6f5a9	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x111357a407545e3e11438241297dfadd85a177a4cad95587d1b7b243b5ed4dd283cd28e18f1c2442db0a21163b4df654ede86fa1fe1bb8f3e1296f281c26f2b2e5f7f2a9	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
95944217-d9e5-4ac2-a7e0-213863fad5e3	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xeb8c3e26b8555a05f74543449225d26567cecdc6d6153fbf17526bd9e6af492414a215cce2871797b43837b6b8d7f14dc41afbf7110690d47e7236588f6bd4af0af21427	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
a1091dff-1b90-4ef1-81ba-1d7228483435	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x7c1d4b4af79abb9ef0e137f5d41ce9589f6a47e6896f8808d0b1ed98675354d526c7f280fc5bf9915dc50ac0e5a7cfb3e22fade167d15afc7033436883ec13ef1b9b4500	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
120b214e-cba9-47bb-b22f-3532455e7f1a	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x5ba09124ede2fa9e0b433a5194c266ef551c0e5c19610253122045c0dca9202010e1d960d1507ee59bf9a3ee22c56ce2488dbd9fb986a5c9cb9d8f6b98bc1b0ab34169a7	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
b7cf5bfc-fdb6-41db-9dc0-6452d264374d	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x57a35dde0266bdb292211cc22b7c9e5828f4494826977ace1f03cab60bf94a2f82574bf7ba6d2946592d6254d18d850f8ea5f10bc6a6047bd7496b2a55930e5ec63ab62e	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
dac1b4d5-52d4-4824-a4cc-33acf97ac8a3	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x8c6736bfbb3b7da0f8e0d4d4936094b551ee04ffefe22417951db0eaa27ab9ddd73bef904674bf7cdd5ce8ae5aa8da6097b6148e74cbb1549a46fd5e145d568173cf6189	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
b15ab67d-108f-490a-ae89-78ee6892b0bc	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x649ecd8c2219ac5623f5a41e824a961dd997c222414bd9be20f5efc31525dfc079ee0776e54beccac06529f4f9d3944ace204af7af571c8f4eb5396aa0c570291fdffe3d	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
b2d934d0-77f6-4755-846c-942ab5e6ea56	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x69b8f5a6a815ead147cdfefd626182a9c60eb2b73e1a9d483ce1d63bbf084e961d26d976b9318021b2b7f4d7c9fad6c137ea5c3bb7710e06757bbba1e7758025520d8aaf	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
5c013035-1712-4a85-be0c-651938356f7e	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x20ff18bc912ec15cb83d704f0568b234c8fa9f29e267415846e75765609513189cd1f6892fc4d7cef05961c6b66468cad4b5c3f561059d1ec8cabef0e05f1041f4b62790	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
6b68adfc-cd4a-44e1-9227-a813a2b8ed0d	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x7cb2db1cf2c5f4b7ccb688b0d73d9b088025fa61ef56dd997698eec15edd5c1bfb4997600049dc77e4a58c3aed3f3c27d058d902dfafa38ae5f10e2d0397d6683a632927	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
680abc8f-3c93-462f-8b30-71f5bd536183	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xd96c3c2a8dea59ce6530ce615b4dc38f83e6593540d4a188ff96c91885780174760d1cfc4e1931d7acdce74ce298cbe0ed0c9ae3ffb8d7a455549fbb646cc71f05cece15	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
347ee1fe-9362-428a-b7af-fa33e86d39ab	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x5593d397e18c4158f8d58cfa2de5c275a38bfc117d6a6146ec43c9be4f3675b2952e453439a537f8b84ac3b2e14ecf06ab5ece59f296de1fa5716844436cda14ab3267a9	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
a6d84220-d508-4c91-87ff-7eb468b00877	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x227fd35e1d79fd02dad9ea6025eb67066e1376009c41d5098424a807527dc13fa19c3012f7f44268e8063926b1c45c30d01a27ed0eed79e6092c0544094b6a0f771ce563	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
d2fcb834-f216-478a-b349-d40e102c33bd	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x55053a32ce3b49b960e19346193e8e4e9b289fb74f6c30a7946a8acb0cee01da61f3d03675324b753dfc85a992b5d489600a69307bbe553c610cd4521630ff1f2a9951d9	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
6bfedaaf-b07c-41ce-b30c-aeafeaedf2df	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x3bf2ec3bcf6a91f0a86e3f9535b7a624e5faf22823366ceedd8d98c03f3878fa904b4695aba19759023f9206414bd80785f0ce1e0964077c6368776f4fa5b0d28d61e7d6	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
9f933717-92dd-4faf-9592-4b4289228660	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x530520d05ffdb1bf3ff13bc07e7df7e297c4fa07ed1ffb1208b169057a9c547480bc3ca804ed95a5e7f1aea962c197afdb738f602863417a58c9eb5d8186408ad4707c4f	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
d344efee-b74c-4f98-b83e-20c0be08566f	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x05a65bb4865aca5691d659897af9d329063d64180c2aa7262abb9e47f98153b8305febe09fa4dcd7f552729e84b876382544984daf4bbe48d44975c3f8c14f946f3d2d70	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
eb8b72e7-7469-4f12-91e1-390f9f159b85	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x22d1ab5c8d45ec564ea48b5c830f1e7cc2c0e7f80b25f4f5208388b9746e09d00536a1ee10e65b3fbe9e13cbfca67d189f88ee8277bcfe4a5c16820724340160a8936533	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
251994b1-6958-4608-85d3-ab5758059f05	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x8de51fa05974f9173fb9cfad3832e50d4dec08f844d9c6cf446686bafeede7ebe18340b5ea1ccf59cfbea1037e14fef70139f38e1fb008459ca44219ab5a2f12e2afce73	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
60e30647-1412-4763-8867-6e3b4b925740	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x0c73cc65136e04ec128ebca07276a8be3dd827156609537e628931d3d9aa90927f7a7c1cb843e2870d6dd2c6c254283072e3599cdc4b108b08f3253c40e106fddd095ccd	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
e4b5fff9-2717-4508-895d-9eeb99a2d9e5	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xdb13166a372111108aee4141caeaf13feac5dd8d50715ac5edc1e4ac3347fae11f131e9f4deed34414ce69f533950eab7be72454a34e7836454fe3d852c3ed3146cae3ac	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
1021418b-d2e0-4328-bef1-681188f610ea	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xad19b3e41d3932c2ed50e6fcf3a8513309b8f1a7e43823d211a75d7fad4786271b179f3e715c87bb9da3c57b03d3ee6c79c06f44516e40f8d9808dbcfe3c34c3042ab2f1	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
380aee1f-9020-4f0d-a857-1d55b341bea3	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x548ff2385ceca4556d170f96e2377700d47778841114bde0a10a01fcae58259481240f51bcd23f76314adbb695ad4c4815c0473ffab8ba62b447f53c532b59a308e5217b	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
5b34f192-641d-457e-a8d7-36a94e0dae24	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xa4863f86b80fbc9b10725a84cf920b659acfd0c3ef734f1109ae74004c477d5533a592d2c0bc620ab4a69bb0553a53ac62d5f5d55a73a6fbf98d450a2bad7fede73d23af	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
0ea3fbd2-26bc-4fe4-a160-9728881282ba	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x6e4f359af174b7ca09b25c1e185616d886c5ddbcf5ef71f4eb78cb7c264c8fdf71d4b79025f64cc3e7c6130c0ff5dc10ff9d7773e8822728e66122d506139fcb5adea06d	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
abad1d11-22d9-4030-b115-204d7e76c4f6	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x97a07c1a76e3012f38acb3e2b9a5dd05b5e64238f4f40f4c0af524812e5bb6da70bfe09b49dac93a269e7227eb4af8ae51fd3a67085166b86fcb950828051f56b47b9a0f	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
3d2a8689-2750-4433-859a-6e8491110f47	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x721a39f647a5bea1bc1ae8dc94e9dee8c29c8daaad540840f4e115d80bf515dc0a5a336915b7c5e67557106442ff316fcd71aa283f096363105ff62d1991d06ae0373feb	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
8c9a2dd3-e9b0-4f34-af66-0011e347e629	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x2aaadebe1dd6a83a88dc42741775db3debe34de8d7c0eacf84decc2d9c79f2bd205b3acea3c5a5c4c16ae0b4095aa6d8734375b92415925dbd94487e71331af1ca178d05	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
ac65f8ca-79ad-4f93-a33e-5c230faf3169	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xf1efc77a39c4890e92e05183b49716a3ea723158dbf612266afaa58bdcaf3dd4db556e5d2e6e794314d7786f0757363595cf1f5ed5467cb2e18f22bd97aead76b91eaf45	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
8da0e4a9-7611-4e3e-8728-2a66e9d32769	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xd68ec13365dbcd6a4cf5fc21881400f478afbd4527b904e3065d412399adc9327594deee83c77a71e09d547afab30e0146f306647a764ac090632cd716d5614a2d651926	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
76b0218d-7783-4388-81f7-2777fcb27ed3	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x9b54a9c197f33e31bb485cb3c17374d433f65f58f2ae6d55308ea2ace7faf167ba4786238d0d7ac33b0da9ba96244b85746a6633a0b4850ec09e8e0646888cb90667c123	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
ef7f4868-cdc6-4c31-96e7-d4518a6eb9d7	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x6a088ca7533a80938677020d888df4810aacc5556a0d2c5658908c80afd224af2c9d9916788f8cd30371270625f8684cf46f5adc5a6b6c64e882beb34244cc885f99c16a	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
82d3b836-6ba7-4686-86f1-ba97a6461a32	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x29efed5185833f17409eb2a2781995548e1315c5f9cb876d067529e607989b1073131c860c8efdd446fee6ae4afe19daed7ba677106e59bfde98d6ede750176443376062	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
9e62e2ea-c9fb-4815-aae7-ecd7c6e27b0c	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x243611e75e2cdd26413f325ec3df4b3e3e3a0ab6dda2ee615f0c95d63c5c609fd739317284aa3d50fdeab0b8ea4083a697f605085ab7b85369f557853a20e1f1e3946d44	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
840dc918-fc97-4047-b067-7986501528f0	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x1a8313d31015733f624565e8d309ed764911f1b12cf57a565c971eab0fa1626a44a0229ed6436d2b16d86632c4e5092cbe5ac50a6b602eea8562b39ece7e79c58d9a932f	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
d42c6bc4-78d6-4816-b711-5fcbcbfb2cc1	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x18f92c30312281729e91a8f0209bee3662c18240fd2ec17c22283e3a8115ee6e6a4ffa9285b60271d2af04d6acb78cb32d15b8ea8963ac5d888e53faddb90f0df979f0f0	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
ad2d1370-8e9d-44d8-be08-fdd3e33bde4c	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x940839956b521e9ba5b0082b7db1d5999943a27ea3a3c1b7451253b2e145acde6763c2c394cfbb399e6c813c7973f5d906805b647af9c9f134117c4debd5adb176581897	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
555fd6ff-8516-48fd-bfb7-e965c2955125	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x5a3c78d377b8385741a5102f402f3c878387594f77cd7badddcce3e10b367ee075dd8aa72b5bbd07f588cd0720848cdb2512ef9ab3ea6f68bd885f96a7c9d1e540dca166	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
af71c59a-3d8a-4212-be92-8a20a409a6b2	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x753bcd7e2fd51e3a2273c07f6fde42b2b22e380e6df348674ca0055e995d2a980d8e4775e7651522e73d4c469df27f96755b90e2f9ccf6c76100128563098b3d42c28e74	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
eae50ded-91dc-4ff7-a439-9c92ffa2d340	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x861f9f44c24f8285691b70ae142685d437a45db06c7f093bc66f2671f9dc3950be58a04d7822b2f960a464a82b5938bbab01957e599d8e633179d500c77c626462d7037a	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
fb0145f5-a563-424c-801f-d7f9ea34f3a3	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x419b02fe84e56d8120b05bc9501bd5c69961e91275ecf9ae1e21eccb0a2d1a0de9bd1176c73af88c2edd4337c9141a751cd295182b6b2b7acd680e4d204bd1d49412cdbf	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
7a1a1331-9421-4285-9664-ea8ecfaa964b	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xaa880c84328965bcb8c351fabb9ea950a9e2f57128f5832eb03a1bd4ddfd864cf52f6446549fa31af4d4d4055ea23ad4efcac5dd9821ec5143e7139aa3718935fc437947	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
149fc5b2-6a45-4318-883b-7c405bc1fb20	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xb5af3149b7449319250ff45799ad4544f19192ba997d29323eefe59ac1639a4f9a8426a117650dea6f68a65160d53b5c133d13c2716db2ddd5ac2f05d5e994e543ec8a6d	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
5b49eb3e-77d1-407a-9df4-1578b1d0b5ca	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x458921873b64bf35ef280560d9d049f81e125032e369842a9b4fe5f82a47823086ca1bb76de2cb29dbad4f4ec3876c9bcd95adcb12d44a77bef621ff0cf0b6b6798d80ae	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
a7104c85-5869-42d0-ac6b-0792ca7659e9	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xa6d46f6a367ef4cd275c503cf0daa65a05d8ef2cb87255b5118a614e60951d40bf95d6f3930cd393c5cad66e3f4940726974682dd4292f449469c9d6f0c1bd387b2a7a4f	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
788d8c95-4d2c-4c98-bb5b-4bad6437dd3f	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x963234821e580a6c23ef7aad6d17f5bca82df6faab0e8b6c3af39b0ad8fbf92a9e64f597c354da1a7dc34f34c5d70b8cd9bcb5e1fea7379482208137757ebbd7b99cbced	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
5553323d-fcbf-4477-88af-9aadedd2126b	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x3b2e7d402984ef08c14143f31779909cbb944ac69a6f89401a7b1d2373ce472d689af6945b4eb3eb0284272a174b7c80f10f0781c1642ccb283b0b025ff211ad73f12d55	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
9ae4f13c-4b69-4d48-b7f3-67721715d7bb	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x7084a87d160af242e57864f71cd9f5e98b0cb6dac6675fc831b2e47db1c44a0f94f0c8ee460a002665d62351237aa02cf808f92c11fe2a0464876ed23c97094bc2cc7cce	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
7b7e80af-5c0f-47a1-9409-da315bf1dd5b	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xcb2afb4d0035901d1e986a6a4cf23e63eaca90fd6f446206733a1951756103401aade759a3c8ff4d19c38795efa2df864fd38cb5b1826f8b4ec3d17c39843a9617f93a6f	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
86f6f4a1-479a-45a1-b24d-4f266cc6b199	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x855e9fa577dbc871420d624f59ae40835423b3c44f02bc2502fa96f672e6201f53e393457f709a3a7ac9a093f3fa4e957191422ce4a7f73776536e8e72cf8addcb0a7269	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
e8021b7e-70b8-4085-bef4-643eb6335614	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xa24ffc16b0eabd207a2e7d1ef04aacf009b375d08e494a67e1bf393099f85983edf5a4a15bbb180850bb71293d99f6cd48512d5fdc8c92c80c768cd49ca9b745c39a9a88	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
6f918f40-a994-4567-b5b0-eef930faf60c	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xc9a9ef6b041fefaaca260a2f4aff92e18ae92962f24af104be71bf6d66696e75ed68e3becf301f0d28ebb8d54308fa67decf75c6d1489170a02db353a7f06879bc9d3585	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
8da2ed5c-fb2f-4e8f-8590-6b6c3193a8f7	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x1b3898908832c3e619e07783ac32921e8d2fc9dc68519582a949a3a560f1ebb7e681b9620003cbe8289dfcc45a47d9b2c7fd9a7e5b16c541b7c80f46bb03ac4fcdcdf4e6	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
8a11548f-9588-4a7e-a397-7d0c3b23d289	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x7d01241e59c7ab123eb71b9f84a64373052e30da9f55c1e1b677bb5fc309662fb09ab8d74928103988538e6b674337e5c476526bf75a0e8781b62f7b18e2eef81ffaac59	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
fcb8d5e3-c9c7-43bc-9129-a5f7252aa3e0	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x4406e95c448f725b2af41ae01da8f3be3257d6b656ea348e90ba4ae834c771fce0d3de8ae2750a934aca7df8e8ce3c915c9aa8243f4ae677a523d25ba9219ff9974d7491	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
be23b141-5598-4e5f-b5a1-1d6314668ef8	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xebc85fe7baaea4cc3b61ccebbfc7c64c2856b11b22c2b94b84917f901844c1b5b089c0734e8d93ba459d1d119f48201f7fa665061f06c33a6c380b5cfc975bd6e2eb8095	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
1cbac59c-d183-4c7a-9042-0f2fe9435cf1	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xb8d253bdd395d9734340c4bd414b46e8f16c4f38dc1b6b254831f22e6fdc0724e495160cf37dc30b7a7fcb75ac7ff50efcdbd600bb8ef7cb910cf78f21d2a314c78c38a9	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
5749b916-cd45-4308-ac72-1ca3b0041553	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x6ef62a06b49db1bf3d80f48093e5ca698468e001ead0dc0b78c0bd3c188a9527266dde75dfa3ac7ddb0698a143157c43385f9aadf4a046dce32e91214bf6a477e762ac90	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
3eb3c59c-b32f-4b0f-b431-308a2679522c	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x04179d09cf82e7993d0c9ee6cedb6987ddd677e632536cbe3f46b60445afcfe73bd9a87f06c2f9cc0fbde6fbdae7f361f3cc1efc38f36e435d969d170be6a3655b5a4081	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
671118e2-c175-478e-99e3-614b43387d5a	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x5e99ad4052e982dafd41450f21ddd9e467eb7c17acc8dc1c38dba45c5d5af0f3a65d5a5e5ecb60ab7cfb39e5b75c339e57bf2a7f9a15f171bbca305e48b950a9aa0d4f24	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
c790190a-e58f-4d31-a600-d240a932ddf7	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x909ea459960e0cff38bba45bd17707d7634b2caaa571ffec4558b4f046b576e6c540e1e0926fd4d0d40d78ec69ccceca2d6e03d505bacb5fb43e475fc4161cb093f51b2a	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
76e6d9e9-ee97-4438-939e-4c85afb19829	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x282e252dca150199538d2a8db4c4b29049980ff3a30ebdfbbec8ea6bf759014e98eec2a5ce6c962b36e15ddd8442987dd33c945fd5dec4097e55208e90a04be3d1f94108	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
ccb8d1b9-bd7f-4eeb-9bfb-7def80c32af1	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x185df826f20e46577f89bc4b12fdb0ed681fe0817d827d6b60761232f971ba3f616786e271c4d39376661185c834edce96875a6e30e822572f5e5fa44e3e3d8daf2527c2	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
c6b3b65b-08f2-4519-8e5f-334de92c694c	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x8a3c730cdf614c56bb805dab7e71bb4d6de8696396635d7aa2c72f7dccbfdacb11096d328e8186a5de90ab3d38575aa9b216a7b8ad49bdc7714823669e4d7aadfb1a6ccf	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
9a1e5ea2-62a9-41c1-846e-c80cb08911cc	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x37ee09c722f4a36beb25df926dd6c923c9894229554a762faeb85b05c1f29881687af5a137f1a0663f5aaf6806aab36ce18408e19ba5d45ea46bd2fe54ed42dbfaaa024b	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
30a00f21-0305-4ea8-841b-c89065e511d5	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x6e824b2cdeb712b3911a7218e5e73c5f061420d2009489e056bfcbeda461be2f532caef370d68581e60f269004e398e0e0fbf9df9eb60354ccd1e95ab8a651b98c55c92a	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
7b92b30b-7d6d-4574-98bb-c68d0713c387	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x1b0fe9a2f8a26edb458dc64f2d39e16eae237b2df323c951374b416420ebe22320150ddea91e23b62789262237f0c3f98013b7bf14f98ae24bd38a1d407ab7527e29585e	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
b3bb3178-0171-4d68-a3b6-0621b7ed58b3	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x25f2ea809f67b1341bf0e2bbb8bd00821cc89591f9b41f34746ad7853988d13473091f2d9d37bb8a1ec3a815f327860dd900935bb21fe7fcf0bbbeb7d5d9e6b7a14f7ab0	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
41e064d7-9076-49ef-8286-0cac377474e1	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xb3129f719b884de8507d0f2ab901497994ecb84ea7e150af9b0b3c8a4c09b43afbed769a0003deb438fc805cdea6721147016cd74448e2cf54b3304cc1668e509058f81a	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
c00e4b44-7da4-43f8-80db-b84378e2058d	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x703131f2f29519fa28890aa8e3f346fc9e8b187df5a09df384bab74b7e3701c2cc2eb9c85c96237810d299bd0fd389ed30801440efb997e95a216dbb21f4b6ba2f2de85e	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
68d72f1d-5386-4b1c-86ae-07b29ae86486	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xdb88499ccbfa870c848b75ecc184c654f19bc4fbe933d2ff4994aa4b6754cf4150f23f0928a9d6c948e8febfba8bee28dc06af74c841a8e49f7952932d2bd1a62ac77a8d	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
cc653794-f77e-4774-9be3-7e528a6ca03a	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x4fedb4fbaae2967e3e0c4baedcb1d40002d2c90c6c72d0d6bb5abdfa34d1681c9d5c76f3fc5eafd5249c55b93adf86ca726b083ebe38c19c60387b8ac371b2bc4744999e	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
8e1c1c56-d1b0-4e13-bb37-755666c014a1	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x43c6c5505d2d81ed3e6caf2e286d27579a7925f57f878a3315c558ef36df864729db066a4d257cf693e48a4ee6351ac00cb4300bc384ac9de3d55b49faebe10c90baaff2	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
5b33f70f-607f-44e2-8954-f103de2ae172	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x4157af2ef0ca536bd7e2f5c16869d2551788a06c3fed7d45e01052f8acb30556c6921db13923586b85795be7bcde5d31f4dc3674235460105e193428b064adc23bb8599a	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
7354925a-e6ff-4552-a86c-8926ff541ea5	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x3ca08f43e17dc5ede7e0a5b3ba0d0e6c7deb21012e2010871790ee2ba7ad81855334ae19fffbc24bc43e181fa21e0a3a11aed9a67577bae4e4714f53dd01e0d11c7345e6	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
494e4373-4048-416e-a7d5-3917e882c137	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x958cc8e8f1f514a1efa3082c232e342cc4c977c326d8e1c59b42a7be801ed6c04418e8961e8618bcfb10f2b8ee9006cf535b8211c09b201194e607986fe2cf2b836414ae	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
402347b2-8103-40c2-88fa-47dfde718d00	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x90a735555dcbd6910ccf7cf6d21110d7594abd660d85a2b8d7167da467a4b90ec80ffe60c42cc80e2b588c37a30ddc070cef5ac67666b8f4077d78607747cdf6a701afdb	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
49970623-605d-4e3e-87ff-bf7dd1422c8b	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x633e6cb7ca9ada8d4d0d1ff0d1d8e759b4a6319fc5e6a3e89090b1dabc70caebb879349509b8c1f05b029ee5f81c9fdce5d8f29011fd09bfee7cdaa8e8f63367eb5f78a0	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
976c0f8d-e50c-45f8-92da-5bae219d4c67	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x4ee8cbfd33bf8ba4bc26231acfaa05fb99f29125363865f450b388621b545d9ebf555967dd084612e88b0739c299abdffa8d342aba355bb61b71ae480d4703f6d086f0c3	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
424a518b-8e4e-4398-a5d5-f06d1d0f0a81	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xbcfd1d058ba85bb263b5499f7fcaaa54c7d6a2aca31a503a94d2ddb2880d337a3960b74c6190d20354fd8f350ac752cb9b4b69fd56d1a41971b0d1fc4775b00a772c4c49	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
cc7c9544-5b1c-4ebd-9913-12c1e24e7816	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xb4165a34f00c5cada07aef4a540cb0f89db01ab7cb3a80dc2e37f4d5f36295227886d4c9c5163a8157ba045492c1341e537506033ebac814d90ce2e870b1ecd80bb6fe33	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
2a214748-4221-49ea-bc3b-521936372e34	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x684391fe68696e4e0ff25ab85de74d8db8078dbd8938415bb3d28fab85839db33e6ef62085e7435dfaf2b352f4bd0eeabbfc24c3d3549c6bc9f1a47c1f51910dd1fef61f	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
7d11b5e5-40d2-4e84-9577-1ed90b5b7474	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xaed86e0a1a77bf2a9c804c4f35957bbeacd83beed50dab2c1af1f0865bc19db336a94af9beb6e1578ae1ad663a8c111775777062db80a44d4b3efa7ff6014c5ee055babd	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
bbb4fd0d-c96d-4aeb-99fb-b2bb2aeff7b0	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x0cf6045f05d282da0dee35007cd9d944d473fb7cae056bea5610a4a8ad0938db5485631aff3c894cbcc9faa83a15ed071aae5870758b71ee7609723f755495ecfd3ee7a8	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
b80fdebe-fdb3-4ab0-968f-dc0ebaa24027	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x0546aaeefa6da81d13f3b22edc2e41b0d4fccef7935507b8b697ba0699d60cf3602c806ff8b7939eebbed00b625068153c1468094a51f5242c3e0d9bdd7fff061d4b876a	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
c9c6caf4-3a42-4b53-8af4-bc598a94db37	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xa77fe10c0e4a61c3c04982487516c5d8620984cf546ad239699e8aefce41843a8d5765dccb02658fee75dabff6e8b41c37a01dc1a1a9498556a528b58a760e6b2e3bbcc1	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
7b7ec0ea-2579-48cf-927f-b6dcf0036490	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x0179a5c066fff4165f6525e21792e76a3131f91d7186d13170c6debd767d4067a4cb894453bece352b238987b1e859a348618e5d38c7f7c0df40df4ea24489763a9be9e0	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
b94693e4-d9d0-40f9-8142-966a1b1f5eb9	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xfd5d06a75de149de743e800288aea3792957b20da23656ba62a1dae92c1f28eb26916e8be3f98a2757b937926716714f32a3cb61e1edd2019fa3f61039099a62e19f85c3	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
936af401-1662-4da1-b3f0-7bf9790d55eb	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xc3e52eec379fe76cb93b11719c7f8146d8d36e0b3724cd2a8dd4a3a06f1279f059ebc0e89f08f771eba2e7f10cc3accbfd9db1158745bb8cb9e28aadc1e0396583ca5add	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
66441419-c543-4639-97bd-2f1c63c9641e	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xca8c2a115ff2169642fdfd5a300d7625d81283e5a5ff030088d110d7bee0d6bd3ba5bd7cd87cac94a2a2b7f631d48b98be450be82e66188e93ae3330832b73c91812f2f8	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
ce51e3fb-02e9-47a9-8b98-f9c74089ef38	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xacce531117edba7475f978f32885476419c83b41a8d827f67115fcb4f1d0bfceff4124b73b806ce8c25ba049ca61e1841a9e1ba86588a843108c29fa427b8537b7030c8d	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
881cc1fe-a33b-4db4-bf1d-d6965472a3ff	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xd098f7e3f8a1c4566a7245cb2a37e8b7457a0f49d648b18c66088381e08920ab3db57d28b359666b0fd0b875062f68ab5bdd2755732c2f258ae238db692555de9d361f32	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
c91a6cac-4053-4efc-82c0-f3f26bd1b745	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x03f04bceace576c64e0aa2154454342ea339fe8346bad22d1b28916df41de074fc1853e3f8bba1cdf212ebfb58d1ca657890046de8133db8f85a6d8b6439c3db8216680b	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
97dc5a50-5ecf-4783-9cbe-0c15d9569b52	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x64e7c4a6a5edf67657e46c7046a52fa34c24fd3204a77160d16a309df7b7394932a17c041af0c2f203de9b3c8811cf0720f0507b290503d74751817083f5a371c041653d	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
6a71f014-9445-4010-866d-2a7fbd6d261c	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xc481f0020b2a5a3a6c0c668ffb0ffc993af5753e0a3342059f670db1211f06e9397ade40deca5d863384eaa80db832f161ec379e0a6009fa0e0d69f664904022994fd4d9	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
c69d982f-9ba9-4a22-b6ae-ec486f562e06	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x6dd3b66505d75dfc19012c394e5041b8513cd2f13f0f83da0bdb245e499a5ad0d1371680538a67476fc81f42c3bb32e09d025d8c37bf4faa34b95370c026b992417ca9f7	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
95957cc5-4d95-4b44-b555-c8399e9eca42	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x99a3869969fdd52f448b82c5677fb871ddacd1f4f6edc877359496d2c01c534bbda3c43cf16dfc345793d6ab717d5ec1b9ee3c9c00f577a42b7c3db82d6326e135effbb6	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
b5f182f2-d8e2-4957-85c7-d3a3a378efa5	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\xddf003d65ed9a1cb12abec89648f05381edce3c889e1d811e02cf6386cb6cf693496bac8ca4ca311ea369962b101ea06a62b9bdcd95e1e62a5063d911d58ec226f85b597	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
aef167ef-1722-4fa3-adee-e4806c283131	220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	\\x84da3aba8f1ac1bd00ec79ee59f8631bee7294c5806296b4bd6e427829fff27b12db4c446ae4d4d841634c2a069275877b290e3cb9f613b3c7ad9a0565f1fc9fc429593c	AVAILABLE	\N	\N	\N	2026-06-22 07:52:38.939
\.


--
-- Data for Name: seller_products; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_products" ("id", "seller_id", "seller_category", "name", "price", "description", "image_url", "publish_date", "is_active", "is_hidden", "is_restricted", "sales_count", "revenue", "created_at", "updated_at", "deleted_at", "sub_category_id", "store_type") FROM stdin;
46d8319b-f7a2-488d-9c21-08a6891c7e67	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	BM FACEBOOK	100000.00	🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779731088619.png	\N	t	f	f	10	700000.00	2026-05-25 17:45:04.69	2026-06-21 18:37:57.002	\N	\N	TAI_NGUYEN_MMO
0fbf8797-e5c2-493a-b175-61f2b6b412ef	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Game	GAME LQMB	79000.00	LQ VIP  1	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/b809ad2f-0580-4c8a-bc4c-7a2389dc6751/1779867104874.png	\N	t	f	f	3	165900.00	2026-05-27 07:32:05.41	2026-06-06 14:21:27.603	\N	\N	TAI_NGUYEN_MMO
a4a52a6a-5914-4f9d-9c07-606b73a5e842	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Via Facebook Clone 2019	79000.00	🔥 Dịch Vụ Bảo Mật - Bảo Kê Facebook Bên DJ Media \n🔹 Gói Bảo Mật 3 Tháng Giá : 4Tr666K\n🔹 Gói Bảo Mật 6 tháng Giá : 6Tr999k\n\n🔥 Lợi Ích Bảo Mật :\n🔹 Chống Bị Kẻ Xấu Hack \n🔹 Không Bị Kẻ Xấu RIP	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1780084783200.png	\N	f	t	f	2	110600.00	2026-05-29 19:59:52.488	2026-06-04 11:31:33.169	2026-06-04 11:31:33.167	\N	TAI_NGUYEN_MMO
45a65117-624f-4e87-b2cc-add4714bc25e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Tài khoản 250$	50000.00	1	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779727106668.png	\N	f	t	f	5	175000.00	2026-05-25 09:46:03.471	2026-06-04 11:31:54.481	2026-06-04 11:31:54.48	\N	TAI_NGUYEN_MMO
8000aac0-41a3-49f4-801e-1a12191721c7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Tài khoản quảng cáo	10000.00	Cung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779727141249.jpg	\N	t	f	f	24	168000.00	2026-05-25 09:21:32.274	2026-06-21 19:36:37.56	\N	\N	TAI_NGUYEN_MMO
d4f4b1b0-4352-413e-8d79-83ae4f3acc0a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Vip	5000.00	addd	https://cdn.hethongmmo.vn/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/0941f802-cdd8-49bf-871a-c1db2423af17.png	\N	f	t	f	0	0.00	2026-06-22 05:38:44.013	2026-06-22 05:40:48.569	2026-06-22 05:40:48.567	\N	TAI_NGUYEN_MMO
9a882cbb-d9d6-45e6-a3b3-7b143a8d1d9e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	Vip	5000.00	VIP	https://cdn.hethongmmo.vn/product-image/3ad147cc-59c4-4623-ba0d-59011dcb6b93/c940af4c-6850-42ce-a91f-22676f53fd4a.png	\N	t	f	f	1	3500.00	2026-06-22 05:41:34.18	2026-06-22 05:50:47.146	\N	\N	TAI_NGUYEN_MMO
afe3f4e2-87e3-43c3-a851-3d7590e74231	e580851a-de0a-48bc-b0a0-922784cbbd2c	Instagram	TEST	5000.00	\N	https://cdn.hethongmmo.vn/product-image/e580851a-de0a-48bc-b0a0-922784cbbd2c/b3403166-1012-46ed-b193-db3fe9cda215.jpg	\N	t	f	f	0	0.00	2026-06-22 07:22:39.16	2026-06-22 07:22:39.16	\N	de47a69f-91cb-4f96-8134-00bcce41fa9a	KHO_TAI_NGUYEN
aead257b-5e76-4941-ad05-0fc9f7e4d71b	e580851a-de0a-48bc-b0a0-922784cbbd2c	Instagram	test 2	10000.00	abc	https://cdn.hethongmmo.vn/product-image/e580851a-de0a-48bc-b0a0-922784cbbd2c/aa265d3b-8ad3-4c50-b972-cb49fc0a8804.jpg	\N	t	f	f	0	0.00	2026-06-22 07:47:34.632	2026-06-22 07:47:34.632	\N	cea42dc3-a88c-4c35-a620-d157b070d2ac	KHO_TAI_NGUYEN
220fe5c7-77a1-4ef4-b5bd-10b1ff2397dd	9c652e2d-15d7-42d8-9b96-1179145dd096	Facebook	Test tài nguyen	1000.00	aaa	https://cdn.hethongmmo.vn/product-image/9c652e2d-15d7-42d8-9b96-1179145dd096/574282ec-eece-429c-9225-09f63b887fea.jpg	\N	t	f	f	0	0.00	2026-06-22 07:52:38.939	2026-06-22 07:52:38.939	\N	d1b73c22-47c7-4770-9402-570673c9379e	TAI_NGUYEN_MMO
\.


--
-- Data for Name: seller_requests; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_requests" ("id", "user_id", "category", "fee", "status", "approved_category", "reject_reason", "reviewed_by_user_id", "created_at", "approved_at", "rejected_at", "store_type") FROM stdin;
ebe7b9d3-047c-4bfe-8550-84bff34e1190	3ad147cc-59c4-4623-ba0d-59011dcb6b93	Facebook	50000.00	APPROVED	Facebook	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-25 08:59:12.504	2026-05-25 08:59:46.592	\N	TAI_NGUYEN_MMO
93fe7f32-cb2f-4372-bf4f-4e91b09b1465	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	Tool & Phần mềm	50000.00	APPROVED	Game	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-27 07:28:20.408	2026-05-27 07:31:01.854	\N	TAI_NGUYEN_MMO
6d105e38-d100-4656-bc21-2dfdcf6dedb9	f15fef1f-7843-44b0-b983-72068d1647c6	Facebook: a	50000.00	APPROVED	Facebook: a	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-29 10:02:19.879	2026-05-29 10:02:37.775	\N	TAI_NGUYEN_MMO
d7f444d4-7577-4561-a630-6908916d41d7	15bbcf73-c01d-4730-85d7-a1cca3730c83	Canva: a	50000.00	REJECTED	\N	ad	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-29 09:51:05.258	\N	2026-06-02 19:19:27.012	TAI_NGUYEN_MMO
1a2fbc54-0ab7-4789-8aa4-52ef6448b93c	e580851a-de0a-48bc-b0a0-922784cbbd2c	Instagram	10000.00	APPROVED	Instagram	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-22 07:21:33.098	2026-06-22 07:22:03.54	\N	KHO_TAI_NGUYEN
ab3d7065-c4d7-41a4-aacd-bfcf5eb5b7df	9c652e2d-15d7-42d8-9b96-1179145dd096	Facebook	10000.00	APPROVED	Facebook	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-22 07:51:46.913	2026-06-22 07:51:57.721	\N	TAI_NGUYEN_MMO
\.


--
-- Data for Name: seller_sub_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_sub_categories" ("id", "name", "category_name", "display_order", "is_active", "created_at", "updated_at", "show_in_kho_tai_nguyen", "show_in_tai_nguyen_mmo") FROM stdin;
6df4dce8-9c23-45bd-a15c-e877996e945c	AA	Google	0	t	2026-06-21 11:45:37.17	2026-06-21 11:45:37.17	t	f
d1b73c22-47c7-4770-9402-570673c9379e	Tài khoản fb cổ	Facebook	0	t	2026-06-21 13:55:51.459	2026-06-21 13:55:51.459	t	f
ef467d06-091c-4a07-a31c-084bc59342c9	Tài khoản cá nhân	Facebook	0	t	2026-06-21 13:55:57.38	2026-06-21 13:55:57.38	t	f
cea42dc3-a88c-4c35-a620-d157b070d2ac	Group 10k	Instagram	0	t	2026-06-21 11:43:39.31	2026-06-21 13:56:36.508	f	t
de47a69f-91cb-4f96-8134-00bcce41fa9a	group 20k	Instagram	1	t	2026-06-21 13:56:45.76	2026-06-21 13:56:45.76	f	t
\.


--
-- Data for Name: seller_tier_definitions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_tier_definitions" ("id", "key", "label", "description", "badge_color", "fee_percent", "min_withdrawal", "hold_days", "benefits", "upgrade_min_revenue", "upgrade_min_orders", "display_order", "is_built_in", "is_active", "created_at", "updated_at") FROM stdin;
9033a6a8-f624-4b37-af6c-d907a82dab11	GOLD	Cấp 3	Seller có doanh thu tốt	amber	11	5000000	7	["Hỗ trợ cskh nhanh tỉ lệ đơn cao"]	20000000	100	3	t	t	2026-06-04 03:26:44.294	2026-06-04 08:31:47.195
77f20ddc-fd13-4ba5-b536-30f12353c35d	SILVER	Cấp 2	Nhà bán hàng hoạt động tích cực	slate	13	3500000	7	["Phí rút tiền giảm còn 4%", "Giữ đơn 2 ngày", "Badge Silver"]	3000000	20	2	t	t	2026-06-04 03:26:44.294	2026-06-04 08:33:01.442
0dd8c092-7df3-4f05-8ef1-29b690aef4a8	STANDARD	Cấp 1	Hạng mặc định khi được duyệt	gray	20	1000000	2	["Đăng bán sản phẩm trên marketplace", "Hỗ trợ cơ bản qua chat"]	500000	0	1	t	t	2026-06-04 03:26:44.294	2026-06-07 14:40:48.335
1208edbf-e67b-42f8-a0c2-f115e20aacc3	VIP	Cấp 4	Seller xuất sắc — ưu đãi cao nhất	violet	9	5000000	0	["Hỗ trợ ưu tiên 24/7", "Badge VIP độc quyền"]	100000000	500	4	t	t	2026-06-04 03:26:44.294	2026-06-08 02:54:05.884
1c149d14-f5c4-43e4-93b5-f6f0c467c8da	SUPPER	Cấp 5	Nhà bán hàng kinh nghiệm	blue	8	1000000	3	[]	0	0	4	f	t	2026-06-04 13:05:38.539	2026-06-08 02:54:11.995
\.


--
-- Data for Name: seller_withdrawals; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."seller_withdrawals" ("id", "seller_id", "amount", "fee_percent", "fee_amount", "net_amount", "bank_name_enc", "bank_account_number_enc", "bank_account_holder_enc", "status", "qualifying_order_ids", "reject_reason", "processed_by_user_id", "created_at", "processed_at") FROM stdin;
3ae0f920-365e-4412-84eb-427b532c7f8d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	220000.00	10	22000.00	198000.00	\\xf94550d4f934743f4d0846b64015fe08b2ce621215e3abbce4b00d65490d9469b3964a	\\x746518ec39d185a9ed95c2326e015d19827de57c7fc24e262df58465309ad8693672069b5852	\\x0b10ce2a5c0fd166c6368a96a9ceeff3d918230ddea141a55c6560f9283ec62b4e04ffa6	REJECTED	["f5986697-1fe9-4778-9f32-540d877b9813", "287872ad-aaba-4d2c-941c-dc2b8806d4ce", "a4293674-897d-4645-8e0a-ca3b6cb5988b", "479458ec-e829-4b69-983a-2880dc884ef5", "b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf", "26622a2c-2286-44ea-b60d-99a8655c86c2", "d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51", "0751a761-71b9-448e-84df-841b9cd772e2", "7c9cddea-a5d2-4c01-9ad9-74f88917b4c4"]	Chưa xác  nhận thông tin	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-26 19:59:36.463	2026-05-26 20:01:06.236
c8515907-0aab-4498-91e0-70c217a64847	3ad147cc-59c4-4623-ba0d-59011dcb6b93	220000.00	15	33000.00	187000.00	\\xf94550d4f934743f4d0846b64015fe08b2ce621215e3abbce4b00d65490d9469b3964a	\\x746518ec39d185a9ed95c2326e015d19827de57c7fc24e262df58465309ad8693672069b5852	\\x0b10ce2a5c0fd166c6368a96a9ceeff3d918230ddea141a55c6560f9283ec62b4e04ffa6	COMPLETED	["fc287ba1-28b3-4daa-b4eb-f159632298b5", "f5986697-1fe9-4778-9f32-540d877b9813", "287872ad-aaba-4d2c-941c-dc2b8806d4ce", "a4293674-897d-4645-8e0a-ca3b6cb5988b", "479458ec-e829-4b69-983a-2880dc884ef5", "b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf", "26622a2c-2286-44ea-b60d-99a8655c86c2", "0751a761-71b9-448e-84df-841b9cd772e2", "7c9cddea-a5d2-4c01-9ad9-74f88917b4c4"]	\N	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-05-29 19:04:18.893	2026-05-29 19:04:53.967
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."service_categories" ("id", "name", "icon_url", "created_at", "updated_at", "display_order") FROM stdin;
c8487ef6-2b1e-432b-97fe-7cb74733d7fe	Facebook	https://svgl.app/library/facebook-icon.svg	2026-05-29 09:11:15.465	2026-06-06 15:20:19.783	1
836babc6-6e6a-456e-9dca-091c49c2ed62	Tiktok	https://svgl.app/library/tiktok-icon-light.svg	2026-06-06 15:42:18.203	2026-06-06 15:42:18.203	2
ed072890-2b5e-440b-a248-19de9dd310c4	Instagram	https://svgl.app/library/instagram-icon.svg	2026-06-06 15:42:28.735	2026-06-06 15:42:28.735	3
d9fc7056-0e96-4184-8f52-10e494d01bff	Google	https://svgl.app/library/google.svg	2026-06-06 15:42:36.542	2026-06-06 15:42:36.542	4
bd783349-7a97-4dba-b969-d346a8fd0a3f	Icloud	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/service-icon/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780760568205.png	2026-06-06 15:42:51.421	2026-06-06 15:42:51.421	5
d8324efb-c8a8-4714-ae30-bc56fa253614	X	https://svgl.app/library/x.svg	2026-06-22 04:26:30.102	2026-06-22 04:26:30.102	6
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."services" ("id", "slug", "name", "thumbnail", "platform", "category", "price", "success_rate", "processing_time", "rating", "total_orders", "total_views", "is_active", "is_featured", "description", "seo_title", "seo_description", "warranty_options", "product_list", "display_order", "created_at", "updated_at", "deleted_at", "customer_count", "platform_variants", "review_count", "requires_account_type", "requires_cccd") FROM stdin;
7a7ad9e2-9cf6-4551-a063-f247e1dbcf41	mo-khoa-gio-hang-tittok	Mở Khóa Giỏ Hàng Tittok	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780244366919.png	OTHER	Tiktok	30000000.00	100	1 ngày	5	21	453	t	f	mở khóa chỉ trong 1 ngày	\N	\N	[]	[]	1	2026-05-31 16:19:20.394	2026-05-31 16:19:31.374	\N	123	[{"icon": "https://svgl.app/library/tiktok-icon-light.svg", "name": "TikTok"}]	92	t	f
7d6cafc1-de27-4831-b383-6fb4fdf53e4c	tai-khoan-tiktok-han-che-de-xuat	Tài khoản tiktok hạn chế đề xuất	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428774308.png	OTHER	Tiktok	1500000.00	100	1 ngày	4.9	243	4321	t	f	Kháng nghị tài khoản tiktok hạn chế đề xuất kênh vi phạm cảnh báo đỏ	\N	\N	[]	[]	2	2026-06-02 12:08:25.727	2026-06-02 19:32:56.827	\N	1231	[]	1231	t	f
a71bbf5c-913d-4232-b1e9-cd37f54b3a05	unlock	Mở Khóa Icloud	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779643299544.png	ICLOUD	Icloud	100000.00	100	1-3 ngày	5	12	13213	t	t	DỊCH VỤ CHẤT LƯỢNG	\N	\N	[{"name": "24 GIỜ", "price": 0}, {"name": "1 THÁNG", "price": 5000000}]	[{"name": "IPHONE 11", "price": 3500000}, {"name": "IPHONE 17 PRO MAX", "price": 14500000}, {"name": "IPHONE 11 PRM", "price": 3000000}, {"name": "IPHONE 12", "price": 4000000}, {"name": "IPHONE 12 PRM", "price": 4500000}, {"name": "IPHONE 13  PRM", "price": 6000000}, {"name": "IPHONE 15 PRM", "price": 8000000}, {"name": "IPHONE 15 PLUS", "price": 7500000}, {"name": "IPHONE 16 PRM", "price": 12000000}]	1	2026-05-24 17:22:28.488	2026-06-08 08:55:01.613	\N	32	[]	124	t	f
d11fa0ca-9935-441c-9f62-d46cf4d45999	adadad	Mở Khóa Fanpage Bị Đình Chỉ Đăng	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779618629337.png	FACEBOOK	Facebook	3500000.00	100	3 Ngày	5	212	2543	t	t	Update siêu tut khôi phục những fanpage thời gian nhanh nhất qua hệ thống meta ai auto tools !	\N	\N	[{"name": "24 giờ", "price": 0}, {"name": "1 tháng", "price": 3000000}]	[]	3	2026-05-24 10:30:42.979	2026-06-02 12:05:10.778	\N	241	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	21	t	t
1700c5db-6a48-48bf-9c5c-57037050267d	dvfb	Mở Khóa 282	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779616281373.png	FACEBOOK	Facebook	200000.00	100	1-3 ngày	5	132	1323123	t	t	abc	\N	\N	[{"name": "1 Tháng", "price": 150000}, {"name": "2 tháng", "price": 500000}]	[]	4	2026-05-23 16:22:38.098	2026-06-02 12:05:18.136	\N	123	[{"icon": "https://svgl.app/library/facebook-icon.svg", "name": "Facebook"}]	2144	t	t
c8f14b74-fff9-46ee-b36b-93fa0e33287f	mo-khoa-tai-khoan-instagram-chinh-chu-180-ngay	Mở khóa tài khoản instagram chính chủ 180 ngày	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428759528.png	OTHER	Instagram	2500000.00	100	1 ngày	5	2134	32123	t	f	Mở khóa những tài khoản instagram chính chủ	\N	\N	[]	[]	0	2026-06-02 12:11:50.312	2026-06-06 15:43:48.316	\N	4124	[]	3242	t	f
914a7223-ade0-464f-aeb8-2506fd1bd252	mo-khoa-tai-khoan-vo-hieu-hoa	Mở Khóa Tài Khoản Vô Hiệu Hóa	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401699924.png	OTHER	Facebook	4500000.00	100	1-7 ngày	4.8	423	4231	t	f	Mở Khóa Tài khoản vô hiệu hóa vĩnh viễn dạng 583, 811, 035 ...	\N	\N	[]	[]	1	2026-06-02 12:01:32.495	2026-06-02 12:01:44.37	\N	3213	[]	342	t	t
e22e8ca8-9c91-4573-b152-e532c6f3bc28	mo-khoa-tai-khoan-xac-thuc-2-yeu-to	Mở khóa tài khoản xác thực 2 yếu tố	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401804344.png	OTHER	Facebook	600000.00	100	1 ngày	5	2312	1243	t	f	Tài khoản dính xác thực 2 yếu tố, mã xác minh ... 	\N	\N	[]	[]	2	2026-06-02 12:03:26.37	2026-06-02 12:03:26.37	\N	213	[]	231	t	f
6b802cb2-5052-4578-9e7b-1b0281d6e820	mo-khoa-tai-khoan-956	Mở khóa Tài khoản 956	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780401926201.png	OTHER	Facebook	900000.00	100	1 ngày	4.9	212	1412	t	f	Mở khóa những tài khoản bị dạng khóa két sắt tím và dạng khóa 956 két sắt mở	\N	\N	[]	[]	5	2026-06-02 12:04:49.509	2026-06-02 12:05:27.849	\N	324	[]	123	t	t
39484b26-a985-4dcb-bccd-87aa3904aa9b	mo-khoa-video-tiktok-vi-pham	Mở khóa video tiktok vi phạm	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428792008.png	OTHER	Tiktok	1500000.00	100	1 ngày	5	124	123	t	f	\N	\N	\N	[]	[]	3	2026-06-02 12:10:39.591	2026-06-02 19:33:15.215	\N	3423	[]	324	t	f
870c3504-944a-4833-a0ee-a25bef4c21e1	xoa-tai-khoan-tiktok-mao-danh	Xóa tài khoản tiktok mao danh	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428801249.png	OTHER	Tiktok	1500000.00	100	1 ngày	5	34	212	t	f	Xóa tai khoản tiktok mạo danh chính chủ, yêu cầu cccd trùng thông tin 	\N	\N	[]	[]	3	2026-06-02 12:09:51.848	2026-06-02 19:33:23.903	\N	412	[]	54	f	t
b3d4bf87-fe9d-4dd6-bc29-fe9c49a50bd5	xoa-danh-gia-gg-map	Xóa Đánh Gía GG MAP	https://cdn.hethongmmo.vn/service-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780047000131.png	OTHER	Google	1500000.00	100	1 NGÀY	5	240	21422	t	t	\N	\N	\N	[]	[]	1	2026-05-29 09:30:17.869	2026-06-06 15:43:18.808	\N	423	[]	124	t	t
f2251457-dd7e-464f-8942-85447bf0fe95	danh-gia-gg-map-vip	Đánh giá GG MAP VIP	https://cdn.hethongmmo.vn/service-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780428783583.png	OTHER	Google	600000.00	100	1 ngày	5	45	241	t	f	30 đánh giá gg map 5 sao ngay lập tực cho gg map khi thanh toán chỉ cần link gg map cho chúng tôi. 	\N	\N	[]	[]	2	2026-06-02 12:07:13.977	2026-06-06 15:43:25.483	\N	132	[]	86	f	f
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."sessions" ("id", "user_id", "session_token", "ip_address", "user_agent", "expires_at", "created_at") FROM stdin;
\.


--
-- Data for Name: site_content; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."site_content" ("id", "key", "content", "updated_at", "updated_by_id") FROM stdin;
\.


--
-- Data for Name: staff_permissions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."staff_permissions" ("id", "user_id", "permission_id", "created_at") FROM stdin;
48bec593-da48-4e4c-af0c-e9cacc10b142	e580851a-de0a-48bc-b0a0-922784cbbd2c	f48d52bb-ea9b-44f6-b5fd-e173099c60bc	2026-06-20 18:05:40.807
eef091f8-40d5-44b2-be52-a2233b08336a	e580851a-de0a-48bc-b0a0-922784cbbd2c	a4dbd7e8-d242-4170-9def-e5aec13214ac	2026-06-20 18:05:40.807
210b09a7-b9e4-416c-a465-7080c2acab29	e580851a-de0a-48bc-b0a0-922784cbbd2c	3e60c108-e46a-4da2-a0ca-1677ccb2a39c	2026-06-20 18:05:40.807
b3da769e-89d6-4e40-8e78-cdcd0fc4c1fe	55d1694a-443e-4f08-8875-8dadff9cbf62	a4dbd7e8-d242-4170-9def-e5aec13214ac	2026-06-22 05:55:49.994
6a8379e0-a2d5-4172-b6c8-f2c62b66b376	55d1694a-443e-4f08-8875-8dadff9cbf62	3e60c108-e46a-4da2-a0ca-1677ccb2a39c	2026-06-22 05:55:49.994
\.


--
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."system_config" ("key", "value", "description", "updated_by_user_id", "updated_at") FROM stdin;
seller_settings	{"slot_packages": [{"price": 50000, "slots": 1}], "order_hold_days": 2, "registration_fee": 10000, "min_withdrawal_amount": 1000000, "withdrawal_fee_percent": 20}	Cấu hình rút tiền nhà bán hàng	e580851a-de0a-48bc-b0a0-922784cbbd2c	2026-06-07 14:40:48.331
deposit_bank_config	{"bank_bin": "970422", "bank_name": "MB Bank", "ip_whitelist": [], "account_holder": "CHU QUANG DOANH", "account_number": "1536238386"}	Cấu hình tài khoản ngân hàng nhận nạp tiền	15bbcf73-c01d-4730-85d7-a1cca3730c83	2026-06-22 18:51:53.371
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."testimonials" ("id", "type", "course_id", "category", "reviewer_name", "reviewer_role", "reviewer_avatar", "reviewer_initials", "reviewer_color", "content", "rating", "is_active", "display_order", "created_at", "updated_at", "service_id") FROM stdin;
493da2e8-5cfc-4f1f-8efd-4c0f4a278d9f	SERVICE	\N	Facebook	Lê tài	\N	\N	LT	#0066ff	Qúa tốt mình đã được hỗ trợ nha chóng	5	t	2	2026-06-04 12:23:35.803	2026-06-04 12:23:35.803	d11fa0ca-9935-441c-9f62-d46cf4d45999
71ca10b6-3a28-43ab-bbee-1ce42830aba3	SERVICE	\N	Facebook	Lê Văn linh	quản lý mkt	\N	LVN	#ef4444	qá tuyệt vời	5	t	0	2026-06-02 08:23:33.258	2026-06-04 12:24:12.82	1700c5db-6a48-48bf-9c5c-57037050267d
7151d2de-207c-43b4-95bb-cc60c48a70f6	COURSE	4447b4b5-91b3-4226-8089-638faa948030	\N	uy	\N	\N	AA	#0066ff	aaaa	5	t	0	2026-06-08 08:15:07.8	2026-06-08 08:15:07.8	\N
4ff19537-5d0a-47e1-9d40-db0597c7ab39	SERVICE	\N	Facebook	Chu Qunag DOanh	\N	https://cdn.hethongmmo.vn/testimonial-avatar/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780907659836.png	CQD	#0066ff	quá tuyệt	5	t	0	2026-06-08 08:34:29.087	2026-06-08 08:34:29.087	1700c5db-6a48-48bf-9c5c-57037050267d
811df510-73fa-45b1-bcfa-00c6fb39996a	SERVICE	\N	Facebook	aaa	\N	\N	A	#0066ff	aa	5	t	0	2026-06-20 13:50:20.536	2026-06-20 13:50:20.536	1700c5db-6a48-48bf-9c5c-57037050267d
\.


--
-- Data for Name: ticker_notifications; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."ticker_notifications" ("id", "phone", "amount", "display_order", "is_active", "created_at") FROM stdin;
\.


--
-- Data for Name: ticker_texts; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."ticker_texts" ("id", "text", "display_order", "is_active", "created_at", "updated_at") FROM stdin;
33077ab6-7ed8-4db9-950d-cd10d376fe5c	Chu Quang Doanh |  Tele :@BossMeta789 | Chạy quảng cáo | Thiết Kế Website	0	t	2026-05-30 10:33:54.347	2026-05-30 10:33:54.347
19bae89f-f56a-4911-9d55-de083febd857	Ra  Mắt | Công Bố Website Hệ Thống MMO Toàn  Quốc	0	t	2026-05-30 10:34:45.316	2026-05-30 10:34:45.316
5cff9073-1c34-4ae4-a1a9-67ee33a7b594	Đăng Kí seller bán hàng tại Fanpage để được hướng dẫn và xác nhận chi tiết	0	t	2026-06-03 02:58:25.782	2026-06-03 02:58:25.782
9c356e58-e215-4313-970e-3c26f0d205f5	Tặng 50k khi nạp 1.000.000đ mua TUT và sử dụng dịch vụ	0	t	2026-06-05 18:24:00.634	2026-06-05 18:24:00.634
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."transactions" ("id", "user_id", "order_id", "type", "amount", "description", "balance_before", "balance_after", "reference_code", "created_at", "metadata", "account_number", "transaction_date") FROM stdin;
920aacda-404a-468c-ab00-3eaf4c904dec	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	50000.00	Admin điều chỉnh số dư: +50000	0.00	50000.00	\N	2026-05-25 08:57:52.612	\N	\N	\N
da77594e-8246-465c-93d2-15c344173c59	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	50000.00	0.00	\N	2026-05-25 08:59:12.512	\N	\N	\N
dc06cf2c-28a6-4ea2-9737-e3b353825482	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	100000.00	Trả tiền thanh toán	0.00	100000.00	\N	2026-05-25 09:40:57.58	\N	\N	\N
cbd7162b-c0d8-41ed-909c-f030d2c2094c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7c9cddea-a5d2-4c01-9ad9-74f88917b4c4	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	100000.00	90000.00	\N	2026-05-25 09:41:42.348	\N	\N	\N
1a302ae3-2f86-4c8e-aa3a-8cab80ce9956	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0751a761-71b9-448e-84df-841b9cd772e2	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	90000.00	80000.00	\N	2026-05-25 09:42:00.62	\N	\N	\N
3e4a402d-9abc-4a9c-8ae5-6a6d4badf90a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d6f39bfe-d5f5-4fdd-ab3b-652b4fe85c51	BUY_SELLER_PRODUCT	-50000.00	Mua: adđ	80000.00	30000.00	\N	2026-05-25 09:47:33.154	\N	\N	\N
ae347e1c-18ea-4593-a5e1-a5f8c5482c2c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	26622a2c-2286-44ea-b60d-99a8655c86c2	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	30000.00	20000.00	\N	2026-05-25 11:11:42.739	\N	\N	\N
0053aa8b-95ab-4c2f-8409-610d58acd391	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b55ea042-ef2f-4d7b-b5aa-c84c58b5fabf	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	20000.00	10000.00	\N	2026-05-25 11:11:48.537	\N	\N	\N
b93537d4-a23a-401c-ad38-820d5342a19f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	479458ec-e829-4b69-983a-2880dc884ef5	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10000.00	0.00	\N	2026-05-25 11:11:53.161	\N	\N	\N
406aa134-5472-43d2-8c02-532582f4a5e7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	1000000.00	Nạp tiền user	0.00	1000000.00	\N	2026-05-25 17:57:06.864	\N	\N	\N
0ed4df27-bd35-440a-8d39-dab5c32460d4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	373ca467-4600-4dfa-a72e-76b20d5abb52	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	1000000.00	901000.00	\N	2026-05-25 18:30:36.642	\N	\N	\N
5bf8b7e6-7600-4406-8304-51175f0e5226	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a4293674-897d-4645-8e0a-ca3b6cb5988b	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	901000.00	891000.00	\N	2026-05-25 18:35:07.026	\N	\N	\N
1c670452-b323-4308-857a-8e497059dc5b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	287872ad-aaba-4d2c-941c-dc2b8806d4ce	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	891000.00	881000.00	\N	2026-05-25 18:35:14.807	\N	\N	\N
5a2c6148-68cc-4711-b47f-0a7d047b1e18	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b34e9db7-b2de-41a5-8ecb-a0301ead185f	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	881000.00	831000.00	\N	2026-05-25 18:35:30.671	\N	\N	\N
ea69d32f-929c-4ff5-a77f-32967131cf5a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	f5986697-1fe9-4778-9f32-540d877b9813	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	831000.00	731000.00	\N	2026-05-25 18:47:15.559	\N	\N	\N
3e9c34df-e835-46ee-9ed9-b63ab305425c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	70855275-0c52-41a1-98b8-9f1364f119c5	BUY_TUTTRICK	-100000.00	Mua: addad	731000.00	631000.00	\N	2026-05-26 00:47:53.41	\N	\N	\N
2872c646-3aa8-483e-9d51-2790b15f24f2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	6da836ad-b3b7-45d6-8825-fc6fa2621f3e	BUY_COURSE	-200000.00	Mua: Khóa mmo	631000.00	431000.00	\N	2026-05-26 03:42:02.177	\N	\N	\N
64594b55-910e-4c36-be57-e795af6723cb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	82e4ba46-1263-4f62-96cb-8462ea8f5ae7	BUY_COURSE	-200000.00	Mua: Khóa mmo	431000.00	231000.00	\N	2026-05-26 03:42:09.115	\N	\N	\N
a067e44d-bca6-460d-82d6-2c5c8409c744	3ad147cc-59c4-4623-ba0d-59011dcb6b93	6d45fd7c-1ffe-4f1e-9de0-7db36147c12a	BUY_COURSE	-200000.00	Mua: Khóa mmo	231000.00	31000.00	\N	2026-05-26 03:42:13.088	\N	\N	\N
4902a8fb-69aa-40ba-a5af-1daa0b89b87a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	1000000.00	Admin điều chỉnh số dư: +1000000	31000.00	1031000.00	\N	2026-05-26 03:48:45.477	\N	\N	\N
f06afabb-ff39-42f3-af38-515c55608efe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a182c6df-0a9e-4418-998c-60862168023b	BUY_COURSE	-200000.00	Mua: Khóa mmo	1031000.00	831000.00	\N	2026-05-26 03:49:08.229	\N	\N	\N
f438b0e1-a710-45e5-842e-73d8726be6a8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	963438b7-fb49-4e25-a2bf-c1894bd1a00d	BUY_SERVICE	-200000.00	Mua: Mở Khóa 282	831000.00	631000.00	\N	2026-05-26 03:49:47.057	\N	\N	\N
f32844a3-2a01-43c5-8f88-bb764bd865fe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	91387efa-602f-4240-b366-7d26464b3eb9	BUY_SERVICE	-200000.00	Mua: Mở Khóa 282	631000.00	431000.00	\N	2026-05-26 03:54:11.613	\N	\N	\N
0f3903a1-6f05-4225-860c-83f9d3cfc283	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a4b0ce0c-67b8-43df-8998-42e8634fb403	BUY_SERVICE	-123213.00	Mua: ADADAD	431000.00	307787.00	\N	2026-05-26 03:54:46.601	\N	\N	\N
2b64c3e8-b0ad-4c0c-95f9-f2dc978794f0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1d3d9688-8042-4381-ad04-ffa209c312ec	BUY_SERVICE	-123213.00	Mua: ADADAD	307787.00	184574.00	\N	2026-05-26 03:55:13.355	\N	\N	\N
e114aa0e-d1ea-4006-b0c7-1d4d0bffe233	3ad147cc-59c4-4623-ba0d-59011dcb6b93	63c430ef-bd77-4eb2-ae85-bdc782c9f5d7	BUY_SERVICE	-123213.00	Mua: ADADAD	184574.00	61361.00	\N	2026-05-26 03:59:04.594	\N	\N	\N
0d45e2bf-b4fc-4b7e-a594-1916f4bea5a7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	10000000.00	Admin điều chỉnh số dư: +10000000	61361.00	10061361.00	\N	2026-05-26 04:00:37.22	\N	\N	\N
3d0b58b2-68a1-46f9-89bd-db83874f9380	3ad147cc-59c4-4623-ba0d-59011dcb6b93	821c5caf-09f4-4071-b258-aecc86aa7701	BUY_SERVICE	-123213.00	Mua: ADADAD	10061361.00	9938148.00	\N	2026-05-26 04:00:45.535	\N	\N	\N
662e10be-4684-4cf8-a1ff-d493c51b075a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e9662536-42f5-4b78-86a5-2207088c8a0d	BUY_SERVICE	-3500000.00	Mua: Mở Khóa Icloud (IPHONE 11)	9938148.00	6438148.00	\N	2026-05-26 04:01:19.589	\N	\N	\N
a2dff25e-41ba-4811-af25-c132382647bb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1aaff007-ccf1-453c-93f7-a0e8114e876a	BUY_SERVICE	-3500000.00	Mua: Mở Khóa Icloud (IPHONE 11)	6438148.00	2938148.00	\N	2026-05-26 04:01:22.904	\N	\N	\N
5a8b7d78-b6a3-4aac-9b2d-0051dab479c6	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1816facb-ba21-4fd9-a765-b62ed9c6e934	BUY_SERVICE	-123213.00	Mua: ADADAD	2938148.00	2814935.00	\N	2026-05-26 04:07:05.047	\N	\N	\N
25ebcea9-8e57-4f80-9c2d-9affee56623c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	18af19f0-0422-4858-b7a4-6a6f7a7cc21e	BUY_SERVICE	-123213.00	Mua: ADADAD	2814935.00	2691722.00	\N	2026-05-26 04:11:45.329	\N	\N	\N
7b11e81f-074b-4743-84c6-4ac1b4e4dc08	3ad147cc-59c4-4623-ba0d-59011dcb6b93	238fe35c-1d5d-427f-b77e-cbb7cac2f379	BUY_SERVICE	-123213.00	Mua: ADADAD	2691722.00	2568509.00	\N	2026-05-26 08:00:53.102	\N	\N	\N
5562acfc-b7f5-4023-b658-67a74c89ff0b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4f2127c4-9914-4e8e-8d09-d312f2286323	BUY_MMO_PRODUCT	-360000.00	Mua: Tài khoản tiktok	2568509.00	2208509.00	\N	2026-05-26 08:31:10.734	\N	\N	\N
1bbd1bc3-1cd2-4ffa-acd1-32498b09fb71	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fc287ba1-28b3-4daa-b4eb-f159632298b5	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	2208509.00	2158509.00	\N	2026-05-26 12:12:27.358	\N	\N	\N
0a1208bf-210a-4bd6-84bf-3fda119b2446	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5f16e9e8-ff23-46cc-918b-cdb591870c6b	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	2158509.00	2058509.00	\N	2026-05-26 12:30:56.77	\N	\N	\N
a816e13b-efca-4bbd-bd60-7f438cd67b51	3ad147cc-59c4-4623-ba0d-59011dcb6b93	90604f49-f398-4a4e-8660-e7225e19d6cc	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	2058509.00	1959509.00	\N	2026-05-26 13:47:37.49	\N	\N	\N
cfcba64c-d7d7-4cdd-a58d-a0e2301e320c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4e8f2cc9-e39e-4f21-8042-9919b38cdaff	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	1959509.00	1859509.00	\N	2026-05-26 20:33:33.987	\N	\N	\N
7f82b861-85d3-4891-88d2-db69608c263b	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	\N	ADMIN_ADJUSTMENT	10000000.00	Nạp tiền hệ  thống	0.00	10000000.00	\N	2026-05-27 07:25:02.431	\N	\N	\N
047ddc23-bd19-487c-a9a1-2228e17c66c5	b809ad2f-0580-4c8a-bc4c-7a2389dc6751	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	10000000.00	9950000.00	\N	2026-05-27 07:28:20.415	\N	\N	\N
149215ad-9365-48c3-8daa-19b7092a23a7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	47951cf1-b33a-407e-8853-705086363659	BUY_SELLER_PRODUCT	-79000.00	Mua: GAME LQMB	1859509.00	1780509.00	\N	2026-05-27 07:32:40.089	\N	\N	\N
7cadc9ca-2761-4094-952e-3173ef4d46aa	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	ADMIN_ADJUSTMENT	500000.00	Admin điều chỉnh số dư: +500000	0.00	500000.00	\N	2026-05-29 09:49:42.208	\N	\N	\N
7ee35e64-3940-4f4b-826b-82b219baf0a9	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	500000.00	450000.00	\N	2026-05-29 09:51:05.272	\N	\N	\N
7054d9ea-7900-4d6b-bc06-179cc5d53a0f	f15fef1f-7843-44b0-b983-72068d1647c6	\N	ADMIN_ADJUSTMENT	500000.00	Admin điều chỉnh số dư: +500000	0.00	500000.00	\N	2026-05-29 10:01:48.55	\N	\N	\N
79cfdfb6-d2bc-4945-91e2-b8b57368932f	f15fef1f-7843-44b0-b983-72068d1647c6	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	500000.00	450000.00	\N	2026-05-29 10:02:19.892	\N	\N	\N
f046d572-b145-4d05-a1b2-57698dd0dee9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	WITHDRAWAL_FEE	-220000.00	Rút tiền duyệt — 9 đơn hàng	1780509.00	1560509.00	\N	2026-05-29 19:04:47.143	\N	\N	\N
b1cd41a6-04c2-42f9-8cb4-de53ae9114bd	15bbcf73-c01d-4730-85d7-a1cca3730c83	46c1d333-5e35-4297-867c-a0d04c61bd7b	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	450000.00	440000.00	\N	2026-05-29 19:07:44.311	\N	\N	\N
17a7f042-a7a6-428f-bc62-e211f0dc57d2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_SLOT_PURCHASE	-50000.00	Mua gói 5 slot sản phẩm	1560509.00	1510509.00	\N	2026-05-29 19:53:32.705	\N	\N	\N
2c1ec05a-7833-4e13-82d5-8c70b0390e62	3ad147cc-59c4-4623-ba0d-59011dcb6b93	605a39a1-7e5c-42b8-9aa2-637b96a29b63	BUY_COURSE	-200000.00	Mua: Khóa mmo	1510509.00	1310509.00	\N	2026-05-31 04:01:28.448	\N	\N	\N
777a11b5-2917-40df-86fd-4799b8e06996	15bbcf73-c01d-4730-85d7-a1cca3730c83	da31c0f9-d65e-4f7b-b01e-e2c65ca10d5a	BUY_COURSE	-200000.00	Mua: Khóa mmo	440000.00	240000.00	\N	2026-05-31 04:42:44.339	\N	\N	\N
3bc0d4ff-c54e-49b1-954f-0216c0672864	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	100000.00	Quà tặng hệ thống	1310509.00	1410509.00	\N	2026-05-31 06:51:55.667	\N	\N	\N
0a1687c9-12f1-41b1-bf49-f8c96459f41b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0bc64cf9-58a5-48a5-9275-92d81dd83200	BUY_SELLER_PRODUCT	-79000.00	Mua: Via Facebook Clone 2019	1410509.00	1331509.00	\N	2026-05-31 06:57:53.953	\N	\N	\N
53300cf6-54ad-4066-9877-cd4b480563f1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	bce1fd9f-46f6-43f8-afc6-ac7e1828b47c	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	1331509.00	1321509.00	\N	2026-06-01 03:14:06.863	\N	\N	\N
56f3ca54-249b-493f-b063-67bc79370aec	3ad147cc-59c4-4623-ba0d-59011dcb6b93	df4dd4cb-0be4-4eda-b7d8-930f1cfc3c44	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	1321509.00	1271509.00	\N	2026-06-01 03:14:21.887	\N	\N	\N
1557b3d9-133e-401d-934f-0d9d29495271	3ad147cc-59c4-4623-ba0d-59011dcb6b93	dbc4681f-fab6-40d7-b33d-68fbaf8e0ff6	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	1271509.00	1172509.00	\N	2026-06-01 08:01:03.009	\N	\N	\N
8cef8063-e232-408a-a8c8-be3a59eb65b3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3d06aecb-2b49-47f9-8d5f-94720e48cc5e	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	1172509.00	1073509.00	\N	2026-06-01 08:01:06.551	\N	\N	\N
4b67739e-03e9-4059-b4d5-1d5bae536b23	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0ff04e93-84f1-4ef1-bcab-476e9a5fdbfc	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	1073509.00	973509.00	\N	2026-06-01 08:02:00.722	\N	\N	\N
3354c378-8000-453c-9b01-0e9ebe2d4aa9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1928e3fb-0e2c-46e5-b5b6-01e180c2f569	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	973509.00	874509.00	\N	2026-06-01 08:02:46.856	\N	\N	\N
bbb77ee1-61aa-4ecd-a173-334a20062d2e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	690a9668-7a57-4275-9207-516b4b9faf50	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	874509.00	775509.00	\N	2026-06-01 08:05:00.438	\N	\N	\N
44002aab-c699-4152-902b-436caee50c57	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e20c58c8-08f9-4c46-8032-bc1e9180b357	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	775509.00	676509.00	\N	2026-06-01 08:07:16.045	\N	\N	\N
6e2a3b0f-ae4e-4637-9290-02e00982068f	3ad147cc-59c4-4623-ba0d-59011dcb6b93	1313ab6a-de81-467d-9c1a-ad655e207fac	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	676509.00	577509.00	\N	2026-06-01 08:07:22.965	\N	\N	\N
104a0d62-8d5e-484e-95b4-41c93f26dfa3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d5cbf671-ed55-4752-a74c-1fcd095a305f	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	577509.00	477509.00	\N	2026-06-01 08:07:57.106	\N	\N	\N
506789a9-8ac6-4f8d-9e6f-82bdc0933bbe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	c8253d47-289c-4ac6-b905-0eeb1167ccd6	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	477509.00	378509.00	\N	2026-06-01 08:11:35.116	\N	\N	\N
e5f36393-1966-43ed-82fe-d63cdbf4b889	3ad147cc-59c4-4623-ba0d-59011dcb6b93	94eabca6-5e5d-43aa-bf36-9a5a773fd29f	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	378509.00	278509.00	\N	2026-06-01 08:11:42.288	\N	\N	\N
a7e221bc-e41b-4296-b921-19b4a3a54399	15bbcf73-c01d-4730-85d7-a1cca3730c83	7c9f520c-80d0-4bdb-9995-87287d80af1d	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	240000.00	141000.00	\N	2026-06-01 12:37:28.251	\N	\N	\N
704ae5fe-8f4d-463c-b885-abb8527144d4	15bbcf73-c01d-4730-85d7-a1cca3730c83	d277e481-1f37-44a0-bc9b-32ea59491e30	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	141000.00	41000.00	\N	2026-06-01 12:37:37.255	\N	\N	\N
871d72eb-7c4e-4092-be61-6657475f8abb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	61ed19d4-72cb-40d3-a018-9e963b80952a	BUY_SELLER_PRODUCT	-50000.00	Mua: Tài khoản 250$	278509.00	228509.00	\N	2026-06-02 09:27:59.291	\N	\N	\N
125e2c7b-48fc-489b-82bb-421b6cdffd3a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	3411ffde-9bde-4f74-9cfa-cfdb1a1c9f05	BUY_SELLER_PRODUCT	-79000.00	Mua: Via Facebook Clone 2019	228509.00	149509.00	\N	2026-06-02 09:35:23.989	\N	\N	\N
fb2dbc45-b9c5-4bfc-b19c-9a6854dd8cab	3ad147cc-59c4-4623-ba0d-59011dcb6b93	33ba99d2-4f44-4cf5-a5e5-fbe849a5991d	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	149509.00	50509.00	\N	2026-06-02 09:58:27.355	\N	\N	\N
74fd72ec-c7fc-4aa1-a378-0f7322225f2a	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	ADMIN_ADJUSTMENT	5000000.00	Admin điều chỉnh số dư: +5000000	41000.00	5041000.00	\N	2026-06-02 10:04:43.055	\N	\N	\N
516123d0-1c57-4740-a6ca-4bd3da067431	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	6666666.00	Admin điều chỉnh số dư: +6666666	50509.00	6717175.00	\N	2026-06-02 12:33:50.533	\N	\N	\N
7d63f6fc-0b56-4286-91b8-abd242a440e1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	84643e15-e06f-4f5d-a029-62058737dde8	BUY_TUTTRICK	-99000.00	Mua: TUT UNLOCK 282	6717175.00	6618175.00	\N	2026-06-02 12:34:07.24	\N	\N	\N
a1976802-179e-4df2-ae25-e8f48d341d3d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2ec9ccff-7621-4925-a6df-6a6dc48a961a	BUY_SELLER_PRODUCT	-79000.00	Mua: GAME LQMB	6618175.00	6539175.00	\N	2026-06-02 12:34:19.234	\N	\N	\N
93195eed-9769-4331-9bb3-e7a0aa03c98a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5470e985-5cf3-4179-bfea-2bc3ea6065c8	BUY_COURSE	-1599000.00	Mua: KHÓA HỌC MMO	6539175.00	4940175.00	\N	2026-06-02 12:34:27.564	\N	\N	\N
09a1c960-1a4d-4934-9669-1c02b18ca301	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_SLOT_PURCHASE	-120000.00	Mua gói 10 slot sản phẩm	4940175.00	4820175.00	\N	2026-06-02 19:05:28.853	\N	\N	\N
22190494-c5f0-408d-8a8b-7966a91c62bf	15bbcf73-c01d-4730-85d7-a1cca3730c83	\N	SELLER_REGISTRATION	-50000.00	Phí đăng ký bán hàng	5041000.00	4991000.00	\N	2026-06-02 19:19:02.305	\N	\N	\N
b854e2aa-b4f1-48ca-855d-65154bd21178	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0c24f7af-f8ab-4da7-a05c-549dd7335f2b	BUY_TUTTRICK	-100000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ	4820175.00	4720175.00	\N	2026-06-02 19:29:53.74	\N	\N	\N
90b57e97-f333-4267-bb6d-04b3dfe7214e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	c4b8ea04-b1a9-4fbb-be7c-fdd66640f3d7	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	4720175.00	4626125.00	\N	2026-06-04 07:51:44.861	\N	\N	\N
4c514bbe-4d28-49e7-b646-7a5e4518b76e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	73421bbe-ff55-4fdf-95e1-7bd81f7d2c19	BUY_SERVICE	-3800000.00	Mua: Mở Khóa Icloud (IPHONE 12) (giảm 5%)	4626125.00	826125.00	\N	2026-06-04 07:52:52.99	\N	\N	\N
2797935f-d7a8-4076-9c67-c53109963deb	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0334e4cd-2a86-4638-b18b-2665b94c0143	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	826125.00	726125.00	\N	2026-06-04 11:36:26.389	\N	\N	\N
5538412f-ac4d-4520-ab87-0e0931ff5b13	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5fe5505f-e4bb-4c2f-88f6-b647051a3ec7	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	726125.00	632075.00	\N	2026-06-04 12:26:24.544	\N	\N	\N
95e43885-6e50-4684-85b8-60c5b7442665	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e890d75e-2f4b-4e55-9f85-02ab7fc9a152	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	632075.00	442075.00	\N	2026-06-05 16:15:16.405	\N	\N	\N
56a0029a-ca96-4494-9f5e-918b4d5944fe	3ad147cc-59c4-4623-ba0d-59011dcb6b93	621bcefe-6099-43a5-be50-4f1b123f01ad	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	442075.00	252075.00	\N	2026-06-05 16:16:12.588	\N	\N	\N
fb22496c-e1ac-42d3-b701-d37a8609d8b1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	bd3f526c-1d84-4585-a680-d049ae7f2a58	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	252075.00	62075.00	\N	2026-06-05 16:20:39.616	\N	\N	\N
d0022431-1ad4-40f8-8c79-554a039c6402	3ad147cc-59c4-4623-ba0d-59011dcb6b93	dcba1098-37fc-4c91-8615-abb46720d953	BUY_TUTTRICK	-950.00	Mua: TUT Mở khóa tài khoản Faq (giảm 5%)	62075.00	61125.00	\N	2026-06-05 16:20:46.962	\N	\N	\N
dd78f0fe-a047-4631-9da0-3772fa1f9f72	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7f2ea2ba-ac75-492f-ad9b-ae5869be3230	BUY_TUTTRICK	-950.00	Mua: TUT Mở khóa tài khoản Faq (giảm 5%)	61125.00	60175.00	\N	2026-06-05 16:21:13.954	\N	\N	\N
1b8aa424-85ff-4868-9766-dceb250bf6b9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	ADMIN_ADJUSTMENT	500000000.00	Admin điều chỉnh số dư: +500000000	60175.00	500060175.00	\N	2026-06-05 16:27:13.768	\N	\N	\N
30144bb7-8495-4198-9da9-0b35557c6c80	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d6375185-eef8-49c5-af68-e6e755dd68c9	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	500060175.00	499966125.00	\N	2026-06-05 16:27:30.07	\N	\N	\N
180b6bfb-1c48-421b-8279-53bda2b2c635	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7fabd2c4-3744-4ea6-a692-80889dc10401	BUY_TUTTRICK	-95000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ (giảm 5%)	499966125.00	499871125.00	\N	2026-06-05 16:29:32.326	\N	\N	\N
d24d3120-b40f-46a5-b353-dc0fae55162a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4631775d-d81f-4a2f-b904-72c228aef56b	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499871125.00	499777075.00	\N	2026-06-05 16:32:58.992	\N	\N	\N
5961eebe-6303-4860-82fe-30f4f6da200e	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4967f83b-6fa3-48cb-a5f8-b87467e4c6d2	BUY_TUTTRICK	-95000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ (giảm 5%)	499777075.00	499682075.00	\N	2026-06-05 16:33:26.762	\N	\N	\N
e257c012-10d5-4870-a26b-3234d9133bf0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	9aaac224-b238-4fd6-94fd-d80f3ecb7f4b	BUY_TUTTRICK	-95000.00	Mua: TUT MỞ  KHÓA TIKTOK HẠN CHẾ (giảm 5%)	499682075.00	499587075.00	\N	2026-06-05 16:33:32.174	\N	\N	\N
c6e636c1-8685-46af-834b-85eb8553b32d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	5133bc8c-63b3-4271-93a0-f3e5d0f36ac7	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499587075.00	499493025.00	\N	2026-06-05 16:35:14.733	\N	\N	\N
a6b55203-11c3-4918-80a3-e47dec8f3c3d	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4e3ed6dc-ae65-4915-9a07-1de00512b25a	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499493025.00	499398975.00	\N	2026-06-05 16:37:35.344	\N	\N	\N
4732cd73-d8a6-4d99-91e4-a47874c9ba52	3ad147cc-59c4-4623-ba0d-59011dcb6b93	83b3f010-bbfd-437a-be1a-8237a6f2c578	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499398975.00	499304925.00	\N	2026-06-05 16:37:55.207	\N	\N	\N
ecf3ca8b-467f-4e68-9381-33e3d7b301ec	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cf95309a-dc00-4dd6-87f5-96b86d133752	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499304925.00	499210875.00	\N	2026-06-05 16:39:26.824	\N	\N	\N
3ed17e1a-5af6-45b0-a2db-137db316eee1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cdb6d997-7957-4011-a5b0-582bf512902e	BUY_TUTTRICK	-94050.00	Mua: TUT UNLOCK 282 (giảm 5%)	499210875.00	499116825.00	\N	2026-06-05 16:39:43.809	\N	\N	\N
42f9808e-13be-4ae6-8494-0547611bc9d4	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4f10d6f9-4b1f-40da-b12a-09667907560c	BUY_MMO_PRODUCT	-99000.00	Mua: VIA	499116825.00	499017825.00	\N	2026-06-05 16:43:55.512	\N	\N	\N
ba9c72ae-204b-4aa3-ab23-9a395a2f99ef	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d48f9bf8-ee42-4b79-8740-431b3bb96552	BUY_MMO_PRODUCT	-200000.00	Mua: Game Liên quân	499017825.00	498817825.00	\N	2026-06-05 18:09:10.065	\N	\N	\N
02ef383e-99d9-43d1-96ea-dc689d0c2a39	3ad147cc-59c4-4623-ba0d-59011dcb6b93	44e47a6e-f082-4ce7-adb6-aace5b5b8777	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	498817825.00	498317825.00	\N	2026-06-06 03:59:24.721	\N	\N	\N
303b1c97-d3a7-4ad6-b601-16d2e8c4bc8c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	df05a069-48b7-4762-8680-4e9090095065	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	498317825.00	497817825.00	\N	2026-06-06 03:59:43.114	\N	\N	\N
f3682580-ae54-4ecf-a621-38144732c962	3ad147cc-59c4-4623-ba0d-59011dcb6b93	cae36b9b-3dff-4d84-9bec-20a648d37366	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	497817825.00	497317825.00	\N	2026-06-06 03:59:45.483	\N	\N	\N
609a56b7-67ab-49a0-bf8e-0abe7b91345b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	2db67bdc-13e9-490e-9666-0482129daf4b	BUY_MMO_PRODUCT	-259000.00	Mua: Tài khoản intagram cổ trust 2021	497317825.00	497058825.00	\N	2026-06-06 04:04:07.251	\N	\N	\N
d081ac92-69db-4a76-8116-c3da53e6bda8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e83a2e30-a9cd-4226-bea3-ee6fb26e70db	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	497058825.00	496558825.00	\N	2026-06-06 04:04:20.431	\N	\N	\N
2da14fd9-81f9-4362-956c-e7843bf1ca91	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7333b0d0-9fb1-4de6-a162-6d1b883aa1bc	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	496558825.00	496058825.00	\N	2026-06-06 04:04:28.496	\N	\N	\N
07565c2e-181d-4166-8345-d009a4d613bf	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fb17d681-5f52-4792-9c2e-c5f8c77f12d9	BUY_SERVICE	-570000.00	Mua: Đánh giá GG MAP VIP (giảm 5%)	496058825.00	495488825.00	\N	2026-06-06 09:05:02.601	\N	\N	\N
c6546f2b-5f6c-4d2f-b5c7-74b246d8acc8	3ad147cc-59c4-4623-ba0d-59011dcb6b93	fa22247f-ec6f-435b-b070-57419639397d	BUY_COURSE	-1519050.00	Mua: KHÓA HỌC MMO (giảm 5%)	495488825.00	493969775.00	\N	2026-06-06 09:05:54.879	\N	\N	\N
0d70019c-f27a-4bb7-bc84-f6a7e80c63b3	3ad147cc-59c4-4623-ba0d-59011dcb6b93	e075b268-818d-41dc-9a2a-4f89177f1acf	BUY_SELLER_PRODUCT	-79000.00	Mua: GAME LQMB	493969775.00	493890775.00	\N	2026-06-06 14:21:27.716	\N	\N	\N
d94ac763-1601-4316-90e1-0c47dde8d790	3ad147cc-59c4-4623-ba0d-59011dcb6b93	b02bd798-3e00-4b18-b2ec-5c6f2b99272a	BUY_SERVICE	-11875000.00	Mua: Mở Khóa Icloud (IPHONE 15 PLUS) (giảm 5%)	493890775.00	482015775.00	\N	2026-06-06 14:52:09.71	\N	\N	\N
9bfcb06b-8be5-44cc-8c8d-ade685f48ff7	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0413bfac-9275-4f8b-a143-2e30066e9bc9	BUY_COURSE	-12349050.00	Mua: Khóa Học Chạy Quảng Cáo Tiktok (giảm 5%)	482015775.00	469666725.00	\N	2026-06-06 14:52:38.374	\N	\N	\N
a0d0449a-0f4c-427a-8a38-39c3c16dd107	3ad147cc-59c4-4623-ba0d-59011dcb6b93	9dcf0cbf-ea8f-4e80-8349-95da399773a9	BUY_TUTTRICK	-190000.00	Mua: TUT MỞ KHÓA CHAT META (giảm 5%)	469666725.00	469476725.00	\N	2026-06-06 14:52:51.036	\N	\N	\N
9d343579-26bd-4295-a48e-ce18669846e9	e580851a-de0a-48bc-b0a0-922784cbbd2c	\N	ADMIN_ADJUSTMENT	500000.00	Admin điều chỉnh số dư: +500000	0.00	500000.00	\N	2026-06-06 16:22:46.593	\N	\N	\N
9b0b3a16-f940-4b4f-b662-f9ad8e8f30b2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	\N	SELLER_SLOT_PURCHASE	-50000.00	Mua gói 5 slot sản phẩm	469476725.00	469426725.00	\N	2026-06-07 11:11:32.879	\N	\N	\N
a25c290a-1232-457c-b259-64a039a059e0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a8255c9d-4ba5-44c1-81c4-3389c541eef6	BUY_MMO_PRODUCT	-360000.00	Mua: Tài khoản tiktok	469426725.00	469066725.00	\N	2026-06-07 17:50:10.135	\N	\N	\N
0851e73b-7297-4aba-ba93-73f46c27ff58	3ad147cc-59c4-4623-ba0d-59011dcb6b93	ef41ab50-c8b8-4c41-8887-3f911434987d	BUY_MMO_PRODUCT	-500000.00	Mua: TOOL JOIN BOX TELEGRAM	469066725.00	468566725.00	\N	2026-06-07 17:50:22.908	\N	\N	\N
f960056b-939d-41fb-b5aa-5479c6ca7950	e580851a-de0a-48bc-b0a0-922784cbbd2c	d02e9b91-0db8-4f4a-9194-61a745e3f301	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	500000.00	400000.00	\N	2026-06-20 10:41:32.484	\N	\N	\N
ec48f5b2-3829-4410-8af5-23030ee38210	e580851a-de0a-48bc-b0a0-922784cbbd2c	179f3897-e9ad-4d55-a5c5-629b70c5e387	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	400000.00	300000.00	\N	2026-06-21 13:58:34.397	\N	\N	\N
e43bc4a9-49ed-492d-85c7-2f6027d8e36c	e580851a-de0a-48bc-b0a0-922784cbbd2c	3981505e-ca0b-44b5-b532-5619a863882f	BUY_MMO_PRODUCT	-1111.00	Mua: aaaa	300000.00	298889.00	\N	2026-06-21 13:58:55.28	\N	\N	\N
ca7eb70e-7ad6-4c3e-8895-eb19154ea483	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d02e9b91-0db8-4f4a-9194-61a745e3f301	SELLER_PAYOUT	100000.00	Thanh toán đơn hàng — người mua không xác nhận trong 60 phút	468566725.00	468666725.00	\N	2026-06-21 14:00:43.451	\N	\N	\N
b740abb8-c57e-42ec-9225-713a33802981	3ad147cc-59c4-4623-ba0d-59011dcb6b93	179f3897-e9ad-4d55-a5c5-629b70c5e387	SELLER_PAYOUT	100000.00	Thanh toán đơn hàng — người mua không xác nhận trong 60 phút	468666725.00	468766725.00	\N	2026-06-21 15:40:01.754	\N	\N	\N
edde699d-f369-4a4e-8dd8-40b42d00a22d	e580851a-de0a-48bc-b0a0-922784cbbd2c	08b1bed9-237f-4864-bc01-03975b26b5a4	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	298889.00	288889.00	\N	2026-06-21 16:52:31.427	\N	\N	\N
9d063236-90e2-4831-8a15-4239b19e2975	e580851a-de0a-48bc-b0a0-922784cbbd2c	75af354a-776c-4d81-95d0-17a76a609b93	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	288889.00	278889.00	\N	2026-06-21 16:57:04.095	\N	\N	\N
f1c699f8-256a-4416-b57c-369ceca75dd0	3ad147cc-59c4-4623-ba0d-59011dcb6b93	08b1bed9-237f-4864-bc01-03975b26b5a4	SELLER_PAYOUT	10000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	468766725.00	468776725.00	\N	2026-06-21 17:02:01.747	\N	\N	\N
2f625d47-f980-41a0-b52a-423bd30dfd09	3ad147cc-59c4-4623-ba0d-59011dcb6b93	4402137d-9582-41ad-856d-390d9aeaab70	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	468776725.00	468676725.00	\N	2026-06-21 17:13:12.04	\N	\N	\N
d7e7756b-b2c9-4c68-8835-9fc60e5bc2b6	e580851a-de0a-48bc-b0a0-922784cbbd2c	f43c66f5-1251-4939-a2cf-b8eb64b881e9	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	278889.00	178889.00	\N	2026-06-21 17:13:30.62	\N	\N	\N
3cfe653a-dcb0-4473-8bd2-4bd05adc126f	e580851a-de0a-48bc-b0a0-922784cbbd2c	a953723d-d10d-4601-9536-08f2cfad4cf4	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	178889.00	78889.00	\N	2026-06-21 17:23:54.814	\N	\N	\N
3732ba47-6747-4206-a587-affa199e0946	3ad147cc-59c4-4623-ba0d-59011dcb6b93	a953723d-d10d-4601-9536-08f2cfad4cf4	SELLER_PAYOUT	100000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	468676725.00	468776725.00	\N	2026-06-21 17:25:21.285	\N	\N	\N
67134d9f-2bc1-493c-be08-ba3f1f8a1b88	e580851a-de0a-48bc-b0a0-922784cbbd2c	\N	ADMIN_ADJUSTMENT	10000000.00	Admin điều chỉnh số dư: +10000000	78889.00	10078889.00	\N	2026-06-21 17:26:08.815	\N	\N	\N
86b76d8f-b983-49fb-b7b0-378cf43a9cf5	e580851a-de0a-48bc-b0a0-922784cbbd2c	51183fd6-d7fa-4bf4-b451-13e03c4415a0	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10078889.00	10068889.00	\N	2026-06-21 17:27:53.22	\N	\N	\N
a597ae51-32c4-4d9d-a829-2bab483d63f1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	51183fd6-d7fa-4bf4-b451-13e03c4415a0	SELLER_PAYOUT	10000.00	Thanh toán đơn hàng — người mua xác nhận nhận hàng	468776725.00	468786725.00	\N	2026-06-21 17:28:36.84	\N	\N	\N
fb5f52bb-8ba5-413d-bf2f-ec57ad132ae5	e580851a-de0a-48bc-b0a0-922784cbbd2c	27773527-36ef-4544-9c57-643149bb66ff	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10068889.00	10058889.00	\N	2026-06-21 17:28:58.298	\N	\N	\N
351b9eb8-23df-4316-b3a9-6c0295ec28cd	e580851a-de0a-48bc-b0a0-922784cbbd2c	8b52fa9a-a367-49dc-b5ae-a219a48ffc1a	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10058889.00	10048889.00	\N	2026-06-21 17:30:09.363	\N	\N	\N
f48b157b-43e0-4a9a-aeb1-8851630d13df	e580851a-de0a-48bc-b0a0-922784cbbd2c	9218d70d-bfcf-4a3b-8e76-cbf1596fd87a	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10048889.00	10038889.00	\N	2026-06-21 17:40:11.074	\N	\N	\N
3fc958de-5695-40ac-8fa5-e6c6a449758c	e580851a-de0a-48bc-b0a0-922784cbbd2c	9218d70d-bfcf-4a3b-8e76-cbf1596fd87a	REFUND	10000.00	Hoàn tiền khiếu nại — người mua xác nhận chưa nhận được hàng	10038889.00	10048889.00	\N	2026-06-21 17:51:26.88	\N	\N	\N
91347479-be39-4c3b-be2a-2bfd2b2e362b	e580851a-de0a-48bc-b0a0-922784cbbd2c	00e2ffad-5f6e-4412-8887-795bf68af323	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10048889.00	10038889.00	\N	2026-06-21 17:52:05.214	\N	\N	\N
9bd71cda-2a12-4771-93a4-4c38ffe53410	e580851a-de0a-48bc-b0a0-922784cbbd2c	00e2ffad-5f6e-4412-8887-795bf68af323	REFUND	10000.00	Hoàn tiền khiếu nại — người mua xác nhận chưa nhận được hàng	10038889.00	10048889.00	\N	2026-06-21 17:53:12.877	\N	\N	\N
502d20e2-e338-4ccf-bc1c-cbd7fad53eae	e580851a-de0a-48bc-b0a0-922784cbbd2c	6ab4b9ce-c56b-447f-a4aa-47febc746300	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10048889.00	10038889.00	\N	2026-06-21 17:58:06.304	\N	\N	\N
1c22709d-42e3-4039-89d9-f9698e219aad	e580851a-de0a-48bc-b0a0-922784cbbd2c	6ab4b9ce-c56b-447f-a4aa-47febc746300	REFUND	10000.00	Hoàn tiền khiếu nại — admin phán quyết người mua thắng	10038889.00	10048889.00	\N	2026-06-21 17:59:21.995	\N	\N	\N
5a2fc32c-919d-4488-8242-5c7d2a226220	e580851a-de0a-48bc-b0a0-922784cbbd2c	d6143418-315b-4598-9e82-79c3fca96e9c	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10048889.00	10038889.00	\N	2026-06-21 18:00:09.796	\N	\N	\N
2017ab60-237c-4f2f-967b-9f95e16ea79b	3ad147cc-59c4-4623-ba0d-59011dcb6b93	d6143418-315b-4598-9e82-79c3fca96e9c	SELLER_PAYOUT	10000.00	Thanh toán đơn hàng — người mua xác nhận nhận hàng	468786725.00	468796725.00	\N	2026-06-21 18:00:41.256	\N	\N	\N
36d4bba4-7b0e-4c21-a144-da9ed316d08c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	f43c66f5-1251-4939-a2cf-b8eb64b881e9	SELLER_PAYOUT	100000.00	Thanh toán đơn hàng — người mua xác nhận nhận hàng	468796725.00	468896725.00	\N	2026-06-21 18:01:16.684	\N	\N	\N
d9282797-d9f1-4067-900a-6adebfa54721	e580851a-de0a-48bc-b0a0-922784cbbd2c	dd2dc810-a1da-4121-b4a9-26febee581d7	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10038889.00	10028889.00	\N	2026-06-21 18:03:44.791	\N	\N	\N
d69e9eb6-60da-46ab-818e-383ad2598b68	e580851a-de0a-48bc-b0a0-922784cbbd2c	dd2dc810-a1da-4121-b4a9-26febee581d7	REFUND	10000.00	Hoàn tiền khiếu nại — admin phán quyết người mua thắng	10028889.00	10038889.00	\N	2026-06-21 18:04:18.505	\N	\N	\N
79e3b4be-ae99-4502-a30d-c4cb0a91c865	e580851a-de0a-48bc-b0a0-922784cbbd2c	122f5101-4b1b-4980-8e34-147581f29ab9	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	10038889.00	10028889.00	\N	2026-06-21 18:04:36.225	\N	\N	\N
c3039cfa-6dd6-4b2b-8f4b-d4cfa9d916c1	3ad147cc-59c4-4623-ba0d-59011dcb6b93	122f5101-4b1b-4980-8e34-147581f29ab9	SELLER_PAYOUT	10000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	468896725.00	468906725.00	\N	2026-06-21 18:05:28.613	\N	\N	\N
b34054d5-9c3e-4035-8f29-4054c4d90543	e580851a-de0a-48bc-b0a0-922784cbbd2c	9b97b3a3-e7af-44e0-a574-8a02cfa712dd	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	10028889.00	9928889.00	\N	2026-06-21 18:12:58.855	\N	\N	\N
e1b4a5c7-9d6d-4a7b-abd3-db8e1c266c6c	3ad147cc-59c4-4623-ba0d-59011dcb6b93	9b97b3a3-e7af-44e0-a574-8a02cfa712dd	SELLER_PAYOUT	100000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	468906725.00	469006725.00	\N	2026-06-21 18:24:33.597	\N	\N	\N
d11919b0-b312-4467-99df-3c8f7eb0a25a	e580851a-de0a-48bc-b0a0-922784cbbd2c	7450f2da-0d9e-4a98-9e84-63811095c148	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	9928889.00	9828889.00	\N	2026-06-21 18:25:08.304	\N	\N	\N
7727fe72-81ad-4ca1-a08c-0f47f6e59440	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7450f2da-0d9e-4a98-9e84-63811095c148	SELLER_PAYOUT	100000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	469006725.00	469106725.00	\N	2026-06-21 18:37:43.469	\N	\N	\N
3c7f9936-aa05-4af9-ac5d-3056988d0d1a	e580851a-de0a-48bc-b0a0-922784cbbd2c	0594a66c-6226-49e4-a615-c57f5c11b93f	BUY_SELLER_PRODUCT	-100000.00	Mua: BM FACEBOOK	9828889.00	9728889.00	\N	2026-06-21 18:37:57.026	\N	\N	\N
472d633a-b804-457a-9a88-27f6fd8fef6a	3ad147cc-59c4-4623-ba0d-59011dcb6b93	0594a66c-6226-49e4-a615-c57f5c11b93f	SELLER_PAYOUT	100000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	469106725.00	469206725.00	\N	2026-06-21 19:03:33.172	\N	\N	\N
e4600645-a991-4a27-a819-ce5dd5576566	e580851a-de0a-48bc-b0a0-922784cbbd2c	f446c556-1e25-44c6-9a80-08a7790c678e	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	9728889.00	9718889.00	\N	2026-06-21 19:04:24.042	\N	\N	\N
84508e21-79e2-4e3b-bcd0-fc7c5dcc9c05	e580851a-de0a-48bc-b0a0-922784cbbd2c	c7793e2e-97d8-43b1-b731-2896dce51db1	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	9718889.00	9708889.00	\N	2026-06-21 19:20:10.619	\N	\N	\N
429e7180-c600-4d19-b7d2-50ab75a170b9	3ad147cc-59c4-4623-ba0d-59011dcb6b93	c7793e2e-97d8-43b1-b731-2896dce51db1	SELLER_PAYOUT	10000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	469206725.00	469216725.00	\N	2026-06-21 19:23:23.135	\N	\N	\N
9b0b1972-0b7c-4bf9-b064-6d1fb1448889	3ad147cc-59c4-4623-ba0d-59011dcb6b93	f446c556-1e25-44c6-9a80-08a7790c678e	SELLER_PAYOUT	10000.00	Thanh toán đơn hàng — admin xác nhận hợp lệ	469216725.00	469226725.00	\N	2026-06-21 19:35:41.097	\N	\N	\N
9e7b3d5f-d62b-48b2-b067-d6da93d441a2	3ad147cc-59c4-4623-ba0d-59011dcb6b93	7a945572-0ae0-4a5d-a252-0d713ea49e76	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	469226725.00	469216725.00	\N	2026-06-21 19:36:22.511	\N	\N	\N
4102e0b5-5b58-4a4a-b996-45a9845612af	e580851a-de0a-48bc-b0a0-922784cbbd2c	ec601ff4-98cc-4b1d-b912-4d09377741fd	BUY_SELLER_PRODUCT	-10000.00	Mua: Tài khoản quảng cáo	9708889.00	9698889.00	\N	2026-06-21 19:36:37.581	\N	\N	\N
e12f0417-38d8-4675-bb24-d111f13d5e60	e580851a-de0a-48bc-b0a0-922784cbbd2c	ec601ff4-98cc-4b1d-b912-4d09377741fd	REFUND	10000.00	Hoàn tiền khiếu nại — admin phán quyết người mua thắng	9698889.00	9708889.00	\N	2026-06-21 19:37:49.941	\N	\N	\N
ded42630-435d-4862-ab7a-ed9eaa19eed4	e580851a-de0a-48bc-b0a0-922784cbbd2c	3992667d-d309-4755-9211-38f5242db551	BUY_SELLER_PRODUCT	-5000.00	Mua: Vip	9708889.00	9703889.00	\N	2026-06-22 05:50:47.189	\N	\N	\N
f2f28b83-7e39-4655-850e-093280c18759	e580851a-de0a-48bc-b0a0-922784cbbd2c	\N	SELLER_REGISTRATION	-10000.00	Phí đăng ký bán hàng	9703889.00	9693889.00	\N	2026-06-22 07:21:33.116	\N	\N	\N
88114e6c-8f73-4da9-806d-856096426787	9c652e2d-15d7-42d8-9b96-1179145dd096	\N	ADMIN_ADJUSTMENT	5000000.00	Admin điều chỉnh số dư: +5000000	0.00	5000000.00	\N	2026-06-22 07:50:49.917	\N	\N	\N
b89a8cc7-4d54-4c19-8831-cf45f4d0a1f2	9c652e2d-15d7-42d8-9b96-1179145dd096	\N	SELLER_REGISTRATION	-10000.00	Phí đăng ký bán hàng	5000000.00	4990000.00	\N	2026-06-22 07:51:46.919	\N	\N	\N
fbeb41da-d83c-4b0c-8178-65788603fe55	3ad147cc-59c4-4623-ba0d-59011dcb6b93	75af354a-776c-4d81-95d0-17a76a609b93	SELLER_PAYOUT	10000.00	Thanh toán đơn hàng — người mua không xác nhận trong 60 phút	469216725.00	469226725.00	\N	2026-06-22 11:45:51.735	\N	\N	\N
f5971558-3db4-4bac-bd55-c72a597bffb8	e580851a-de0a-48bc-b0a0-922784cbbd2c	\N	DEPOSIT_MANUAL	10000000.00	Admin nạp thủ công: Cộng	9693889.00	19693889.00	MANUAL-15BBCF-1782153021824	2026-06-22 18:30:21.86	{"note": "Cộng", "adminId": "15bbcf73-c01d-4730-85d7-a1cca3730c83"}	\N	\N
\.


--
-- Data for Name: tut_trick_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."tut_trick_categories" ("id", "name", "created_at", "updated_at", "icon_url", "display_order") FROM stdin;
1113abc4-9877-487d-82b4-588cf58f029b	Facebook	2026-06-02 13:40:25.415	2026-06-06 15:20:19.841	https://svgl.app/library/facebook-icon.svg	1
39588a82-d0c1-491a-ba88-652868b25fef	TikTok	2026-06-06 15:24:21.579	2026-06-06 15:24:21.579	https://svgl.app/library/tiktok-icon-light.svg	2
\.


--
-- Data for Name: tut_tricks; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."tut_tricks" ("id", "slug", "name", "thumbnail", "platform", "category", "price", "description", "content_url_enc", "docs", "seo_title", "seo_description", "is_active", "is_featured", "total_orders", "total_views", "success_rate", "rating", "display_order", "published_date", "created_at", "updated_at", "deleted_at", "processing_time", "warranty_policy", "requires_account_type", "requires_cccd", "tier") FROM stdin;
f978b336-1afc-4d93-ae65-0417bce2040d	addad	TUT MỞ  KHÓA TIKTOK HẠN CHẾ	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779632633906.png	TIKTOK	Facebook	100000.00	TUT ĐẲNG CẤP THẾ GIỚI	\\x69bcd44587bad931f3fc6838771f92035e50fc1921741ef9918e5fd464	\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Cho Khách Hàng Mới \n#Giá Gói 899k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 5.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n\n🎁Combo Xây Dựng Trang Fanpage Bán Hàng Gói 2\n#Giá Gói 2.499k\n- Tạo và SEO Fanpage Chuẩn\nXây Dựng Hình Ảnh và Thông Tin Fanpage\nCó 10.000 Người Theo Dõi và Like Trang Fanpage\nTư Vấn Đăng Bài và Cách Sử Dụng Trang Fanpage\n-> Hỗ trợ content bán hàng chi tiết trên Facebook\n\n	Mở khóa hạn chế	2026	t	f	242	0	100	5	1	2026-05-24	2026-05-24 14:24:12.335	2026-06-05 16:33:18.275	\N	giao ngay	3 ngày	f	f	Có phí
165f87a9-d530-48aa-beb9-c94995d60aae	tut-mo-khoa-chat-meta	TUT MỞ KHÓA CHAT META	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780676088566.png	OTHER	Facebook	200000.00	\N	\N	TUT VIP	\N	\N	t	f	213	0	80	5	3	2026-06-05	2026-06-05 16:14:51.046	2026-06-05 16:14:51.046	\N	GIAO NGAY	1 NGÀY	f	f	Có phí
a5e5093b-abdc-4ec6-b888-72085054523a	tut-unlock-282	TUT UNLOCK 282	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1779798518102.png	FACEBOOK	Facebook	99000.00	TUT NÀY SỞ HỮU MỞ KHÓA ĐƯỢC MỌI DẠNG 282 TREO 282 CHƯA ẤN KHÁNG NGHỊ	\N	FANPAGE KIẾM TIỀN VIP : #GIÁ 10.500k\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : BAO BACK SỬ DỤNG -> Bàn Giao FULL QUYỀN Fanpage\n- Hỗ Trợ Xử Lý Khi Vi Phạm Trong 1 Tháng Miễn Phí\nFANPAGE KIẾM TIỀN VIP : #GIÁ 5tr500\nCung Cấp : 1 Trang Fanpage Sạch + Không Dính Vi Phạm\nHỗ Trợ : Thay Đổi Tên + Thông Tin\nĐược CTY DJ MEDIA Hỗ Trợ RÚT TIỀN Trực TIếp Với FACEBOOK : Quy Trình Cài + Thanh Toán Tiền Về Ví PAYPAN\n Chính Sách Bảo Hành : Không Bảo Hành Fanpage -> Bang Giao Full Quyền Quản Trị 	TUT MỚI NHẤT	Tut này chỉ sử dụng cho mở khóa	t	f	523	0	100	5	1	2026-05-26	2026-05-26 12:29:58.967	2026-06-05 16:43:28.923	\N	Giao ngay	Không bảo hành	f	f	Có phí
15ef906b-fe34-43a9-83a8-b1a542251db3	tut-change-pass-facebook-khong-dinh-sdt-va-gmail	TUT Change Pass Facebook Không Dính SDT và Gmail	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780317253851.png	FACEBOOK	Facebook	600000.00	TUT SIÊU VIP DÀNH CHO AE MMO	\\x3909e4d541631a52793943397a62ca99b20e45caaa1fd2d1edca07ea4d2dde6962ece1a5dd48ddc3b614362f80b6f8f7ce168db0bc	IB ZALO 0393118789 ( MK : TUT VIP CHANGE PASS FACEBOOK ) 	\N	\N	t	f	123	0	100	5	3	2026-06-01	2026-06-01 12:35:04.36	2026-06-02 14:03:29.081	\N	Giao ngay	Bảo hàng 3 Ngày	f	f	Có phí
2729244b-ae96-4a23-9703-180bb075df0a	tut-mo-khoa-tai-khoan-faq	TUT Mở khóa tài khoản Faq	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/tut-trick-thumbnail/e580851a-de0a-48bc-b0a0-922784cbbd2c/1780762576912.png	OTHER	Facebook	1000.00	TUT VIP	\\xb3b22b4de6b2dbc6363507e211db291b3522ca76518772b0368d5803930bbfede18819e0135868e3bb31f8f8e354ef2fbe436efc6c2869204f20a661b8be5fd622138d0a84ef5c5cc00b42458e3d42e06bdd515dc6ac34cb4a34baca4c08e08ebe391fdc783459049f0996	TUT ĐÂY	\N	\N	t	f	234	0	100	5	3	2026-06-02	2026-06-02 13:56:54.167	2026-06-06 16:16:22.571	\N	1 ngày	Không bảo hành	f	f	Miễn phí
a0db9bb3-dc95-443f-acd6-2160c90576de	tut-1	TUT 1	\N	OTHER	Facebook	11111.00	\N	\N	\N	\N	\N	f	f	0	0	100	0	0	\N	2026-06-20 18:06:02.191	2026-06-20 18:42:06.214	2026-06-20 18:42:06.199	\N	\N	f	f	Miễn phí
\.


--
-- Data for Name: unmatched_transfers; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."unmatched_transfers" ("id", "content", "amount", "reference_code", "raw_payload", "candidates_tried", "status", "resolved_by_user_id", "resolved_at", "created_at") FROM stdin;
\.


--
-- Data for Name: user_sub_categories; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."user_sub_categories" ("user_id", "sub_category_id") FROM stdin;
e580851a-de0a-48bc-b0a0-922784cbbd2c	cea42dc3-a88c-4c35-a620-d157b070d2ac
e580851a-de0a-48bc-b0a0-922784cbbd2c	de47a69f-91cb-4f96-8134-00bcce41fa9a
9c652e2d-15d7-42d8-9b96-1179145dd096	ef467d06-091c-4a07-a31c-084bc59342c9
9c652e2d-15d7-42d8-9b96-1179145dd096	d1b73c22-47c7-4770-9402-570673c9379e
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY "public"."users" ("id", "email", "email_verified_at", "password_hash", "full_name", "phone", "role", "status", "balance", "total_deposited", "total_spent", "seller_status", "seller_category", "max_seller_products", "bank_name_enc", "bank_account_number_enc", "bank_account_holder_enc", "cccd_image_url", "portrait_image_url", "two_factor_secret_enc", "two_factor_enabled", "last_login_at", "last_login_ip", "failed_login_count", "locked_until", "uid_prefix", "created_at", "updated_at", "deleted_at", "facebook_url", "telegram_username", "shop_locked", "seller_tier", "discount_percent", "avatar_url") FROM stdin;
b490690a-17bd-4b8b-8e8a-88f060bbbd9c	 lasvergasblackmeta@gmail.com	2026-06-02 19:22:43.3	$argon2id$v=19$m=65536,t=3,p=4$p1FSXVhPb/0AQKv+QZki8Q$fR1PT75vQ3Pd1zBJsiJqfFAdAFNFZlKhrIhEM85p7BQ	Chu Quang doanh	\N	USER	ACTIVE	0.00	0.00	0.00	NONE	\N	3	\N	\N	\N	\N	\N	\N	f	\N	\N	0	\N	b490690a	2026-06-03 02:22:43.278	2026-06-02 19:25:45.265	\N	\N	\N	f	STANDARD	0	\N
e580851a-de0a-48bc-b0a0-922784cbbd2c	chuquangdoanh2004@gmail.com	2026-06-02 19:24:16.113	$argon2id$v=19$m=65536,t=3,p=4$zfE8TgVAEBxQbSCmyo7NRg$WxeYTVnkhNBLJpgkwip6H0nDNHVFCg9RweLp1hl8sQY	ADMIN CHU QUANG DOANH	0922999910	SELLER	ACTIVE	19693889.00	10000000.00	846111.00	APPROVED	Instagram	3	\\xb1f49accda2c3b06d3e9e5da537a711cf19c45e741c2079504625404d0b7255ee53f3b0f9db6a3	\\xea75e7ff5d52a44733de48d4be54db17f43a1ce58bf87e6c71d5b123e4153ab2	\\x029017e0dbee2dfb24c6c24659d45668689f9ff72481812e40f98fc4d7	/api/admin/secure-image?key=cccd%2Fe580851a-de0a-48bc-b0a0-922784cbbd2c%2F1782112892127.jpg	/api/admin/secure-image?key=portrait%2Fe580851a-de0a-48bc-b0a0-922784cbbd2c%2F1782112892127.jpg	\N	f	2026-06-20 10:50:04.631	::1	0	\N	e580851a	2026-06-03 02:24:16.048	2026-06-22 18:30:21.831	\N	a	a	f	STANDARD	0	\N
15bbcf73-c01d-4730-85d7-a1cca3730c83	chudoanhofficial@gmail.com	2026-05-23 16:16:24.356	$argon2id$v=19$m=65536,t=3,p=4$gx7ysfeIt17rztFzVgF1jw$5mmRNT7u9tTeS+AveEUlA9oe5cZ8q49bsrsv0Vag3rQ	Chu Quang Doanh	0393118789	ADMIN	ACTIVE	4991000.00	0.00	409000.00	REJECTED	\N	3	\\x8fbe08cd3787c05b4462da78ae78089810bf7e06c06561d20870b2b64b18e293a9180b22a49f72	\\x53513ee69b2c5f8a0ffdd75978bed22c908335b0ea3f8d51ed0bf2aab9	\\xaba7e6cea3c90476df0384870ffc62c008bc716c527878eca85529412a	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780427940659.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/15bbcf73-c01d-4730-85d7-a1cca3730c83/1780427940670.jpg	\N	f	2026-06-20 10:23:39.433	::1	0	\N	15bbcf73	2026-05-23 23:16:24.334	2026-06-20 10:23:39.443	\N	https://www.facebook.com/Chu.Quang.Doanh.Media88/	BossMeta789	f	STANDARD	0	\N
55d1694a-443e-4f08-8875-8dadff9cbf62	nhanvien@gmail.com	2026-06-02 19:26:23.855	$argon2id$v=19$m=65536,t=3,p=4$Jh5x4kA8XQ4cRisv3i++GQ$qmpcxC9QxIx1LiqJHPaevNzNM8+YB4yrawP3dzT3734	chu quang doanh	0929990999	STAFF	ACTIVE	0.00	0.00	0.00	NONE	\N	3	\N	\N	\N	\N	\N	\N	f	2026-06-02 19:27:19.254	::1	2	\N	55d1694a	2026-06-02 19:26:23.857	2026-06-20 10:48:20.582	\N	\N	\N	f	STANDARD	0	\N
b809ad2f-0580-4c8a-bc4c-7a2389dc6751	doanh123@gmail.com	2026-05-27 07:24:16.268	$argon2id$v=19$m=65536,t=3,p=4$wjo2zUoQjuN3yXcqcQhU0g$kamElZK6MYoF45atgWiGsdkv7G+zpu96Hd4tjnbIH8Q	Chuquangdoanh	0989888999	SELLER	ACTIVE	9950000.00	0.00	0.00	APPROVED	Game	3	\\xc8af03c63647c987a6444f6b1be61019a4b1fbdd0c0f278a3c799d90a5d81adb316e18	\\x1a1cc71c2ba6dab5d3837f56911e12553dafac1a1e17ffa1944b719eb63d0522df5e611250	\\x040aaeefa2948bfa3bffc6858936333b49329aec44baac2d98fd0e4b5eeba59f	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/b809ad2f-0580-4c8a-bc4c-7a2389dc6751/1779866898388.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/b809ad2f-0580-4c8a-bc4c-7a2389dc6751/1779866898410.jpg	\N	f	2026-05-27 07:24:31.44	::1	0	\N	b809ad2f	2026-05-27 07:24:16.27	2026-05-27 07:31:01.861	\N	\N	\N	f	STANDARD	0	\N
f15fef1f-7843-44b0-b983-72068d1647c6	a@gmail.com	2026-05-25 11:20:10.604	$argon2id$v=19$m=65536,t=3,p=4$LdpXCifpY0oKLUYXuIbJaw$WbX77aa3fSR652k0IypvWp+YgRnP7AVkJef29RPFLfQ	Chu quang doanh	\N	SELLER	ACTIVE	450000.00	0.00	0.00	APPROVED	Facebook: a	3	\\xe94cc48c290f3bdfa09877ad4560b7010056b9db1286cf170cc13c66a94915aedee5	\\x794e365c0e9a4d9e85a8edf8aa03c16ee17fb660b912e7478c5396d418f4	\\xfbb82149c9d2208cfb8eb3e64a0b41014abb6ed12a25c0871fb46e2fa6	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/f15fef1f-7843-44b0-b983-72068d1647c6/1780048936052.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/f15fef1f-7843-44b0-b983-72068d1647c6/1780048936089.png	\N	f	2026-05-28 02:22:23.333	::1	0	\N	f15fef1f	2026-05-25 11:20:10.606	2026-06-04 12:15:31.347	\N	\N	\N	f	STANDARD	0	\N
9c652e2d-15d7-42d8-9b96-1179145dd096	khachhangtrungtamfb@gmail.com	2026-06-22 07:50:14.443	$argon2id$v=19$m=65536,t=3,p=4$Y7epKi/Vpzc49Y8rZGKeqw$LEteda1SW5JY9vUlxx/eH+l81aHSmtlG6EmjqHoAUlE	Tâm FB Trung	0999222888	SELLER	ACTIVE	4990000.00	0.00	0.00	APPROVED	Facebook	3	\\x88a125a84cfcdf14fd931ddf664ac20ac7740efcef6688501db06822275e8bd5ab29	\\x50dd4e4445fda2873435c68ebceb8da1626bdbfbee414f01ac2431d33b07c7	\\x08d368aec414cf27892c80bcca1ad6a9f56f9279b37bf3e5ac7a32752e98	/api/admin/secure-image?key=cccd%2F9c652e2d-15d7-42d8-9b96-1179145dd096%2F1782114706400.jpg	/api/admin/secure-image?key=portrait%2F9c652e2d-15d7-42d8-9b96-1179145dd096%2F1782114706401.jpg	\N	f	2026-06-22 07:50:23.404	::1	0	\N	9c652e2d	2026-06-22 07:50:14.446	2026-06-22 07:51:57.727	\N	a	a	f	STANDARD	0	\N
3ad147cc-59c4-4623-ba0d-59011dcb6b93	chudoanh107@gmail.com	2026-05-25 08:13:19.365	$argon2id$v=19$m=65536,t=3,p=4$ijXPCOyCiOK8VVYp2BDNtA$z2cNBpjvOWVrUpZjU9EOJk1yosUDJ35K2KLAreiIW1A	Chu Quang Doanh	0929990999	SELLER	ACTIVE	469226725.00	0.00	49969941.00	APPROVED	Facebook	5	\\xf94550d4f934743f4d0846b64015fe08b2ce621215e3abbce4b00d65490d9469b3964a	\\x746518ec39d185a9ed95c2326e015d19827de57c7fc24e262df58465309ad8693672069b5852	\\x0b10ce2a5c0fd166c6368a96a9ceeff3d918230ddea141a55c6560f9283ec62b4e04ffa6	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/cccd/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779699549835.jpg	https://pub-c326d5e2e2684ee680453a1069ae2795.r2.dev/portrait/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1779699549807.jpg	\N	f	2026-05-29 19:03:40.67	::1	0	\N	3ad147cc	2026-05-25 08:13:19.367	2026-06-22 11:45:51.725	\N	https://web.facebook.com/Chu.Quang.Doanh.Media88/	BossMeta789	f	VIP	5	https://cdn.hethongmmo.vn/avatar/3ad147cc-59c4-4623-ba0d-59011dcb6b93/1780908006606.png
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."_prisma_migrations"
    ADD CONSTRAINT "_prisma_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: ads_registrations ads_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."ads_registrations"
    ADD CONSTRAINT "ads_registrations_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."audit_logs"
    ADD CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id");


--
-- Name: bank_change_requests bank_change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."bank_change_requests"
    ADD CONSTRAINT "bank_change_requests_pkey" PRIMARY KEY ("id");


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_pkey" PRIMARY KEY ("id");


--
-- Name: chat_participants chat_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_participants"
    ADD CONSTRAINT "chat_participants_pkey" PRIMARY KEY ("id");


--
-- Name: chat_rooms chat_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_rooms"
    ADD CONSTRAINT "chat_rooms_pkey" PRIMARY KEY ("id");


--
-- Name: complaints complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."complaints"
    ADD CONSTRAINT "complaints_pkey" PRIMARY KEY ("id");


--
-- Name: course_categories course_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_categories"
    ADD CONSTRAINT "course_categories_pkey" PRIMARY KEY ("id");


--
-- Name: course_faq_categories course_faq_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faq_categories"
    ADD CONSTRAINT "course_faq_categories_pkey" PRIMARY KEY ("id");


--
-- Name: course_faqs course_faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faqs"
    ADD CONSTRAINT "course_faqs_pkey" PRIMARY KEY ("id");


--
-- Name: course_support_items course_support_items_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_support_items"
    ADD CONSTRAINT "course_support_items_pkey" PRIMARY KEY ("id");


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."courses"
    ADD CONSTRAINT "courses_pkey" PRIMARY KEY ("id");


--
-- Name: fanpage_registrations fanpage_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."fanpage_registrations"
    ADD CONSTRAINT "fanpage_registrations_pkey" PRIMARY KEY ("id");


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."login_attempts"
    ADD CONSTRAINT "login_attempts_pkey" PRIMARY KEY ("id");


--
-- Name: mmo_product_items mmo_product_items_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."mmo_product_items"
    ADD CONSTRAINT "mmo_product_items_pkey" PRIMARY KEY ("id");


--
-- Name: mmo_products mmo_products_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."mmo_products"
    ADD CONSTRAINT "mmo_products_pkey" PRIMARY KEY ("id");


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."modules"
    ADD CONSTRAINT "modules_pkey" PRIMARY KEY ("id");


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_pkey" PRIMARY KEY ("id");


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."otp_codes"
    ADD CONSTRAINT "otp_codes_pkey" PRIMARY KEY ("id");


--
-- Name: page_permissions page_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."page_permissions"
    ADD CONSTRAINT "page_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: pending_registrations pending_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."pending_registrations"
    ADD CONSTRAINT "pending_registrations_pkey" PRIMARY KEY ("id");


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."permissions"
    ADD CONSTRAINT "permissions_pkey" PRIMARY KEY ("id");


--
-- Name: public_page_configs public_page_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."public_page_configs"
    ADD CONSTRAINT "public_page_configs_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: resource_categories resource_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."resource_categories"
    ADD CONSTRAINT "resource_categories_pkey" PRIMARY KEY ("id");


--
-- Name: reviews reviews_order_id_key; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_order_id_key" UNIQUE ("order_id");


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_pkey" PRIMARY KEY ("id");


--
-- Name: seller_product_stock seller_product_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_product_stock"
    ADD CONSTRAINT "seller_product_stock_pkey" PRIMARY KEY ("id");


--
-- Name: seller_products seller_products_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_products"
    ADD CONSTRAINT "seller_products_pkey" PRIMARY KEY ("id");


--
-- Name: seller_requests seller_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_requests"
    ADD CONSTRAINT "seller_requests_pkey" PRIMARY KEY ("id");


--
-- Name: seller_sub_categories seller_sub_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_sub_categories"
    ADD CONSTRAINT "seller_sub_categories_pkey" PRIMARY KEY ("id");


--
-- Name: seller_tier_definitions seller_tier_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_tier_definitions"
    ADD CONSTRAINT "seller_tier_definitions_pkey" PRIMARY KEY ("id");


--
-- Name: seller_withdrawals seller_withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_withdrawals"
    ADD CONSTRAINT "seller_withdrawals_pkey" PRIMARY KEY ("id");


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."service_categories"
    ADD CONSTRAINT "service_categories_pkey" PRIMARY KEY ("id");


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."services"
    ADD CONSTRAINT "services_pkey" PRIMARY KEY ("id");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: site_content site_content_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."site_content"
    ADD CONSTRAINT "site_content_pkey" PRIMARY KEY ("id");


--
-- Name: staff_permissions staff_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."staff_permissions"
    ADD CONSTRAINT "staff_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: staff_permissions staff_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."staff_permissions"
    ADD CONSTRAINT "staff_permissions_user_id_permission_id_key" UNIQUE ("user_id", "permission_id");


--
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."system_config"
    ADD CONSTRAINT "system_config_pkey" PRIMARY KEY ("key");


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."testimonials"
    ADD CONSTRAINT "testimonials_pkey" PRIMARY KEY ("id");


--
-- Name: ticker_notifications ticker_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."ticker_notifications"
    ADD CONSTRAINT "ticker_notifications_pkey" PRIMARY KEY ("id");


--
-- Name: ticker_texts ticker_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."ticker_texts"
    ADD CONSTRAINT "ticker_texts_pkey" PRIMARY KEY ("id");


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_pkey" PRIMARY KEY ("id");


--
-- Name: tut_trick_categories tut_trick_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."tut_trick_categories"
    ADD CONSTRAINT "tut_trick_categories_pkey" PRIMARY KEY ("id");


--
-- Name: tut_tricks tut_tricks_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."tut_tricks"
    ADD CONSTRAINT "tut_tricks_pkey" PRIMARY KEY ("id");


--
-- Name: unmatched_transfers unmatched_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."unmatched_transfers"
    ADD CONSTRAINT "unmatched_transfers_pkey" PRIMARY KEY ("id");


--
-- Name: user_sub_categories user_sub_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."user_sub_categories"
    ADD CONSTRAINT "user_sub_categories_pkey" PRIMARY KEY ("user_id", "sub_category_id");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: ads_registrations_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ads_registrations_created_at_idx" ON "public"."ads_registrations" USING "btree" ("created_at");


--
-- Name: ads_registrations_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ads_registrations_status_idx" ON "public"."ads_registrations" USING "btree" ("status");


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "audit_logs_action_idx" ON "public"."audit_logs" USING "btree" ("action");


--
-- Name: audit_logs_actor_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "audit_logs_actor_id_created_at_idx" ON "public"."audit_logs" USING "btree" ("actor_id", "created_at");


--
-- Name: audit_logs_target_type_target_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "audit_logs_target_type_target_id_idx" ON "public"."audit_logs" USING "btree" ("target_type", "target_id");


--
-- Name: bank_change_requests_seller_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "bank_change_requests_seller_id_status_idx" ON "public"."bank_change_requests" USING "btree" ("seller_id", "status");


--
-- Name: bank_change_requests_status_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "bank_change_requests_status_created_at_idx" ON "public"."bank_change_requests" USING "btree" ("status", "created_at");


--
-- Name: chat_messages_room_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "chat_messages_room_id_created_at_idx" ON "public"."chat_messages" USING "btree" ("room_id", "created_at");


--
-- Name: chat_participants_room_id_user_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "chat_participants_room_id_user_id_key" ON "public"."chat_participants" USING "btree" ("room_id", "user_id");


--
-- Name: chat_participants_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "chat_participants_user_id_idx" ON "public"."chat_participants" USING "btree" ("user_id");


--
-- Name: chat_rooms_complaint_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "chat_rooms_complaint_id_key" ON "public"."chat_rooms" USING "btree" ("complaint_id");


--
-- Name: complaints_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "complaints_status_idx" ON "public"."complaints" USING "btree" ("status");


--
-- Name: complaints_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "complaints_user_id_idx" ON "public"."complaints" USING "btree" ("user_id");


--
-- Name: course_categories_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_categories_display_order_idx" ON "public"."course_categories" USING "btree" ("display_order");


--
-- Name: course_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "course_categories_name_key" ON "public"."course_categories" USING "btree" ("name");


--
-- Name: course_faq_categories_course_id_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_faq_categories_course_id_display_order_idx" ON "public"."course_faq_categories" USING "btree" ("course_id", "display_order");


--
-- Name: course_faqs_course_id_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_faqs_course_id_display_order_idx" ON "public"."course_faqs" USING "btree" ("course_id", "display_order");


--
-- Name: course_support_items_course_id_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "course_support_items_course_id_display_order_idx" ON "public"."course_support_items" USING "btree" ("course_id", "display_order");


--
-- Name: courses_category_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "courses_category_idx" ON "public"."courses" USING "btree" ("category");


--
-- Name: courses_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "courses_is_active_display_order_idx" ON "public"."courses" USING "btree" ("is_active", "display_order");


--
-- Name: courses_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "courses_slug_idx" ON "public"."courses" USING "btree" ("slug");


--
-- Name: courses_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "courses_slug_key" ON "public"."courses" USING "btree" ("slug");


--
-- Name: fanpage_registrations_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "fanpage_registrations_created_at_idx" ON "public"."fanpage_registrations" USING "btree" ("created_at");


--
-- Name: fanpage_registrations_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "fanpage_registrations_status_idx" ON "public"."fanpage_registrations" USING "btree" ("status");


--
-- Name: login_attempts_email_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "login_attempts_email_created_at_idx" ON "public"."login_attempts" USING "btree" ("email", "created_at");


--
-- Name: login_attempts_ip_address_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "login_attempts_ip_address_created_at_idx" ON "public"."login_attempts" USING "btree" ("ip_address", "created_at");


--
-- Name: mmo_product_items_order_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_product_items_order_id_idx" ON "public"."mmo_product_items" USING "btree" ("order_id");


--
-- Name: mmo_product_items_product_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_product_items_product_id_status_idx" ON "public"."mmo_product_items" USING "btree" ("product_id", "status");


--
-- Name: mmo_product_items_product_id_value_hash_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "mmo_product_items_product_id_value_hash_key" ON "public"."mmo_product_items" USING "btree" ("product_id", "value_hash");


--
-- Name: mmo_products_category_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_products_category_idx" ON "public"."mmo_products" USING "btree" ("category");


--
-- Name: mmo_products_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_products_is_active_idx" ON "public"."mmo_products" USING "btree" ("is_active");


--
-- Name: mmo_products_section_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_products_section_idx" ON "public"."mmo_products" USING "btree" ("section");


--
-- Name: mmo_products_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "mmo_products_slug_idx" ON "public"."mmo_products" USING "btree" ("slug");


--
-- Name: mmo_products_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "mmo_products_slug_key" ON "public"."mmo_products" USING "btree" ("slug");


--
-- Name: modules_code_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "modules_code_idx" ON "public"."modules" USING "btree" ("code");


--
-- Name: modules_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "modules_code_key" ON "public"."modules" USING "btree" ("code");


--
-- Name: modules_sort_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "modules_sort_order_idx" ON "public"."modules" USING "btree" ("sort_order");


--
-- Name: notifications_user_id_is_read_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "notifications_user_id_is_read_created_at_idx" ON "public"."notifications" USING "btree" ("user_id", "is_read", "created_at");


--
-- Name: orders_idempotency_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "orders_idempotency_key_key" ON "public"."orders" USING "btree" ("idempotency_key");


--
-- Name: orders_order_code_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_order_code_idx" ON "public"."orders" USING "btree" ("order_code");


--
-- Name: orders_order_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "orders_order_code_key" ON "public"."orders" USING "btree" ("order_code");


--
-- Name: orders_order_type_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_order_type_idx" ON "public"."orders" USING "btree" ("order_type");


--
-- Name: orders_seller_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_seller_id_idx" ON "public"."orders" USING "btree" ("seller_id");


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_status_idx" ON "public"."orders" USING "btree" ("status");


--
-- Name: orders_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "orders_user_id_created_at_idx" ON "public"."orders" USING "btree" ("user_id", "created_at");


--
-- Name: otp_codes_email_purpose_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "otp_codes_email_purpose_idx" ON "public"."otp_codes" USING "btree" ("email", "purpose");


--
-- Name: otp_codes_expires_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "otp_codes_expires_at_idx" ON "public"."otp_codes" USING "btree" ("expires_at");


--
-- Name: page_permissions_role_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "page_permissions_role_idx" ON "public"."page_permissions" USING "btree" ("role");


--
-- Name: page_permissions_role_page_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "page_permissions_role_page_key_key" ON "public"."page_permissions" USING "btree" ("role", "page_key");


--
-- Name: pending_registrations_email_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "pending_registrations_email_key" ON "public"."pending_registrations" USING "btree" ("email");


--
-- Name: permissions_code_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "permissions_code_idx" ON "public"."permissions" USING "btree" ("code");


--
-- Name: permissions_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "permissions_code_key" ON "public"."permissions" USING "btree" ("code");


--
-- Name: permissions_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "permissions_is_active_idx" ON "public"."permissions" USING "btree" ("is_active");


--
-- Name: permissions_module_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "permissions_module_id_idx" ON "public"."permissions" USING "btree" ("module_id");


--
-- Name: public_page_configs_page_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "public_page_configs_page_key_key" ON "public"."public_page_configs" USING "btree" ("page_key");


--
-- Name: refresh_tokens_family_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "refresh_tokens_family_idx" ON "public"."refresh_tokens" USING "btree" ("family");


--
-- Name: refresh_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "refresh_tokens_token_hash_key" ON "public"."refresh_tokens" USING "btree" ("token_hash");


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "refresh_tokens_user_id_idx" ON "public"."refresh_tokens" USING "btree" ("user_id");


--
-- Name: resource_categories_name_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "resource_categories_name_idx" ON "public"."resource_categories" USING "btree" ("name");


--
-- Name: resource_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "resource_categories_name_key" ON "public"."resource_categories" USING "btree" ("name");


--
-- Name: reviews_product_type_product_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "reviews_product_type_product_id_idx" ON "public"."reviews" USING "btree" ("product_type", "product_id");


--
-- Name: reviews_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "reviews_user_id_idx" ON "public"."reviews" USING "btree" ("user_id");


--
-- Name: seller_product_stock_product_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_product_stock_product_id_status_idx" ON "public"."seller_product_stock" USING "btree" ("product_id", "status");


--
-- Name: seller_products_is_active_is_hidden_is_restricted_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_products_is_active_is_hidden_is_restricted_idx" ON "public"."seller_products" USING "btree" ("is_active", "is_hidden", "is_restricted");


--
-- Name: seller_products_seller_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_products_seller_id_idx" ON "public"."seller_products" USING "btree" ("seller_id");


--
-- Name: seller_products_sub_category_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_products_sub_category_id_idx" ON "public"."seller_products" USING "btree" ("sub_category_id");


--
-- Name: seller_requests_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_requests_status_idx" ON "public"."seller_requests" USING "btree" ("status");


--
-- Name: seller_requests_user_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "seller_requests_user_id_key" ON "public"."seller_requests" USING "btree" ("user_id");


--
-- Name: seller_sub_categories_category_name_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_sub_categories_category_name_is_active_idx" ON "public"."seller_sub_categories" USING "btree" ("category_name", "is_active");


--
-- Name: seller_sub_categories_category_name_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "seller_sub_categories_category_name_name_key" ON "public"."seller_sub_categories" USING "btree" ("category_name", "name");


--
-- Name: seller_tier_definitions_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_tier_definitions_is_active_display_order_idx" ON "public"."seller_tier_definitions" USING "btree" ("is_active", "display_order");


--
-- Name: seller_tier_definitions_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "seller_tier_definitions_key_key" ON "public"."seller_tier_definitions" USING "btree" ("key");


--
-- Name: seller_withdrawals_seller_id_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_withdrawals_seller_id_status_idx" ON "public"."seller_withdrawals" USING "btree" ("seller_id", "status");


--
-- Name: seller_withdrawals_status_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "seller_withdrawals_status_created_at_idx" ON "public"."seller_withdrawals" USING "btree" ("status", "created_at");


--
-- Name: service_categories_name_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "service_categories_name_idx" ON "public"."service_categories" USING "btree" ("name");


--
-- Name: service_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "service_categories_name_key" ON "public"."service_categories" USING "btree" ("name");


--
-- Name: services_category_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_category_idx" ON "public"."services" USING "btree" ("category");


--
-- Name: services_is_active_is_featured_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_is_active_is_featured_idx" ON "public"."services" USING "btree" ("is_active", "is_featured");


--
-- Name: services_platform_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_platform_idx" ON "public"."services" USING "btree" ("platform");


--
-- Name: services_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "services_slug_idx" ON "public"."services" USING "btree" ("slug");


--
-- Name: services_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "services_slug_key" ON "public"."services" USING "btree" ("slug");


--
-- Name: sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "sessions_expires_at_idx" ON "public"."sessions" USING "btree" ("expires_at");


--
-- Name: sessions_session_token_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "sessions_session_token_idx" ON "public"."sessions" USING "btree" ("session_token");


--
-- Name: sessions_session_token_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "sessions_session_token_key" ON "public"."sessions" USING "btree" ("session_token");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "sessions_user_id_idx" ON "public"."sessions" USING "btree" ("user_id");


--
-- Name: site_content_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "site_content_key_key" ON "public"."site_content" USING "btree" ("key");


--
-- Name: staff_permissions_permission_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "staff_permissions_permission_id_idx" ON "public"."staff_permissions" USING "btree" ("permission_id");


--
-- Name: staff_permissions_user_id_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "staff_permissions_user_id_idx" ON "public"."staff_permissions" USING "btree" ("user_id");


--
-- Name: testimonials_course_id_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "testimonials_course_id_is_active_idx" ON "public"."testimonials" USING "btree" ("course_id", "is_active");


--
-- Name: testimonials_service_id_is_active_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "testimonials_service_id_is_active_idx" ON "public"."testimonials" USING "btree" ("service_id", "is_active");


--
-- Name: testimonials_type_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "testimonials_type_is_active_display_order_idx" ON "public"."testimonials" USING "btree" ("type", "is_active", "display_order");


--
-- Name: ticker_notifications_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ticker_notifications_is_active_display_order_idx" ON "public"."ticker_notifications" USING "btree" ("is_active", "display_order");


--
-- Name: ticker_texts_is_active_display_order_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "ticker_texts_is_active_display_order_idx" ON "public"."ticker_texts" USING "btree" ("is_active", "display_order");


--
-- Name: transactions_reference_code_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "transactions_reference_code_idx" ON "public"."transactions" USING "btree" ("reference_code");


--
-- Name: transactions_reference_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "transactions_reference_code_key" ON "public"."transactions" USING "btree" ("reference_code");


--
-- Name: transactions_type_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "transactions_type_idx" ON "public"."transactions" USING "btree" ("type");


--
-- Name: transactions_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "transactions_user_id_created_at_idx" ON "public"."transactions" USING "btree" ("user_id", "created_at");


--
-- Name: tut_trick_categories_name_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_trick_categories_name_idx" ON "public"."tut_trick_categories" USING "btree" ("name");


--
-- Name: tut_trick_categories_name_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "tut_trick_categories_name_key" ON "public"."tut_trick_categories" USING "btree" ("name");


--
-- Name: tut_tricks_is_active_is_featured_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_tricks_is_active_is_featured_idx" ON "public"."tut_tricks" USING "btree" ("is_active", "is_featured");


--
-- Name: tut_tricks_platform_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_tricks_platform_idx" ON "public"."tut_tricks" USING "btree" ("platform");


--
-- Name: tut_tricks_slug_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "tut_tricks_slug_idx" ON "public"."tut_tricks" USING "btree" ("slug");


--
-- Name: tut_tricks_slug_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "tut_tricks_slug_key" ON "public"."tut_tricks" USING "btree" ("slug");


--
-- Name: unmatched_transfers_reference_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "unmatched_transfers_reference_code_key" ON "public"."unmatched_transfers" USING "btree" ("reference_code");


--
-- Name: unmatched_transfers_status_created_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "unmatched_transfers_status_created_at_idx" ON "public"."unmatched_transfers" USING "btree" ("status", "created_at");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_email_idx" ON "public"."users" USING "btree" ("email");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "users_email_key" ON "public"."users" USING "btree" ("email");


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_role_idx" ON "public"."users" USING "btree" ("role");


--
-- Name: users_seller_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_seller_status_idx" ON "public"."users" USING "btree" ("seller_status");


--
-- Name: users_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_status_idx" ON "public"."users" USING "btree" ("status");


--
-- Name: users_uid_prefix_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "users_uid_prefix_idx" ON "public"."users" USING "btree" ("uid_prefix");


--
-- Name: audit_logs audit_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."audit_logs"
    ADD CONSTRAINT "audit_logs_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bank_change_requests bank_change_requests_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."bank_change_requests"
    ADD CONSTRAINT "bank_change_requests_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_messages chat_messages_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "public"."chat_rooms"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_participants chat_participants_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_participants"
    ADD CONSTRAINT "chat_participants_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "public"."chat_rooms"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_participants chat_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_participants"
    ADD CONSTRAINT "chat_participants_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_rooms chat_rooms_complaint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."chat_rooms"
    ADD CONSTRAINT "chat_rooms_complaint_id_fkey" FOREIGN KEY ("complaint_id") REFERENCES "public"."complaints"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: complaints complaints_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."complaints"
    ADD CONSTRAINT "complaints_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: course_faq_categories course_faq_categories_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faq_categories"
    ADD CONSTRAINT "course_faq_categories_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: course_faqs course_faqs_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faqs"
    ADD CONSTRAINT "course_faqs_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."course_faq_categories"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: course_faqs course_faqs_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_faqs"
    ADD CONSTRAINT "course_faqs_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: course_support_items course_support_items_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."course_support_items"
    ADD CONSTRAINT "course_support_items_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: login_attempts login_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."login_attempts"
    ADD CONSTRAINT "login_attempts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: mmo_product_items mmo_product_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."mmo_product_items"
    ADD CONSTRAINT "mmo_product_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."mmo_products"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_mmo_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_mmo_product_id_fkey" FOREIGN KEY ("mmo_product_id") REFERENCES "public"."mmo_products"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_seller_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_seller_product_id_fkey" FOREIGN KEY ("seller_product_id") REFERENCES "public"."seller_products"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_service_id_fkey" FOREIGN KEY ("service_id") REFERENCES "public"."services"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tut_trick_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_tut_trick_id_fkey" FOREIGN KEY ("tut_trick_id") REFERENCES "public"."tut_tricks"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: permissions permissions_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."permissions"
    ADD CONSTRAINT "permissions_module_id_fkey" FOREIGN KEY ("module_id") REFERENCES "public"."modules"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reviews reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."reviews"
    ADD CONSTRAINT "reviews_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: seller_product_stock seller_product_stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_product_stock"
    ADD CONSTRAINT "seller_product_stock_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."seller_products"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_products seller_products_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_products"
    ADD CONSTRAINT "seller_products_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_products seller_products_sub_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_products"
    ADD CONSTRAINT "seller_products_sub_category_id_fkey" FOREIGN KEY ("sub_category_id") REFERENCES "public"."seller_sub_categories"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: seller_requests seller_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_requests"
    ADD CONSTRAINT "seller_requests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_sub_categories seller_sub_categories_category_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_sub_categories"
    ADD CONSTRAINT "seller_sub_categories_category_name_fkey" FOREIGN KEY ("category_name") REFERENCES "public"."resource_categories"("name") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seller_withdrawals seller_withdrawals_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."seller_withdrawals"
    ADD CONSTRAINT "seller_withdrawals_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: site_content site_content_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."site_content"
    ADD CONSTRAINT "site_content_updated_by_id_fkey" FOREIGN KEY ("updated_by_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: staff_permissions staff_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."staff_permissions"
    ADD CONSTRAINT "staff_permissions_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "public"."permissions"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: staff_permissions staff_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."staff_permissions"
    ADD CONSTRAINT "staff_permissions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: testimonials testimonials_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."testimonials"
    ADD CONSTRAINT "testimonials_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: testimonials testimonials_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."testimonials"
    ADD CONSTRAINT "testimonials_service_id_fkey" FOREIGN KEY ("service_id") REFERENCES "public"."services"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_sub_categories user_sub_categories_sub_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."user_sub_categories"
    ADD CONSTRAINT "user_sub_categories_sub_category_id_fkey" FOREIGN KEY ("sub_category_id") REFERENCES "public"."seller_sub_categories"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_sub_categories user_sub_categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY "public"."user_sub_categories"
    ADD CONSTRAINT "user_sub_categories_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: app_user
--

REVOKE USAGE ON SCHEMA "public" FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict wZWledRND31AmLVKCHgEmSt3lx2cXJECEf75gm9I7LkEaRANxjpIcoU60tiBWgw

